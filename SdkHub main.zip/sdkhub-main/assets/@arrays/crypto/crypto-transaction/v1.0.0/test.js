// Senior QA Engineer comprehensive tests for Company Crypto Transactions

function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
}

function testGetCompanyCryptoTransactions() {
    console.log('\n=== Testing getCompanyCryptoTransactions (Direct Function) ===');

    const { getCompanyCryptoTransactions } = require('@arrays/crypto/crypto-transaction:v1.0.0');

    const TX_TYPES = ['BORROW', 'BUY', 'DEPOSIT', 'LOAN', 'MINT', 'SELL', 'TRANSFER'];

    let totalTests = 0;
    let passedTests = 0;

    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    function extractTransactions(res) {
        if (res && res.response && Array.isArray(res.response.transactions)) return res.response.transactions;
        if (res && Array.isArray(res.transactions)) return res.transactions;
        if (res && res.result && Array.isArray(res.result.transactions)) return res.result.transactions;
        return [];
    }

    // ============ Happy Path Tests ============
    runTest('getCompanyCryptoTransactions with symbol + crypto_ticker', () => {
        const res = getCompanyCryptoTransactions({ symbol: 'MSTR', crypto_ticker: 'BTC' });
        assert(res && typeof res === 'object', 'Should return an object');
        const txs = extractTransactions(res);
        assert(Array.isArray(txs), 'Should contain transactions array');
        if (txs.length > 0) {
            const t = txs[0];
            assert(typeof t.id === 'number', 'transaction.id should be number');
            assert(typeof t.name === 'string', 'transaction.name should be string');
            assert(typeof t.symbol === 'string', 'transaction.symbol should be string');
            assert(typeof t.cik === 'string', 'transaction.cik should be string');
            assert(typeof t.filing_form === 'string', 'transaction.filing_form should be string');
            assert(typeof t.filing_date === 'string', 'transaction.filing_date should be string');
            assert(typeof t.accession_number === 'string', 'transaction.accession_number should be string');
            assert(typeof t.source_url === 'string', 'transaction.source_url should be string');
            assert(typeof t.transaction_type === 'string', 'transaction.transaction_type should be string');
            assert(typeof t.crypto_ticker === 'string', 'transaction.crypto_ticker should be string');
            if (t.transaction_date !== null) assert(typeof t.transaction_date === 'string', 'transaction_date should be string or null');
            if (t.amount !== null) assert(typeof t.amount === 'number', 'amount should be number or null');
            if (t.price_usd !== null) assert(typeof t.price_usd === 'number', 'price_usd should be number or null');
            if (t.total_value_usd !== null) assert(typeof t.total_value_usd === 'number', 'total_value_usd should be number or null');
            assert(typeof t.created_at === 'string', 'created_at should be string');
            assert(typeof t.updated_at === 'string', 'updated_at should be string');
        }
    });

    runTest('getCompanyCryptoTransactions with crypto_ticker only (BTC)', () => {
        const res = getCompanyCryptoTransactions({ crypto_ticker: 'BTC' });
        assert(res && typeof res === 'object', 'Should return an object');
        const txs = extractTransactions(res);
        assert(Array.isArray(txs), 'Should contain transactions array');
        if (txs.length > 0) {
            assert(txs.every(t => t.crypto_ticker === 'BTC'), 'All transactions should be BTC');
        }
    });

    runTest('getCompanyCryptoTransactions with crypto_ticker only (ETH)', () => {
        const res = getCompanyCryptoTransactions({ crypto_ticker: 'ETH' });
        assert(res && typeof res === 'object', 'Should return an object');
        const txs = extractTransactions(res);
        assert(Array.isArray(txs), 'Should contain transactions array');
        if (txs.length > 0) {
            assert(txs.every(t => t.crypto_ticker === 'ETH'), 'All transactions should be ETH');
        }
    });

    runTest('getCompanyCryptoTransactions with symbol only', () => {
        const res = getCompanyCryptoTransactions({ symbol: 'MSTR' });
        assert(res && typeof res === 'object', 'Should return an object');
        const txs = extractTransactions(res);
        assert(Array.isArray(txs), 'Should contain transactions array');
        if (txs.length > 0) {
            assert(txs.every(t => t.symbol === 'MSTR'), 'All transactions should be for MSTR');
        }
    });

    runTest('getCompanyCryptoTransactions with all filters (MSTR, BTC, BUY)', () => {
        const res = getCompanyCryptoTransactions({ symbol: 'MSTR', crypto_ticker: 'BTC', transaction_type: 'BUY' });
        assert(res && typeof res === 'object', 'Should return an object');
        const txs = extractTransactions(res);
        assert(Array.isArray(txs), 'Should contain transactions array');
        if (txs.length > 0) {
            assert(txs.every(t => t.symbol === 'MSTR'), 'All transactions should match symbol');
            assert(txs.every(t => t.crypto_ticker === 'BTC'), 'All transactions should match crypto_ticker');
            assert(txs.every(t => t.transaction_type === 'BUY'), 'All transactions should match transaction_type');
        }
    });

    // ============ Enumeration Coverage for transaction_type ============
    for (const txType of TX_TYPES) {
        runTest(`getCompanyCryptoTransactions transaction_type=${txType}`, () => {
            const res = getCompanyCryptoTransactions({ crypto_ticker: 'BTC', transaction_type: txType });
            assert(res && typeof res === 'object', 'Should return an object');
            const txs = extractTransactions(res);
            assert(Array.isArray(txs), 'Should contain transactions array');
            if (txs.length > 0) {
                assert(txs.every(t => t.transaction_type === txType), `All transactions should have type ${txType}`);
                assert(txs.every(t => t.crypto_ticker === 'BTC'), 'All transactions should be BTC');
            }
        });
    }

    // ============ Boundary and Special Value Tests ============
    runTest('getCompanyCryptoTransactions with no params', () => {
        const res = getCompanyCryptoTransactions();
        assert(res && typeof res === 'object', 'Should return an object when called without params');
        const txs = extractTransactions(res);
        assert(Array.isArray(txs), 'Should contain transactions array even without filters');
    });

    runTest('transaction_type undefined (treated as no filter)', () => {
        const res = getCompanyCryptoTransactions({ symbol: 'MSTR', crypto_ticker: 'BTC', transaction_type: undefined });
        assert(res && typeof res === 'object', 'Should return an object');
        const txs = extractTransactions(res);
        assert(Array.isArray(txs), 'Should contain transactions array');
    });

    runTest('transaction_type null (treated as no filter)', () => {
        const res = getCompanyCryptoTransactions({ symbol: 'MSTR', crypto_ticker: 'BTC', transaction_type: null });
        assert(res && typeof res === 'object', 'Should return an object');
        const txs = extractTransactions(res);
        assert(Array.isArray(txs), 'Should contain transactions array');
    });

    runTest('invalid transaction_type should error or return empty', () => {
        try {
            const res = getCompanyCryptoTransactions({ crypto_ticker: 'BTC', transaction_type: 'INVALID' });
            const txs = extractTransactions(res);
            assert(Array.isArray(txs) && txs.length === 0, 'Should return empty transactions for invalid transaction_type');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid') || e.message.includes('invalid'), 'Should handle invalid transaction_type');
        }
    });

    runTest('invalid crypto_ticker should error or return empty', () => {
        try {
            const res = getCompanyCryptoTransactions({ crypto_ticker: 'ZZZ' });
            const txs = extractTransactions(res);
            assert(Array.isArray(txs) && txs.length === 0, 'Should return empty transactions for invalid crypto_ticker');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid') || e.message.includes('invalid'), 'Should handle invalid crypto_ticker');
        }
    });

    runTest('invalid symbol should error or return empty', () => {
        try {
            const res = getCompanyCryptoTransactions({ symbol: 'INVALID' });
            const txs = extractTransactions(res);
            assert(Array.isArray(txs) && txs.length === 0, 'Should return empty transactions for invalid symbol');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid') || e.message.includes('invalid'), 'Should handle invalid symbol');
        }
    });

    runTest('empty string symbol should error or return empty', () => {
        try {
            const res = getCompanyCryptoTransactions({ symbol: '' });
            const txs = extractTransactions(res);
            assert(Array.isArray(txs) && txs.length === 0, 'Should return empty transactions for empty symbol');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('empty') || e.message.includes('invalid'), 'Should handle empty string symbol');
        }
    });

    runTest('empty string crypto_ticker should error or return empty', () => {
        try {
            const res = getCompanyCryptoTransactions({ crypto_ticker: '' });
            const txs = extractTransactions(res);
            assert(Array.isArray(txs) && txs.length === 0, 'Should return empty transactions for empty crypto_ticker');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('empty') || e.message.includes('invalid'), 'Should handle empty string crypto_ticker');
        }
    });

    console.log('\n=== getCompanyCryptoTransactions Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    if (passedTests === totalTests) {
        console.log('🎉 All direct getCompanyCryptoTransactions tests passed!');
    } else {
        console.log('⚠️  Some direct tests failed. Please review the output above.');
    }
}

function testNodeIntegration() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeCompanyCryptoTransactionsNode } = require('@arrays/crypto/crypto-transaction:v1.0.0');

    const graph = new Graph(jagentId);
    graph.addNode(
        'crypto_transactions',
        makeCompanyCryptoTransactionsNode({
            symbol: 'MSTR',
            crypto_ticker: 'BTC',
        })
    );

    graph.run();

    // Validate refs for output crypto_transactions
    const refsCryptoTx = graph.getRefsForOutput('crypto_transactions', 'crypto_transactions');
    if (refsCryptoTx.length > 0) {
        const ref = refsCryptoTx[0];
        const expected = {
            id: '@arrays/crypto/crypto-transaction/getCompanyCryptoTransactions',
            module_name: '@arrays/crypto/crypto-transaction',
            module_display_name: 'Crypto: Company Crypto Transactions',
            sdk_name: 'getCompanyCryptoTransactions',
            sdk_display_name: 'Company Crypto Transactions',
            source_name: 'SEC Edgar API',
            source: 'https://www.sec.gov/search-filings/edgar-application-programming-interfaces',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for crypto_transactions');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for crypto_transactions');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for crypto_transactions');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for crypto_transactions');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for crypto_transactions');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for crypto_transactions');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for crypto_transactions');
        log('✓ crypto_transactions refs validated');
    } else {
        throw new Error('Assertion failed: refsCryptoTx array is empty.');
    }

    // Materialize and validate the crypto transactions output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'crypto_transactions', 'crypto_transactions', { last: '10' }), graph.store);
    ts.init();

    if (!Array.isArray(ts.data)) {
        throw new Error('Expected crypto transactions data to be an array');
    }

    if (ts.data.length > 0) {
        const record = ts.data[0];

        // Validate record structure
        if (typeof record.date !== 'number') {
            throw new Error('Expected record.date to be a number (timestamp in ms)');
        }

        if (typeof record.total_count !== 'number') {
            throw new Error('Expected record.total_count to be a number');
        }

        if (!Array.isArray(record.transactions)) {
            throw new Error('Expected record.transactions to be an array');
        }

        // Validate transaction fields if any exist
        if (record.transactions.length > 0) {
            const transaction = record.transactions[0];

            if (typeof transaction.id !== 'number') {
                throw new Error('Expected transaction.id to be a number');
            }

            if (typeof transaction.name !== 'string') {
                throw new Error('Expected transaction.name to be a string');
            }

            if (typeof transaction.symbol !== 'string') {
                throw new Error('Expected transaction.symbol to be a string');
            }

            if (typeof transaction.cik !== 'string') {
                throw new Error('Expected transaction.cik to be a string');
            }

            if (typeof transaction.filing_form !== 'string') {
                throw new Error('Expected transaction.filing_form to be a string');
            }

            if (typeof transaction.filing_date !== 'string') {
                throw new Error('Expected transaction.filing_date to be a string');
            }

            if (typeof transaction.accession_number !== 'string') {
                throw new Error('Expected transaction.accession_number to be a string');
            }

            if (typeof transaction.source_url !== 'string') {
                throw new Error('Expected transaction.source_url to be a string');
            }

            if (typeof transaction.transaction_type !== 'string') {
                throw new Error('Expected transaction.transaction_type to be a string');
            }

            if (typeof transaction.crypto_ticker !== 'string') {
                throw new Error('Expected transaction.crypto_ticker to be a string');
            }

            // Optional fields can be null or their specific type
            if (transaction.transaction_date !== null && typeof transaction.transaction_date !== 'string') {
                throw new Error('Expected transaction.transaction_date to be a string or null');
            }

            if (transaction.amount !== null && typeof transaction.amount !== 'number') {
                throw new Error('Expected transaction.amount to be a number or null');
            }

            if (transaction.price_usd !== null && typeof transaction.price_usd !== 'number') {
                throw new Error('Expected transaction.price_usd to be a number or null');
            }

            if (transaction.total_value_usd !== null && typeof transaction.total_value_usd !== 'number') {
                throw new Error('Expected transaction.total_value_usd to be a number or null');
            }

            if (typeof transaction.created_at !== 'string') {
                throw new Error('Expected transaction.created_at to be a string');
            }

            if (typeof transaction.updated_at !== 'string') {
                throw new Error('Expected transaction.updated_at to be a string');
            }

            log(`✅ Crypto transactions validation passed: ${record.total_count} transactions found`);
            log(`   Example: ${transaction.name} (${transaction.symbol}) - ${transaction.transaction_type} ${transaction.crypto_ticker}`);
        }

        log(`   Snapshot time: ${new Date(record.date).toISOString()}`);
        log(`   Structure validated: single record with nested transactions array`);
    }

    log('✅ Company Crypto Transactions make*Node tests passed');
}

function main() {
    // 1) Direct get* API tests with enumeration coverage and boundary/special values
    testGetCompanyCryptoTransactions();

    // 2) Existing node integration tests
    testNodeIntegration();

    return 0;
}

main();
