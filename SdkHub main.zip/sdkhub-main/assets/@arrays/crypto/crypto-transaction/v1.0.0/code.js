const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for this module's SDK function and data source
const getCompanyCryptoTransactionsRef = {
    id: '@arrays/crypto/crypto-transaction/getCompanyCryptoTransactions',
    module_name: '@arrays/crypto/crypto-transaction',
    module_display_name: 'Crypto: Company Crypto Transactions',
    sdk_name: 'getCompanyCryptoTransactions',
    sdk_display_name: 'Company Crypto Transactions',
    source_name: 'SEC Edgar API',
    source: 'https://www.sec.gov/search-filings/edgar-application-programming-interfaces',
};

// Internal description strings and builders (not exported)
// Summary (baseFuncDesc): Retrieves cryptocurrency transactions from SEC filings for public companies.
const baseGetCompanyCryptoTransactionsDesc = 'Retrieve company crypto transactions from SEC filings';

function buildGetCompanyCryptoTransactionsCallDescription(actualParams = {}) {
    const parts = [baseGetCompanyCryptoTransactionsDesc];

    const filters = [];
    // Company stock symbol (uppercase, e.g., MSTR)
    if (actualParams.symbol) {
        filters.push(`Symbol: ${actualParams.symbol}`);
    }
    // Cryptocurrency ticker (uppercase, e.g., BTC)
    if (actualParams.crypto_ticker) {
        filters.push(`Crypto: ${actualParams.crypto_ticker}`);
    }
    // Transaction type (BORROW, BUY, DEPOSIT, LOAN, MINT, SELL, TRANSFER)
    if (actualParams.transaction_type) {
        filters.push(`Type: ${actualParams.transaction_type}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getCompanyCryptoTransactions(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/tokens/crypto-transactions';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function toNumber(value) {
    if (value == null || value === '') {
        return null;
    }
    const num = Number(value);
    return Number.isNaN(num) ? null : num;
}

function makeCompanyCryptoTransactionsNode(params) {
    return {
        inputs: {
            crypto_tx_raw: () => getCompanyCryptoTransactions(params),
        },
        outputs: {
            crypto_transactions: {
                name: 'crypto_transactions',
                description: 'Company cryptocurrency transactions from SEC filings.',
                fields: [
                    { name: 'date', type: 'number', description: 'snapshot time in ms since epoch (UTC)' },
                    { name: 'total_count', type: 'number', description: 'total number of transactions' },
                    {
                        name: 'transactions',
                        type: 'array',
                        description: 'all cryptocurrency transactions',
                        fields: [
                            { name: 'id', type: 'number', description: 'unique transaction ID' },
                            { name: 'name', type: 'string', description: 'company name' },
                            { name: 'symbol', type: 'string', description: 'stock symbol' },
                            { name: 'cik', type: 'string', description: 'CIK number' },
                            { name: 'filing_form', type: 'string', description: 'SEC filing form type' },
                            { name: 'filing_date', type: 'string', description: 'filing date' },
                            { name: 'accession_number', type: 'string', description: 'SEC accession number' },
                            { name: 'source_url', type: 'string', description: 'link to SEC filing' },
                            { name: 'transaction_type', type: 'string', description: 'transaction type (BUY/SELL/TRANSFER/MINT/DEPOSIT)' },
                            { name: 'crypto_ticker', type: 'string', description: 'cryptocurrency ticker symbol' },
                            { name: 'transaction_date', type: 'string', description: 'transaction date' },
                            { name: 'amount', type: 'number', description: 'amount of cryptocurrency' },
                            { name: 'price_usd', type: 'number', description: 'price per unit in USD' },
                            { name: 'total_value_usd', type: 'number', description: 'total transaction value in USD' },
                            { name: 'created_at', type: 'string', description: 'record creation timestamp' },
                            { name: 'updated_at', type: 'string', description: 'record update timestamp' },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(
                    getCompanyCryptoTransactionsRef,
                    params,
                    buildGetCompanyCryptoTransactionsCallDescription
                ),
            },
        },
        run: (inputs) => {
            const raw = inputs.crypto_tx_raw;

            if (raw?.error) {
                throw new Error(`API Error: ${raw.error.message || 'Unknown error'}`);
            }

            if (!raw?.response?.transactions) {
                return { crypto_transactions: [] };
            }

            if (!Array.isArray(raw.response.transactions)) {
                throw new Error('Invalid API response: transactions is not an array');
            }

            // Use snapshot time for the single record
            const snapshotTime = Date.now();

            // Normalize transactions into nested array
            const normalizedTransactions = raw.response.transactions.map((item) => ({
                id: item.id,
                name: item.name,
                symbol: item.symbol,
                cik: item.cik,
                filing_form: item.filing_form,
                filing_date: item.filing_date,
                accession_number: item.accession_number,
                source_url: item.source_url,
                transaction_type: item.transaction_type,
                crypto_ticker: item.crypto_ticker,
                transaction_date: item.transaction_date,
                amount: toNumber(item.amount),
                price_usd: toNumber(item.price_usd),
                total_value_usd: toNumber(item.total_value_usd),
                created_at: item.created_at,
                updated_at: item.updated_at,
            }));

            // Return a single record with nested array
            return {
                crypto_transactions: [{
                    date: snapshotTime,
                    total_count: normalizedTransactions.length,
                    transactions: normalizedTransactions
                }]
            };
        },
    };
}

function makeCompanyCryptoTransactionsDataNode(params) {
    return makeCompanyCryptoTransactionsNode(params);
}

function getRefs() {
    return [
        getCompanyCryptoTransactionsRef,
    ];
}

module.exports = {
    getCompanyCryptoTransactions,
    makeCompanyCryptoTransactionsNode,
    makeCompanyCryptoTransactionsDataNode,
    getRefs,
};
