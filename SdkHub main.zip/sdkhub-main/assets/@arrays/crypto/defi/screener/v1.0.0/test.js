function testGetDeFiPoolsListDirect() {
    console.log('\n=== Testing getDeFiPoolsList (Direct) ===');

    // Manual import for get* function per instruction
    const { getDeFiPoolsList } = require('@arrays/crypto/defi/screener:v1.0.0');

    // Simple assert helper
    const assert = (cond, msg) => {
        if (!cond) throw new Error(msg || 'Assertion failed');
    };

    let totalTests = 0;
    let passedTests = 0;

    function runTest(name, fn) {
        totalTests++;
        try {
            fn();
            console.log(`✅ ${name}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${name}: ${e.message}`);
        }
    }

    // Enumerated protocols coverage (from examples/docs)
    const PROTOCOLS = ['uniswap-v3', 'uniswap-v4', 'lido', 'lynex-v2'];

    // ============ Happy Path Tests ============
    for (const p of PROTOCOLS) {
        runTest(`getDeFiPoolsList - single protocol ${p}`, () => {
            const res = getDeFiPoolsList({ protocols: [p], min_avg_apy: 0, min_avg_tvl: 0 });
            assert(res && typeof res === 'object', 'Should return an object');
            assert(typeof res.count === 'number', 'count should be a number');
            assert(Array.isArray(res.results), 'results should be an array');
            if (res.results.length > 0) {
                const item = res.results[0];
                ['pool_id', 'protocol', 'pool_name', 'pool_url', 'chain_name', 'avg_apy', 'avg_tvl'].forEach((k) => {
                    assert(k in item, `missing field in pool result: ${k}`);
                });
            }
        });
    }

    runTest('getDeFiPoolsList - multiple protocols happy path', () => {
        const res = getDeFiPoolsList({
            protocols: PROTOCOLS,
            min_avg_apy: 10,
            min_avg_tvl: 0,
        });
        assert(res && typeof res === 'object', 'Should return an object');
        assert(typeof res.count === 'number', 'count should be a number');
        assert(Array.isArray(res.results), 'results should be an array');
    });

    runTest('getDeFiPoolsList - RFC3339 timestamps provided', () => {
        const params = {
            from_ts: '2025-07-01T23:59:59Z',
            to_ts: '2025-07-02T23:59:59Z',
            protocols: PROTOCOLS.slice(0, 2),
            min_avg_apy: 0,
            min_avg_tvl: 0,
        };
        const res = getDeFiPoolsList(params);
        assert(res && typeof res === 'object', 'Should return an object with timestamps applied');
        if (res.filters) {
            assert(typeof res.filters.from_ts === 'string', 'filters.from_ts should be string');
            assert(typeof res.filters.to_ts === 'string', 'filters.to_ts should be string');
        }
    });

    // ============ Boundary Value Analysis ============
    runTest('Boundary: min_avg_apy = 0', () => {
        const res = getDeFiPoolsList({ protocols: [PROTOCOLS[0]], min_avg_apy: 0, min_avg_tvl: 0 });
        assert(res && typeof res === 'object', 'Should return object with min_avg_apy=0');
    });

    runTest('Boundary: min_avg_apy = very high', () => {
        const res = getDeFiPoolsList({ protocols: [PROTOCOLS[0]], min_avg_apy: 100000, min_avg_tvl: 0 });
        assert(res && typeof res === 'object', 'Should return object even for extreme APY');
        assert(typeof res.count === 'number', 'count is number');
        assert(Array.isArray(res.results), 'results array exists');
    });

    runTest('Boundary: min_avg_tvl = 0', () => {
        const res = getDeFiPoolsList({ protocols: [PROTOCOLS[1]], min_avg_apy: 0, min_avg_tvl: 0 });
        assert(res && typeof res === 'object', 'Should return object with min_avg_tvl=0');
    });

    runTest('Boundary: min_avg_tvl = very high', () => {
        const res = getDeFiPoolsList({ protocols: [PROTOCOLS[1]], min_avg_apy: 0, min_avg_tvl: 1e12 });
        assert(res && typeof res === 'object', 'Should return object even for extreme TVL');
        assert(typeof res.count === 'number', 'count is number');
        assert(Array.isArray(res.results), 'results array exists');
    });

    // ============ Special Values ============
    runTest('Special: empty protocols array (no protocol filter)', () => {
        const res = getDeFiPoolsList({ protocols: [], min_avg_apy: 0, min_avg_tvl: 0 });
        assert(res && typeof res === 'object', 'Should return object with empty protocols filter');
    });

    runTest('Special: undefined params object', () => {
        const res = getDeFiPoolsList({});
        assert(res && typeof res === 'object', 'Should return object when called with empty params');
    });

    runTest('Special: null fields for optional params', () => {
        const res = getDeFiPoolsList({ protocols: null, min_avg_apy: null, min_avg_tvl: null });
        assert(res && typeof res === 'object', 'Should gracefully handle null optional fields');
    });

    // ============ Error Handling ============
    runTest('Error: invalid protocol value', () => {
        try {
            getDeFiPoolsList({ protocols: ['invalid-protocol'], min_avg_apy: 0, min_avg_tvl: 0 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            const msg = (e && e.message) || '';
            assert(/error|invalid|unsupported|protocol/i.test(msg), 'Should handle invalid protocol');
        }
    });

    runTest('Error: protocols not an array', () => {
        try {
            // @ts-ignore - intentional bad type for testing
            getDeFiPoolsList({ protocols: 'uniswap-v3', min_avg_apy: 0, min_avg_tvl: 0 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            const msg = (e && e.message) || '';
            assert(/error|invalid|array|unsupported|protocol/i.test(msg), 'Should handle non-array protocols type');
        }
    });

    runTest('Error: invalid RFC3339 timestamp format', () => {
        try {
            getDeFiPoolsList({ from_ts: 'not-a-date', to_ts: 'also-bad', min_avg_apy: 0, min_avg_tvl: 0 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            const msg = (e && e.message) || '';
            assert(/error|invalid|date|time|rfc/i.test(msg), 'Should handle invalid timestamp');
        }
    });

    console.log('\n=== getDeFiPoolsList Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
}

function main() {
    // Run direct function tests first
    testGetDeFiPoolsListDirect();

    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeDeFiPoolsListNode } = require('@arrays/crypto/defi/screener:v1.0.0');

    // Smoke test - basic functionality test
    const g = new Graph(jagentId);
    g.addNode(
        'defi_pools_smoke',
        makeDeFiPoolsListNode({
            protocols: ['uniswap-v3'],
            min_avg_apy: 10,
            min_avg_tvl: 45825000,
        })
    );
    g.run();

    // Mock test - using sample data to avoid network dependency
    const nodeCfg = makeDeFiPoolsListNode({
        protocols: ['uniswap-v3', 'uniswap-v4', 'lido', 'lynex-v2'],
        min_avg_apy: 10,
        min_avg_tvl: 0,
    });

    // Override input with mock data that matches the API response structure
    nodeCfg.inputs.de_fi_pools_list_raw = () => ({
        count: 744,
        filters: {
            from_ts: '2025-08-01T23:59:59Z',
            min_avg_apy: 10,
            min_avg_tvl: 0,
            protocols: ['uniswap-v3', 'uniswap-v4', 'lido', 'lynex-v2'],
            to_ts: '2025-08-02T23:59:59Z',
        },
        results: [
            {
                avg_apy: 1089.05371,
                avg_tvl: 335493,
                chain_name: 'Base',
                fee_tier: '0.3%',
                pool_id: 'b52515ba-fa64-4af2-9123-df0246b5115e',
                pool_name: 'CLANKER-WETH',
                pool_url: 'https://app.uniswap.org/#/add/0x1bc0c42215582d5a085795f4badbac3ff36d1bcb/0x4200000000000000000000000000000000000006/3000?chain=base',
                protocol: 'uniswap-v3',
            },
            {
                avg_apy: 949.4969,
                avg_tvl: 1377321,
                chain_name: 'Base',
                fee_tier: '0.3%',
                pool_id: '438b0229-b9ce-4e98-9b8d-e9527c61aff3',
                pool_name: 'ZORA-WETH',
                pool_url: 'https://app.uniswap.org/#/add/0x1111111111166b7fe7bd91427724b487980afc69/0x4200000000000000000000000000000000000006/3000?chain=base',
                protocol: 'uniswap-v3',
            },
            {
                avg_apy: 874.07085,
                avg_tvl: 10014,
                chain_name: 'Ethereum',
                fee_tier: '1%',
                pool_id: '2b53e332-3ad2-4307-bc32-54ed412c1652',
                pool_name: 'MEME-WETH',
                pool_url: 'https://app.uniswap.org/#/add/0xb131f4a55907b10d1f0a50d8ab8fa09ec342cd74/0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2/10000?chain=mainnet',
                protocol: 'uniswap-v3',
            },
        ],
    });

    const g2 = new Graph(jagentId);
    g2.addNode('defi_pools_mock', nodeCfg);
    g2.run();

    // Validate mock data output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'defi_pools_mock', 'defi_pools_snapshot', { last: '5' }), g2.store);
    ts.init();

    if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('snapshot empty');
    const snap = ts.data[0];
    ['date', 'count', 'filters', 'pools'].forEach((k) => {
        if (!(k in snap)) throw new Error('missing snapshot field: ' + k);
    });
    if (!Array.isArray(snap.pools) || snap.pools.length !== 3) throw new Error('pools length must be 3 in mock');

    const p0 = snap.pools[0];
    ['pool_id', 'protocol', 'pool_name', 'chain_name', 'avg_apy', 'avg_tvl', 'pool_url', 'fee_tier'].forEach((k) => {
        if (!(k in p0)) throw new Error('missing pool field: ' + k);
    });

    // Validate smoke test output
    const tsSmoke = new TimeSeries(new TimeSeriesUri(jagentId, 'defi_pools_smoke', 'defi_pools_snapshot', { last: '5' }), g.store);
    tsSmoke.init();
    if (!Array.isArray(tsSmoke.data)) throw new Error('smoke test data must be an array');
    if (tsSmoke.data.length > 0) {
        const r = tsSmoke.data[0];
        if (typeof r.date !== 'number') throw new Error('smoke.date must be number(ms)');
        if (!Array.isArray(r.pools)) throw new Error('smoke.pools must be array');
        if (r.pools.length > 0) {
            const pool = r.pools[0];
            if (typeof pool.pool_id !== 'string') throw new Error('smoke.pools.pool_id must be string');
        }
    }

    // Validate refs for outputs that have associated Ref metadata
    // getDeFiPoolsListRef for output 'defi_pools_snapshot'
    const refsDefiPools = g2.getRefsForOutput('defi_pools_mock', 'defi_pools_snapshot');
    if (refsDefiPools.length > 0) {
        const ref = refsDefiPools[0];
        const expected = {
            id: '@arrays/crypto/defi/screener/getDeFiPoolsList',
            module_name: '@arrays/crypto/defi/screener',
            module_display_name: 'DeFi Screener',
            sdk_name: 'getDeFiPoolsList',
            sdk_display_name: 'DeFi Pool Screener',
            source_name: 'defillama, uniswap-v4, pancakeswap, hyperliquid',
            source: 'https://app.uniswap.org/explore/pools, https://yields.llama.fi/pools, https://stats-data.hyperliquid.xyz/Mainnet/vaults',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for defi_pools_snapshot');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for defi_pools_snapshot');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for defi_pools_snapshot');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for defi_pools_snapshot');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for defi_pools_snapshot');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for defi_pools_snapshot');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for defi_pools_snapshot');
        console.log('✓ defi_pools_snapshot refs validated');
    } else {
        throw new Error('Assertion failed: refsDefiPools array is empty.');
    }

    return 0;
}

main();
