const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getDeFiPoolsList(params) {
    const { syncFetch: fetch } = require('net/http');

    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/tokens/defi_pools/list';

    const fetchOptions = {
        method: 'POST',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(params || {}),
    };

    const r = fetch(baseUrl, fetchOptions);
    return r.json();
}

/**
 * Parse various timestamp string formats to epoch ms (UTC).
 * Supported:
 * - ISO 8601 strings parsable by Date.parse
 * - 'YYYY-MM-DD HH:mm:ss'
 * - 'YYYY-MM-DD'
 * - 'MM-DD-YYYY' or 'MM/DD/YYYY'
 */
function parseToMs(s) {
    if (s == null) return undefined;
    if (typeof s !== 'string') return undefined;

    // Try native Date.parse first (handles many ISO variants)
    const parsed = Date.parse(s);
    if (!Number.isNaN(parsed)) return parsed;

    // 'YYYY-MM-DD HH:mm:ss'
    let m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/);
    if (m) {
        const y = +m[1];
        const mo = +m[2] - 1;
        const d = +m[3];
        const hh = +m[4];
        const mm = +m[5];
        const ss = +m[6];
        return Date.UTC(y, mo, d, hh, mm, ss, 0);
    }

    // 'YYYY-MM-DD'
    m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (m) {
        const y = +m[1];
        const mo = +m[2] - 1;
        const d = +m[3];
        return Date.UTC(y, mo, d, 0, 0, 0, 0);
    }

    // 'MM-DD-YYYY' or 'MM/DD/YYYY'
    m = s.match(/^(\d{2})[-\/](\d{2})[-\/](\d{4})$/);
    if (m) {
        const mo = +m[1] - 1;
        const d = +m[2];
        const y = +m[3];
        return Date.UTC(y, mo, d, 0, 0, 0, 0);
    }

    return undefined;
}

// ===== Internal description helpers (do not export) =====
// Base description summary derived from doc for getDeFiPoolsList
const getDeFiPoolsListBaseDesc = "Get filtered DeFi pools";

function buildGetDeFiPoolsListCallDescription(actualParams = {}) {
    const parts = [getDeFiPoolsListBaseDesc];

    const filters = [];
    const { from_ts, to_ts, protocols, min_avg_apy, min_avg_tvl } = actualParams || {};

    if (from_ts && to_ts) {
        filters.push(`Time: ${from_ts} to ${to_ts}`);
    } else if (from_ts) {
        filters.push(`Time from: ${from_ts}`);
    } else if (to_ts) {
        filters.push(`Time to: ${to_ts}`);
    }

    if (Array.isArray(protocols) && protocols.length > 0) {
        filters.push(`Protocols: ${protocols.join(', ')}`);
    }

    if (typeof min_avg_apy === 'number') {
        filters.push(`Min APY: ${min_avg_apy}%`);
    }

    if (typeof min_avg_tvl === 'number') {
        filters.push(`Min TVL: ${min_avg_tvl}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

// Reference metadata for getDeFiPoolsList following the standard pattern
const getDeFiPoolsListRef = {
    id: "@arrays/crypto/defi/screener/getDeFiPoolsList",
    module_name: "@arrays/crypto/defi/screener",
    module_display_name: "DeFi Screener",
    sdk_name: "getDeFiPoolsList",
    sdk_display_name: "DeFi Pool Screener",
    source_name: "defillama, uniswap-v4, pancakeswap, hyperliquid",
    source: "https://app.uniswap.org/explore/pools, https://yields.llama.fi/pools, https://stats-data.hyperliquid.xyz/Mainnet/vaults",
};

function makeDeFiPoolsListNode(params) {
    return {
        inputs: {
            de_fi_pools_list_raw: () => getDeFiPoolsList(params),
        },
        outputs: {
            defi_pools_snapshot: {
                name: 'defi_pools_snapshot',
                description: 'Single snapshot with all DeFi pools data',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'snapshot time in ms since epoch (UTC), derived from to_ts (interval end time)',
                    },
                    {
                        name: 'count',
                        type: 'number',
                        description: 'number of pools in this snapshot',
                    },
                    {
                        name: 'filters',
                        type: 'object',
                        description: 'effective filters applied to the query',
                        fields: [
                            {
                                name: 'from_ts',
                                type: 'string',
                                description: 'RFC3339 earliest time (if provided)',
                            },
                            {
                                name: 'to_ts',
                                type: 'string',
                                description: 'RFC3339 latest time (if provided)',
                            },
                            {
                                name: 'protocols',
                                type: 'array',
                                description: 'protocol identifiers',
                                fields: [
                                    {
                                        name: 'value',
                                        type: 'string',
                                        description: 'protocol identifier',
                                    },
                                ],
                            },
                            {
                                name: 'min_avg_apy',
                                type: 'number',
                                description: 'minimum average APY filter (if provided)',
                            },
                            {
                                name: 'min_avg_tvl',
                                type: 'number',
                                description: 'minimum average TVL filter (if provided)',
                            },
                        ],
                    },
                    {
                        name: 'pools',
                        type: 'array',
                        description: 'the pools returned in this snapshot',
                        fields: [
                            { name: 'pool_id', type: 'string', description: 'unique pool identifier' },
                            { name: 'protocol', type: 'string', description: 'protocol identifier' },
                            { name: 'pool_name', type: 'string', description: 'pool name' },
                            { name: 'chain_name', type: 'string', description: 'blockchain name' },
                            { name: 'avg_apy', type: 'number', description: 'average APY percentage' },
                            { name: 'avg_tvl', type: 'number', description: 'average TVL USD' },
                            { name: 'pool_url', type: 'string', description: 'pool dashboard URL' },
                            { name: 'fee_tier', type: 'string', description: 'fee tier for the pool' },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getDeFiPoolsListRef, params, buildGetDeFiPoolsListCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.de_fi_pools_list_raw;

            // 兼容 {success, response:{data}} 和 {data:{data}} 两种结构
            const poolsArr = Array.isArray(raw?.results) ? raw.results : [];
            if (poolsArr.length === 0) {
                // 没有数据就不追加
                return undefined;
            }

            // 1) 选定一个确定时间 - 使用 to_ts 作为区间结束时间，如果无效则使用当前时间
            const filters = raw?.filters || {};
            let snapshotTime = parseToMs(filters.to_ts);
            if (!Number.isFinite(snapshotTime)) {
                snapshotTime = Date.now();
            }

            const count = raw.count || poolsArr.length;

            // 2) Map all pools into the nested array
            const poolsData = poolsArr.map((pool) => ({
                pool_id: pool.pool_id,
                protocol: pool.protocol,
                pool_name: pool.pool_name,
                chain_name: pool.chain_name,
                avg_apy: pool.avg_apy,
                avg_tvl: pool.avg_tvl,
                pool_url: pool.pool_url,
                fee_tier: pool.fee_tier,
            }));

            // 可选：排序，便于下游一致性
            poolsData.sort((a, b) => {
                if (b.avg_apy !== a.avg_apy) return b.avg_apy - a.avg_apy;
                return (a.pool_name || '').localeCompare(b.pool_name || '');
            });

            // 3) 返回单条快照（外层唯一 date，内层嵌套数组）
            return {
                defi_pools_snapshot: [
                    {
                        date: snapshotTime,
                        count,
                        filters,
                        pools: poolsData,
                    },
                ],
            };
        },
    };
}

function getRefs() {
    return [
        getDeFiPoolsListRef,
    ];
}

module.exports = {
    getDeFiPoolsList,
    makeDeFiPoolsListNode,
    getRefs,
};
