const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getCryptoHoldingsData
// Following the learned pattern, the id must be ModuleName + function name
const getCryptoHoldingsDataRef = {
  id: '@arrays/crypto/crypto-holdings/getCryptoHoldingsData',
  module_name: '@arrays/crypto/crypto-holdings',
  module_display_name: 'Public Company Crypto Holdings',
  sdk_name: 'getCryptoHoldingsData',
  sdk_display_name: 'Public Company Crypto Holdings',
  source_name: 'Coingecko',
  source: 'https://docs.coingecko.com/reference/companies-public-treasury',
};

function getCryptoHoldingsData(params) {
  const { syncFetch: fetch } = require('net/http');
  const baseUrl = 'https://data-gateway.prd.space.id/api/v1/tokens/crypto-holdings';
  const keyValuePairs = Object.keys(params || {}).map((k) => {
    const v = params[k];
    return encodeURIComponent(k) + '=' + encodeURIComponent(v);
  });
  const queryString = keyValuePairs.join('&');
  const fullUrl = `${baseUrl}?${queryString}`;
  const fetchOptions = {
    method: 'GET',
    headers: {
      'X-API-Key': key || 'c84b079d-3888-4366-9752-10bb6c51543d',
      'Content-Type': 'application/json',
    },
  };
  const r = fetch(fullUrl, fetchOptions);
  return r.json();
}

// Base description and dynamic call description builder for getCryptoHoldingsData (internal, not exported)
const getCryptoHoldingsDataBaseDesc = "Fetch companies' crypto holdings snapshot";
function buildGetCryptoHoldingsDataCallDescription(actualParams = {}) {
  const parts = [getCryptoHoldingsDataBaseDesc];

  // Token symbol (required by doc, but only mention if provided)
  if (actualParams.token_symbol) {
    parts.push(`for ${String(actualParams.token_symbol).toUpperCase()}`);
  }

  // Collect filters
  const filters = [];

  // Limit (1-100)
  if (typeof actualParams.limit === 'number') {
    filters.push(`Limit: ${actualParams.limit}`);
  }

  // NAV to market cap ratio filters
  const min = actualParams.crypto_nav_to_market_cap_ratio_min;
  const max = actualParams.crypto_nav_to_market_cap_ratio_max;
  const hasMin = typeof min === 'number';
  const hasMax = typeof max === 'number';
  if (hasMin && hasMax) {
    filters.push(`NAV/MC: ${min} to ${max}`);
  } else if (hasMin) {
    filters.push(`NAV/MC >= ${min}`);
  } else if (hasMax) {
    filters.push(`NAV/MC <= ${max}`);
  }

  // Append filters, if any
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }

  return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
  // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
  const title = titleBuilder(params);

  // 2. 组合 refObject 和新 title
  const newObject = {
    ...refObject,
    title: title
  };

  // 3. 返回新对象
  return newObject;
}

function makeCryptoHoldingsNode(params) {
  function pickTokenValueUsd(company, tokenSymbol) {
    if (!company || !company.token_holdings) return null;
    const sym = (tokenSymbol || '').toUpperCase();
    const token = company.token_holdings[sym];
    if (token && typeof token.current_value_usd === 'number') return token.current_value_usd;
    return null;
  }

  function pickTokenAmount(company, tokenSymbol) {
    if (!company || !company.token_holdings) return null;
    const sym = (tokenSymbol || '').toUpperCase();
    const token = company.token_holdings[sym];
    if (token && typeof token.amount === 'number') return token.amount;
    return null;
  }

  return {
    inputs: {
      crypto_holdings_raw: () => getCryptoHoldingsData(params),
    },
    outputs: {
      crypto_holdings: {
        name: 'crypto_holdings',
        description: "Snapshot of public companies' holdings in a specific crypto token",
        fields: [
          { name: 'date', type: 'number', description: 'snapshot time ms (UTC)' },
          { name: 'total', type: 'number', description: 'total matched companies' },
          {
            name: 'companies',
            type: 'array',
            description: 'companies with holdings in the requested token',
            fields: [
              { name: 'ticker', type: 'string', description: 'stock ticker' },
              { name: 'company_name', type: 'string', description: 'company name' },
              { name: 'country', type: 'string', description: 'country/region' },
              { name: 'total_crypto_value_usd', type: 'number', description: 'total USD value of all crypto holdings' },
              { name: 'crypto_nav_to_market_cap_ratio', type: 'number', description: 'NAV to market cap ratio' },
              { name: 'token_symbol', type: 'string', description: 'requested token symbol' },
              { name: 'token_amount', type: 'number', description: 'amount of tokens held' },
              { name: 'token_value_usd', type: 'number', description: 'USD value for the requested token' },
              { name: 'total_holdings', type: 'number', description: 'total token holdings at company level' },
            ],
          },
        ],
        ref: createReferenceWithTitle(getCryptoHoldingsDataRef, params, buildGetCryptoHoldingsDataCallDescription),
      },
    },
    run: (inputs) => {
      const raw = inputs.crypto_holdings_raw;
      if (!raw || raw.success !== true || !raw.response) {
        throw new Error('Crypto holdings raw data is invalid');
      }
      const companiesSrc = Array.isArray(raw.response.companies) ? raw.response.companies : [];
      const tokenSymbol = (params && params.token_symbol) || '';

      const mapped = companiesSrc
        .map((c) => ({
          ticker: c.ticker,
          company_name: c.company_name,
          country: c.country,
          total_crypto_value_usd: c.total_crypto_value_usd,
          crypto_nav_to_market_cap_ratio: c.crypto_nav_to_market_cap_ratio,
          token_symbol: tokenSymbol ? String(tokenSymbol).toUpperCase() : undefined,
          token_amount: pickTokenAmount(c, tokenSymbol),
          token_value_usd: pickTokenValueUsd(c, tokenSymbol),
          total_holdings: c.total_holdings,
        }))
        .filter((c) => typeof c.ticker === 'string' && c.ticker.length > 0);

      // Deduplicate by ticker, keep first occurrence (API already sorted by value desc)
      const dedup = new Map();
      for (const c of mapped) if (!dedup.has(c.ticker)) dedup.set(c.ticker, c);
      const companies = Array.from(dedup.values());
      const total = typeof raw.response.total === 'number' ? raw.response.total : companies.length;

      return {
        crypto_holdings: [
          {
            date: Date.now(),
            total,
            companies,
          },
        ],
      };
    },
  };
}

function getRefs() {
  return [getCryptoHoldingsDataRef];
}

module.exports = {
  getCryptoHoldingsData,
  makeCryptoHoldingsNode,
  getRefs,
};
