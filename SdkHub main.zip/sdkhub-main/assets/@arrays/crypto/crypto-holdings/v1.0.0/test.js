function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
}

function testGetCryptoHoldingsData() {
    console.log('\n=== Testing getCryptoHoldingsData (Direct Function) ===');

    const { getCryptoHoldingsData } = require('@arrays/crypto/crypto-holdings:v1.0.0');

    const TOKEN_ENUMS = ['BTC', 'ETH', 'SOL', 'BNB'];

    let totalTests = 0;
    let passedTests = 0;

    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    function validateResponseShape(ret) {
        assert(ret && typeof ret === 'object', 'Should return an object');
        assert(typeof ret.success === 'boolean', 'success should be a boolean');
        assert(ret.success === true, 'success should be true for valid requests');
        assert(ret.response && typeof ret.response === 'object', 'response should be an object');
        assert(Array.isArray(ret.response.companies), 'response.companies should be an array');
        assert(typeof ret.response.total === 'number', 'response.total should be a number');
        assert(ret.response.total >= 0, 'response.total should be non-negative');
    }

    function validateCompanyItem(company, tokenSymbol) {
        assert(company && typeof company === 'object', 'Company item should be an object');
        assert(typeof company.ticker === 'string' && company.ticker.length > 0, 'ticker should be a non-empty string');
        assert(typeof company.company_name === 'string' && company.company_name.length > 0, 'company_name should be a non-empty string');
        assert(typeof company.country === 'string' && company.country.length > 0, 'country should be a non-empty string');
        assert(typeof company.total_crypto_value_usd === 'number', 'total_crypto_value_usd should be a number');
        assert(typeof company.crypto_nav_to_market_cap_ratio === 'number', 'crypto_nav_to_market_cap_ratio should be a number');
        assert(company.token_holdings && typeof company.token_holdings === 'object', 'token_holdings should be an object');
        assert(typeof company.total_holdings === 'number', 'total_holdings should be a number');
        const key = tokenSymbol.toUpperCase();
        const tokenInfo = company.token_holdings[key] || company.token_holdings[key.toLowerCase()];
        assert(tokenInfo && typeof tokenInfo === 'object', `token_holdings should contain key for ${key}`);
        assert(typeof tokenInfo.amount === 'number', 'amount should be a number');
        assert(typeof tokenInfo.current_value_usd === 'number', 'current_value_usd should be a number');
        assert(typeof tokenInfo.total_holdings === 'number', 'total_holdings should be a number');
    }

    // === Happy Path: Enum coverage (uppercase) ===
    for (const token of TOKEN_ENUMS) {
        runTest(`Happy Path - token ${token} (uppercase)`, () => {
            const ret = getCryptoHoldingsData({ token_symbol: token, limit: 5 });
            validateResponseShape(ret);
            const companies = ret.response.companies;
            if (companies.length > 0) {
                validateCompanyItem(companies[0], token);
            }
        });
    }

    // === Happy Path: Enum coverage (lowercase to verify case-insensitive) ===
    for (const token of TOKEN_ENUMS.map((t) => t.toLowerCase())) {
        runTest(`Happy Path - token ${token} (lowercase)`, () => {
            const ret = getCryptoHoldingsData({ token_symbol: token, limit: 5 });
            validateResponseShape(ret);
            const companies = ret.response.companies;
            if (companies.length > 0) {
                validateCompanyItem(companies[0], token);
            }
        });
    }

    // === Happy Path: Mixed case tokens ===
    for (const token of ['bTc', 'eTh', 'sOl', 'bNb']) {
        runTest(`Happy Path - token ${token} (mixed case)`, () => {
            const ret = getCryptoHoldingsData({ token_symbol: token, limit: 5 });
            validateResponseShape(ret);
            const companies = ret.response.companies;
            if (companies.length > 0) {
                validateCompanyItem(companies[0], token);
            }
        });
    }

    // === Boundary Value Analysis: limit ===
    runTest('Boundary - limit minimum (1)', () => {
        const ret = getCryptoHoldingsData({ token_symbol: 'BTC', limit: 1 });
        validateResponseShape(ret);
        assert(ret.response.companies.length <= 1, 'Should respect minimum limit of 1');
    });

    runTest('Boundary - limit maximum (100)', () => {
        const ret = getCryptoHoldingsData({ token_symbol: 'ETH', limit: 100 });
        validateResponseShape(ret);
        assert(ret.response.companies.length <= 100, 'Should respect maximum limit of 100');
    });

    // === Boundary Value Analysis: NAV/Market Cap Ratio filters ===
    runTest('Boundary - ratio min = 0', () => {
        const ret = getCryptoHoldingsData({ token_symbol: 'BTC', crypto_nav_to_market_cap_ratio_min: 0, limit: 5 });
        validateResponseShape(ret);
        for (const c of ret.response.companies) {
            assert(c.crypto_nav_to_market_cap_ratio >= 0, 'ratio should be >= 0');
        }
    });

    runTest('Boundary - ratio max = 2', () => {
        const ret = getCryptoHoldingsData({ token_symbol: 'BTC', crypto_nav_to_market_cap_ratio_max: 2, limit: 5 });
        validateResponseShape(ret);
        for (const c of ret.response.companies) {
            assert(c.crypto_nav_to_market_cap_ratio <= 2, 'ratio should be <= 2');
        }
    });

    runTest('Boundary - ratio min and max within range (0.5 to 1.5)', () => {
        const ret = getCryptoHoldingsData({ token_symbol: 'BTC', crypto_nav_to_market_cap_ratio_min: 0.5, crypto_nav_to_market_cap_ratio_max: 1.5, limit: 5 });
        validateResponseShape(ret);
        for (const c of ret.response.companies) {
            assert(c.crypto_nav_to_market_cap_ratio >= 0.5 && c.crypto_nav_to_market_cap_ratio <= 1.5, 'ratio should be within [0.5, 1.5]');
        }
    });

    // === Special Values: optional params omitted ===
    runTest('Special - works without optional params', () => {
        const ret = getCryptoHoldingsData({ token_symbol: 'BTC' });
        validateResponseShape(ret);
    });

    // === Error Handling ===
    runTest('Error - invalid token symbol', () => {
        let handled = false;
        try {
            const ret = getCryptoHoldingsData({ token_symbol: 'DOGE', limit: 5 });
            // May return success=false or empty results for unsupported tokens
            if (ret && typeof ret === 'object') {
                if (ret.success === false) handled = true;
                else if (ret.response && Array.isArray(ret.response.companies) && ret.response.companies.length === 0) handled = true;
            }
        } catch (e) {
            // Or may throw an error
            handled = true;
        }
        assert(handled, 'Should handle invalid token symbol');
    });

    runTest('Error - empty token symbol', () => {
        try {
            getCryptoHoldingsData({ token_symbol: '', limit: 5 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e && e.message);
        }
    });

    runTest('Error - missing token symbol', () => {
        try {
            // @ts-ignore - testing missing required param
            getCryptoHoldingsData({});
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e && e.message);
        }
    });

    runTest('Error - limit below minimum (0)', () => {
        try {
            getCryptoHoldingsData({ token_symbol: 'BTC', limit: 0 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e && e.message);
        }
    });

    runTest('Error - limit above maximum (101)', () => {
        try {
            getCryptoHoldingsData({ token_symbol: 'ETH', limit: 101 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e && e.message);
        }
    });

    runTest('Error - ratio min below 0', () => {
        try {
            getCryptoHoldingsData({ token_symbol: 'BTC', crypto_nav_to_market_cap_ratio_min: -0.1, limit: 5 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e && e.message);
        }
    });

    runTest('Error - ratio max above 2', () => {
        try {
            getCryptoHoldingsData({ token_symbol: 'BTC', crypto_nav_to_market_cap_ratio_max: 2.1, limit: 5 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e && e.message);
        }
    });

    runTest('Error - ratio min greater than max', () => {
        try {
            getCryptoHoldingsData({ token_symbol: 'BTC', crypto_nav_to_market_cap_ratio_min: 1.6, crypto_nav_to_market_cap_ratio_max: 1.5, limit: 5 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e && e.message);
        }
    });

    // Print test summary
    console.log('\n=== getCryptoHoldingsData Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function testGraphIntegration() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeCryptoHoldingsNode } = require('@arrays/crypto/crypto-holdings:v1.0.0');

    const g = new Graph(jagentId);
    g.addNode('crypto_holdings_test', makeCryptoHoldingsNode({ token_symbol: 'BTC', limit: 5 }));

    g.run();

    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'crypto_holdings_test', 'crypto_holdings', { last: '1' }), g.store);
    ts.init();

    if (!ts.data.length) throw new Error('crypto_holdings empty');
    const snapshot = ts.data[0];
    ['date', 'total', 'companies'].forEach((k) => {
        if (!(k in snapshot)) throw new Error('missing field: ' + k);
    });
    if (!Array.isArray(snapshot.companies) || !snapshot.companies.length) throw new Error('companies empty');
    const c = snapshot.companies[0];
    [
        'ticker',
        'company_name',
        'country',
        'total_crypto_value_usd',
        'crypto_nav_to_market_cap_ratio',
        'token_symbol',
        'token_amount',
        'token_value_usd',
        'total_holdings',
    ].forEach((k) => {
        if (!(k in c)) throw new Error('missing company field: ' + k);
    });

    // Validate refs for outputs following the learned testing structure
    const refsCryptoHoldings = g.getRefsForOutput('crypto_holdings_test', 'crypto_holdings');
    if (refsCryptoHoldings.length > 0) {
        const ref = refsCryptoHoldings[0];
        const expected = {
            id: '@arrays/crypto/crypto-holdings/getCryptoHoldingsData',
            module_name: '@arrays/crypto/crypto-holdings',
            module_display_name: 'Public Company Crypto Holdings',
            sdk_name: 'getCryptoHoldingsData',
            sdk_display_name: 'Public Company Crypto Holdings',
            source_name: 'Coingecko',
            source: 'https://docs.coingecko.com/reference/companies-public-treasury',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for crypto_holdings');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for crypto_holdings');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for crypto_holdings');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for crypto_holdings');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for crypto_holdings');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for crypto_holdings');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for crypto_holdings');
        console.log('✓ crypto_holdings refs validated');
    } else {
        throw new Error('Assertion failed: refsCryptoHoldings array is empty.');
    }
}

function main() {
    // Direct function tests with manual import (get* function)
    testGetCryptoHoldingsData();

    // Graph integration test (existing)
    testGraphIntegration();

    return 0;
}

main();
