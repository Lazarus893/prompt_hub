const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');
const { makeCryptoKlineNode, getCryptoKline } = require('@arrays/crypto/ohlcv:v1.0.0');

function main() {
	// Offline formatting test (deterministic)
	const nodeCfg = makeCryptoKlineNode({
		symbol: 'BTC',
		start_time: 1723000000,
		end_time: 1723100000,
		interval: '5min',
		limit: 1000,
	});
	// Override input to avoid network dependency; matches getCryptoKline response shape
	nodeCfg.inputs.crypto_kline_raw = () => ({
		success: true,
		response: {
			data: [
				{
					time_open: 1723008800,
					time_close: 1723012400,
					time_period_start: '1723008800',
					time_period_end: '1723012400',
					price_open: 180.1,
					price_close: 181.2,
					price_low: 179.9,
					price_high: 182.0,
					trades_count: 1200,
					volume_traded: 345678,
				},
				{
					time_open: 1723012400,
					time_close: 1723016000,
					time_period_start: '1723012400',
					time_period_end: '1723016000',
					price_open: 181.2,
					price_close: 183.5,
					price_low: 180.8,
					price_high: 184.0,
					trades_count: 1100,
					volume_traded: 289012,
				},
			],
			count: 2,
			cursor: '',
		},
	});

	const g = new Graph(jagentId);
	g.addNode('crypto_kline_offline', nodeCfg);
	g.run();

	const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'crypto_kline_offline', 'ohlcv', { last: '10' }), g.store);
	ts.init();
	if (!Array.isArray(ts.data) || ts.data.length < 2) throw new Error('Expected at least 2 OHLCV records');
	const latest = ts.data[0];
	const older = ts.data[1];
	if (typeof latest.date !== 'number') throw new Error('date must be number (ms)');
	if (typeof latest.open !== 'number') throw new Error('open must be number');
	if (typeof latest.high !== 'number') throw new Error('high must be number');
	if (typeof latest.low !== 'number') throw new Error('low must be number');
	if (typeof latest.time_period_start !== 'string') throw new Error('time_period_start must be string');
	if (typeof latest.time_period_end !== 'string') throw new Error('time_period_end must be string');
	if (typeof latest.close !== 'number') throw new Error('close must be number');
	if (typeof latest.volume !== 'number') throw new Error('volume must be number');
	if (typeof latest.trades_count !== 'number') throw new Error('trades_count must be number');
	if (!(latest.date > older.date)) throw new Error('TimeSeries must be date-descending when read');

	// Validate refs metadata for ohlcv output
	const refsOhlcv = g.getRefsForOutput('crypto_kline_offline', 'ohlcv');
	if (refsOhlcv.length > 0) {
		const ref = refsOhlcv[0];
		const expected = {
			id: '@arrays/crypto/ohlcv/getCryptoKline',
			module_name: '@arrays/crypto/ohlcv',
			module_display_name: 'Crypto Market Price',
			sdk_name: 'getCryptoKline',
			sdk_display_name: 'Crypto Market Price',
			source_name: 'Binance',
			source: 'https://developers.binance.com/docs/binance-spot-api-docs/rest-api#market-data-endpoints',
		};

		if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for ohlcv');
		if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for ohlcv');
		if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for ohlcv');
		if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for ohlcv');
		if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for ohlcv');
		if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for ohlcv');
		if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for ohlcv');
	} else {
		throw new Error('Assertion failed: refsOhlcv array is empty.');
	}

	// Online API test using real gateway data for BTC
	const nodeCfgOnline = makeCryptoKlineNode({
		symbol: 'BTC',
		start_time: 1514481460,
		end_time: 1534481520,
		interval: '1min',
		limit: 200,
	});
	const g2 = new Graph(jagentId);
	g2.addNode('crypto_kline_online', nodeCfgOnline);
	g2.run();
	const ts2 = new TimeSeries(new TimeSeriesUri(jagentId, 'crypto_kline_online', 'ohlcv', { last: '200' }), g2.store);
	ts2.init();
	console.log("length of online data", ts2.data.length);
	if (!Array.isArray(ts2.data)) throw new Error('online data must be an array');
	if (ts2.data.length === 0) throw new Error('online data must not be empty');
	const r = ts2.data[0];
	if (typeof r.date !== 'number') throw new Error('online.date must be number (ms)');
	if (typeof r.open !== 'number') throw new Error('online.open must be number');
	if (typeof r.high !== 'number') throw new Error('online.high must be number');
	if (typeof r.low !== 'number') throw new Error('online.low must be number');
	if (typeof r.time_period_start !== 'string') throw new Error('online.time_period_start must be string');
	if (typeof r.time_period_end !== 'string') throw new Error('online.time_period_end must be string');
	if (typeof r.close !== 'number') throw new Error('online.close must be number');
	if (typeof r.volume !== 'number') throw new Error('online.volume must be number');
	if (typeof r.trades_count !== 'number') throw new Error('online.trades_count must be number');
	if (ts2.data.length > 1 && !(ts2.data[0].date > ts2.data[1].date)) throw new Error('Online TimeSeries must be date-descending when read');

	//test if getCryptoKline return cursor
	const res = getCryptoKline({
		symbol: 'BTC',
		start_time: 1758515912,
		end_time: 1758615912,
		interval: '1min',
		limit: 100,
		cursor: '',
	});
	if (res.response.cursor === '') throw new Error('cursor must be not empty string');
	console.log('cursor', res.response.cursor);
}

main();
