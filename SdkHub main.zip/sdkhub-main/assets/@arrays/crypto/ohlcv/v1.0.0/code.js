const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata (from tool.json) for getCryptoKline
const getCryptoKlineRef = {
    id: '@arrays/crypto/ohlcv/getCryptoKline',
    module_name: '@arrays/crypto/ohlcv',
    module_display_name: 'Crypto Market Price',
    sdk_name: 'getCryptoKline',
    sdk_display_name: 'Crypto Market Price',
    source_name: 'Binance',
    source: 'https://developers.binance.com/docs/binance-spot-api-docs/rest-api#market-data-endpoints',
};

// Base description (summarized from doc) for getCryptoKline
const baseGetCryptoKlineDesc = 'Get crypto OHLCV candlesticks';

// Dynamic description builder for getCryptoKline
function buildGetCryptoKlineCallDescription(actualParams = {}) {
    const parts = [baseGetCryptoKlineDesc];

    // Symbol focus
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }

    // Additional filters
    const filters = [];
    if (actualParams.interval) {
        filters.push(`Interval: ${actualParams.interval}`);
    }

    const { start_time, end_time } = actualParams;
    if (start_time && end_time) {
        filters.push(`Time: ${start_time} to ${end_time}`);
    } else if (start_time) {
        filters.push(`Time from: ${start_time}`);
    } else if (end_time) {
        filters.push(`Time to: ${end_time}`);
    }

    if (typeof actualParams.limit === 'number' && actualParams.limit !== 5000) {
        filters.push(`Limit: ${actualParams.limit}`);
    }

    if (actualParams.cursor) {
        filters.push(`Cursor: ${actualParams.cursor}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getCryptoKline(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/tokens/kline';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    const originalData = r.json();
    return {
        success: originalData.success,
        response: {
            data: originalData?.response?.data || [],
            cursor: originalData?.response?.cursor || '',
            count: originalData?.response?.count || 0,
        },
    };
}

function makeCryptoKlineNode(params) {
    return {
        inputs: {
            crypto_kline_raw: () => getCryptoKline(params),
        },
        outputs: {
            ohlcv: {
                name: 'crypto_ohlcv',
                description: 'Crypto adjusted candlestick data for the requested token and interval',
                fields: [
                    { name: 'date', type: 'number', description: 'ms since epoch (UTC), beginning of the interval' },
                    { name: 'open', type: 'number', description: 'open price of the interval' },
                    { name: 'high', type: 'number', description: 'high price of the interval' },
                    { name: 'low', type: 'number', description: 'low price of the interval' },
                    { name: 'time_period_start', type: 'string', description: 'ISO 8601, e.g. 2024-08-07T23:56:00Z' },
                    { name: 'time_period_end', type: 'string', description: 'ISO 8601, e.g. 2024-08-08T00:01:00Z' },
                    { name: 'close', type: 'number', description: 'close price of the interval' },
                    { name: 'volume', type: 'number', description: 'traded volume of the interval' },
                    { name: 'trades_count', type: 'number', description: 'number of trades within the interval' },
                ],
                ref: createReferenceWithTitle(getCryptoKlineRef, params, buildGetCryptoKlineCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.crypto_kline_raw;
            const arr = raw && raw.response && Array.isArray(raw.response.data) ? raw.response.data : [];
            const mapped = arr
                .map((d) => ({
                    date: typeof d.time_open === 'number' ? d.time_open * 1000 : undefined,
                    open: d.price_open,
                    high: d.price_high,
                    low: d.price_low,
                    time_period_start: d.time_period_start != null ? String(d.time_period_start) : undefined,
                    time_period_end: d.time_period_end != null ? String(d.time_period_end) : undefined,
                    close: d.price_close,
                    volume: d.volume_traded,
                    trades_count: d.trades_count,
                }))
                .filter((r) => typeof r.date === 'number');

            // Deduplicate by date (keep last), then sort descending by date
            const dedup = new Map();
            for (const r of mapped) dedup.set(r.date, r);
            const out = Array.from(dedup.values()).sort((a, b) => b.date - a.date);

            return { ohlcv: out };
        },
    };
}

function getRefs() {
    return [
        getCryptoKlineRef,
    ];
}

module.exports = {
    getCryptoKline,
    makeCryptoKlineNode,
    getRefs,
};
