const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getTokenList derived from tool.json
const getTokenListRef = {
    id: "@arrays/crypto/screener/getTokenList",
    module_name: "@arrays/crypto/screener",
    module_display_name: "Crypto Screener",
    sdk_name: "getTokenList",
    sdk_display_name: "Token Screener",
    source_name: "CoinMarketCap",
    source: "https://coinmarketcap.com/api/documentation/v1/?utm_source=chatgpt.com#operation/getV1CryptocurrencyListingsLatest",
};

// ========================= Internal description helpers (not exported) =========================
// Base description strings derived from doc for each function
const getTokenListBaseDesc = "Get filtered token list";

// Dynamic description builder for getTokenList based on provided params
function buildGetTokenListCallDescription(actualParams = {}) {
    const parts = [getTokenListBaseDesc];

    // Time window
    if (actualParams.interval) {
        parts.push(`over ${actualParams.interval}`);
    } else {
        const st = actualParams.start_time;
        const et = actualParams.end_time;
        if (st && et) {
            parts.push(`from ${st} to ${et}`);
        } else if (st) {
            parts.push(`from ${st}`);
        } else if (et) {
            parts.push(`until ${et}`);
        }
    }

    // Filters and options
    const filters = [];

    // Symbol
    if (actualParams.symbol) {
        filters.push(`Symbol: ${actualParams.symbol}`);
    }

    // Chain type mapping
    const chainMap = { 0: 'BTC', 1: 'ETH', 2: 'BSC', 3: 'BASE', 4: 'SOL', 99: 'OTHER' };
    if (actualParams.chain_type !== undefined && actualParams.chain_type !== null) {
        const chainLabel = chainMap[actualParams.chain_type] ?? String(actualParams.chain_type);
        filters.push(`Chain: ${chainLabel}`);
    }

    // Price range
    const hasMinPrice = actualParams.min_price !== undefined && actualParams.min_price !== null;
    const hasMaxPrice = actualParams.max_price !== undefined && actualParams.max_price !== null;
    if (hasMinPrice || hasMaxPrice) {
        if (hasMinPrice && hasMaxPrice) {
            filters.push(`Price: ${actualParams.min_price} to ${actualParams.max_price}`);
        } else if (hasMinPrice) {
            filters.push(`Min Price: ${actualParams.min_price}`);
        } else {
            filters.push(`Max Price: ${actualParams.max_price}`);
        }
    }

    // Volume range
    const hasMinVol = actualParams.min_volume !== undefined && actualParams.min_volume !== null;
    const hasMaxVol = actualParams.max_volume !== undefined && actualParams.max_volume !== null;
    if (hasMinVol || hasMaxVol) {
        if (hasMinVol && hasMaxVol) {
            filters.push(`Volume: ${actualParams.min_volume} to ${actualParams.max_volume}`);
        } else if (hasMinVol) {
            filters.push(`Min Volume: ${actualParams.min_volume}`);
        } else {
            filters.push(`Max Volume: ${actualParams.max_volume}`);
        }
    }

    // Price change range
    const hasMinChg = actualParams.min_price_change !== undefined && actualParams.min_price_change !== null;
    const hasMaxChg = actualParams.max_price_change !== undefined && actualParams.max_price_change !== null;
    if (hasMinChg || hasMaxChg) {
        if (hasMinChg && hasMaxChg) {
            filters.push(`Price Change: ${actualParams.min_price_change} to ${actualParams.max_price_change}`);
        } else if (hasMinChg) {
            filters.push(`Min Price Change: ${actualParams.min_price_change}`);
        } else {
            filters.push(`Max Price Change: ${actualParams.max_price_change}`);
        }
    }

    // Sorting (only show if deviates from defaults or explicitly provided)
    const sortBy = actualParams.sort_by;
    const sortDir = actualParams.sort_direction;
    const sortParts = [];
    if (sortBy && sortBy !== 'volume') {
        sortParts.push(sortBy);
    }
    if (sortDir && sortDir !== 'DESC') {
        sortParts.push(sortDir);
    }
    if (sortParts.length > 0) {
        filters.push(`Sort: ${sortParts.join(' ')}`);
    }

    // Pagination options
    if (actualParams.limit !== undefined && actualParams.limit !== null && actualParams.limit !== 10) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (actualParams.cursor) {
        filters.push(`Cursor: ${actualParams.cursor}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function parseNumber(value) {
    if (value == null) {
        return null;
    }
    const n = Number(value);
    return Number.isNaN(n) ? null : n;
}

function getTokenList(params) {
    // Validate parameters
    params = params || {};
    
    // Time window validation: must have either interval OR (start_time AND end_time), not both
    const hasInterval = params.interval != null;
    const hasAbsoluteTime = params.start_time != null || params.end_time != null;
    
    if (hasInterval && hasAbsoluteTime) {
        throw new Error('Cannot provide both interval and start_time/end_time. Use either interval or absolute time window, not both.');
    }
    
    if (!hasInterval && !hasAbsoluteTime) {
        throw new Error('Required: must provide either interval or both start_time and end_time.');
    }
    
    // Validate interval enum
    if (hasInterval) {
        const validIntervals = ['1min', '15min', '60min', '24h'];
        if (!validIntervals.includes(params.interval)) {
            throw new Error(`Invalid interval: ${params.interval}. Must be one of: ${validIntervals.join(', ')}`);
        }
    }
    
    // Validate absolute time window
    if (hasAbsoluteTime) {
        if (params.start_time == null || params.end_time == null) {
            throw new Error('Both start_time and end_time are required when using absolute time window.');
        }
        if (params.start_time < 0 || params.end_time < 0) {
            throw new Error('Invalid time: start_time and end_time must be non-negative.');
        }
        if (params.start_time > params.end_time) {
            throw new Error('Invalid time range: start_time must be less than or equal to end_time.');
        }
    }
    
    // Validate chain_type enum
    if (params.chain_type != null) {
        const validChainTypes = [0, 1, 2, 3, 4, 99];
        if (!validChainTypes.includes(params.chain_type)) {
            throw new Error(`Invalid chain_type: ${params.chain_type}. Must be one of: ${validChainTypes.join(', ')}`);
        }
    }
    
    // Validate sort_by enum
    if (params.sort_by != null) {
        const validSortBy = ['price', 'volume', 'price_change'];
        if (!validSortBy.includes(params.sort_by)) {
            throw new Error(`Invalid sort_by: ${params.sort_by}. Must be one of: ${validSortBy.join(', ')}`);
        }
    }
    
    // Validate sort_direction enum
    if (params.sort_direction != null) {
        const validDirections = ['ASC', 'DESC'];
        if (!validDirections.includes(params.sort_direction)) {
            throw new Error(`Invalid sort_direction: ${params.sort_direction}. Must be one of: ${validDirections.join(', ')}`);
        }
    }
    
    // Validate limit range
    if (params.limit != null) {
        if (params.limit < 1 || params.limit > 500) {
            throw new Error('Invalid limit: must be between 1 and 500 (inclusive).');
        }
    }
    
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/tokens/list_by_filter_cursor';
    
    // Filter out null, undefined, and empty string values before building query string
    const keyValuePairs = Object.keys(params || {})
        .filter((key) => {
            const value = params[key];
            // Keep the value if it's not null, undefined, or empty string
            // But keep 0 and false as they are valid values
            return value !== null && value !== undefined && value !== '';
        })
        .map((key) => {
            const value = params[key];
            return encodeURIComponent(key) + '=' + encodeURIComponent(value);
        });
    
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);

    if (r.status !== 200) {
        throw new Error(`API request failed with status ${r.status}: ${r.statusText}`);
    }

    const result = r.json();

    if (!result || typeof result !== 'object') {
        throw new Error('Invalid API response: response is not an object');
    }

    if (result.success === false) {
        const errorMsg = result.error || result.message || 'API returned success=false';
        throw new Error(`API error: ${errorMsg}`);
    }

    const responseArray = Array.isArray(result.response) ? result.response : [];

    const transformedResponse = responseArray.map(item => {
        return {
            trade_pair_id: parseNumber(item.trade_pair_id) || 0,
            address: item.address || '',
            chain_type: parseNumber(item.chain_type) || 0,
            symbol: item.symbol || '',
            logo: item.logo || '',
            twitter_url: item.twitter_url || '',
            website_url: item.website_url || '',

            price_change: item.price_change || '0',
            open: parseNumber(item.open_price) || 0,
            close: parseNumber(item.close_price) || 0,
            high: parseNumber(item.high_price) || 0,
            low: parseNumber(item.low_price) || 0,
            volume: parseNumber(item.total_volume) || 0
        };
    });

    // Ensure pagination object has proper structure with all required fields
    const pagination = result.pagination || {};
    const paginationResult = {
        has_more: typeof pagination.has_more === 'boolean' ? pagination.has_more : false,
        next_cursor: typeof pagination.next_cursor === 'string' ? pagination.next_cursor : ''
    };

    return {
        success: result.success,
        response: transformedResponse,
        total: parseNumber(result.total) || 0,
        pagination: paginationResult
    };
}

function makeTokenListNode(params) {
    return {
        inputs: {
            token_list_raw: () => getTokenList(params),
        },
        outputs: {
            token_list: {
                name: 'token_list_snapshot',
                description: 'Token list snapshot filtered by criteria (single record with nested tokens array)',
                fields: [
                    { name: 'date', type: 'number', description: 'snapshot time ms' },
                    { name: 'total', type: 'number', description: 'total tokens matching criteria' },
                    { name: 'has_more', type: 'boolean', description: 'whether more pages are available' },
                    { name: 'next_cursor', type: 'string', description: 'cursor for next page if has_more' },
                    {
                        name: 'tokens',
                        type: 'array',
                        description: 'tokens in this snapshot (ordered per API sort)',
                        fields: [
                            { name: 'trade_pair_id', type: 'number', description: 'trade pair identifier' },
                            { name: 'address', type: 'string', description: 'token contract address (null for native tokens like BTC)' },
                            { name: 'chain_type', type: 'number', description: 'chain type code' },
                            { name: 'symbol', type: 'string', description: 'token symbol' },
                            { name: 'logo', type: 'string', description: 'logo URL' },
                            { name: 'twitter_url', type: 'string', description: 'Twitter profile URL (null if not available)' },
                            { name: 'website_url', type: 'string', description: 'official website URL' },
                            { name: 'price_change', type: 'string', description: 'price change over interval' },
                            { name: 'open', type: 'number', description: 'opening price' },
                            { name: 'close', type: 'number', description: 'closing price' },
                            { name: 'high', type: 'number', description: 'high price' },
                            { name: 'low', type: 'number', description: 'low price' },
                            { name: 'volume', type: 'string', description: 'total traded volume' },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getTokenListRef, params, buildGetTokenListCallDescription)
            },
        },
        run: (inputs) => {
            const raw = inputs.token_list_raw;

            if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
                throw new Error('Invalid input: token_list_raw must be an object');
            }
            if (!Array.isArray(raw.response)) {
                throw new Error('Invalid API response: missing or invalid response array');
            }

            const response = raw.response.filter((item) => item && typeof item === 'object');

            const snapshotTime = Date.now();

            const tokens = response.map((item) => ({
                trade_pair_id: item.trade_pair_id,
                address: item.address || null,
                chain_type: item.chain_type,
                symbol: item.symbol,
                logo: item.logo,
                twitter_url: item.twitter_url || null,
                website_url: item.website_url,
                price_change: item.price_change,
                open: item.open,
                close: item.close,
                high: item.high,
                low: item.low,
                volume: item.volume,
            }));

            const total = typeof raw.total === 'number' ? raw.total : tokens.length;
            const has_more = raw && raw.pagination && typeof raw.pagination.has_more === 'boolean' ? raw.pagination.has_more : false;
            const next_cursor = raw && raw.pagination && typeof raw.pagination.next_cursor === 'string' ? raw.pagination.next_cursor : '';

            return {
                token_list: [
                    {
                        date: snapshotTime,
                        total,
                        has_more,
                        next_cursor,
                        tokens,
                    },
                ],
            };
        },
    };
}

function getRefs() {
    return [
        getTokenListRef,
    ];
}

module.exports = {
    getTokenList,
    makeTokenListNode,
    getRefs,
};
