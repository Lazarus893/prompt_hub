function testGetTokenListDirect() {
  console.log('\n=== Testing getTokenList (Direct Calls) ===');

  const { getTokenList } = require('@arrays/crypto/screener:v1.0.0');

  let totalTests = 0;
  let passedTests = 0;

  function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
  }

  function runTest(testName, testFunc) {
    totalTests++;
    try {
      testFunc();
      console.log(`✅ ${testName}`);
      passedTests++;
    } catch (e) {
      console.log(`❌ ${testName}: ${e.message}`);
    }
  }

  function validateResponseShape(result, opts = {}) {
    assert(result && typeof result === 'object', 'Result should be an object');
    assert(typeof result.success === 'boolean', 'success should be boolean');
    assert(Array.isArray(result.response), 'response should be an array');
    assert(typeof result.total === 'number', 'total should be a number');
    assert(result.pagination && typeof result.pagination === 'object', 'pagination should be an object');
    assert(typeof result.pagination.has_more === 'boolean', 'pagination.has_more should be boolean');
    assert(typeof result.pagination.next_cursor === 'string', 'pagination.next_cursor should be string');

    if (result.response.length > 0) {
      const t = result.response[0];
      assert(typeof t.trade_pair_id === 'number', 'trade_pair_id must be number');
      assert(typeof t.address === 'string', 'address must be string');
      assert(typeof t.chain_type === 'number', 'chain_type must be number');
      assert(typeof t.symbol === 'string', 'symbol must be string');
      assert(typeof t.logo === 'string', 'logo must be string');
      assert(typeof t.twitter_url === 'string', 'twitter_url must be string');
      assert(typeof t.website_url === 'string', 'website_url must be string');
      assert(typeof t.price_change === 'string', 'price_change must be string');
      assert(typeof t.open === 'number', 'open must be number');
      assert(typeof t.close === 'number', 'close must be number');
      assert(typeof t.high === 'number', 'high must be number');
      assert(typeof t.low === 'number', 'low must be number');
      assert(typeof t.volume === 'number', 'volume must be number');

      if (opts.expectChainType != null) {
        // When filter applied, all items should match the chain_type
        for (const item of result.response) {
          assert(item.chain_type === opts.expectChainType, `Expected chain_type ${opts.expectChainType}, got ${item.chain_type}`);
        }
      }
      if (opts.expectSymbolIncludes) {
        for (const item of result.response) {
          assert(
            item.symbol && item.symbol.toUpperCase().includes(opts.expectSymbolIncludes.toUpperCase()),
            `symbol should include ${opts.expectSymbolIncludes}`
          );
        }
      }
      if (opts.expectMinVolume != null) {
        for (const item of result.response) {
          assert(item.volume >= opts.expectMinVolume, `volume must be >= ${opts.expectMinVolume}`);
        }
      }
      if (opts.expectMaxVolume != null) {
        for (const item of result.response) {
          assert(item.volume <= opts.expectMaxVolume, `volume must be <= ${opts.expectMaxVolume}`);
        }
      }
      if (opts.expectMinPriceChange != null) {
        for (const item of result.response) {
          const v = parseFloat(item.price_change);
          assert(!Number.isNaN(v), 'price_change should be numeric string');
          assert(v >= opts.expectMinPriceChange, `price_change must be >= ${opts.expectMinPriceChange}`);
        }
      }
      if (opts.expectMaxPriceChange != null) {
        for (const item of result.response) {
          const v = parseFloat(item.price_change);
          assert(!Number.isNaN(v), 'price_change should be numeric string');
          assert(v <= opts.expectMaxPriceChange, `price_change must be <= ${opts.expectMaxPriceChange}`);
        }
      }
    }
  }

  function checkSorted(arr, key, dir, parse = (x) => x) {
    if (!arr || arr.length < 2) return;
    for (let i = 0; i < arr.length - 1; i++) {
      const a = parse(arr[i][key]);
      const b = parse(arr[i + 1][key]);
      if (dir === 'DESC') assert(a >= b, `${key} should be sorted DESC`);
      else assert(a <= b, `${key} should be sorted ASC`);
    }
  }

  // Happy Path basic
  runTest('Basic 24h fetch with limit=5', () => {
    const res = getTokenList({ interval: '24h', limit: 5 });
    validateResponseShape(res);
    assert(res.response.length <= 5, 'Should respect limit');
  });

  // Interval coverage
  for (const interval of ['1min', '15min', '60min', '24h']) {
    runTest(`Interval coverage: ${interval} + chain_type=SOL(4)`, () => {
      const res = getTokenList({ interval, chain_type: 4, limit: 2 });
      validateResponseShape(res, { expectChainType: 4 });
    });
  }

  // Chain type coverage
  const CHAIN_TYPES = [0, 1, 2, 3, 4, 99];
  const CHAIN_NAMES = { 0: 'BTC', 1: 'ETH', 2: 'BSC', 3: 'BASE', 4: 'SOL', 99: 'OTHER' };
  for (const ct of CHAIN_TYPES) {
    runTest(`Chain filter: ${CHAIN_NAMES[ct]} (${ct})`, () => {
      const res = getTokenList({ interval: '24h', chain_type: ct, limit: 2 });
      validateResponseShape(res, { expectChainType: ct });
    });
  }

  // Sort coverage (sort_by x sort_direction)
  const SORT_BYS = ['price', 'volume', 'price_change'];
  const DIRECTIONS = ['ASC', 'DESC'];
  for (const sort_by of SORT_BYS) {
    for (const sort_direction of DIRECTIONS) {
      runTest(`Sorting: ${sort_by} ${sort_direction}`, () => {
        const res = getTokenList({ interval: '24h', limit: 5, sort_by, sort_direction });
        validateResponseShape(res);
        if (sort_by === 'volume') {
          checkSorted(res.response, 'volume', sort_direction, Number);
        } else if (sort_by === 'price_change') {
          checkSorted(res.response, 'price_change', sort_direction, parseFloat);
        } else if (sort_by === 'price') {
          // Assuming price refers to close price per doc
          checkSorted(res.response.map(i => ({ close: i.close })), 'close', sort_direction, Number);
        }
      });
    }
  }

  // Pagination test
  runTest('Pagination: next page with cursor when available', () => {
    const res1 = getTokenList({ interval: '24h', limit: 2 });
    validateResponseShape(res1);
    if (res1.pagination.has_more && res1.pagination.next_cursor) {
      const res2 = getTokenList({ interval: '24h', limit: 2, cursor: res1.pagination.next_cursor });
      validateResponseShape(res2);
    }
  });

  // Boundary: limit
  runTest('Boundary: limit minimum (1)', () => {
    const res = getTokenList({ interval: '24h', limit: 1 });
    validateResponseShape(res);
    assert(res.response.length <= 1, 'limit=1 should return at most 1');
  });
  runTest('Boundary: limit maximum (500)', () => {
    const res = getTokenList({ interval: '24h', limit: 500 });
    validateResponseShape(res);
    assert(res.response.length <= 500, 'limit=500 should return at most 500');
  });

  // Boundary: volume filters
  runTest('Boundary: min_volume = 0', () => {
    const res = getTokenList({ interval: '24h', min_volume: 0, limit: 3 });
    validateResponseShape(res, { expectMinVolume: 0 });
  });
  runTest('Boundary: min_volume = 1,000,000', () => {
    const res = getTokenList({ interval: '24h', min_volume: 1_000_000, limit: 3 });
    validateResponseShape(res, { expectMinVolume: 1_000_000 });
  });
  runTest('Boundary: max_volume very small (<=1)', () => {
    const res = getTokenList({ interval: '24h', max_volume: 1, limit: 3 });
    validateResponseShape(res, { expectMaxVolume: 1 });
  });

  // Boundary: price change filters
  runTest('Boundary: price_change in [-1, 1]', () => {
    const res = getTokenList({ interval: '24h', min_price_change: -1, max_price_change: 1, limit: 5 });
    validateResponseShape(res, { expectMinPriceChange: -1, expectMaxPriceChange: 1 });
  });

  // Symbol filter tests (case-insensitive and special values)
  runTest('Symbol filter: case-insensitive (SOL)', () => {
    const res = getTokenList({ interval: '24h', chain_type: 4, symbol: 'SOL', limit: 5 });
    validateResponseShape(res, { expectChainType: 4, expectSymbolIncludes: 'SOL' });
  });
  runTest('Symbol filter: empty string should not throw', () => {
    const res = getTokenList({ interval: '24h', symbol: '', limit: 2 });
    validateResponseShape(res);
  });

  // Absolute time window
  runTest('Absolute time window: last 1 hour', () => {
    const now = Math.floor(Date.now() / 1000);
    const res = getTokenList({ start_time: now - 3600, end_time: now, limit: 3, chain_type: 1 });
    validateResponseShape(res, { expectChainType: 1 });
  });

  // Error Handling
  runTest('Invalid: provide both interval and start/end time', () => {
    try {
      const now = Math.floor(Date.now() / 1000);
      getTokenList({ interval: '24h', start_time: now - 3600, end_time: now, limit: 2 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.match(/(cannot|either|not both|invalid)/i), 'Should reject both interval and start/end');
    }
  });
  runTest('Invalid: missing required time window (no interval nor start/end)', () => {
    try {
      getTokenList({ limit: 2 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.match(/(required|interval|start|end)/i), 'Should require a time window');
    }
  });
  runTest('Invalid: start_time > end_time', () => {
    try {
      const now = Math.floor(Date.now() / 1000);
      getTokenList({ start_time: now, end_time: now - 3600, limit: 2 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.match(/(start.*end|invalid|greater)/i), 'Should reject start_time > end_time');
    }
  });
  runTest('Invalid: negative start_time', () => {
    try {
      const now = Math.floor(Date.now() / 1000);
      getTokenList({ start_time: -now, end_time: now, limit: 2 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.match(/(invalid|negative)/i), 'Should reject negative start_time');
    }
  });
  runTest('Invalid: unsupported chain_type', () => {
    try {
      getTokenList({ interval: '24h', chain_type: 5, limit: 2 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.match(/(invalid|unsupported|chain)/i), 'Should reject unsupported chain_type');
    }
  });
  runTest('Invalid: sort_by not in enum', () => {
    try {
      getTokenList({ interval: '24h', sort_by: 'abc', limit: 2 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.match(/(invalid|sort_by)/i), 'Should reject invalid sort_by');
    }
  });
  runTest('Invalid: sort_direction not in enum', () => {
    try {
      getTokenList({ interval: '24h', sort_by: 'volume', sort_direction: 'UP', limit: 2 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.match(/(invalid|direction)/i), 'Should reject invalid sort_direction');
    }
  });
  runTest('Invalid: limit out of range (0)', () => {
    try {
      getTokenList({ interval: '24h', limit: 0 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.match(/(range|limit|1–500|1-500|minimum)/i), 'Should reject limit < 1');
    }
  });
  runTest('Invalid: limit out of range (501)', () => {
    try {
      getTokenList({ interval: '24h', limit: 501 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.match(/(range|limit|1–500|1-500|maximum)/i), 'Should reject limit > 500');
    }
  });

  // Print test summary
  console.log('\n=== getTokenList Direct Tests Summary ===');
  console.log(`Total tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${totalTests - passedTests}`);
  console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function main() {
  // Run direct function tests first (manual import as required)
  testGetTokenListDirect();

  // Existing Graph/TimeSeries based test
  const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
  const { jagentId } = require('env');
  const { makeTokenListNode } = require('@arrays/crypto/screener:v1.0.0');

  // Test make node
  const g = new Graph(jagentId);
  g.addNode(
    'token_list',
    makeTokenListNode({
      interval: '24h',
      min_volume: 1000000,
      chain_type: 4,
      sort_by: 'price_change',
      sort_direction: 'DESC',
      limit: 5,
    })
  );
  g.run();

  // Validate refs metadata for token_list output
  const refsTokenList = g.getRefsForOutput('token_list', 'token_list');
  if (refsTokenList.length > 0) {
    const ref = refsTokenList[0];
    const expected = {
      id: '@arrays/crypto/screener/getTokenList',
      module_name: '@arrays/crypto/screener',
      module_display_name: 'Crypto Screener',
      sdk_name: 'getTokenList',
      sdk_display_name: 'Token Screener',
      source_name: 'CoinMarketCap',
      source: 'https://coinmarketcap.com/api/documentation/v1/?utm_source=chatgpt.com#operation/getV1CryptocurrencyListingsLatest',
    };

    if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for token_list');
    if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for token_list');
    if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for token_list');
    if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for token_list');
    if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for token_list');
    if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for token_list');
    if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for token_list');
  } else {
    throw new Error('Assertion failed: refsTokenList array is empty.');
  }

  // Assert graph output via TimeSeries API
  const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'token_list', 'token_list', { last: '1' }), g.store);
  ts.init();
  if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('expected at least 1 record');
  if (ts.data.length > 1 && !(ts.data[0].date > ts.data[1].date)) throw new Error('TimeSeries must be date-descending when read');
  const r = ts.data[0];
  if (typeof r.date !== 'number') throw new Error('date must be number (ms)');
  if (typeof r.total !== 'number') throw new Error('total must be number');
  if (typeof r.has_more !== 'boolean') throw new Error('has_more must be boolean');
  if (typeof r.next_cursor !== 'string') throw new Error('next_cursor must be string');
  if (!Array.isArray(r.tokens)) throw new Error('tokens must be array');
  if (r.tokens.length !== 5) throw new Error('tokens array length should match limit parameter (5)');
  if (r.tokens.length > 0) {
    const token = r.tokens[0];
    if (typeof token.trade_pair_id !== 'number') throw new Error('token.trade_pair_id must be number');
    if (typeof token.symbol !== 'string') throw new Error('token.symbol must be string');
    if (typeof token.chain_type !== 'number') throw new Error('token.chain_type must be number');
    if (typeof token.price_change !== 'string') throw new Error('token.price_change must be string');
    if (typeof token.close !== 'number') throw new Error('token.close must be number');
    if (typeof token.volume !== 'number') throw new Error('token.volume must be number');
    //assert token meets chain_type filter
    if (token.chain_type !== 4) throw new Error('token.chain_type must be 4 (SOL)');
    //assert token meets volume filter
    if (parseFloat(token.volume) < 1000000) throw new Error('token.volume must be >= 1000000');
    //assert token has valid symbol
    if (!token.symbol || token.symbol.length === 0) throw new Error('token.symbol must be non-empty string');
  }

  //assert tokens are sorted by price_change in DESC order
  if (r.tokens.length > 1) {
    for (let i = 0; i < r.tokens.length - 1; i++) {
      const current = parseFloat(r.tokens[i].price_change);
      const next = parseFloat(r.tokens[i + 1].price_change);
      if (current < next) throw new Error('tokens should be sorted by price_change in DESC order');
    }
  }

  return 0;
}

main();
