const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

function getInstitutionOwnershipSummary(params) {
  const { syncFetch: fetch } = require('net/http');
  const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/institution/ownership/summary';
  const keyValuePairs = Object.keys(params || {}).map((key) => {
    const value = params[key];
    return encodeURIComponent(key) + '=' + encodeURIComponent(value);
  });
  const queryString = keyValuePairs.join('&');
  const fullUrl = queryString ? `${baseUrl}?${queryString}` : baseUrl;
  const fetchOptions = {
    method: 'GET',
    headers: {
      'X-API-Key': key,
      'Content-Type': 'application/json',
    },
  };
  const r = fetch(fullUrl, fetchOptions);
  return r.json();
}

// Reference object (from tool.json metadata)
const getInstitutionOwnershipSummaryRef = {
  id: '@arrays/data/stock/institution/ownership-summary/getInstitutionOwnershipSummary',
  module_name: '@arrays/data/stock/institution/ownership-summary',
  module_display_name: 'Stock Institution Holdings Summary',
  sdk_name: 'getInstitutionOwnershipSummary',
  sdk_display_name: 'Stock Institution Holdings Summary',
  source_name: 'Financial Modeling Prep',
  source: 'https://site.financialmodelingprep.com/developer/docs/stable/positions-summary',
};

// Utility to create a reference object with a dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
  // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
  const title = titleBuilder(params);

  // 2. 组合 refObject 和新 title
  const newObject = {
    ...refObject,
    title: title
  };

  // 3. 返回新对象
  return newObject;
}

// Helpers for deterministic date derivation (ms epoch, UTC)
function quarterEndMs(year, quarter) {
  if (typeof year !== 'number' || typeof quarter !== 'number' || quarter < 1 || quarter > 4) {
    return null;
  }
  // quarter end months: Q1=Mar(2), Q2=Jun(5), Q3=Sep(8), Q4=Dec(11)
  const month = quarter === 1 ? 2 : quarter === 2 ? 5 : quarter === 3 ? 8 : 11;
  // Day 0 of next month -> last day of target month
  return Date.UTC(year, month + 1, 0, 0, 0, 0, 0);
}

/**
 * Parse various timestamp string formats to epoch ms (UTC).
 * Supported:
 * - ISO 8601 strings parsable by Date.parse
 * - 'YYYY-MM-DD HH:mm:ss'
 * - 'YYYY-MM-DD'
 * - 'MM-DD-YYYY' or 'MM/DD/YYYY'
 */
function parseToMs(s) {
  if (s == null) return undefined;
  if (typeof s !== 'string') return undefined;

  // Try native Date.parse first (handles many ISO variants)
  const parsed = Date.parse(s);
  if (!Number.isNaN(parsed)) return parsed;

  // 'YYYY-MM-DD HH:mm:ss'
  let m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/);
  if (m) {
    const y = +m[1];
    const mo = +m[2] - 1;
    const d = +m[3];
    const hh = +m[4];
    const mm = +m[5];
    const ss = +m[6];
    return Date.UTC(y, mo, d, hh, mm, ss, 0);
  }

  // 'YYYY-MM-DD'
  m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (m) {
    const y = +m[1];
    const mo = +m[2] - 1;
    const d = +m[3];
    return Date.UTC(y, mo, d, 0, 0, 0, 0);
  }

  // 'MM-DD-YYYY' or 'MM/DD/YYYY'
  m = s.match(/^(\d{2})[-/](\d{2})[-/](\d{4})$/);
  if (m) {
    const mo = +m[1] - 1;
    const d = +m[2];
    const y = +m[3];
    return Date.UTC(y, mo, d, 0, 0, 0, 0);
  }

  return undefined;
}

function makeInstitutionOwnershipSummaryNode(params) {
  return {
    inputs: {
      institution_ownership_summary_raw: () => getInstitutionOwnershipSummary(params),
    },
    outputs: {
      ownership_summary_snapshot: {
        name: 'ownership_summary_snapshot',
        description: 'Single snapshot with all ownership summary data',
        fields: [
          {
            name: 'date',
            type: 'number',
            description: 'snapshot time in ms since epoch (UTC), derived from latest date',
          },
          {
            name: 'summaries',
            type: 'array',
            description: 'all ownership summary records',
            fields: [
              { name: 'symbol', type: 'string', description: 'stock symbol' },
              { name: 'cik', type: 'string', description: 'CIK of the company' },
              { name: 'date', type: 'string', description: 'data date (YYYY-MM-DD)' },
              { name: 'investors_holding', type: 'number', description: 'number of investors holding' },
              { name: 'last_investors_holding', type: 'number', description: 'previous period investors holding' },
              { name: 'investors_holding_change', type: 'number', description: 'change in investors holding' },
              { name: 'number_of_13f_shares', type: 'number', description: 'number of 13F shares' },
              { name: 'last_number_of_13f_shares', type: 'number', description: 'previous period number of 13F shares' },
              { name: 'number_of_13f_shares_change', type: 'number', description: 'change in number of 13F shares' },
              { name: 'total_invested', type: 'number', description: 'total invested amount in USD' },
              { name: 'last_total_invested', type: 'number', description: 'previous period total invested amount in USD' },
              { name: 'total_invested_change', type: 'number', description: 'change in total invested amount in USD' },
              { name: 'ownership_percent', type: 'number', description: 'ownership percentage' },
              { name: 'last_ownership_percent', type: 'number', description: 'previous period ownership percentage' },
              { name: 'ownership_percent_change', type: 'number', description: 'change in ownership percentage' },
              { name: 'new_positions', type: 'number', description: 'number of new positions' },
              { name: 'last_new_positions', type: 'number', description: 'previous period new positions' },
              { name: 'new_positions_change', type: 'number', description: 'change in new positions' },
              { name: 'increased_positions', type: 'number', description: 'number of increased positions' },
              { name: 'last_increased_positions', type: 'number', description: 'previous period increased positions' },
              { name: 'increased_positions_change', type: 'number', description: 'change in increased positions' },
              { name: 'closed_positions', type: 'number', description: 'number of closed positions' },
              { name: 'last_closed_positions', type: 'number', description: 'previous period closed positions' },
              { name: 'closed_positions_change', type: 'number', description: 'change in closed positions' },
              { name: 'reduced_positions', type: 'number', description: 'number of reduced positions' },
              { name: 'last_reduced_positions', type: 'number', description: 'previous period reduced positions' },
              { name: 'reduced_positions_change', type: 'number', description: 'change in reduced positions' },
              { name: 'total_calls', type: 'number', description: 'total calls' },
              { name: 'last_total_calls', type: 'number', description: 'previous period total calls' },
              { name: 'total_calls_change', type: 'number', description: 'change in total calls' },
              { name: 'total_puts', type: 'number', description: 'total puts' },
              { name: 'last_total_puts', type: 'number', description: 'previous period total puts' },
              { name: 'total_puts_change', type: 'number', description: 'change in total puts' },
              { name: 'put_call_ratio', type: 'number', description: 'put call ratio' },
              { name: 'last_put_call_ratio', type: 'number', description: 'previous period put call ratio' },
              { name: 'put_call_ratio_change', type: 'number', description: 'change in put call ratio' },
            ],
          },
        ],
        ref: createReferenceWithTitle(
          getInstitutionOwnershipSummaryRef,
          params,
          buildGetInstitutionOwnershipSummaryCallDescription
        ),
      },
    },
    run: (inputs) => {
      const raw = inputs.institution_ownership_summary_raw;

      // 兼容 {success, response:{data}} 和 {data:{data}} 两种结构
      const container = (raw && (raw.response || raw.data)) || {};
      const summaries = Array.isArray(container.summary) ? container.summary : [];
      if (summaries.length === 0) {
        // 没有数据就不追加
        return undefined;
      }

      // 1) 从数据里推导一个确定性的 snapshot 时间（最新 date）
      let snapshotTime = Number.NEGATIVE_INFINITY;
      for (const s of summaries) {
        const t = parseToMs(s.date);
        if (Number.isFinite(t) && t > snapshotTime) snapshotTime = t;
      }
      if (!Number.isFinite(snapshotTime)) {
        throw new Error('No valid snapshot time found in ownership summary data');
      }

      // 2) Map all summaries into the nested array
      const summariesData = summaries.map((s) => ({
        symbol: s.symbol,
        cik: s.cik,
        date: s.date,
        investors_holding: s.investors_holding,
        last_investors_holding: s.last_investors_holding,
        investors_holding_change: s.investors_holding_change,
        number_of_13f_shares: s.number_of_13f_shares,
        last_number_of_13f_shares: s.last_number_of_13f_shares,
        number_of_13f_shares_change: s.number_of_13f_shares_change,
        total_invested: s.total_invested,
        last_total_invested: s.last_total_invested,
        total_invested_change: s.total_invested_change,
        ownership_percent: s.ownership_percent,
        last_ownership_percent: s.last_ownership_percent,
        ownership_percent_change: s.ownership_percent_change,
        new_positions: s.new_positions,
        last_new_positions: s.last_new_positions,
        new_positions_change: s.new_positions_change,
        increased_positions: s.increased_positions,
        last_increased_positions: s.last_increased_positions,
        increased_positions_change: s.increased_positions_change,
        closed_positions: s.closed_positions,
        last_closed_positions: s.last_closed_positions,
        closed_positions_change: s.closed_positions_change,
        reduced_positions: s.reduced_positions,
        last_reduced_positions: s.last_reduced_positions,
        reduced_positions_change: s.reduced_positions_change,
        total_calls: s.total_calls,
        last_total_calls: s.last_total_calls,
        total_calls_change: s.total_calls_change,
        total_puts: s.total_puts,
        last_total_puts: s.last_total_puts,
        total_puts_change: s.total_puts_change,
        put_call_ratio: s.put_call_ratio,
        last_put_call_ratio: s.last_put_call_ratio,
        put_call_ratio_change: s.put_call_ratio_change,
      }));

      // 可选：排序，便于下游一致性
      summariesData.sort((a, b) => {
        const ta = parseToMs(a.date) ?? -1;
        const tb = parseToMs(b.date) ?? -1;
        if (tb !== ta) return tb - ta;
        return (a.symbol || '').localeCompare(b.symbol || '');
      });

      // 3) 返回单条快照（外层唯一 date，内层嵌套数组）
      return {
        ownership_summary_snapshot: [
          {
            date: snapshotTime,
            summaries: summariesData,
          },
        ],
      };
    },
  };
}

// Base description string for getInstitutionOwnershipSummary (internal use)
const getInstitutionOwnershipSummaryBaseDesc = 'Retrieve institutional ownership summary';

// Build a dynamic, human-readable call description (internal use)
function buildGetInstitutionOwnershipSummaryCallDescription(actualParams = {}) {
  const parts = [getInstitutionOwnershipSummaryBaseDesc];

  // Primary subject
  const targets = [];
  if (actualParams.symbol) targets.push(`${actualParams.symbol}`);
  if (actualParams.cik) targets.push(`CIK ${actualParams.cik}`);
  if (targets.length > 0) {
    parts.push(`for ${targets.join(' & ')}`);
  }

  // Additional filters
  const filters = [];
  const q = Number(actualParams.quarter);
  const y = Number(actualParams.year);
  if (Number.isFinite(y) && Number.isFinite(q) && [1, 2, 3, 4].includes(q)) {
    filters.push(`Period: ${y} Q${q}`);
  } else {
    if (Number.isFinite(y)) filters.push(`Year: ${y}`);
    if (Number.isFinite(q) && [1, 2, 3, 4].includes(q)) filters.push(`Quarter: Q${q}`);
  }
  if (actualParams.limit != null && actualParams.limit !== '' && Number.isFinite(Number(actualParams.limit))) {
    filters.push(`Limit: ${Number(actualParams.limit)}`);
  }

  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }

  return parts.join(' ').trim();
}

// Collect and return all reference objects defined in this module
function getRefs() {
  return [
    getInstitutionOwnershipSummaryRef,
  ];
}

module.exports = {
  getInstitutionOwnershipSummary,
  makeInstitutionOwnershipSummaryNode,
  getRefs,
};
