function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}
const { getInstitutionOwnershipSummary } = require('@arrays/data/stock/institution/ownership-summary:v1.0.0');

function testGetInstitutionOwnershipSummary() {
  console.log('\n=== Testing getInstitutionOwnershipSummary (Direct) ===');

  let totalTests = 0;
  let passedTests = 0;

  function runTest(testName, testFunc) {
    totalTests++;
    try {
      testFunc();
      console.log(`✅ ${testName}`);
      passedTests++;
    } catch (e) {
      console.log(`❌ ${testName}: ${e.message}`);
    }
  }

  // Happy Path: basic by symbol
  runTest('basic by symbol (AAPL)', () => {
    const res = getInstitutionOwnershipSummary({ symbol: 'AAPL' });
    assert(res && typeof res === 'object', 'Should return an object');
    if (res.success) {
      assert(res.data && Array.isArray(res.data.summary), 'data.summary should be array when success');
      if (res.data.summary.length > 0) {
        const s = res.data.summary[0];
        assert(typeof s.symbol === 'string', 'summary[0].symbol must be string');
        assert(typeof s.date === 'string', 'summary[0].date must be string');
      }
    }
  });

  // Happy Path: by CIK only
  runTest('basic by cik only', () => {
    const res = getInstitutionOwnershipSummary({ cik: '0000320193' }); // Apple CIK
    assert(res && typeof res === 'object', 'Should return an object');
    if (res.success) {
      assert(res.data && Array.isArray(res.data.summary), 'data.summary should be array when success');
    }
  });

  // Happy Path: year + quarter with full enum coverage
  const TARGET_YEAR = 2023;
  [1, 2, 3, 4].forEach((q) => {
    runTest(`year+quarter enum coverage (year=${TARGET_YEAR}, q=${q})`, () => {
      const res = getInstitutionOwnershipSummary({ symbol: 'AAPL', year: TARGET_YEAR, quarter: q });
      assert(res && typeof res === 'object', 'Should return an object');
      if (res.success) {
        assert(res.data && Array.isArray(res.data.summary), 'data.summary should be array when success');
        // If there is data, validate a couple of fields
        const summaries = res.data.summary || [];
        if (summaries.length > 0) {
          const s = summaries[0];
          assert(typeof s.symbol === 'string', 'symbol should be string');
          assert(typeof s.date === 'string', 'date should be string');
        }
      }
    });
  });

  // Boundary Value Analysis: limit
  runTest('limit boundary: limit=1', () => {
    const res = getInstitutionOwnershipSummary({ symbol: 'AAPL', limit: 1 });
    assert(res && typeof res === 'object', 'Should return an object');
    if (res.success) {
      const arr = (res.data && res.data.summary) || [];
      assert(Array.isArray(arr), 'data.summary should be array');
      assert(arr.length <= 1, 'Should respect limit=1');
    }
  });

  runTest('limit boundary: large limit', () => {
    const res = getInstitutionOwnershipSummary({ symbol: 'AAPL', limit: 100 });
    assert(res && typeof res === 'object', 'Should return an object');
    if (res.success) {
      const arr = (res.data && res.data.summary) || [];
      assert(Array.isArray(arr), 'data.summary should be array');
      assert(arr.length <= 100, 'Should respect limit=100');
    }
  });

  // Boundary Value Analysis: quarter boundaries (1 and 4)
  runTest('quarter boundary: q=1', () => {
    const res = getInstitutionOwnershipSummary({ symbol: 'AAPL', year: TARGET_YEAR, quarter: 1 });
    assert(res && typeof res === 'object', 'Should return an object');
  });

  runTest('quarter boundary: q=4', () => {
    const res = getInstitutionOwnershipSummary({ symbol: 'AAPL', year: TARGET_YEAR, quarter: 4 });
    assert(res && typeof res === 'object', 'Should return an object');
  });

  // Boundary Value Analysis: year extremes (may return empty but should not crash)
  runTest('year boundary: very early year', () => {
    const res = getInstitutionOwnershipSummary({ symbol: 'AAPL', year: 1900, quarter: 1 });
    assert(res && typeof res === 'object', 'Should return an object even for old year');
  });

  runTest('year boundary: future year', () => {
    const res = getInstitutionOwnershipSummary({ symbol: 'AAPL', year: 2100, quarter: 1 });
    assert(res && typeof res === 'object', 'Should return an object even for future year');
  });

  // Special values: null/undefined/empty
  runTest('special values: symbol undefined', () => {
    const res = getInstitutionOwnershipSummary({});
    assert(res && typeof res === 'object', 'Should return an object without symbol');
  });

  runTest('special values: symbol null', () => {
    try {
      const res = getInstitutionOwnershipSummary({ symbol: null });
      assert(res && typeof res === 'object', 'Should return object or throw');
    } catch (e) {
      assert(e.message, 'Should throw an error message for null symbol');
    }
  });

  runTest('special values: symbol empty string', () => {
    try {
      const res = getInstitutionOwnershipSummary({ symbol: '' });
      assert(res && typeof res === 'object', 'Should return object or throw');
    } catch (e) {
      assert(e.message, 'Should throw an error message for empty symbol');
    }
  });

  runTest('special values: cik undefined', () => {
    const res = getInstitutionOwnershipSummary({ cik: undefined });
    assert(res && typeof res === 'object', 'Should handle undefined cik');
  });

  runTest('special values: cik empty string', () => {
    try {
      const res = getInstitutionOwnershipSummary({ cik: '' });
      assert(res && typeof res === 'object', 'Should return object or throw');
    } catch (e) {
      assert(e.message, 'Should throw an error message for empty cik');
    }
  });

  // Invalid quarter values
  runTest('invalid quarter: q=0', () => {
    try {
      getInstitutionOwnershipSummary({ symbol: 'AAPL', year: TARGET_YEAR, quarter: 0 });
      throw new Error('Expected error for quarter=0 but function succeeded');
    } catch (e) {
      assert(e.message.includes('quarter') || e.message.includes('Invalid') || e.message.includes('1|2|3|4'), 'Should report invalid quarter');
    }
  });

  runTest('invalid quarter: q=5', () => {
    try {
      getInstitutionOwnershipSummary({ symbol: 'AAPL', year: TARGET_YEAR, quarter: 5 });
      throw new Error('Expected error for quarter=5 but function succeeded');
    } catch (e) {
      assert(e.message.includes('quarter') || e.message.includes('Invalid') || e.message.includes('1|2|3|4'), 'Should report invalid quarter');
    }
  });

  runTest('invalid quarter type: q="2" (string)', () => {
    try {
      const res = getInstitutionOwnershipSummary({ symbol: 'AAPL', year: TARGET_YEAR, quarter: '2' });
      // Some implementations may coerce; accept either behavior as long as no crash
      assert(res && typeof res === 'object', 'Should return object or throw');
    } catch (e) {
      assert(e.message, 'Should throw an error message for string quarter');
    }
  });

  // Invalid/edge limit values
  runTest('invalid limit: 0', () => {
    try {
      const res = getInstitutionOwnershipSummary({ symbol: 'AAPL', limit: 0 });
      assert(res && typeof res === 'object', 'Should return object or throw');
      if (res.success) {
        const arr = (res.data && res.data.summary) || [];
        assert(Array.isArray(arr), 'data.summary should be array');
      }
    } catch (e) {
      assert(e.message, 'Should throw an error for invalid limit');
    }
  });

  runTest('invalid limit: negative', () => {
    try {
      getInstitutionOwnershipSummary({ symbol: 'AAPL', limit: -5 });
      throw new Error('Expected error for negative limit but function succeeded');
    } catch (e) {
      assert(e.message.includes('limit') || e.message.includes('Invalid'), 'Should report invalid limit');
    }
  });

  // Combined filters
  runTest('combined filters: symbol + year + quarter + limit', () => {
    const res = getInstitutionOwnershipSummary({ symbol: 'AAPL', year: 2022, quarter: 2, limit: 3 });
    assert(res && typeof res === 'object', 'Should return an object');
    if (res.success) {
      const arr = (res.data && res.data.summary) || [];
      assert(Array.isArray(arr), 'data.summary should be array');
      assert(arr.length <= 3, 'Should respect limit=3');
    }
  });

  // Print summary for direct tests
  console.log('\n=== getInstitutionOwnershipSummary Test Summary ===');
  console.log(`Total tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${totalTests - passedTests}`);
  console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function main() {
  const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
  const { jagentId } = require('env');
  const { makeInstitutionOwnershipSummaryNode } = require('@arrays/data/stock/institution/ownership-summary:v1.0.0');

  // Smoke test - basic functionality test
  const g = new Graph(jagentId);
  g.addNode('ownership_summary_smoke', makeInstitutionOwnershipSummaryNode({ symbol: 'AAPL', year: 2023, quarter: 4 }));
  g.run();

  // Mock test - using sample data to avoid network dependency
  const nodeCfg = makeInstitutionOwnershipSummaryNode({ symbol: 'AAPL', year: 2023, quarter: 4 });

  // Override input with mock data that matches the API response structure
  nodeCfg.inputs.institution_ownership_summary_raw = () => ({
    data: {
      summary: [
        {
          symbol: 'AAPL',
          cik: '0000320193',
          date: '2024-03-31',
          investors_holding: 5239,
          last_investors_holding: 5186,
          investors_holding_change: 53,
          number_of_13f_shares: 9228814504,
          last_number_of_13f_shares: 9324080218,
          number_of_13f_shares_change: -95265714,
          total_invested: 1591025857877,
          last_total_invested: 1803399946568,
          total_invested_change: -212374088691,
          ownership_percent: 59.9046,
          last_ownership_percent: 60.1175,
          ownership_percent_change: -0.2129,
          new_positions: 208,
          last_new_positions: 527,
          new_positions_change: -319,
          increased_positions: 2148,
          last_increased_positions: 2260,
          increased_positions_change: -112,
          closed_positions: 172,
          last_closed_positions: 158,
          closed_positions_change: 14,
          reduced_positions: 2588,
          last_reduced_positions: 2460,
          reduced_positions_change: 128,
          total_calls: 155510300,
          last_total_calls: 172887581,
          total_calls_change: -17377281,
          total_puts: 152947118,
          last_total_puts: 176362559,
          total_puts_change: -23415441,
          put_call_ratio: 0.9835,
          last_put_call_ratio: 1.0201,
          put_call_ratio_change: -3.6582,
        },
      ],
    },
  });

  const g2 = new Graph(jagentId);
  g2.addNode('ownership_summary_mock', nodeCfg);
  g2.run();

  // Validate mock data output
  const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'ownership_summary_mock', 'ownership_summary_snapshot', { last: '5' }), g2.store);
  ts.init();

  if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('snapshot empty');
  const snap = ts.data[0];
  ['date', 'summaries'].forEach((k) => {
    if (!(k in snap)) throw new Error('missing snapshot field: ' + k);
  });
  if (!Array.isArray(snap.summaries) || snap.summaries.length !== 1) throw new Error('summaries length must be 1 in mock');

  const s0 = snap.summaries[0];
  [
    'symbol',
    'cik',
    'date',
    'investors_holding',
    'number_of_13f_shares',
    'total_invested',
    'ownership_percent',
    'new_positions',
    'increased_positions',
    'closed_positions',
    'reduced_positions',
    'total_calls',
    'total_puts',
    'put_call_ratio',
  ].forEach((k) => {
    if (!(k in s0)) throw new Error('missing summary field: ' + k);
  });

  // Validate smoke test output
  const tsSmoke = new TimeSeries(new TimeSeriesUri(jagentId, 'ownership_summary_smoke', 'ownership_summary_snapshot', { last: '5' }), g.store);
  tsSmoke.init();
  if (!Array.isArray(tsSmoke.data)) throw new Error('smoke test data must be an array');
  if (tsSmoke.data.length > 0) {
    const r = tsSmoke.data[0];
    if (typeof r.date !== 'number') throw new Error('smoke.date must be number(ms)');
    if (!Array.isArray(r.summaries)) throw new Error('smoke.summaries must be array');
    if (r.summaries.length > 0) {
      const summary = r.summaries[0];
      if (typeof summary.symbol !== 'string') throw new Error('smoke.summary.symbol must be string');
    }
  }

  // Validate refs metadata for ownership_summary_snapshot
  const refs = g.getRefsForOutput('ownership_summary_smoke', 'ownership_summary_snapshot');
  if (refs.length === 0) throw new Error('Assertion failed: refs array is empty for ownership_summary_snapshot.');
  const ref = refs[0];
  const expected = {
    id: '@arrays/data/stock/institution/ownership-summary/getInstitutionOwnershipSummary',
    module_name: '@arrays/data/stock/institution/ownership-summary',
    module_display_name: 'Stock Institution Holdings Summary',
    sdk_name: 'getInstitutionOwnershipSummary',
    sdk_display_name: 'Stock Institution Holdings Summary',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/stable/positions-summary',
  };
  if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for ownership_summary_snapshot');
  if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for ownership_summary_snapshot');
  if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for ownership_summary_snapshot');
  if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for ownership_summary_snapshot');
  if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for ownership_summary_snapshot');
  if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for ownership_summary_snapshot');
  if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for ownership_summary_snapshot');

  // Run the direct get() function test suite at the end
  testGetInstitutionOwnershipSummary();

  return 0;
}

main();
