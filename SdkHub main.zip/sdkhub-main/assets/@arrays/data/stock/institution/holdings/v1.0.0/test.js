function assert(cond, msg) {
    if (!cond) throw new Error(msg || 'Assertion failed');
}
assert.strictEqual = function(actual, expected, msg) {
    if (actual !== expected) {
        throw new Error(msg || `Expected ${expected} but got ${actual}`);
    }
};

function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeInstitutionHoldingsNode, getInstitutionHoldings } = require('@arrays/data/stock/institution/holdings:v1.0.0');

    // =========================
    // Graph/Node-based tests
    // =========================
    // Smoke test - basic functionality test
    const g = new Graph(jagentId);
    g.addNode('institutional_holdings_smoke', makeInstitutionHoldingsNode({ cik: '0001388838', year: 2023, quarter: 4 }));
    g.run();

    // Mock test - using sample data to avoid network dependency
    const nodeCfg = makeInstitutionHoldingsNode({ cik: '0001388838', year: 2023, quarter: 4 });

    // Override input with mock data that matches the API response structure
    nodeCfg.inputs.institution_holdings_raw = () => ({
        success: true,
        data: [
                {
                    date: '2024-03-31',
                    filing_date: '2024-05-15',
                    accepted_date: '2024-05-15',
                    cik: '0001388838',
                    security_cusip: '02390A101',
                    symbol: 'AMX',
                    name_of_issuer: 'AMERICA MOVIL SAB DE CV',
                    shares: 176300,
                    title_of_class: 'SPON ADS RP CL B',
                    shares_type: 'SH',
                    value: 3289758,
                    link: 'https://www.sec.gov/Archives/edgar/data/1388838/000117266124002373/0001172661-24-002373-index.htm',
                    final_link: 'https://www.sec.gov/Archives/edgar/data/1388838/000117266124002373/infotable.xml',
                },
                {
                    date: '2024-03-31',
                    filing_date: '2024-05-15',
                    accepted_date: '2024-05-15',
                    cik: '0001388838',
                    security_cusip: '040413106',
                    symbol: 'ANET',
                    name_of_issuer: 'ARISTA NETWORKS INC',
                    shares: 11300,
                    title_of_class: 'COM',
                    shares_type: 'SH',
                    value: 3276774,
                    link: 'https://www.sec.gov/Archives/edgar/data/1388838/000117266124002373/0001172661-24-002373-index.htm',
                    final_link: 'https://www.sec.gov/Archives/edgar/data/1388838/000117266124002373/infotable.xml',
                },
                {
                    date: '2024-03-31',
                    filing_date: '2024-05-15',
                    accepted_date: '2024-05-15',
                    cik: '0001388838',
                    security_cusip: 'G3922B107',
                    symbol: 'G',
                    name_of_issuer: 'GENPACT LIMITED',
                    shares: 367776,
                    title_of_class: 'SHS',
                    shares_type: 'SH',
                    value: 12118219,
                    link: 'https://www.sec.gov/Archives/edgar/data/1388838/000117266124002373/0001172661-24-002373-index.htm',
                    final_link: 'https://www.sec.gov/Archives/edgar/data/1388838/000117266124002373/infotable.xml',
                },
            ],
    });

    const g2 = new Graph(jagentId);
    g2.addNode('institutional_holdings_mock', nodeCfg);
    g2.run();

    // Validate mock data output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'institutional_holdings_mock', 'institutional_holdings_snapshot', { last: '5' }), g2.store);
    ts.init();

    if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('snapshot empty');
    const snap = ts.data[0];
    ['date', 'holdings'].forEach((k) => {
        if (!(k in snap)) throw new Error('missing snapshot field: ' + k);
    });
    if (!Array.isArray(snap.holdings) || snap.holdings.length !== 3) throw new Error('holdings length must be 3 in mock');

    const h0 = snap.holdings[0];
    ['report_date', 'filing_date', 'accepted_date', 'cik', 'security_cusip', 'symbol', 'name_of_issuer', 'shares', 'title_of_class', 'shares_type', 'value', 'link', 'final_link'].forEach((k) => {
        if (!(k in h0)) throw new Error('missing holding field: ' + k);
    });

    // Validate refs for institutional_holdings_snapshot
    const refsHoldings = g2.getRefsForOutput('institutional_holdings_mock', 'institutional_holdings_snapshot');
    if (Array.isArray(refsHoldings) && refsHoldings.length > 0) {
        const ref = refsHoldings[0];
        const expected = {
            id: '@arrays/data/stock/institution/holdings/getInstitutionHoldings',
            module_name: '@arrays/data/stock/institution/holdings',
            module_display_name: 'Institutional Holdings',
            sdk_name: 'getInstitutionHoldings',
            sdk_display_name: 'Institutional Holdings',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stable/latest-filings',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for institutional_holdings_snapshot');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for institutional_holdings_snapshot');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for institutional_holdings_snapshot');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for institutional_holdings_snapshot');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for institutional_holdings_snapshot');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for institutional_holdings_snapshot');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for institutional_holdings_snapshot');
    } else {
        throw new Error('Assertion failed: refsHoldings array is empty.');
    }

    // Validate smoke test output
    const tsSmoke = new TimeSeries(new TimeSeriesUri(jagentId, 'institutional_holdings_smoke', 'institutional_holdings_snapshot', { last: '5' }), g.store);
    tsSmoke.init();
    if (!Array.isArray(tsSmoke.data)) throw new Error('smoke test data must be an array');
    if (tsSmoke.data.length > 0) {
        const r = tsSmoke.data[0];
        if (typeof r.date !== 'number') throw new Error('smoke.date must be number(ms)');
        if (!Array.isArray(r.holdings)) throw new Error('smoke.holdings must be array');
        if (r.holdings.length > 0) {
            const holding = r.holdings[0];
            if (typeof holding.name_of_issuer !== 'string') throw new Error('smoke.holding.name_of_issuer must be string');
        }
    }

    // =========================
    // Direct getInstitutionHoldings tests (manual import required)
    // =========================
    console.log('\n=== Testing getInstitutionHoldings (Direct) ===');

    let totalTests = 0;
    let passedTests = 0;

    function runTest(name, fn) {
        totalTests++;
        try {
            fn();
            console.log(`✅ ${name}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${name}: ${e && e.message ? e.message : e}`);
        }
    }

    function expectSuccessShape(result, prefix) {
        assert(result && typeof result === 'object', `${prefix}: result should be an object`);
        assert.strictEqual(typeof result.success, 'boolean', `${prefix}: success should be boolean`);
        if (result.success) {
            if ('count' in result) {
                assert.strictEqual(typeof result.count, 'number', `${prefix}: count should be number`);
            }
            assert(Array.isArray(result.data), `${prefix}: data should be an array`);
            if (result.data.length > 0) {
                const item = result.data[0];
                [
                    'date',
                    'filing_date',
                    'accepted_date',
                    'cik',
                    'security_cusip',
                    'symbol',
                    'name_of_issuer',
                    'shares',
                    'title_of_class',
                    'shares_type',
                    'value',
                    'link',
                    'final_link',
                ].forEach((k) => assert(k in item, `${prefix}: missing field ${k}`));
            }
        }
    }

    function assertThrowsOrUnsuccessful(executor, message) {
        let threw = false;
        try {
            const res = executor();
            if (res && typeof res === 'object' && 'success' in res) {
                assert.strictEqual(res.success, false, `${message}: expected success=false`);
            } else if (res && Array.isArray(res.data)) {
                assert.strictEqual(res.data.length, 0, `${message}: expected empty data when invalid params`);
            } else {
                // Unknown shape but did not throw — allow but record assertion to ensure test accounted for execution
                assert(true, `${message}: returned unknown shape`);
            }
        } catch (e) {
            threw = true;
            assert(threw, `${message}: expected to throw or be unsuccessful`);
        }
    }

    // --- Happy Path: Cover all quarter enum values 1|2|3|4 with cik ---
    [1, 2, 3, 4].forEach((q) => {
        runTest(`happy path with cik=0000320193 (Apple), year=2023, quarter=${q}`, () => {
            const res = getInstitutionHoldings({ cik: '0000320193', year: 2023, quarter: q });
            // Some CIKs may return different structure or empty data
            if (res && typeof res === 'object' && res.success && Array.isArray(res.data)) {
                expectSuccessShape(res, `CIK 0000320193 q=${q}`);
            }
            // Otherwise accept different structure or no data
        });
    });

    // --- Happy Path: Using CIK with all quarter enum values ---
    [1, 2, 3, 4].forEach((q) => {
        runTest(`happy path with cik=0001388838, year=2023, quarter=${q}`, () => {
            const res = getInstitutionHoldings({ cik: '0001388838', year: 2023, quarter: q });
            expectSuccessShape(res, `CIK q=${q}`);
        });
    });

    // --- Boundary Value Analysis ---
    runTest('boundary: minimum quarter=1', () => {
        const res = getInstitutionHoldings({ cik: '0001388838', year: 2023, quarter: 1 });
        expectSuccessShape(res, 'Boundary quarter=1');
    });

    runTest('boundary: maximum quarter=4', () => {
        const res = getInstitutionHoldings({ cik: '0001388838', year: 2023, quarter: 4 });
        expectSuccessShape(res, 'Boundary quarter=4');
    });

    runTest('boundary: missing quarter (optional)', () => {
        const res = getInstitutionHoldings({ cik: '0001388838', year: 2023 });
        expectSuccessShape(res, 'Missing quarter');
    });

    runTest('boundary: plausible current year', () => {
        const y = new Date().getUTCFullYear();
        const res = getInstitutionHoldings({ cik: '0001388838', year: y, quarter: 1 });
        expectSuccessShape(res, `Year=${y}`);
    });

    runTest('boundary: very old year (expect empty or unsuccessful)', () => {
        assertThrowsOrUnsuccessful(() => getInstitutionHoldings({ cik: '0001388838', year: 1900, quarter: 1 }), 'Very old year');
    });

    runTest('boundary: far future year (expect empty or unsuccessful)', () => {
        assertThrowsOrUnsuccessful(() => getInstitutionHoldings({ cik: '0001388838', year: 3000, quarter: 1 }), 'Far future year');
    });

    // --- Special Values ---
    runTest('special: cik empty string', () => {
        assertThrowsOrUnsuccessful(() => getInstitutionHoldings({ cik: '', year: 2023, quarter: 2 }), 'Empty cik');
    });

    runTest('special: cik null', () => {
        assertThrowsOrUnsuccessful(() => getInstitutionHoldings({ cik: null, year: 2023, quarter: 2 }), 'Null cik');
    });

    runTest('special: cik undefined (omitted)', () => {
        assertThrowsOrUnsuccessful(() => getInstitutionHoldings({ year: 2023, quarter: 2 }), 'Undefined/omitted cik (required)');
    });

    runTest('special: year undefined (omitted)', () => {
        assertThrowsOrUnsuccessful(() => getInstitutionHoldings({ cik: '0001388838', quarter: 2 }), 'Undefined/omitted year (required)');
    });

    runTest('special: year null', () => {
        assertThrowsOrUnsuccessful(() => getInstitutionHoldings({ cik: '0001388838', year: null, quarter: 2 }), 'Null year');
    });

    runTest('special: no parameters (expect broad results or unsuccessful)', () => {
        // Depending on backend, this may either return broad results or error. Test should pass either way.
        try {
            const res = getInstitutionHoldings({});
            if (res && typeof res === 'object' && 'success' in res) {
                // Accept success true/false; if true, validate shape
                if (res.success) expectSuccessShape(res, 'No params');
                else assert.strictEqual(res.success, false, 'No params: success should be false when not supported');
            } else {
                // Unknown shape but call succeeded
                assert(true, 'No params: call returned without throwing');
            }
        } catch (e) {
            // Throwing is acceptable for no-params scenario
            assert(true, 'No params: threw as expected');
        }
    });

    // --- Invalid enum/type combinations ---
    runTest('invalid: quarter=0 (below range)', () => {
        assertThrowsOrUnsuccessful(() => getInstitutionHoldings({ cik: '0001388838', year: 2023, quarter: 0 }), 'Quarter below range');
    });

    runTest('invalid: quarter=5 (above range)', () => {
        assertThrowsOrUnsuccessful(() => getInstitutionHoldings({ cik: '0001388838', year: 2023, quarter: 5 }), 'Quarter above range');
    });

    runTest('invalid: quarter=-1 (negative)', () => {
        assertThrowsOrUnsuccessful(() => getInstitutionHoldings({ cik: '0001388838', year: 2023, quarter: -1 }), 'Negative quarter');
    });

    runTest('invalid: quarter as string', () => {
        assertThrowsOrUnsuccessful(() => getInstitutionHoldings({ cik: '0001388838', year: 2023, quarter: '1' }), 'Quarter as string');
    });

    runTest('invalid: year as string', () => {
        assertThrowsOrUnsuccessful(() => getInstitutionHoldings({ cik: '0001388838', year: '2023', quarter: 1 }), 'Year as string');
    });

    runTest('special: quarter null', () => {
        assertThrowsOrUnsuccessful(() => getInstitutionHoldings({ cik: '0001388838', year: 2023, quarter: null }), 'Quarter null');
    });

    // Print test summary for direct calls
    console.log('\n=== getInstitutionHoldings Direct Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    return 0;
}

main();
