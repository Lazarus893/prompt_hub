function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeInstitutionOwnershipAnalyticsNode, getInstitutionOwnershipAnalytics } = require('@arrays/data/stock/institution/ownership-analytics:v1.0.0');

    // Simple assert helper (mirrors example style usage)
    function assert(condition, message) {
        if (!condition) throw new Error(message || 'Assertion failed');
    }

    // ================= Graph/Node based tests (existing) =================
    // Smoke test - basic functionality test
    const g = new Graph(jagentId);
    g.addNode('ownership_analytics_smoke', makeInstitutionOwnershipAnalyticsNode({ symbol: 'AAPL', year: 2023, quarter: 4 }));
    g.run();

    // Mock test - using sample data to avoid network dependency
    const nodeCfg = makeInstitutionOwnershipAnalyticsNode({ symbol: 'AAPL', year: 2023, quarter: 4 });

    // Override input with mock data that matches the API response structure
    nodeCfg.inputs.institution_ownership_analytics_raw = () => ({
        data: {
            analytics: [
                {
                    date: '2024-03-31',
                    cik: '0000102909',
                    filing_date: '2024-05-10',
                    investor_name: 'VANGUARD GROUP INC',
                    symbol: 'AAPL',
                    security_name: 'APPLE INC',
                    type_of_security: 'COM',
                    security_cusip: '037833100',
                    shares_type: 'SH',
                    put_call_share: 'Share',
                    investment_discretion: 'DFND',
                    industry_title: 'ELECTRONIC COMPUTERS',
                    weight: 4.4795,
                    last_weight: 5.5438,
                    change_in_weight: -1.0642,
                    change_in_weight_percentage: -19.1969,
                    market_value: 226158046670,
                    last_market_value: 253766929171,
                    change_in_market_value: -27608882501,
                    change_in_market_value_percentage: -10.8796,
                    shares_number: 1318859614,
                    last_shares_number: 1318064349,
                    change_in_shares_number: 795265,
                    change_in_shares_number_percentage: 0.0603,
                    quarter_end_price: 170.03,
                    avg_price_paid: 23.1,
                    is_new: false,
                    is_sold_out: false,
                    ownership: 8.5608,
                    last_ownership: 8.4983,
                    change_in_ownership: 0.0625,
                    change_in_ownership_percentage: 0.7352,
                    holding_period: 77,
                    first_added: '2005-03-31',
                    performance: -29656447852,
                    performance_percentage: -11.6865,
                    last_performance: 27715938875,
                    change_in_performance: -57372386727,
                    is_counted_for_performance: true,
                },
                {
                    date: '2024-03-31',
                    cik: '0001364742',
                    filing_date: '2024-05-10',
                    investor_name: 'BLACKROCK INC.',
                    symbol: 'AAPL',
                    security_name: 'APPLE INC',
                    type_of_security: 'COM',
                    security_cusip: '037833100',
                    shares_type: 'SH',
                    put_call_share: 'Share',
                    investment_discretion: 'SOLE',
                    industry_title: 'ELECTRONIC COMPUTERS',
                    weight: 4.1536,
                    last_weight: 5.1171,
                    change_in_weight: -0.9635,
                    change_in_weight_percentage: -18.8289,
                    market_value: 178428953659,
                    last_market_value: 200691694824,
                    change_in_market_value: -22262741165,
                    change_in_market_value_percentage: -11.093,
                    shares_number: 1040523406,
                    last_shares_number: 1042391808,
                    change_in_shares_number: -1868402,
                    change_in_shares_number_percentage: -0.1792,
                    quarter_end_price: 170.03,
                    avg_price_paid: 40.43,
                    is_new: false,
                    is_sold_out: false,
                    ownership: 6.7541,
                    last_ownership: 6.7209,
                    change_in_ownership: 0.0332,
                    change_in_ownership_percentage: 0.494,
                    holding_period: 67,
                    first_added: '2007-09-28',
                    performance: -23453815680,
                    performance_percentage: -11.6865,
                    last_performance: 21989609029,
                    change_in_performance: -45443424709,
                    is_counted_for_performance: true,
                },
            ],
        },
    });

    const g2 = new Graph(jagentId);
    g2.addNode('ownership_analytics_mock', nodeCfg);
    g2.run();

    // Validate mock data output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'ownership_analytics_mock', 'ownership_analytics_snapshot', { last: '5' }), g2.store);
    ts.init();

    if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('snapshot empty');
    const snap = ts.data[0];
    ['date', 'analytics'].forEach((k) => {
        if (!(k in snap)) throw new Error('missing snapshot field: ' + k);
    });
    if (!Array.isArray(snap.analytics) || snap.analytics.length !== 2) throw new Error('analytics length must be 2 in mock');

    const a0 = snap.analytics[0];
    [
        'date',
        'cik',
        'filing_date',
        'investor_name',
        'symbol',
        'security_name',
        'type_of_security',
        'security_cusip',
        'shares_type',
        'put_call_share',
        'investment_discretion',
        'industry_title',
        'weight',
        'market_value',
        'shares_number',
        'ownership',
        'performance',
    ].forEach((k) => {
        if (!(k in a0)) throw new Error('missing analytics field: ' + k);
    });

    // Validate smoke test output
    const tsSmoke = new TimeSeries(new TimeSeriesUri(jagentId, 'ownership_analytics_smoke', 'ownership_analytics_snapshot', { last: '5' }), g.store);
    tsSmoke.init();
    if (!Array.isArray(tsSmoke.data)) throw new Error('smoke test data must be an array');
    if (tsSmoke.data.length > 0) {
        const r = tsSmoke.data[0];
        if (typeof r.date !== 'number') throw new Error('smoke.date must be number(ms)');
        if (!Array.isArray(r.analytics)) throw new Error('smoke.analytics must be array');
        if (r.analytics.length > 0) {
            const analytics = r.analytics[0];
            if (typeof analytics.investor_name !== 'string') throw new Error('smoke.analytics.investor_name must be string');
        }
    }

    // Validate refs for ownership_analytics_snapshot output
    const refs = g2.getRefsForOutput('ownership_analytics_mock', 'ownership_analytics_snapshot');
    if (refs.length > 0) {
        const ref = refs[0];
        const expected = {
            id: '@arrays/data/stock/institution/ownership-analytics/getInstitutionOwnershipAnalytics',
            module_name: '@arrays/data/stock/institution/ownership-analytics',
            module_display_name: 'Stock Institutional Ownership Analytics',
            sdk_name: 'getInstitutionOwnershipAnalytics',
            sdk_display_name: 'Institution Ownership Analytics',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stable/filings-extract-with-analytics-by-holder',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for ownership_analytics_snapshot');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for ownership_analytics_snapshot');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for ownership_analytics_snapshot');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for ownership_analytics_snapshot');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for ownership_analytics_snapshot');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for ownership_analytics_snapshot');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for ownership_analytics_snapshot');
    } else {
        throw new Error('Assertion failed: refs array is empty for ownership_analytics_snapshot');
    }

    // ================= Direct get* function tests =================
    function testGetInstitutionOwnershipAnalytics() {
        console.log('\n=== Testing getInstitutionOwnershipAnalytics (Direct) ===');

        let totalTests = 0;
        let passedTests = 0;

        function runTest(name, fn) {
            totalTests++;
            try {
                fn();
                console.log(`✅ ${name}`);
                passedTests++;
            } catch (e) {
                console.log(`❌ ${name}: ${e.message}`);
            }
        }

        // Helper to validate basic APIResponse structure
        function expectAPIResponseStructure(res, label) {
            assert(res && typeof res === 'object', `Response must be object: ${label}`);
            assert(typeof res.success === 'boolean', `Response.success must be boolean: ${label}`);
            const analytics = Array.isArray(res.data)
                ? res.data
                : (res.data && res.data.analytics);
            assert(Array.isArray(analytics), `Response analytics must be array: ${label}`);
            return analytics;
        }

        // --- Happy Path ---
        runTest('Happy Path: symbol + year + quarter', () => {
            const res = getInstitutionOwnershipAnalytics({ symbol: 'AAPL', year: 2023, quarter: 4 });
            expectAPIResponseStructure(res, 'symbol+year+quarter');
        });

        runTest('Happy Path: cik + year + quarter + limit', () => {
            const res = getInstitutionOwnershipAnalytics({ symbol: 'AAPL', cik: '0000102909', year: 2023, quarter: 4, limit: 5 });
            const analytics = expectAPIResponseStructure(res, 'cik+year+quarter');
            assert(analytics.length <= 5, 'Should respect limit=5');
        });

        // --- Boundary Value Analysis ---
        // Quarter enumeration coverage (1..4)
        [1, 2, 3, 4].forEach((q) => {
            runTest(`Quarter enum coverage: q=${q}`, () => {
                const res = getInstitutionOwnershipAnalytics({ symbol: 'AAPL', year: 2023, quarter: q, limit: 2 });
                const analytics = expectAPIResponseStructure(res, `quarter=${q}`);
                assert(analytics.length <= 2, 'Should respect limit=2');
            });
        });

        // Limit boundaries
        runTest('Boundary: limit=1', () => {
            const res = getInstitutionOwnershipAnalytics({ symbol: 'AAPL', year: 2023, quarter: 4, limit: 1 });
            const analytics = expectAPIResponseStructure(res, 'limit=1 with year+quarter');
            assert(analytics.length <= 1, 'Should respect limit=1');
        });

        runTest('Boundary: reasonably large limit=100', () => {
            const res = getInstitutionOwnershipAnalytics({ symbol: 'AAPL', year: 2023, quarter: 4, limit: 100 });
            expectAPIResponseStructure(res, 'limit=100 with year+quarter');
        });

        // --- Special Values ---
        runTest('Special: empty params object {}', () => {
            try {
                getInstitutionOwnershipAnalytics({});
                throw new Error('Expected error but function succeeded for empty params');
            } catch (e) {
                assert(e.message, 'Should throw or report error for empty params');
            }
        });

        runTest('Special: empty string symbol', () => {
            try {
                getInstitutionOwnershipAnalytics({ symbol: '' });
                throw new Error('Expected error but function succeeded for empty symbol');
            } catch (e) {
                assert(e.message, 'Should throw or report error for empty symbol');
            }
        });

        runTest('Special: null symbol', () => {
            try {
                getInstitutionOwnershipAnalytics({ symbol: null });
                throw new Error('Expected error but function succeeded for null symbol');
            } catch (e) {
                assert(e.message, 'Should throw or report error for null symbol');
            }
        });

        runTest('Special: undefined params (no argument)', () => {
            try {
                // Intentionally call without params
                // eslint-disable-next-line no-undef
                const res = getInstitutionOwnershipAnalytics();
                // If it does not throw, it should still provide a valid response shape
                expectAPIResponseStructure(res, 'no-arg');
            } catch (e) {
                // Acceptable if SDK enforces params object
                assert(e.message, 'Should handle undefined params with error or valid response');
            }
        });

        // --- Invalid/Out-of-range values ---
        runTest('Invalid quarter: 0', () => {
            try {
                getInstitutionOwnershipAnalytics({ symbol: 'AAPL', year: 2023, quarter: 0 });
                throw new Error('Expected error but function succeeded for quarter=0');
            } catch (e) {
                assert(e.message, 'Should error for invalid quarter=0');
            }
        });

        runTest('Invalid quarter: 5', () => {
            try {
                getInstitutionOwnershipAnalytics({ symbol: 'AAPL', year: 2023, quarter: 5 });
                throw new Error('Expected error but function succeeded for quarter=5');
            } catch (e) {
                assert(e.message, 'Should error for invalid quarter=5');
            }
        });

        runTest('Invalid quarter: -1', () => {
            try {
                getInstitutionOwnershipAnalytics({ symbol: 'AAPL', year: 2023, quarter: -1 });
                throw new Error('Expected error but function succeeded for quarter=-1');
            } catch (e) {
                assert(e.message, 'Should error for invalid quarter=-1');
            }
        });

        runTest('Invalid year type: year="2023" (string)', () => {
            try {
                getInstitutionOwnershipAnalytics({ symbol: 'AAPL', year: '2023', quarter: 4 });
                throw new Error('Expected error but function succeeded for year as string');
            } catch (e) {
                assert(e.message, 'Should error for year as string');
            }
        });

        runTest('Invalid limit: 0', () => {
            try {
                getInstitutionOwnershipAnalytics({ symbol: 'AAPL', limit: 0 });
                throw new Error('Expected error but function succeeded for limit=0');
            } catch (e) {
                assert(e.message, 'Should error for invalid limit=0');
            }
        });

        runTest('Invalid limit: -5', () => {
            try {
                getInstitutionOwnershipAnalytics({ symbol: 'AAPL', limit: -5 });
                throw new Error('Expected error but function succeeded for limit=-5');
            } catch (e) {
                assert(e.message, 'Should error for invalid limit=-5');
            }
        });

        // Print test summary
        console.log('\n=== getInstitutionOwnershipAnalytics Test Summary ===');
        console.log(`Total tests: ${totalTests}`);
        console.log(`Passed: ${passedTests}`);
        console.log(`Failed: ${totalTests - passedTests}`);
        console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
    }

    // Run direct tests for get* API
    testGetInstitutionOwnershipAnalytics();

    return 0;
}

main();
