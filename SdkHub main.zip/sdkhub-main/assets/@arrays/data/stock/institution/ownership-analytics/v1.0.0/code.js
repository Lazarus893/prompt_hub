const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for this module's SDK and data source
const getInstitutionOwnershipAnalyticsRef = {
    id: '@arrays/data/stock/institution/ownership-analytics/getInstitutionOwnershipAnalytics',
    module_name: '@arrays/data/stock/institution/ownership-analytics',
    module_display_name: 'Stock Institutional Ownership Analytics',
    sdk_name: 'getInstitutionOwnershipAnalytics',
    sdk_display_name: 'Institution Ownership Analytics',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/stable/filings-extract-with-analytics-by-holder',
};
// Base description and dynamic call description builder (internal)
const baseGetInstitutionOwnershipAnalyticsDescription = 'Get institutional ownership analytics';

function buildGetInstitutionOwnershipAnalyticsCallDescription(actualParams = {}) {
    const parts = [baseGetInstitutionOwnershipAnalyticsDescription];

    // Primary selectors
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }
    if (actualParams.cik) {
        parts.push(`for investor CIK ${actualParams.cik}`);
    }

    // Optional filters
    const filters = [];
    if (actualParams.year != null) {
        filters.push(`Year: ${actualParams.year}`);
    }
    if (actualParams.quarter != null) {
        filters.push(`Quarter: ${actualParams.quarter}`);
    }
    if (actualParams.limit != null) {
        filters.push(`Limit: ${actualParams.limit}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getInstitutionOwnershipAnalytics(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/institution/ownership/analytics';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

/**
 * Parse various timestamp string formats to epoch ms (UTC).
 * Supported:
 * - ISO 8601 strings parsable by Date.parse
 * - 'YYYY-MM-DD HH:mm:ss'
 * - 'YYYY-MM-DD'
 * - 'MM-DD-YYYY' or 'MM/DD/YYYY'
 */
function parseToMs(s) {
    if (s == null) return undefined;
    if (typeof s !== 'string') return undefined;

    // Try native Date.parse first (handles many ISO variants)
    const parsed = Date.parse(s);
    if (!Number.isNaN(parsed)) return parsed;

    // 'YYYY-MM-DD HH:mm:ss'
    let m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/);
    if (m) {
        const y = +m[1];
        const mo = +m[2] - 1;
        const d = +m[3];
        const hh = +m[4];
        const mm = +m[5];
        const ss = +m[6];
        return Date.UTC(y, mo, d, hh, mm, ss, 0);
    }

    // 'YYYY-MM-DD'
    m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (m) {
        const y = +m[1];
        const mo = +m[2] - 1;
        const d = +m[3];
        return Date.UTC(y, mo, d, 0, 0, 0, 0);
    }

    // 'MM-DD-YYYY' or 'MM/DD/YYYY'
    m = s.match(/^(\d{2})[-/](\d{2})[-/](\d{4})$/);
    if (m) {
        const mo = +m[1] - 1;
        const d = +m[2];
        const y = +m[3];
        return Date.UTC(y, mo, d, 0, 0, 0, 0);
    }

    return undefined;
}

function makeInstitutionOwnershipAnalyticsNode(params) {
    return {
        inputs: {
            institution_ownership_analytics_raw: () => getInstitutionOwnershipAnalytics(params),
        },
        outputs: {
            ownership_analytics_snapshot: {
                name: 'ownership_analytics_snapshot',
                description: 'Single snapshot with all ownership analytics data',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'snapshot time in ms since epoch (UTC), derived from latest date/filing_date',
                    },
                    {
                        name: 'analytics',
                        type: 'array',
                        description: 'all ownership analytics records',
                        fields: [
                            { name: 'date', type: 'string', description: 'data date (YYYY-MM-DD)' },
                            { name: 'cik', type: 'string', description: 'CIK of the institutional investor' },
                            { name: 'filing_date', type: 'string', description: 'filing date' },
                            { name: 'investor_name', type: 'string', description: 'name of the institutional investor' },
                            { name: 'symbol', type: 'string', description: 'stock symbol' },
                            { name: 'security_name', type: 'string', description: 'name of the security' },
                            { name: 'type_of_security', type: 'string', description: 'type of security' },
                            { name: 'security_cusip', type: 'string', description: 'CUSIP of the security' },
                            { name: 'shares_type', type: 'string', description: 'type of shares' },
                            { name: 'put_call_share', type: 'string', description: 'put/call share indicator' },
                            { name: 'investment_discretion', type: 'string', description: 'investment discretion' },
                            { name: 'industry_title', type: 'string', description: 'industry title' },
                            { name: 'weight', type: 'number', description: 'portfolio weight percentage' },
                            { name: 'last_weight', type: 'number', description: 'previous period weight percentage' },
                            { name: 'change_in_weight', type: 'number', description: 'change in weight' },
                            { name: 'change_in_weight_percentage', type: 'number', description: 'change in weight percentage' },
                            { name: 'market_value', type: 'number', description: 'market value in USD' },
                            { name: 'last_market_value', type: 'number', description: 'previous period market value in USD' },
                            { name: 'change_in_market_value', type: 'number', description: 'change in market value in USD' },
                            { name: 'change_in_market_value_percentage', type: 'number', description: 'change in market value percentage' },
                            { name: 'shares_number', type: 'number', description: 'number of shares held' },
                            { name: 'last_shares_number', type: 'number', description: 'previous period shares number' },
                            { name: 'change_in_shares_number', type: 'number', description: 'change in shares number' },
                            { name: 'change_in_shares_number_percentage', type: 'number', description: 'change in shares number percentage' },
                            { name: 'quarter_end_price', type: 'number', description: 'quarter end price' },
                            { name: 'avg_price_paid', type: 'number', description: 'average price paid' },
                            { name: 'is_new', type: 'boolean', description: 'is new position' },
                            { name: 'is_sold_out', type: 'boolean', description: 'is sold out position' },
                            { name: 'ownership', type: 'number', description: 'ownership percentage' },
                            { name: 'last_ownership', type: 'number', description: 'previous period ownership percentage' },
                            { name: 'change_in_ownership', type: 'number', description: 'change in ownership' },
                            { name: 'change_in_ownership_percentage', type: 'number', description: 'change in ownership percentage' },
                            { name: 'holding_period', type: 'number', description: 'holding period in quarters' },
                            { name: 'first_added', type: 'string', description: 'first added date' },
                            { name: 'performance', type: 'number', description: 'performance in USD' },
                            { name: 'performance_percentage', type: 'number', description: 'performance percentage' },
                            { name: 'last_performance', type: 'number', description: 'previous period performance in USD' },
                            { name: 'change_in_performance', type: 'number', description: 'change in performance in USD' },
                            { name: 'is_counted_for_performance', type: 'boolean', description: 'is counted for performance' },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(
                    getInstitutionOwnershipAnalyticsRef,
                    params,
                    buildGetInstitutionOwnershipAnalyticsCallDescription
                ),
            },
        },
        run: (inputs) => {
            const raw = inputs.institution_ownership_analytics_raw;

            // 兼容 {success, response:{data}} 和 {data:{data}} 两种结构
            const container = (raw && (raw.response || raw.data)) || {};
            const analytics = Array.isArray(container.analytics) ? container.analytics : [];
            if (analytics.length === 0) {
                // 没有数据就不追加
                return undefined;
            }

            // 1) 选定一个确定时间 - 使用 date
            let snapshotTime = Number.NEGATIVE_INFINITY;
            for (const a of analytics) {
                const t = parseToMs(a.date);
                if (Number.isFinite(t) && t > snapshotTime) snapshotTime = t;
            }
            if (!Number.isFinite(snapshotTime)) {
                throw new Error('No valid date found in ownership analytics data');
            }

            // 2) Map all analytics into the nested array
            const analyticsData = analytics.map((a) => ({
                date: a.date,
                cik: a.cik,
                filing_date: a.filing_date,
                investor_name: a.investor_name,
                symbol: a.symbol,
                security_name: a.security_name,
                type_of_security: a.type_of_security,
                security_cusip: a.security_cusip,
                shares_type: a.shares_type,
                put_call_share: a.put_call_share,
                investment_discretion: a.investment_discretion,
                industry_title: a.industry_title,
                weight: a.weight,
                last_weight: a.last_weight,
                change_in_weight: a.change_in_weight,
                change_in_weight_percentage: a.change_in_weight_percentage,
                market_value: a.market_value,
                last_market_value: a.last_market_value,
                change_in_market_value: a.change_in_market_value,
                change_in_market_value_percentage: a.change_in_market_value_percentage,
                shares_number: a.shares_number,
                last_shares_number: a.last_shares_number,
                change_in_shares_number: a.change_in_shares_number,
                change_in_shares_number_percentage: a.change_in_shares_number_percentage,
                quarter_end_price: a.quarter_end_price,
                avg_price_paid: a.avg_price_paid,
                is_new: a.is_new,
                is_sold_out: a.is_sold_out,
                ownership: a.ownership,
                last_ownership: a.last_ownership,
                change_in_ownership: a.change_in_ownership,
                change_in_ownership_percentage: a.change_in_ownership_percentage,
                holding_period: a.holding_period,
                first_added: a.first_added,
                performance: a.performance,
                performance_percentage: a.performance_percentage,
                last_performance: a.last_performance,
                change_in_performance: a.change_in_performance,
                is_counted_for_performance: a.is_counted_for_performance,
            }));

            // 可选：排序，便于下游一致性
            analyticsData.sort((a, b) => {
                const ta = parseToMs(a.date) ?? parseToMs(a.filing_date) ?? parseToMs(a.first_added) ?? -1;
                const tb = parseToMs(b.date) ?? parseToMs(b.filing_date) ?? parseToMs(b.first_added) ?? -1;
                if (tb !== ta) return tb - ta;
                return (a.investor_name || '').localeCompare(b.investor_name || '');
            });

            // 3) 返回单条快照（外层唯一 date，内层嵌套数组）
            return {
                ownership_analytics_snapshot: [
                    {
                        date: snapshotTime,
                        analytics: analyticsData,
                    },
                ],
            };
        },
    };
}

function getRefs() {
    return [getInstitutionOwnershipAnalyticsRef];
}

module.exports = {
    getInstitutionOwnershipAnalytics,
    makeInstitutionOwnershipAnalyticsNode,
    getRefs,
};
