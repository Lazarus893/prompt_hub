const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for the senator trades SDK/node output
const getSenatorTradesRef = {
	id: '@arrays/data/stock/person/senator-trading/getSenatorTrades',
	module_name: '@arrays/data/stock/person/senator-trading',
	module_display_name: 'Stocks - Person: Senator Trading',
	sdk_name: 'getSenatorTrades',
	sdk_display_name: 'Senator Trades',
	source_name: 'Arrays Data Gateway',
	source: 'https://data-gateway.prd.space.id/api/v1/stocks/person/senate_trades',
};

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getSenatorTrades(params) {
	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/person/senate_trades';
	const keyValuePairs = Object.keys(params || {})
		.map((key) => {
			const value = params[key];
			// Skip null and undefined values
			if (value === null || value === undefined) return null;
			return encodeURIComponent(key) + '=' + encodeURIComponent(value);
		})
		.filter(Boolean);
	const queryString = keyValuePairs.join('&');
	const fullUrl = `${baseUrl}?${queryString}`;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

function _parseYyyyMmDdToUtcMs(s) {
	if (typeof s !== 'string') return null;
	// Expect YYYY-MM-DD
	const parts = s.split('-');
	if (parts.length !== 3) return null;
	const y = Number(parts[0]);
	const m = Number(parts[1]);
	const d = Number(parts[2]);
	if (!Number.isFinite(y) || !Number.isFinite(m) || !Number.isFinite(d)) {
		return null;
	}
	// Use UTC midnight
	return Date.UTC(y, m - 1, d, 0, 0, 0, 0);
}

function makeSenatorTradesNode(params) {
	return {
		inputs: {
			senator_trades_raw: () => getSenatorTrades(params),
		},
		outputs: {
			senator_trades: {
				name: 'senator_trades',
				description: 'Senator trades grouped by event timestamp (one record per timestamp)',
				fields: [
					{ name: 'date', type: 'number', description: 'event timestamp ms' },
					{
						name: 'senator_trade_list',
						type: 'array',
						description: 'all trades with this event timestamp',
						fields: [
							{ name: 'disclosure_date', type: 'string', description: 'YYYY-MM-DD' },
							{ name: 'transaction_date', type: 'string', description: 'YYYY-MM-DD' },
							{ name: 'transaction_timestamp', type: 'number', description: 'Unix seconds (source)' },
							{ name: 'first_name', type: 'string', description: 'First name' },
							{ name: 'last_name', type: 'string', description: 'Last name' },
							{ name: 'office', type: 'string', description: 'Office or full title' },
							{ name: 'district', type: 'string', description: 'District (optional)' },
							{ name: 'owner', type: 'string', description: 'Owner (Self/Spouse/...)' },
							{ name: 'asset_description', type: 'string', description: 'Asset description' },
							{ name: 'asset_type', type: 'string', description: 'Asset type (e.g., stock, option)' },
							{ name: 'symbol', type: 'string', description: 'Ticker (optional)' },
							{ name: 'type', type: 'string', description: 'Purchase/Sale (Full)/Sale (Partial)' },
							{ name: 'amount', type: 'string', description: 'Estimated value range' },
							{ name: 'capital_gains_over_200_usd', type: 'boolean', description: 'Capital gains exceed $200 (if provided)' },
							{ name: 'comment', type: 'string', description: 'Additional disclosure comments' },
							{ name: 'link', type: 'string', description: 'Disclosure URL' },
						],
					},
				],
				ref: createReferenceWithTitle(getSenatorTradesRef, params, buildGetSenatorTradesCallDescription),
			},
		},
		run: (inputs) => {
			const rows = inputs.senator_trades_raw?.response?.data;
			const src = Array.isArray(rows) ? rows : [];

			// Group by event time:
			// 1) Prefer transaction_timestamp (if numeric). Value may be seconds (e.g., 1755216000) or milliseconds (>1e12).
			// 2) If missing, parse transaction_date or disclosure_date (YYYY-MM-DD) as UTC midnight.
			// This produces a true time-series grouped by precise timestamps, sorted ascending.
			const byTimestamp = Object.create(null);
			for (const t of src) {
				let tsMs = null;
				if (t && Number.isFinite(t.transaction_timestamp)) {
					// Treat values < 1e12 as seconds and convert to milliseconds
					tsMs = t.transaction_timestamp > 1e12 ? t.transaction_timestamp : t.transaction_timestamp * 1000;
				} else {
					// Fallbacks: parse YYYY-MM-DD dates at UTC midnight
					tsMs = _parseYyyyMmDdToUtcMs(t?.transaction_date);
					if (tsMs == null) tsMs = _parseYyyyMmDdToUtcMs(t?.disclosure_date);
				}
				if (!tsMs || !Number.isFinite(tsMs)) continue;

				let capitalBool;
				if (typeof t?.capital_gains_over_200_usd === 'boolean') {
					capitalBool = t.capital_gains_over_200_usd;
				} else if (typeof t?.capital_gains_over200_usd === 'string') {
					const v = t.capital_gains_over200_usd.trim().toLowerCase();
					capitalBool = v === 'true' || v === 'yes';
				}

				if (!byTimestamp[tsMs]) byTimestamp[tsMs] = [];
				byTimestamp[tsMs].push({
					disclosure_date: t?.disclosure_date,
					transaction_date: t?.transaction_date,
					transaction_timestamp: t?.transaction_timestamp,
					first_name: t?.first_name,
					last_name: t?.last_name,
					office: t?.office,
					district: t?.district,
					owner: t?.owner,
					asset_description: t?.asset_description,
					asset_type: t?.asset_type,
					symbol: t?.symbol,
					type: t?.type,
					amount: t?.amount,
					capital_gains_over_200_usd: capitalBool,
					comment: t?.comment,
					link: t?.link,
				});
			}

			const timestamps = Object.keys(byTimestamp)
				.map((k) => +k)
				.sort((a, b) => a - b);
			const series = timestamps.map((ms) => ({
				date: ms,
				senator_trade_list: byTimestamp[ms],
			}));

			return { senator_trades: series };
		},
	};
}

// Base description and dynamic call description builder (internal only, do not export)
const baseGetSenatorTradesDescription = 'Get congressional trade disclosures';

function buildGetSenatorTradesCallDescription(actualParams = {}) {
	const parts = [baseGetSenatorTradesDescription];

	// Priority: ticker over name
	const ticker = actualParams?.ticker;
	const name = actualParams?.name;
	if (ticker) {
		parts.push(`for ${ticker}`);
	} else if (name) {
		parts.push(`by ${name}`);
	}

	const filters = [];
	const tag = actualParams?.tag;
	if (tag && tag !== 'all') {
		const chamber = tag === 'senate' ? 'Senate' : tag === 'house' ? 'House' : String(tag);
		filters.push(`Chamber: ${chamber}`);
	}
	const limitRaw = actualParams?.limit;
	const limitNum = typeof limitRaw === 'string' ? Number(limitRaw) : limitRaw;
	if (Number.isFinite(limitNum) && limitNum !== 100) {
		filters.push(`Limit: ${limitNum}`);
	}

	if (filters.length > 0) {
		parts.push(`(${filters.join(', ')})`);
	}

	return parts.join(' ').trim();
}

function getRefs() {
	return [
		getSenatorTradesRef,
	];
}

module.exports = {
	getSenatorTrades,
	makeSenatorTradesNode,
	getRefs,
};
