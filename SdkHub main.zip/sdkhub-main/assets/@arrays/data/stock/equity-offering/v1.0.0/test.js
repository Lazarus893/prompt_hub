const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');
// Manual import for get* function as requested
const { makeEquityOfferingeventsNode, getEquityOfferingevents } = require('@arrays/data/stock/equity-offering:v1.0.0');

function testDirectGetEquityOfferingevents() {
  console.log('\n=== Testing Direct getEquityOfferingevents ===');

  let totalTests = 0;
  let passedTests = 0;

  function runTest(testName, testFunc) {
    totalTests++;
    try {
      testFunc();
      console.log(`✅ ${testName}`);
      passedTests++;
    } catch (e) {
      console.log(`❌ ${testName}: ${e.message}`);
    }
  }

  // ============ Happy Path ============
  runTest('getEquityOfferingevents page=0 returns object with data array', () => {
    const res = getEquityOfferingevents({ page: 0 });
    assert(res && typeof res === 'object', 'Should return an object');
    assert(Array.isArray(res.data), 'res.data should be an array');
    if (res.data.length > 0) {
      const e = res.data[0];
      // Validate a representative subset strictly
      assert(typeof e.formType === 'string', 'formType should be string');
      assert(typeof e.acceptanceTime === 'string', 'acceptanceTime should be string');
      assert(typeof e.cik === 'string', 'cik should be string');
      assert(typeof e.companyName === 'string', 'companyName should be string');
      assert(typeof e.url === 'string', 'url should be string');
      // Validate optional/tri-state fields when present
      if (e.securitiesOfferedAreOfEquityType !== undefined && e.securitiesOfferedAreOfEquityType !== null) {
        assert(typeof e.securitiesOfferedAreOfEquityType === 'boolean', 'securitiesOfferedAreOfEquityType should be boolean if present');
      }
    }
  });

  runTest('getEquityOfferingevents pagination page=1', () => {
    const res = getEquityOfferingevents({ page: 1 });
    assert(res && typeof res === 'object', 'Should return an object');
    assert(Array.isArray(res.data), 'res.data should be an array');
  });

  runTest('getEquityOfferingevents pagination page=2', () => {
    const res = getEquityOfferingevents({ page: 2 });
    assert(res && typeof res === 'object', 'Should return an object');
    assert(Array.isArray(res.data), 'res.data should be an array');
  });

  // ============ Boundary Value Analysis ============
  runTest('boundary: page=0 (minimum)', () => {
    const res = getEquityOfferingevents({ page: 0 });
    assert(Array.isArray(res.data), 'Should work with minimum page 0');
  });

  runTest('boundary: large page (e.g., 1000)', () => {
    const res = getEquityOfferingevents({ page: 1000 });
    assert(res && typeof res === 'object', 'Should return an object');
    assert(Array.isArray(res.data), 'Should handle large page numbers (possibly empty array)');
  });

  // ============ Special Values ============
  runTest('special: page undefined (treated as default)', () => {
    const res = getEquityOfferingevents({ page: undefined });
    assert(res && typeof res === 'object', 'Should return an object');
    assert(Array.isArray(res.data), 'res.data should be an array');
  });

  runTest('special: params as empty object', () => {
    const res = getEquityOfferingevents({});
    assert(res && typeof res === 'object', 'Should return an object');
    assert(Array.isArray(res.data), 'res.data should be an array');
  });

  // ============ Error Handling for Invalid Inputs ============
  runTest('invalid: page is negative (-1)', () => {
    try {
      getEquityOfferingevents({ page: -1 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(
        e.message.includes('Error') || e.message.includes('invalid') || e.message.includes('Unsupported'),
        'Should handle invalid negative page'
      );
    }
  });

  runTest('invalid: page is non-integer float (1.5)', () => {
    try {
      getEquityOfferingevents({ page: 1.5 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(
        e.message.includes('Error') || e.message.includes('invalid') || e.message.includes('Unsupported'),
        'Should handle non-integer page'
      );
    }
  });

  runTest('invalid: page is string ("1")', () => {
    try {
      getEquityOfferingevents({ page: '1' });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(
        e.message.includes('Error') || e.message.includes('invalid') || e.message.includes('Unsupported'),
        'Should handle string page'
      );
    }
  });

  runTest('invalid: page is NaN', () => {
    try {
      getEquityOfferingevents({ page: NaN });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(
        e.message.includes('Error') || e.message.includes('invalid') || e.message.includes('Unsupported'),
        'Should handle NaN page'
      );
    }
  });

  runTest('invalid: page is null', () => {
    try {
      getEquityOfferingevents({ page: null });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(
        e.message.includes('Error') || e.message.includes('invalid') || e.message.includes('Unsupported'),
        'Should handle null page'
      );
    }
  });

  // Print test summary
  console.log('\n=== getEquityOfferingevents Test Summary ===');
  console.log(`Total tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${totalTests - passedTests}`);
  console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function testMakeEquityOfferingeventsNode() {
  const graph = new Graph(jagentId);
  graph.addNode(
    'equity_offeringevents',
    makeEquityOfferingeventsNode({
      page: 0,
    })
  );

  graph.run();

  // Materialize and validate the equity offering events output
  const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'equity_offeringevents', 'equity_offeringevents', { last: '10' }), graph.store);
  ts.init();

  if (!Array.isArray(ts.data)) {
    throw new Error('Expected equity offering events data to be an array');
  }

  if (ts.data.length > 0) {
    const event = ts.data[0];

    // Validate all required fields and their types
    if (typeof event.date !== 'number') {
      throw new Error('Expected event.date to be a number (timestamp in ms)');
    }

    if (typeof event.formType !== 'string') {
      throw new Error('Expected event.formType to be a string');
    }

    if (typeof event.formSignification !== 'string') {
      throw new Error('Expected event.formSignification to be a string');
    }

    if (typeof event.acceptanceTime !== 'string') {
      throw new Error('Expected event.acceptanceTime to be a string');
    }

    if (typeof event.cik !== 'string') {
      throw new Error('Expected event.cik to be a string');
    }

    if (typeof event.entityName !== 'string') {
      throw new Error('Expected event.entityName to be a string');
    }

    if (typeof event.issuerStreet !== 'string') {
      throw new Error('Expected event.issuerStreet to be a string');
    }

    if (typeof event.issuerCity !== 'string') {
      throw new Error('Expected event.issuerCity to be a string');
    }

    if (typeof event.issuerStateOrCountry !== 'string') {
      throw new Error('Expected event.issuerStateOrCountry to be a string');
    }

    if (typeof event.issuerStateOrCountryDescription !== 'string') {
      throw new Error('Expected event.issuerStateOrCountryDescription to be a string');
    }

    if (typeof event.issuerZipCode !== 'string') {
      throw new Error('Expected event.issuerZipCode to be a string');
    }

    if (typeof event.issuerPhoneNumber !== 'string') {
      throw new Error('Expected event.issuerPhoneNumber to be a string');
    }

    if (typeof event.jurisdictionOfIncorporation !== 'string') {
      throw new Error('Expected event.jurisdictionOfIncorporation to be a string');
    }

    if (typeof event.entityType !== 'string') {
      throw new Error('Expected event.entityType to be a string');
    }

    if (typeof event.incorporatedWithinFiveYears !== 'boolean') {
      throw new Error('Expected event.incorporatedWithinFiveYears to be a boolean');
    }

    if (typeof event.yearOfIncorporation !== 'string') {
      throw new Error('Expected event.yearOfIncorporation to be a string');
    }

    if (typeof event.relatedPersonFirstName !== 'string') {
      throw new Error('Expected event.relatedPersonFirstName to be a string');
    }

    if (typeof event.relatedPersonLastName !== 'string') {
      throw new Error('Expected event.relatedPersonLastName to be a string');
    }

    if (typeof event.relatedPersonStreet !== 'string') {
      throw new Error('Expected event.relatedPersonStreet to be a string');
    }

    if (typeof event.relatedPersonCity !== 'string') {
      throw new Error('Expected event.relatedPersonCity to be a string');
    }

    if (typeof event.relatedPersonStateOrCountry !== 'string') {
      throw new Error('Expected event.relatedPersonStateOrCountry to be a string');
    }

    if (typeof event.relatedPersonStateOrCountryDescription !== 'string') {
      throw new Error('Expected event.relatedPersonStateOrCountryDescription to be a string');
    }

    if (typeof event.relatedPersonZipCode !== 'string') {
      throw new Error('Expected event.relatedPersonZipCode to be a string');
    }

    if (typeof event.relatedPersonRelationship !== 'string') {
      throw new Error('Expected event.relatedPersonRelationship to be a string');
    }

    if (typeof event.industryGroupType !== 'string') {
      throw new Error('Expected event.industryGroupType to be a string');
    }

    if (typeof event.revenueRange !== 'string') {
      throw new Error('Expected event.revenueRange to be a string');
    }

    if (typeof event.federalExemptionsExclusions !== 'string') {
      throw new Error('Expected event.federalExemptionsExclusions to be a string');
    }

    if (typeof event.isAmendment !== 'boolean') {
      throw new Error('Expected event.isAmendment to be a boolean');
    }

    if (typeof event.dateOfFirstSale !== 'string') {
      throw new Error('Expected event.dateOfFirstSale to be a string');
    }

    if (typeof event.durationOfOfferingIsMoreThanYear !== 'boolean') {
      throw new Error('Expected event.durationOfOfferingIsMoreThanYear to be a boolean');
    }

    // securitiesOfferedAreOfEquityType can be boolean or undefined
    if (event.securitiesOfferedAreOfEquityType !== undefined && typeof event.securitiesOfferedAreOfEquityType !== 'boolean') {
      throw new Error('Expected event.securitiesOfferedAreOfEquityType to be a boolean or undefined');
    }

    if (typeof event.isBusinessCombinationTransaction !== 'boolean') {
      throw new Error('Expected event.isBusinessCombinationTransaction to be a boolean');
    }

    if (typeof event.minimumInvestmentAccepted !== 'number') {
      throw new Error('Expected event.minimumInvestmentAccepted to be a number');
    }

    if (typeof event.totalOfferingAmount !== 'number') {
      throw new Error('Expected event.totalOfferingAmount to be a number');
    }

    if (typeof event.totalAmountSold !== 'number') {
      throw new Error('Expected event.totalAmountSold to be a number');
    }

    if (typeof event.totalAmountRemaining !== 'number') {
      throw new Error('Expected event.totalAmountRemaining to be a number');
    }

    if (typeof event.hasNonAccreditedInvestors !== 'boolean') {
      throw new Error('Expected event.hasNonAccreditedInvestors to be a boolean');
    }

    if (typeof event.totalNumberAlreadyInvested !== 'number') {
      throw new Error('Expected event.totalNumberAlreadyInvested to be a number');
    }

    if (typeof event.salesCommissions !== 'number') {
      throw new Error('Expected event.salesCommissions to be a number');
    }

    if (typeof event.findersFees !== 'number') {
      throw new Error('Expected event.findersFees to be a number');
    }

    if (typeof event.grossProceedsUsed !== 'number') {
      throw new Error('Expected event.grossProceedsUsed to be a number');
    }

    if (typeof event.url !== 'string') {
      throw new Error('Expected event.url to be a string');
    }

    if (typeof event.companyName !== 'string') {
      throw new Error('Expected event.companyName to be a string');
    }

    log(`✅ Equity offering event validation passed: ${event.formType} by ${event.entityName} on ${new Date(event.date).toISOString()}`);
    log(`   All ${Object.keys(event).length} fields validated successfully`);
  }

  // Validate refs metadata for the equity_offeringevents output
  const refsEquityOffering = graph.getRefsForOutput('equity_offeringevents', 'equity_offeringevents');
  if (refsEquityOffering.length > 0) {
    const ref = refsEquityOffering[0];
    const expected = {
      id: '@arrays/data/stock/equity-offering/getEquityOfferingevents',
      module_name: '@arrays/data/stock/equity-offering',
      module_display_name: 'Company Equity Offering Calendar',
      sdk_name: 'getEquityOfferingevents',
      sdk_display_name: 'Company Equity Offerings Calendar',
      source_name: 'Financial Modeling Prep',
      source: 'https://site.financialmodelingprep.com/developer/docs/equity-offerings-fundraising-rss-feed-api',
    };

    if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for equity_offeringevents');
    if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for equity_offeringevents');
    if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for equity_offeringevents');
    if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for equity_offeringevents');
    if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for equity_offeringevents');
    if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for equity_offeringevents');
    if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for equity_offeringevents');
    log('✓ equity_offeringevents refs validated');
  } else {
    throw new Error('Assertion failed: refsEquityOffering array is empty.');
  }

  log('✅ Equity Offering Events make*Node tests passed');
}

function main() {
  // 1) Direct SDK function tests (manual import) for getEquityOfferingevents
  testDirectGetEquityOfferingevents();

  // 2) Graph node integration tests (existing)
  testMakeEquityOfferingeventsNode();
}

main();
