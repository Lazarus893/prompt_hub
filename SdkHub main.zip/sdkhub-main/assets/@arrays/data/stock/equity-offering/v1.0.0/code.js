const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getEquityOfferingevents derived from tool.json
const getEquityOfferingeventsRef = {
    id: '@arrays/data/stock/equity-offering/getEquityOfferingevents',
    module_name: '@arrays/data/stock/equity-offering',
    module_display_name: 'Company Equity Offering Calendar',
    sdk_name: 'getEquityOfferingevents',
    sdk_display_name: 'Company Equity Offerings Calendar',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/equity-offerings-fundraising-rss-feed-api',
};

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

/**
 * Retrieve the latest equity offerings including new share issuances, exempt offerings, and amendments.
 * Authentication via API Key is required in the 'X-API-Key' header.
 *
 * @function getEquityOfferingevents
 * @param {Object} params
 * @param {number} params.page Page number for pagination, starting from 0.
 * @returns {Object} The raw API response JSON.
 */
function getEquityOfferingevents(params) {
	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/equity-offering';
	const keyValuePairs = Object.keys(params || {}).map((key) => {
		const value = params[key];
		return encodeURIComponent(key) + '=' + encodeURIComponent(value);
	});
	const queryString = keyValuePairs.join('&');
	const fullUrl = `${baseUrl}?${queryString}`;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

/**
 * Parse "YYYY-MM-DD HH:mm:ss" as UTC ms.
 */
function parseAcceptanceTimeMs(s) {
	if (typeof s !== 'string') return null;
	// Expected format: "YYYY-MM-DD HH:mm:ss"
	const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/.exec(s.trim());
	if (!m) return null;
	const y = Number(m[1]);
	const mon = Number(m[2]);
	const d = Number(m[3]);
	const hh = Number(m[4]);
	const mm = Number(m[5]);
	const ss = Number(m[6]);
	if (Number.isNaN(y) || Number.isNaN(mon) || Number.isNaN(d) || Number.isNaN(hh) || Number.isNaN(mm) || Number.isNaN(ss)) {
		return null;
	}
	return Date.UTC(y, mon - 1, d, hh, mm, ss, 0);
}

/**
 * Parse "YYYY-MM-DD" (date-only) as UTC ms at 00:00:00.
 */
function parseYmdMs(s) {
	if (typeof s !== 'string') return null;
	const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s.trim());
	if (!m) return null;
	const y = Number(m[1]);
	const mon = Number(m[2]);
	const d = Number(m[3]);
	if (Number.isNaN(y) || Number.isNaN(mon) || Number.isNaN(d)) return null;
	return Date.UTC(y, mon - 1, d, 0, 0, 0, 0);
}

/**
 * Build a nodified graph-node for equity offering events.
 * Params are exactly the same as getEquityOfferingevents.
 *
 * Output is one record per event, dated by acceptanceTime (ms).
 */
function makeEquityOfferingeventsNode(params) {
	return {
		inputs: {
			equity_offeringevents_raw: () => getEquityOfferingevents(params),
		},
		outputs: {
			equity_offeringevents: {
				name: 'equity_offeringevents',
				description: 'Equity offering events (one record per filing, dated by acceptance time).',
				fields: [
					{ name: 'date', type: 'number', description: 'acceptance time ms (UTC)' },
					{ name: 'formType', type: 'string', description: 'Form type of the offering (e.g., "D/A").' },
					{ name: 'formSignification', type: 'string', description: 'Description of the form significance.' },
					{ name: 'acceptanceTime', type: 'string', description: 'Acceptance time, original string "YYYY-MM-DD HH:mm:ss".' },
					{ name: 'cik', type: 'string', description: 'Central Index Key of the filing entity.' },
					{ name: 'entityName', type: 'string', description: 'Name of the filing entity.' },
					{ name: 'issuerStreet', type: 'string', description: "Issuer's street address." },
					{ name: 'issuerCity', type: 'string', description: "Issuer's city." },
					{ name: 'issuerStateOrCountry', type: 'string', description: "Issuer's state or country code." },
					{ name: 'issuerStateOrCountryDescription', type: 'string', description: "Issuer's full state or country name." },
					{ name: 'issuerZipCode', type: 'string', description: "Issuer's postal code." },
					{ name: 'issuerPhoneNumber', type: 'string', description: "Issuer's contact phone number." },
					{ name: 'jurisdictionOfIncorporation', type: 'string', description: "Entity's jurisdiction of incorporation." },
					{ name: 'entityType', type: 'string', description: 'Type of entity (e.g., Limited Partnership).' },
					{ name: 'incorporatedWithinFiveYears', type: 'boolean', description: 'Whether entity was incorporated within last five years.' },
					{ name: 'yearOfIncorporation', type: 'string', description: 'Year the entity was incorporated.' },
					{ name: 'relatedPersonFirstName', type: 'string', description: "Related person's first name or N/A." },
					{ name: 'relatedPersonLastName', type: 'string', description: "Related person's last name or entity name." },
					{ name: 'relatedPersonStreet', type: 'string', description: "Related person's street address." },
					{ name: 'relatedPersonCity', type: 'string', description: "Related person's city." },
					{ name: 'relatedPersonStateOrCountry', type: 'string', description: "Related person's state or country code." },
					{ name: 'relatedPersonStateOrCountryDescription', type: 'string', description: "Related person's full state or country name." },
					{ name: 'relatedPersonZipCode', type: 'string', description: "Related person's postal code." },
					{ name: 'relatedPersonRelationship', type: 'string', description: 'Relationship to issuer (e.g., "Promoter").' },
					{ name: 'industryGroupType', type: 'string', description: 'Industry group classification.' },
					{ name: 'revenueRange', type: 'string', description: 'Reported revenue range or disclosure status.' },
					{ name: 'federalExemptionsExclusions', type: 'string', description: 'Applicable federal exemptions or exclusions.' },
					{ name: 'isAmendment', type: 'boolean', description: 'Whether this filing is an amendment.' },
					{ name: 'dateOfFirstSale', type: 'string', description: 'Date of first sale (YYYY-MM-DD).' },
					{ name: 'durationOfOfferingIsMoreThanYear', type: 'boolean', description: 'Whether offering duration exceeds one year.' },
					{ name: 'securitiesOfferedAreOfEquityType', type: 'boolean', description: 'Indicates if securities are equity type; may be null.' },
					{ name: 'isBusinessCombinationTransaction', type: 'boolean', description: 'Whether related to a business combination transaction.' },
					{ name: 'minimumInvestmentAccepted', type: 'number', description: 'Minimum investment amount accepted.' },
					{ name: 'totalOfferingAmount', type: 'number', description: 'Total amount offered.' },
					{ name: 'totalAmountSold', type: 'number', description: 'Total offering amount sold.' },
					{ name: 'totalAmountRemaining', type: 'number', description: 'Remaining offering amount.' },
					{ name: 'hasNonAccreditedInvestors', type: 'boolean', description: 'Whether non-accredited investors are included.' },
					{ name: 'totalNumberAlreadyInvested', type: 'number', description: 'Number of investors to date.' },
					{ name: 'salesCommissions', type: 'number', description: 'Sales commissions paid.' },
					{ name: 'findersFees', type: 'number', description: "Finder's fees paid." },
					{ name: 'grossProceedsUsed', type: 'number', description: 'Gross proceeds used from the offering.' },
					{ name: 'url', type: 'string', description: 'URL to the filing document.' },
					{ name: 'companyName', type: 'string', description: 'Company name from the filing.' },
				],
				ref: createReferenceWithTitle(getEquityOfferingeventsRef, params, buildGetEquityOfferingeventsCallDescription),
			},
		},
		run: (inputs) => {
			const raw = inputs.equity_offeringevents_raw;

			// Basic error checks akin to API contract
			if (raw?.error) {
				throw new Error(`API Error: ${raw.error.message || 'Unknown error'}`);
			}
			if (raw && typeof raw === 'object' && 'success' in raw && raw.success === false) {
				throw new Error('API request failed');
			}

			if (!raw?.data) {
				return { equity_offeringevents: [] };
			}

			const rows = Array.isArray(raw.data) ? raw.data : [];

			// Build with deterministic timestamp from acceptanceTime (fallback to dateOfFirstSale)
			const prepared = [];
			for (const r of rows) {
				let ms = parseAcceptanceTimeMs(r.acceptanceTime);
				if (ms == null && r.dateOfFirstSale) {
					ms = parseYmdMs(r.dateOfFirstSale);
				}
				if (ms == null) {
					// If no usable timestamp, skip this record to keep time-series integrity
					continue;
				}
				prepared.push({ ms, r });
			}

			// Sort ascending by date, and de-dup by adding +1ms for ties
			prepared.sort((a, b) => a.ms - b.ms);
			for (let i = 0; i < prepared.length - 1; i++) {
				if (prepared[i].ms === prepared[i + 1].ms) {
					prepared[i + 1].ms = prepared[i + 1].ms + 1;
				}
			}

			const out = prepared.map(({ ms, r }) => ({
				date: ms,
				formType: r.formType,
				formSignification: r.formSignification,
				acceptanceTime: r.acceptanceTime,
				cik: r.cik,
				entityName: r.entityName,
				issuerStreet: r.issuerStreet,
				issuerCity: r.issuerCity,
				issuerStateOrCountry: r.issuerStateOrCountry,
				issuerStateOrCountryDescription: r.issuerStateOrCountryDescription,
				issuerZipCode: r.issuerZipCode,
				issuerPhoneNumber: r.issuerPhoneNumber,
				jurisdictionOfIncorporation: r.jurisdictionOfIncorporation,
				entityType: r.entityType,
				incorporatedWithinFiveYears: r.incorporatedWithinFiveYears,
				yearOfIncorporation: r.yearOfIncorporation,
				relatedPersonFirstName: r.relatedPersonFirstName,
				relatedPersonLastName: r.relatedPersonLastName,
				relatedPersonStreet: r.relatedPersonStreet,
				relatedPersonCity: r.relatedPersonCity,
				relatedPersonStateOrCountry: r.relatedPersonStateOrCountry,
				relatedPersonStateOrCountryDescription: r.relatedPersonStateOrCountryDescription,
				relatedPersonZipCode: r.relatedPersonZipCode,
				relatedPersonRelationship: r.relatedPersonRelationship,
				industryGroupType: r.industryGroupType,
				revenueRange: r.revenueRange,
				federalExemptionsExclusions: r.federalExemptionsExclusions,
				isAmendment: r.isAmendment,
				dateOfFirstSale: r.dateOfFirstSale,
				durationOfOfferingIsMoreThanYear: r.durationOfOfferingIsMoreThanYear,
				securitiesOfferedAreOfEquityType: r.securitiesOfferedAreOfEquityType === true ? true : r.securitiesOfferedAreOfEquityType === false ? false : undefined,
				isBusinessCombinationTransaction: r.isBusinessCombinationTransaction,
				minimumInvestmentAccepted: r.minimumInvestmentAccepted,
				totalOfferingAmount: r.totalOfferingAmount,
				totalAmountSold: r.totalAmountSold,
				totalAmountRemaining: r.totalAmountRemaining,
				hasNonAccreditedInvestors: r.hasNonAccreditedInvestors,
				totalNumberAlreadyInvested: r.totalNumberAlreadyInvested,
				salesCommissions: r.salesCommissions,
				findersFees: r.findersFees,
				grossProceedsUsed: r.grossProceedsUsed,
				url: r.url,
				companyName: r.companyName,
			}));

			return { equity_offeringevents: out };
		},
	};
}

// Base description and dynamic call description builder for getEquityOfferingevents
const getEquityOfferingeventsBaseFuncDesc = 'Retrieve latest equity offering events';

function buildGetEquityOfferingeventsCallDescription(actualParams = {}) {
    const parts = [getEquityOfferingeventsBaseFuncDesc];

    const filters = [];
    // Page number for pagination (starts from 0)
    if (actualParams && Object.prototype.hasOwnProperty.call(actualParams, 'page')) {
        filters.push(`Page: ${actualParams.page}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

// Unified function to get all Ref-suffixed reference objects in this module
function getRefs() {
    return [
        getEquityOfferingeventsRef,
    ];
}

module.exports = {
	getEquityOfferingevents,
	makeEquityOfferingeventsNode,
	getRefs,
};
