function getFinancialEstimates(params) {
	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/financial-estimates';
	const keyValuePairs = Object.keys(params || {}).map((key) => {
		const value = params[key];
		return encodeURIComponent(key) + '=' + encodeURIComponent(value);
	});
	const queryString = keyValuePairs.join('&');
	const fullUrl = `${baseUrl}?${queryString}`;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': 'c84b079d-3888-4366-9752-10bb6c51543d',
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

// Robust ISO date (YYYY-MM-DD) -> ms (UTC) converter; otherwise fallback to Date.parse
function toMs(value) {
	if (!value) return null;
	if (typeof value === 'string') {
		const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
		if (m) {
			const y = Number(m[1]);
			const mm0 = Number(m[2]) - 1;
			const d = Number(m[3]);
			return Date.UTC(y, mm0, d, 0, 0, 0, 0);
		}
	}
	const parsed = Date.parse(value);
	return Number.isNaN(parsed) ? null : parsed;
}

function toNumber(value) {
	if (value == null || value === '') {
		return null;
	}
	const num = Number(value);
	return Number.isNaN(num) ? null : num;
}

function ensureUniqueDates(records) {
	const used = new Set();
	return records.map((record) => {
		let { date } = record;
		while (used.has(date)) {
			date += 1;
		}
		used.add(date);
		return { ...record, date };
	});
}
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

const getFinancialEstimatesRef = {
    id: '@arrays/data/stock/financial-estimates/getFinancialEstimates',
    module_name: '@arrays/data/stock/financial-estimates',
    module_display_name: 'Company Financial Estimate',
    sdk_name: 'getFinancialEstimates',
    sdk_display_name: 'Company Financial Estimate',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/stable/financial-estimates',
};

// Summarized base description for getFinancialEstimates (from doc)
const getFinancialEstimatesBaseDesc = "Get consensus financial estimates";

function buildGetFinancialEstimatesCallDescription(actualParams = {}) {
  const parts = [getFinancialEstimatesBaseDesc];
  if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
  const filters = [];
  if (actualParams.period) filters.push(`Period: ${actualParams.period}`);
  if (actualParams.page != null && actualParams.page !== 0) filters.push(`Page: ${actualParams.page}`);
  if (actualParams.limit != null && actualParams.limit !== 10) filters.push(`Limit: ${actualParams.limit}`);
  if (filters.length) parts.push(`(${filters.join(', ')})`);
  return parts.join(' ').trim();
}

function makeFinancialEstimatesNode(params) {
	return {
		inputs: {
			estimates_raw: () => getFinancialEstimates(params),
		},
		outputs: {
			financial_estimates: {
				name: 'financial_estimates',
				description: 'Consensus financial estimates',
				fields: [
					{ name: 'date', type: 'number', description: 'estimate date ms' },
					{ name: 'symbol', type: 'string', description: 'stock symbol' },
					{ name: 'revenue_low', type: 'number', description: 'low revenue estimate' },
					{ name: 'revenue_high', type: 'number', description: 'high revenue estimate' },
					{ name: 'revenue_avg', type: 'number', description: 'average revenue estimate' },
					{ name: 'ebitda_low', type: 'number', description: 'low EBITDA estimate' },
					{ name: 'ebitda_high', type: 'number', description: 'high EBITDA estimate' },
					{ name: 'ebitda_avg', type: 'number', description: 'average EBITDA estimate' },
					{ name: 'ebit_low', type: 'number', description: 'low EBIT estimate' },
					{ name: 'ebit_high', type: 'number', description: 'high EBIT estimate' },
					{ name: 'ebit_avg', type: 'number', description: 'average EBIT estimate' },
					{ name: 'net_income_low', type: 'number', description: 'low net income estimate' },
					{ name: 'net_income_high', type: 'number', description: 'high net income estimate' },
					{ name: 'net_income_avg', type: 'number', description: 'average net income estimate' },
					{ name: 'sga_expense_low', type: 'number', description: 'low SGA expense' },
					{ name: 'sga_expense_high', type: 'number', description: 'high SGA expense' },
					{ name: 'sga_expense_avg', type: 'number', description: 'average SGA expense' },
					{ name: 'eps_low', type: 'number', description: 'low EPS' },
					{ name: 'eps_high', type: 'number', description: 'high EPS' },
					{ name: 'eps_avg', type: 'number', description: 'average EPS' },
					{ name: 'num_analysts_revenue', type: 'number', description: 'revenue analyst count' },
					{ name: 'num_analysts_eps', type: 'number', description: 'EPS analyst count' },
				],
                ref: createReferenceWithTitle(getFinancialEstimatesRef, params, buildGetFinancialEstimatesCallDescription),
			},
		},
		run: (inputs) => {
			const response = inputs.estimates_raw;
			if (!response || response.success !== true || !response.response) {
				throw new Error('Financial estimates raw data is invalid');
			}
			const estimates = Array.isArray(response.response?.estimates) ? response.response.estimates : [];

			function addIfNum(obj, key, v) {
				if (v != null) obj[key] = v;
			}

			const series = estimates
				.map((item) => {
					const date = toMs(item.date);
					if (date == null) return null;

					const rec = {
						date,
						symbol: item.symbol || params?.symbol,
					};

					addIfNum(rec, 'revenue_low', toNumber(item.revenueLow));
					addIfNum(rec, 'revenue_high', toNumber(item.revenueHigh));
					addIfNum(rec, 'revenue_avg', toNumber(item.revenueAvg));

					addIfNum(rec, 'ebitda_low', toNumber(item.ebitdaLow));
					addIfNum(rec, 'ebitda_high', toNumber(item.ebitdaHigh));
					addIfNum(rec, 'ebitda_avg', toNumber(item.ebitdaAvg));

					addIfNum(rec, 'ebit_low', toNumber(item.ebitLow));
					addIfNum(rec, 'ebit_high', toNumber(item.ebitHigh));
					addIfNum(rec, 'ebit_avg', toNumber(item.ebitAvg));

					addIfNum(rec, 'net_income_low', toNumber(item.netIncomeLow));
					addIfNum(rec, 'net_income_high', toNumber(item.netIncomeHigh));
					addIfNum(rec, 'net_income_avg', toNumber(item.netIncomeAvg));

					addIfNum(rec, 'sga_expense_low', toNumber(item.sgaExpenseLow));
					addIfNum(rec, 'sga_expense_high', toNumber(item.sgaExpenseHigh));
					addIfNum(rec, 'sga_expense_avg', toNumber(item.sgaExpenseAvg));

					addIfNum(rec, 'eps_low', toNumber(item.epsLow));
					addIfNum(rec, 'eps_high', toNumber(item.epsHigh));
					addIfNum(rec, 'eps_avg', toNumber(item.epsAvg));

					addIfNum(rec, 'num_analysts_revenue', toNumber(item.numAnalystsRevenue));
					addIfNum(rec, 'num_analysts_eps', toNumber(item.numAnalystsEps));

					return rec;
				})
				.filter(Boolean);

			return {
				financial_estimates: ensureUniqueDates(series),
			};
		},
	};
}

function getRefs() {
	return [getFinancialEstimatesRef];
}

module.exports = {
	getFinancialEstimates,
	makeFinancialEstimatesNode,
	getRefs,
};
