function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
}

function runTest(testName, testFunc, ctx) {
    ctx.totalTests++;
    try {
        testFunc();
        console.log(`✅ ${testName}`);
        ctx.passedTests++;
    } catch (e) {
        console.log(`❌ ${testName}: ${e.message}`);
    }
}

function validateEstimateRecordForGet(rec, expectedSymbol) {
    // Validate required string fields based on doc
    const stringFields = [
        'symbol', 'date',
        'revenueLow', 'revenueHigh', 'revenueAvg',
        'ebitdaLow', 'ebitdaHigh', 'ebitdaAvg',
        'ebitLow', 'ebitHigh', 'ebitAvg',
        'netIncomeLow', 'netIncomeHigh', 'netIncomeAvg',
        'sgaExpenseLow', 'sgaExpenseHigh', 'sgaExpenseAvg',
        'epsLow', 'epsHigh', 'epsAvg',
    ];
    stringFields.forEach((k) => assert(k in rec, `Missing field: ${k}`));
    stringFields.forEach((k) => assert(typeof rec[k] === 'string', `Field ${k} should be string`));

    // Date format: YYYY-MM-DD
    assert(/^\d{4}-\d{2}-\d{2}$/.test(rec.date), 'date should be string in YYYY-MM-DD format');

    if (expectedSymbol) {
        assert(
            typeof rec.symbol === 'string' && rec.symbol.toUpperCase() === expectedSymbol.toUpperCase(),
            `symbol should equal ${expectedSymbol}`
        );
    }

    // Numeric fields
    const numericFields = ['numAnalystsRevenue', 'numAnalystsEps'];
    numericFields.forEach((k) => assert(k in rec, `Missing field: ${k}`));
    numericFields.forEach((k) => assert(typeof rec[k] === 'number', `Field ${k} should be number`));
}

function validateGetFinancialEstimatesResponse(result, expectedSymbol, limit) {
    assert(result && typeof result === 'object', 'Result should be an object');
    assert(result.success === true, 'success should be true');
    assert(result.response && typeof result.response === 'object', 'response should be an object');
    assert(Array.isArray(result.response.estimates), 'response.estimates should be an array');

    if (typeof result.response.page !== 'undefined') {
        assert(typeof result.response.page === 'number', 'response.page should be a number');
    }
    if (typeof result.response.limit !== 'undefined') {
        assert(typeof result.response.limit === 'number', 'response.limit should be a number');
    }

    if (typeof limit === 'number') {
        assert(result.response.estimates.length <= limit, 'Should respect limit');
    }

    if (result.response.estimates.length > 0) {
        validateEstimateRecordForGet(result.response.estimates[0], expectedSymbol);
    }
}

function expectGracefulHandling(fn) {
    // Considered graceful if:
    // - The call throws (input validation error path), or
    // - Returns an object with success either true or false (API handled input), or
    // - Returns undefined/null (treated as handled by environment)
    try {
        const res = fn();
        if (res == null) return;
        assert(typeof res === 'object', 'Return should be an object when provided');
        if ('success' in res) {
            assert(typeof res.success === 'boolean', 'success should be boolean when present');
        }
        return;
    } catch (e) {
        return; // exceptions are acceptable as a form of handling invalid input
    }
}

function testGetFinancialEstimates(ctx) {
    console.log('\n=== Testing getFinancialEstimates (Direct API) ===');
    const { getFinancialEstimates, makeFinancialEstimatesNode } = require('@arrays/data/stock/financial-estimates:v1.0.0');

    // Happy path: default params (no period), and enumerated periods
    runTest('getFinancialEstimates default params (AAPL)', () => {
        const res = getFinancialEstimates({ symbol: 'AAPL' });
        validateGetFinancialEstimatesResponse(res, 'AAPL');
    }, ctx);

    for (const period of ['annual', 'quarterly']) {
        runTest(`getFinancialEstimates with period=${period}`, () => {
            const res = getFinancialEstimates({ symbol: 'AAPL', period, page: 0, limit: 5 });
            validateGetFinancialEstimatesResponse(res, 'AAPL', 5);
        }, ctx);
    }

    // Boundary Value Analysis: page and limit
    runTest('Boundary: page=0, limit=1', () => {
        const res = getFinancialEstimates({ symbol: 'AAPL', period: 'annual', page: 0, limit: 1 });
        validateGetFinancialEstimatesResponse(res, 'AAPL', 1);
    }, ctx);

    runTest('Boundary: large limit=100', () => {
        const res = getFinancialEstimates({ symbol: 'AAPL', period: 'annual', page: 0, limit: 100 });
        validateGetFinancialEstimatesResponse(res, 'AAPL', 100);
    }, ctx);

    // Special values and invalid inputs
    runTest('Invalid period value handled gracefully', () => {
        expectGracefulHandling(() => getFinancialEstimates({ symbol: 'AAPL', period: 'monthly', page: 0, limit: 5 }));
    }, ctx);

    runTest('Missing symbol (undefined) handled gracefully', () => {
        expectGracefulHandling(() => getFinancialEstimates({ period: 'annual', page: 0, limit: 5 }));
    }, ctx);

    runTest('Empty symbol string handled gracefully', () => {
        expectGracefulHandling(() => getFinancialEstimates({ symbol: '', period: 'annual' }));
    }, ctx);

    runTest('Null symbol handled gracefully', () => {
        expectGracefulHandling(() => getFinancialEstimates({ symbol: null, period: 'annual' }));
    }, ctx);

    runTest('Numeric symbol handled gracefully', () => {
        expectGracefulHandling(() => getFinancialEstimates({ symbol: 0, period: 'annual' }));
    }, ctx);

    runTest('Boundary: negative page handled gracefully', () => {
        expectGracefulHandling(() => getFinancialEstimates({ symbol: 'AAPL', period: 'annual', page: -1, limit: 5 }));
    }, ctx);

    runTest('Boundary: zero limit handled gracefully', () => {
        expectGracefulHandling(() => getFinancialEstimates({ symbol: 'AAPL', period: 'annual', page: 0, limit: 0 }));
    }, ctx);

    runTest('Boundary: negative limit handled gracefully', () => {
        expectGracefulHandling(() => getFinancialEstimates({ symbol: 'AAPL', period: 'annual', page: 0, limit: -5 }));
    }, ctx);

    runTest('Boundary: non-integer limit handled gracefully', () => {
        expectGracefulHandling(() => getFinancialEstimates({ symbol: 'AAPL', period: 'annual', page: 0, limit: '5' }));
    }, ctx);

    // Integration test similar to original (Graph + TimeSeries + Refs)
    runTest('Integration: Graph node + TimeSeries output + Refs validation', () => {
        const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
        const { jagentId } = require('env');

        const g = new Graph(jagentId);
        g.addNode('estimates_aapl', makeFinancialEstimatesNode({ symbol: 'AAPL', period: 'annual', limit: 5 }));

        g.run();

        const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'estimates_aapl', 'financial_estimates', { last: '10' }), g.store);
        ts.init();

        assert(Array.isArray(ts.data) && ts.data.length > 0, 'financial_estimates empty');
        const r = ts.data[0];
        [
            'date',
            'symbol',
            'revenue_low',
            'revenue_high',
            'revenue_avg',
            'ebitda_low',
            'ebitda_high',
            'ebitda_avg',
            'ebit_low',
            'ebit_high',
            'ebit_avg',
            'net_income_low',
            'net_income_high',
            'net_income_avg',
            'sga_expense_low',
            'sga_expense_high',
            'sga_expense_avg',
            'eps_low',
            'eps_high',
            'eps_avg',
            'num_analysts_revenue',
            'num_analysts_eps',
        ].forEach((k) => {
            assert(k in r, 'missing estimate field: ' + k);
        });
        assert(typeof r.date === 'number', 'estimate date must be number(ms)');

        // Validate refs for financial_estimates output
        const refsFinancialEstimates = g.getRefsForOutput('estimates_aapl', 'financial_estimates');
        assert(Array.isArray(refsFinancialEstimates) && refsFinancialEstimates.length > 0, 'refsFinancialEstimates array is empty');
        const ref = refsFinancialEstimates[0];
        const expected = {
            id: '@arrays/data/stock/financial-estimates/getFinancialEstimates',
            module_name: '@arrays/data/stock/financial-estimates',
            module_display_name: 'Company Financial Estimate',
            sdk_name: 'getFinancialEstimates',
            sdk_display_name: 'Company Financial Estimate',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stable/financial-estimates',
        };

        assert(ref.id === expected.id, 'ref.id mismatch for financial_estimates');
        assert(ref.module_name === expected.module_name, 'ref.module_name mismatch for financial_estimates');
        assert(ref.module_display_name === expected.module_display_name, 'ref.module_display_name mismatch for financial_estimates');
        assert(ref.sdk_name === expected.sdk_name, 'ref.sdk_name mismatch for financial_estimates');
        assert(ref.sdk_display_name === expected.sdk_display_name, 'ref.sdk_display_name mismatch for financial_estimates');
        assert(ref.source_name === expected.source_name, 'ref.source_name mismatch for financial_estimates');
        assert(ref.source === expected.source, 'ref.source mismatch for financial_estimates');
        console.log('✓ financial_estimates refs validated');
    }, ctx);
}

function main() {
    const ctx = { totalTests: 0, passedTests: 0 };
    testGetFinancialEstimates(ctx);

    console.log('\n=== Test Summary ===');
    console.log(`Total tests: ${ctx.totalTests}`);
    console.log(`Passed: ${ctx.passedTests}`);
    console.log(`Failed: ${ctx.totalTests - ctx.passedTests}`);
    console.log(`Success rate: ${((ctx.passedTests / ctx.totalTests) * 100).toFixed(1)}%`);

    if (ctx.passedTests === ctx.totalTests) {
        console.log('🎉 All tests passed!');
    } else {
        console.log('⚠️  Some tests failed. Please review the output above.');
    }
}

main();
