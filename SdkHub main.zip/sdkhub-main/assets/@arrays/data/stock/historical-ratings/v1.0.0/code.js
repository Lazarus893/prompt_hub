const { load } = require('@alva/secret');
const apiKey = load('X-ARRAY-KEY');

function getHistoricalRatings(params) {
	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/historical-ratings';
	const keyValuePairs = Object.keys(params || {}).map((key) => {
		const value = params[key];
		return encodeURIComponent(key) + '=' + encodeURIComponent(value);
	});
	const queryString = keyValuePairs.join('&');
	const fullUrl = queryString ? `${baseUrl}?${queryString}` : baseUrl;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': apiKey || 'c84b079d-3888-4366-9752-10bb6c51543d',
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

function parseDateYMD(ymd) {
	if (!ymd || typeof ymd !== 'string') return null;
	const parts = ymd.split('-');
	if (parts.length !== 3) return null;
	const y = parseInt(parts[0], 10);
	const m = parseInt(parts[1], 10);
	const d = parseInt(parts[2], 10);
	if (!Number.isFinite(y) || !Number.isFinite(m) || !Number.isFinite(d)) {
		return null;
	}
	return Date.UTC(y, m - 1, d, 0, 0, 0, 0);
}

// Summaries derived from docs
const getHistoricalRatingsBaseDesc = "Get historical stock ratings";

function buildGetHistoricalRatingsCallDescription(actualParams = {}) {
  const parts = [getHistoricalRatingsBaseDesc];
  // Symbol
  if (actualParams.symbol) {
    parts.push(`for ${actualParams.symbol}`);
  }
  // Filters
  const filters = [];
  if (actualParams.limit != null && Number(actualParams.limit) !== 1) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

// Reference metadata for getHistoricalRatings following the standard pattern
const getHistoricalRatingsRef = {
    id: '@arrays/data/stock/historical-ratings/getHistoricalRatings',
    module_name: '@arrays/data/stock/historical-ratings',
    module_display_name: 'Historical Analyst Rating',
    sdk_name: 'getHistoricalRatings',
    sdk_display_name: 'Historical Analyst Rating',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/stable/historical-ratings',
};

function makeHistoricalRatingsNode(params) {
	return {
		inputs: {
			historical_ratings_raw: () => getHistoricalRatings(params),
		},
		outputs: {
			ratings: {
				name: 'historical_ratings',
				description: 'Historical stock ratings, one record per rating date',
				fields: [
					{
						name: 'date',
						type: 'number',
						description: 'rating date ms (UTC midnight)',
					},
					{ name: 'symbol', type: 'string' },
					{
						name: 'rating',
						type: 'string',
						description: 'letter rating',
					},
					{ name: 'overallScore', type: 'number' },
					{ name: 'discountedCashFlowScore', type: 'number' },
					{ name: 'returnOnEquityScore', type: 'number' },
					{ name: 'returnOnAssetsScore', type: 'number' },
					{ name: 'debtToEquityScore', type: 'number' },
					{ name: 'priceToEarningsScore', type: 'number' },
					{ name: 'priceToBookScore', type: 'number' },
				],
                ref: createReferenceWithTitle(getHistoricalRatingsRef, params, buildGetHistoricalRatingsCallDescription),
			},
		},
		run: (inputs) => {
			const raw = inputs.historical_ratings_raw;
			if (!raw || raw.success !== true || !raw.response || !Array.isArray(raw.response.ratings)) {
				throw new Error('historical_ratings_raw invalid shape');
			}

			const mapped = raw.response.ratings.map((r) => {
				const dateMs = parseDateYMD(r.date);
				if (dateMs == null) {
					throw new Error('Invalid rating date: ' + JSON.stringify(r.date));
				}
				return {
					date: dateMs,
					symbol: r.symbol,
					rating: r.rating,
					overallScore: r.overallScore,
					discountedCashFlowScore: r.discountedCashFlowScore,
					returnOnEquityScore: r.returnOnEquityScore,
					returnOnAssetsScore: r.returnOnAssetsScore,
					debtToEquityScore: r.debtToEquityScore,
					priceToEarningsScore: r.priceToEarningsScore,
					priceToBookScore: r.priceToBookScore,
				};
			});

			// sort ascending by date
			mapped.sort((a, b) => a.date - b.date);
			// ensure uniqueness: if duplicate date, shift the later one by +1 ms (see announcements example)
			for (let i = 0; i < mapped.length - 1; i++) {
				if (mapped[i].date === mapped[i + 1].date) {
					mapped[i + 1].date = mapped[i + 1].date + 1;
				}
			}

			return { ratings: mapped };
		},
	};
}

function getRefs() {
	return [getHistoricalRatingsRef];
}

module.exports = {
	getHistoricalRatings,
	makeHistoricalRatingsNode,
	getRefs,
};
