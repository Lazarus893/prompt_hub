function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
}

function testGraphNodeAndRefs(runTest) {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeHistoricalRatingsNode } = require('@arrays/data/stock/historical-ratings:v1.0.0');

    runTest('Graph node produces ratings with required fields and valid refs', () => {
        const g = new Graph(jagentId);
        g.addNode('ratings_aapl', makeHistoricalRatingsNode({ symbol: 'AAPL', limit: 5 }));

        g.run();

        const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'ratings_aapl', 'ratings', { last: '5' }), g.store);
        ts.init();

        assert(Array.isArray(ts.data) && ts.data.length > 0, 'ratings empty');
        const r = ts.data[0];
        [
            'symbol', 'date', 'rating', 'overallScore',
            'discountedCashFlowScore', 'returnOnEquityScore', 'returnOnAssetsScore',
            'debtToEquityScore', 'priceToEarningsScore', 'priceToBookScore'
        ].forEach((k) => {
            assert(k in r, 'missing rating field: ' + k);
        });

        // Validate refs for outputs following the standard pattern
        const refsRatings = g.getRefsForOutput('ratings_aapl', 'ratings');
        assert(refsRatings.length > 0, 'Assertion failed: refsRatings array is empty.');
        const ref = refsRatings[0];
        const expected = {
            id: '@arrays/data/stock/historical-ratings/getHistoricalRatings',
            module_name: '@arrays/data/stock/historical-ratings',
            module_display_name: 'Historical Analyst Rating',
            sdk_name: 'getHistoricalRatings',
            sdk_display_name: 'Historical Analyst Rating',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stable/historical-ratings',
        };

        assert(ref.id === expected.id, 'Assertion failed: ref.id mismatch for ratings');
        assert(ref.module_name === expected.module_name, 'Assertion failed: ref.module_name mismatch for ratings');
        assert(ref.module_display_name === expected.module_display_name, 'Assertion failed: ref.module_display_name mismatch for ratings');
        assert(ref.sdk_name === expected.sdk_name, 'Assertion failed: ref.sdk_name mismatch for ratings');
        assert(ref.sdk_display_name === expected.sdk_display_name, 'Assertion failed: ref.sdk_display_name mismatch for ratings');
        assert(ref.source_name === expected.source_name, 'Assertion failed: ref.source_name mismatch for ratings');
        assert(ref.source === expected.source, 'Assertion failed: ref.source mismatch for ratings');
    });
}

function testGetHistoricalRatings() {
    console.log('\n=== Testing getHistoricalRatings (Direct Function) ===');
    const { getHistoricalRatings } = require('@arrays/data/stock/historical-ratings:v1.0.0');

    let totalTests = 0;
    let passedTests = 0;

    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    // Helper: validate basic structure of a single rating record
    function validateRatingRecord(rec, symbol) {
        const numericFields = [
            'overallScore', 'discountedCashFlowScore', 'returnOnEquityScore', 'returnOnAssetsScore',
            'debtToEquityScore', 'priceToEarningsScore', 'priceToBookScore'
        ];
        assert(typeof rec.symbol === 'string', 'symbol should be string');
        if (symbol) assert(rec.symbol.toUpperCase() === symbol.toUpperCase(), 'record symbol mismatch');
        assert(/^\d{4}-\d{2}-\d{2}$/.test(rec.date), 'date format should be YYYY-MM-DD');
        assert(
            typeof rec.rating === 'string' && /^[A-F](?:[+-])?$/.test(rec.rating),
            'rating should be a letter A-F optionally suffixed by + or -'
        );
        numericFields.forEach((f) => {
            assert(Number.isFinite(rec[f]), `${f} should be a finite number`);
        });
        // overall score usually 0-100 per doc
        assert(rec.overallScore >= 0 && rec.overallScore <= 100, 'overallScore should be between 0 and 100');
    }

    // Helper: validate response structure
    function validateResponse(res, { symbol, limit }) {
        assert(res && typeof res === 'object', 'Result should be an object');
        assert(res.success === true, 'success flag should be true');
        assert(res.response && typeof res.response === 'object', 'response should exist');
        assert(Array.isArray(res.response.ratings), 'ratings should be an array');

        const arr = res.response.ratings;
        // limit may cap the length, but provider may return fewer
        if (typeof limit === 'number' && limit > 0) {
            assert(arr.length <= limit, 'ratings length should be <= requested limit');
        }
        assert(res.response.limit === arr.length, 'response.limit should equal ratings length');

        // Validate each record shape and types
        if (arr.length > 0) {
            arr.forEach((rec) => validateRatingRecord(rec, symbol));

            // Ensure sorted from most recent to oldest
            for (let i = 1; i < arr.length; i++) {
                assert(arr[i - 1].date >= arr[i].date, 'ratings should be sorted most recent to oldest');
            }
        }
    }

    // ============ Happy Path ============
    ;['AAPL', 'MSFT'].forEach((sym) => {
        runTest(`happy path: ${sym} with limit=3`, () => {
            const res = getHistoricalRatings({ symbol: sym, limit: 3 });
            validateResponse(res, { symbol: sym, limit: 3 });
        });
    });

    runTest('default limit is 1 when omitted', () => {
        const res = getHistoricalRatings({ symbol: 'AAPL' });
        validateResponse(res, { symbol: 'AAPL' });
        assert(res.response.ratings.length === 1, 'default limit should return 1 record');
    });

    // ============ Boundary Value Analysis ============
    runTest('limit=1 (minimum valid)', () => {
        const res = getHistoricalRatings({ symbol: 'AAPL', limit: 1 });
        validateResponse(res, { symbol: 'AAPL', limit: 1 });
        assert(res.response.ratings.length <= 1, 'should return at most 1 record');
    });

    runTest('limit=2 (small set)', () => {
        const res = getHistoricalRatings({ symbol: 'AAPL', limit: 2 });
        validateResponse(res, { symbol: 'AAPL', limit: 2 });
        assert(res.response.ratings.length <= 2, 'should return at most 2 records');
    });

    runTest('limit=50 (large set)', () => {
        const res = getHistoricalRatings({ symbol: 'AAPL', limit: 50 });
        validateResponse(res, { symbol: 'AAPL', limit: 50 });
        assert(res.response.ratings.length <= 50, 'should return at most 50 records');
    });

    // ============ Special Values and Error Handling ============
    runTest('empty string symbol should error', () => {
        try {
            getHistoricalRatings({ symbol: '', limit: 1 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(
                /symbol|invalid|Error/i.test(e.message || ''),
                'Should handle empty symbol with an error'
            );
        }
    });

    runTest('null symbol should error', () => {
        try {
            getHistoricalRatings({ symbol: null, limit: 1 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(/symbol|invalid|Error/i.test(e.message || ''), 'Should handle null symbol with an error');
        }
    });

    runTest('undefined symbol should error', () => {
        try {
            // @ts-ignore - intentionally undefined
            getHistoricalRatings({});
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(/symbol|invalid|Error/i.test(e.message || ''), 'Should handle missing symbol with an error');
        }
    });

    runTest('non-string symbol should error', () => {
        try {
            // @ts-ignore - intentionally wrong type
            getHistoricalRatings({ symbol: 12345, limit: 1 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(/symbol|invalid|Error/i.test(e.message || ''), 'Should handle non-string symbol with an error');
        }
    });

    runTest('limit=0 should error or fall back safely', () => {
        let threw = false;
        try {
            const res = getHistoricalRatings({ symbol: 'AAPL', limit: 0 });
            // If no error thrown, validate structure and non-negative length
            validateResponse(res, { symbol: 'AAPL' });
            assert(res.response.ratings.length >= 0, 'ratings length should be non-negative');
        } catch (e) {
            threw = true;
            assert(/limit|invalid|Error/i.test(e.message || ''), 'Should handle invalid limit (0)');
        }
        assert(threw || true, 'Either throws or returns a valid fallback');
    });

    runTest('negative limit should error or fall back safely', () => {
        let threw = false;
        try {
            const res = getHistoricalRatings({ symbol: 'AAPL', limit: -5 });
            // If no error thrown, validate structure and non-negative length
            validateResponse(res, { symbol: 'AAPL' });
            assert(res.response.ratings.length >= 0, 'ratings length should be non-negative');
        } catch (e) {
            threw = true;
            assert(/limit|invalid|Error/i.test(e.message || ''), 'Should handle invalid negative limit');
        }
        assert(threw || true, 'Either throws or returns a valid fallback');
    });

    // Print test summary
    console.log('\n=== getHistoricalRatings Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    if (passedTests !== totalTests) {
        console.log('⚠️  Some getHistoricalRatings tests failed. Please review the output above.');
    } else {
        console.log('🎉 All getHistoricalRatings tests passed!');
    }
}

function main() {
    // Provide a simple runTest wrapper for the graph test to align with example style
    let t = 0, p = 0;
    const runTest = (name, fn) => {
        t++;
        try {
            fn();
            console.log(`✅ ${name}`);
            p++;
        } catch (e) {
            console.log(`❌ ${name}: ${e.message}`);
        }
    };

    console.log('\n=== Testing Graph Node and Refs ===');
    testGraphNodeAndRefs(runTest);
    console.log(`Graph tests passed: ${p}/${t}`);

    // Now run direct function tests styled after example.js
    testGetHistoricalRatings();
}

main();
