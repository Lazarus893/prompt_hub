const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');

// =============== Additional tests for getMergersAcquisitions ===============
function testGetMergersAcquisitions() {
  console.log('\n=== Testing getMergersAcquisitions API ===');

  const { getMergersAcquisitions } = require('@arrays/data/stock/mergers-acquisitions:v1.0.0');

  let totalTests = 0;
  let passedTests = 0;

  function assert(cond, msg) {
    if (!cond) throw new Error(msg || 'Assertion failed');
  }

  function runTest(name, fn) {
    totalTests++;
    try {
      fn();
      console.log(`✅ ${name}`);
      passedTests++;
    } catch (e) {
      console.log(`❌ ${name}: ${e.message}`);
    }
  }

  const isYYYYMMDD = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s);

  function extractDataArray(result) {
    if (result && result.response && Array.isArray(result.response.data)) return result.response.data;
    if (result && result.response && Array.isArray(result.response)) return result.response;
    if (result && result.result && result.result.data && Array.isArray(result.result.data)) return result.result.data;
    if (result && Array.isArray(result.data)) return result.data;
    if (Array.isArray(result)) return result;
    // Fallbacks: sometimes single object or no data field; treat as empty
    if (result && result.response && result.response.data && typeof result.response.data === 'object') {
      return [result.response.data];
    }
    return [];
  }

  function checkResultShape(result, opts = {}) {
    assert(result && typeof result === 'object', 'result should be an object');
    if ('success' in result) assert(typeof result.success === 'boolean', 'result.success should be boolean');

    const data = extractDataArray(result);
    assert(Array.isArray(data), 'response.data should be an array');

    if (data.length > 0) {
      const item = data[0];
      const requiredStringFields = [
        'companyName', 'cik', 'symbol', 'targetedCompanyName',
        'targetedCik', 'targetedSymbol', 'transactionDate', 'acceptanceTime', 'url'
      ];
      for (const k of requiredStringFields) {
        assert(typeof item[k] === 'string', `data[0].${k} should be string`);
      }
      assert(isYYYYMMDD(item.transactionDate), 'transactionDate should be YYYY-MM-DD');
      assert(item.url.length > 0, 'url should be non-empty');
    }

    if (opts.expectEmpty === true) {
      assert(Array.isArray(data) && data.length === 0, 'expected empty data array');
    }
  }

  // ---------------- Happy Path ----------------
  runTest('Happy: symbol only', () => {
    const res = getMergersAcquisitions({ symbol: 'AAPL' });
    checkResultShape(res);
  });

  runTest('Happy: date range only', () => {
    const res = getMergersAcquisitions({ from: '2023-08-10', to: '2023-08-15' });
    checkResultShape(res);
  });

  runTest('Happy: symbol + date range', () => {
    const res = getMergersAcquisitions({ symbol: 'AAPL', from: '2023-08-10', to: '2023-08-15' });
    checkResultShape(res);
  });

  runTest('Happy: empty params {}', () => {
    const res = getMergersAcquisitions({});
    checkResultShape(res);
  });

  // ---------------- Boundary Value Analysis ----------------
  runTest('Boundary: same-day window', () => {
    const day = '2023-08-10';
    const res = getMergersAcquisitions({ from: day, to: day });
    checkResultShape(res);
  });

  runTest('Boundary: large window (count may exceed 100)', () => {
    const res = getMergersAcquisitions({ from: '2000-01-01', to: '2030-01-01' });
    checkResultShape(res);
  });

  // ---------------- Special Values ----------------
  runTest('Special: params undefined', () => {
    let threw = false;
    let res;
    try {
      res = getMergersAcquisitions();
    } catch (e) {
      threw = true;
    }
    if (!threw) {
      checkResultShape(res);
    }
  });

  runTest('Special: params null (should be handled gracefully)', () => {
    let threw = false;
    let res;
    try {
      res = getMergersAcquisitions(null);
    } catch (e) {
      threw = true;
    }
    if (!threw) {
      checkResultShape(res);
    } else {
      assert(threw === false, 'Function should not throw on null');
    }
  });

  runTest('Special: empty string symbol', () => {
    let threw = false;
    let res;
    try {
      res = getMergersAcquisitions({ symbol: '' });
    } catch (e) {
      threw = true;
    }
    if (!threw) {
      checkResultShape(res);
    }
  });

  runTest('Special: empty string dates', () => {
    let threw = false;
    let res;
    try {
      res = getMergersAcquisitions({ from: '', to: '' });
    } catch (e) {
      threw = true;
    }
    if (!threw) {
      checkResultShape(res);
    }
  });

  // ---------------- Invalid Inputs and Error Handling ----------------
  runTest('Invalid: bad date format should error or return empty/valid object', () => {
    let threw = false;
    let res;
    try {
      res = getMergersAcquisitions({ from: '2023/08/10', to: '2023/08/15' });
    } catch (e) {
      threw = true;
    }
    if (!threw) {
      // Accept either empty results or valid shape
      const data = extractDataArray(res);
      assert(Array.isArray(data), 'Should return an array even for invalid date format');
    }
  });

  runTest('Invalid: from > to should error or return empty/valid object', () => {
    let threw = false;
    let res;
    try {
      res = getMergersAcquisitions({ from: '2023-08-15', to: '2023-08-10' });
    } catch (e) {
      threw = true;
    }
    if (!threw) {
      const data = extractDataArray(res);
      assert(Array.isArray(data), 'Should return an array even for inverted date range');
    }
  });

  console.log('\n=== getMergersAcquisitions Test Summary ===');
  console.log(`Total tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${totalTests - passedTests}`);
  console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function main() {
  const { makeMergersAcquisitionsNode } = require('@arrays/data/stock/mergers-acquisitions:v1.0.0');

  const node = makeMergersAcquisitionsNode({ page: 0 });
  const rawKey = 'mergers_acquisitions_rss_feed_raw';

  const sample = {
    success: true,
    response: {
      count: 4,
      data: [
        {
          companyName: 'Acquirer A',
          cik: '0000000001',
          symbol: 'ACQA',
          targetedCompanyName: 'Target 1',
          targetedCik: '0000001000',
          targetedSymbol: 'TRG1',
          transactionDate: '2025-01-15',
          acceptanceTime: '2025-01-16T14:30:00Z',
          url: 'https://www.sec.gov/Archives/edgar/data/a',
        },
        {
          companyName: 'Acquirer B',
          cik: '0000000002',
          symbol: 'ACQB',
          targetedCompanyName: 'Target 2',
          targetedCik: '0000002000',
          targetedSymbol: 'TRG2',
          transactionDate: '2025-01-15',
          acceptanceTime: '2025-01-15T13:00:00Z',
          url: 'https://www.sec.gov/Archives/edgar/data/b',
        },
        {
          companyName: 'Acquirer C',
          cik: '0000000003',
          symbol: 'ACQC',
          targetedCompanyName: 'Target 3',
          targetedCik: '0000003000',
          targetedSymbol: 'TRG3',
          transactionDate: '2025-01-14',
          acceptanceTime: '2025-01-14T09:00:00Z',
          url: 'https://www.sec.gov/Archives/edgar/data/c',
        },
        {
          companyName: 'Acquirer D',
          cik: '0000000004',
          symbol: 'ACQD',
          targetedCompanyName: 'Target 4',
          targetedCik: '0000004000',
          targetedSymbol: 'TRG4',
          transactionDate: '2025-01-16',
          acceptanceTime: '2025-01-16T10:00:00Z',
          url: 'https://www.sec.gov/Archives/edgar/data/d',
        },
      ],
    },
  };

  const outputs = node.run({ [rawKey]: sample });
  const grouped = outputs['events_by_transaction_date'];
  if (!Array.isArray(grouped)) {
    throw new Error('grouped output must be an array');
  }
  // Expect dates sorted descending: 2025-01-16, 2025-01-15, 2025-01-14
  if (grouped.length !== 3) {
    throw new Error(`expected 3 groups, got ${grouped.length}`);
  }
  const total = grouped.reduce((acc, g) => acc + (typeof g.count === 'number' ? g.count : Array.isArray(g.events) ? g.events.length : 0), 0);
  if (total !== 4) {
    throw new Error(`expected total 4 events, got ${total}`);
  }
  const firstDate = grouped[0].date;
  const lastDate = grouped[grouped.length - 1].date;
  if (!(firstDate > lastDate)) {
    throw new Error('dates must be sorted descending');
  }
  if (!Array.isArray(grouped[1].events) || grouped[1].events.length !== 2) {
    throw new Error('middle group should contain 2 events');
  }
  // USING ONLINE DATA FOR TESTING
  const nodeCfgOnline = makeMergersAcquisitionsNode({ from: '2023-08-10', to: '2023-08-15' });
  const g2 = new Graph(jagentId);
  g2.addNode('ma_online', nodeCfgOnline);
  g2.run();
  const ts2 = new TimeSeries(new TimeSeriesUri(jagentId, 'ma_online', 'events_by_transaction_date', { last: '10' }), g2.store);
  ts2.init();
  if (!Array.isArray(ts2.data)) {
    throw new Error('online: grouped output must be an array');
  }
  const onlineGroups = ts2.data;
  if (onlineGroups.length < 1) {
    throw new Error('online: expected at least 1 group');
  }
  // Expect 3 groups and total 8 items for 2023-08-10..2023-08-15 per sample
  if (onlineGroups.length !== 3) {
    throw new Error(`online: expected 3 groups, got ${onlineGroups.length}`);
  }
  const onlineTotal = onlineGroups.reduce((acc, g) => acc + (typeof g.count === 'number' ? g.count : Array.isArray(g.events) ? g.events.length : 0), 0);
  if (onlineTotal !== 8) {
    throw new Error(`online: expected total 8 events, got ${onlineTotal}`);
  }
  // Ensure descending order
  if (!(onlineGroups[0].date > onlineGroups[onlineGroups.length - 1].date)) {
    throw new Error('online: groups should be sorted descending');
  }

  // Validate refs for output events_by_transaction_date
  {
    const gRef = new Graph(jagentId);
    const nodeRef = makeMergersAcquisitionsNode({ page: 0 });
    gRef.addNode('ma_ref', nodeRef);
    gRef.run();
    const refs = gRef.getRefsForOutput('ma_ref', 'events_by_transaction_date');
    if (refs.length > 0) {
      const ref = refs[0];
      const expected = {
        id: '@arrays/data/stock/mergers-acquisitions/getMergersAcquisitions',
        module_name: '@arrays/data/stock/mergers-acquisitions',
        module_display_name: 'Company M&A Calendar',
        sdk_name: 'getMergersAcquisitions',
        sdk_display_name: 'Company M&A Calendar',
        source_name: 'Financial Modeling Prep',
        source: 'https://site.financialmodelingprep.com/developer/docs/merger-and-acquisition-api',
      };
      if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for events_by_transaction_date');
      if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for events_by_transaction_date');
      if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for events_by_transaction_date');
      if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for events_by_transaction_date');
      if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for events_by_transaction_date');
      if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for events_by_transaction_date');
      if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for events_by_transaction_date');
    } else {
      throw new Error('Assertion failed: refs array is empty for events_by_transaction_date.');
    }
  }

  // After existing node/graph tests, run direct API tests per doc
  testGetMergersAcquisitions();
}

main();
