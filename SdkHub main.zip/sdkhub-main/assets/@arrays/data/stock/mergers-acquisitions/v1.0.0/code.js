const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for this SDK following the global pattern
const getMergersAcquisitionsRef = {
    id: "@arrays/data/stock/mergers-acquisitions/getMergersAcquisitions",
    module_name: "@arrays/data/stock/mergers-acquisitions",
    module_display_name: "Company M&A Calendar",
    sdk_name: "getMergersAcquisitions",
    sdk_display_name: "Company M&A Calendar",
    source_name: "Financial Modeling Prep",
    source: "https://site.financialmodelingprep.com/developer/docs/merger-and-acquisition-api",
};

// Internal description strings and dynamic description builders (not exported)
const baseGetMergersAcquisitionsDesc = "Retrieve M&A data";

function buildGetMergersAcquisitionsCallDescription(actualParams = {}) {
    const parts = [baseGetMergersAcquisitionsDesc];

    // Add symbol context if provided
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }

    // Add date filters if provided
    const filters = [];
    if (actualParams.from && actualParams.to) {
        filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
    } else if (actualParams.from) {
        filters.push(`From: ${actualParams.from}`);
    } else if (actualParams.to) {
        filters.push(`Until: ${actualParams.to}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getMergersAcquisitions(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/mergers-acquisitions';
    const qs =
        params && Object.keys(params).length > 0
            ? '?' +
                Object.keys(params)
                    .map((k) => encodeURIComponent(k) + '=' + encodeURIComponent(params[k]))
                    .join('&')
            : '';
    const fullUrl = `${baseUrl}${qs}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key || 'c84b079d-3888-4366-9752-10bb6c51543d',
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function makeMergersAcquisitionsNode(params) {
    function parseAcceptanceMs(s) {
        if (typeof s !== 'string') return null;
        const t = Date.parse(s);
        return Number.isFinite(t) ? t : null;
    }
    function parseYyyyMmDdMs(s) {
        if (typeof s !== 'string') return null;
        const parts = s.split('-');
        if (parts.length !== 3) return null;
        const y = Number(parts[0]);
        const m = Number(parts[1]);
        const d = Number(parts[2]);
        if (!Number.isFinite(y) || !Number.isFinite(m) || !Number.isFinite(d)) return null;
        return Date.UTC(y, m - 1, d, 0, 0, 0, 0);
    }

    return {
        inputs: {
            mergers_acquisitions_rss_feed_raw: () => getMergersAcquisitions(params),
        },
        /**
         * Output schema: group events by transaction date (UTC midnight). Multiple events can
         * occur on the same date, so each group contains an array of items for that date.
         * If transactionDate is missing, the group date falls back to the acceptanceTime day (UTC midnight).
         */
        outputs: {
            events_by_transaction_date: {
                name: 'events_by_transaction_date',
                description: 'M&A events grouped by transaction date (UTC midnight).',
                fields: [
                    { name: 'date', type: 'number', description: 'transaction date ms (UTC midnight) or acceptance day if missing' },
                    { name: 'count', type: 'number', description: 'number of events on this date' },
                    {
                        name: 'events',
                        type: 'array',
                        description: 'events for this date',
                        fields: [
                            { name: 'company_name', type: 'string' },
                            { name: 'cik', type: 'string' },
                            { name: 'symbol', type: 'string' },
                            { name: 'targeted_company_name', type: 'string' },
                            { name: 'targeted_cik', type: 'string' },
                            { name: 'targeted_symbol', type: 'string' },
                            { name: 'acceptance_time', type: 'number', description: 'SEC filing acceptance time ms if provided' },
                            { name: 'url', type: 'string' },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getMergersAcquisitionsRef, params, buildGetMergersAcquisitionsCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.mergers_acquisitions_rss_feed_raw;
            const arr = raw && raw.response && Array.isArray(raw.response.data) ? raw.response.data : [];
            const byDate = new Map(); // key: ms at UTC midnight, value: items[]

            for (const item of arr) {
                const acceptanceMs = parseAcceptanceMs(item && item.acceptanceTime);
                const txnMs = parseYyyyMmDdMs(item && item.transactionDate);
                // Grouping key: transaction date (midnight) if present; otherwise acceptance day (midnight)
                let groupDateMs = txnMs;
                if (groupDateMs == null && acceptanceMs != null) {
                    const d = new Date(acceptanceMs);
                    groupDateMs = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 0, 0, 0, 0);
                }
                if (groupDateMs == null) {
                    // skip records with no valid time reference
                    continue;
                }
                if (!byDate.has(groupDateMs)) byDate.set(groupDateMs, []);
                byDate.get(groupDateMs).push({
                    company_name: item && item.companyName != null ? item.companyName : '',
                    cik: item && item.cik != null ? item.cik : '',
                    symbol: item && item.symbol != null ? item.symbol : '',
                    targeted_company_name: item && item.targetedCompanyName != null ? item.targetedCompanyName : '',
                    targeted_cik: item && item.targetedCik != null ? item.targetedCik : '',
                    targeted_symbol: item && item.targetedSymbol != null ? item.targetedSymbol : '',
                    acceptance_time: acceptanceMs != null ? acceptanceMs : undefined,
                    url: item && item.url != null ? item.url : '',
                });
            }

            const records = Array.from(byDate.entries())
                .sort((a, b) => b[0] - a[0])
                .map(([date, items]) => ({ date, count: items.length, events: items }));

            return { events_by_transaction_date: records };
        },
    };
}

function getRefs() {
    return [getMergersAcquisitionsRef];
}

module.exports = {
    getMergersAcquisitions,
    makeMergersAcquisitionsNode,
    getRefs,
};
