function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
}

function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const {
        makeCompanyBalanceStatementsNode,
        getCompanyBalanceStatements,
    } = require('@arrays/data/stock/company/balance:v1.0.0');

    let totalTests = 0;
    let passedTests = 0;

    function runTest(name, fn) {
        totalTests++;
        try {
            fn();
            console.log(`✅ ${name}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${name}: ${e.message}`);
        }
    }

    function extractMetrics(res) {
        if (res && res.response && Array.isArray(res.response.metrics)) return res.response.metrics;
        if (res && res.result && Array.isArray(res.result.data)) return res.result.data; // fallback style
        if (res && Array.isArray(res.metrics)) return res.metrics;
        if (res && Array.isArray(res.data)) return res.data;
        return null;
    }

    // ===================== Direct getCompanyBalanceStatements Tests =====================
    console.log('\n=== Testing getCompanyBalanceStatements (Direct) ===');

    const PERIOD_ENUMS = ['quarterly', 'annual', 'Q1', 'Q2', 'Q3', 'Q4'];
    const SYMBOL = 'AAPL';

    // Happy Path: cover all enum values for period
    for (const period of PERIOD_ENUMS) {
        runTest(`getCompanyBalanceStatements happy path - period=${period}`, () => {
            const res = getCompanyBalanceStatements({ symbol: SYMBOL, period, limit: '2' });
            assert(res && typeof res === 'object', 'Should return an object');
            const metrics = extractMetrics(res);
            assert(Array.isArray(metrics), 'metrics should be an array');
            if (metrics.length > 0) {
                const m = metrics[0];
                assert(typeof m.date === 'string', 'date should be a string (YYYY-MM-DD)');
                if ('period' in m) {
                    if (period === 'quarterly') {
                        assert(['Q1', 'Q2', 'Q3', 'Q4'].includes(m.period), 'period should be one of Q1/Q2/Q3/Q4 for quarterly');
                    } else if (period === 'annual') {
                        assert(['FY', 'Q4', 'annual'].includes(m.period), 'annual should map to FY (or equivalent)');
                    } else {
                        assert(m.period === period, `period should equal ${period}`);
                    }
                }
            }
        });
    }

    // Boundary Value Analysis: limit and cursor
    runTest('getCompanyBalanceStatements boundary - limit min=1', () => {
        const res = getCompanyBalanceStatements({ symbol: SYMBOL, period: 'quarterly', limit: '1' });
        const metrics = extractMetrics(res);
        assert(Array.isArray(metrics), 'metrics should be array');
        assert(metrics.length <= 1, 'Should respect limit=1');
    });

    runTest('getCompanyBalanceStatements boundary - limit large', () => {
        const res = getCompanyBalanceStatements({ symbol: SYMBOL, period: 'quarterly', limit: '100' });
        const metrics = extractMetrics(res);
        assert(Array.isArray(metrics), 'metrics should be array');
    });

    runTest('getCompanyBalanceStatements boundary - limit zero-like', () => {
        const res = getCompanyBalanceStatements({ symbol: SYMBOL, period: 'quarterly', limit: '0' });
        const metrics = extractMetrics(res);
        assert(Array.isArray(metrics), 'metrics should be array even with limit=0');
    });

    runTest('getCompanyBalanceStatements boundary - cursor examples', () => {
        const res1 = getCompanyBalanceStatements({ symbol: SYMBOL, period: 'quarterly', limit: '2', cursor: '2015-01-01' });
        const res2 = getCompanyBalanceStatements({ symbol: SYMBOL, period: 'quarterly', limit: '2', cursor: '2025-06-28' });
        const m1 = extractMetrics(res1);
        const m2 = extractMetrics(res2);
        assert(Array.isArray(m1) && Array.isArray(m2), 'metrics arrays should be present for cursors');
    });

    // Special Value Tests: optional params null/undefined/empty
    runTest('getCompanyBalanceStatements special - omit optional params', () => {
        const res = getCompanyBalanceStatements({ symbol: SYMBOL, period: 'quarterly' });
        const metrics = extractMetrics(res);
        assert(Array.isArray(metrics), 'metrics should be array when optional params omitted');
    });

    runTest('getCompanyBalanceStatements special - empty string cursor', () => {
        const res = getCompanyBalanceStatements({ symbol: SYMBOL, period: 'quarterly', cursor: '' });
        const metrics = extractMetrics(res);
        assert(Array.isArray(metrics), 'metrics should be array with empty cursor');
    });

    // Error Handling: required params and invalid enums
    runTest('getCompanyBalanceStatements error - missing symbol', () => {
        try {
            getCompanyBalanceStatements({ period: 'quarterly', limit: '2' });
            throw new Error('Expected error for missing symbol');
        } catch (e) {
            assert(e.message.includes('symbol') || e.message.includes('Required') || e.message.includes('missing'), 'Should indicate missing symbol');
        }
    });

    runTest('getCompanyBalanceStatements error - missing period', () => {
        try {
            getCompanyBalanceStatements({ symbol: SYMBOL, limit: '2' });
            throw new Error('Expected error for missing period');
        } catch (e) {
            assert(e.message.includes('period') || e.message.includes('Required') || e.message.includes('missing'), 'Should indicate missing period');
        }
    });

    runTest('getCompanyBalanceStatements error - invalid period enum', () => {
        try {
            getCompanyBalanceStatements({ symbol: SYMBOL, period: 'Q5', limit: '2' });
            throw new Error('Expected error for invalid period');
        } catch (e) {
            assert(e.message.includes('period') || e.message.includes('Invalid') || e.message.includes('enum'), 'Should indicate invalid period');
        }
    });

    runTest('getCompanyBalanceStatements error - invalid symbol', () => {
        try {
            getCompanyBalanceStatements({ symbol: 'INVALID', period: 'quarterly', limit: '2' });
            throw new Error('Expected error for invalid symbol');
        } catch (e) {
            assert(e.message.toLowerCase().includes('invalid') || e.message.toLowerCase().includes('error'), 'Should indicate invalid symbol');
        }
    });

    // Special: lowercase symbol should still work or be handled gracefully
    runTest('getCompanyBalanceStatements lowercase symbol handling', () => {
        const res = getCompanyBalanceStatements({ symbol: 'aapl', period: 'quarterly', limit: '2' });
        assert(res && typeof res === 'object', 'Should return object for lowercase symbol if normalization is supported');
    });

    // ===================== Graph/Node Integration Tests (Existing) =====================
    console.log('\n=== Testing Graph/Node Integration ===');

    runTest('Graph Node -> TimeSeries balance_statements end-to-end', () => {
        const g = new Graph(jagentId);
        g.addNode(
            'balance_aapl',
            makeCompanyBalanceStatementsNode({
                symbol: 'AAPL',
                period: 'quarterly',
                limit: '4',
            })
        );

        g.run();

        const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'balance_aapl', 'balance_statements', { last: '5' }), g.store);
        ts.init();

        if (!ts.data.length) throw new Error('balance_statements empty');
        const row = ts.data[0];
        [
            'date',
            'symbol',
            'fiscal_year',
            'period',
            'cash_and_cash_equivalents',
            'short_term_investments',
            'cash_and_short_term_investments',
            'net_receivables',
            'accounts_receivables',
            'other_receivables',
            'inventory',
            'prepaids',
            'other_current_assets',
            'total_current_assets',
            'property_plant_equipment_net',
            'goodwill',
            'intangible_assets',
            'goodwill_and_intangible_assets',
            'long_term_investments',
            'tax_assets',
            'other_non_current_assets',
            'total_non_current_assets',
            'other_assets',
            'total_assets',
            'total_payables',
            'account_payables',
            'other_payables',
            'accrued_expenses',
            'short_term_debt',
            'capital_lease_obligations_current',
            'tax_payables',
            'deferred_revenue',
            'other_current_liabilities',
            'total_current_liabilities',
            'long_term_debt',
            'capital_lease_obligations_non_current',
            'deferred_revenue_non_current',
            'deferred_tax_liabilities_non_current',
            'other_non_current_liabilities',
            'total_non_current_liabilities',
            'other_liabilities',
            'capital_lease_obligations',
            'total_liabilities',
            'treasury_stock',
            'preferred_stock',
            'common_stock',
            'retained_earnings',
            'additional_paid_in_capital',
            'accumulated_other_comprehensive_income_loss',
            'other_total_stockholders_equity',
            'total_stockholders_equity',
            'total_equity',
            'minority_interest',
            'total_liabilities_and_total_equity',
            'total_investments',
            'total_debt',
            'net_debt',
        ].forEach((k) => {
            if (!(k in row)) throw new Error('missing field: ' + k);
        });
        if (typeof row.date !== 'number') throw new Error('date must be number (ms)');

        // refs validation for balance_statements
        const refsBalance = g.getRefsForOutput('balance_aapl', 'balance_statements');
        if (refsBalance.length > 0) {
            const ref = refsBalance[0];
            const expected = {
                id: '@arrays/data/stock/company/balance/getCompanyBalanceStatements',
                module_name: '@arrays/data/stock/company/balance',
                module_display_name: 'Company Financials - Balance Sheets',
                sdk_name: 'getCompanyBalanceStatements',
                sdk_display_name: 'Company Financials - Balance Sheets',
                source_name: 'Financial Modeling Prep',
                source: 'https://site.financialmodelingprep.com/developer/docs/stable/balance-sheet-statement',
            };

            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for balance_statements');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for balance_statements');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for balance_statements');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for balance_statements');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for balance_statements');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for balance_statements');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for balance_statements');
        } else {
            throw new Error('Assertion failed: refsBalance array is empty.');
        }
    });

    // ===================== Summary =====================
    console.log('\n=== Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    if (passedTests !== totalTests) {
        throw new Error('Some tests failed. Please review the output above.');
    }

    // pagination 暂不支持，测试不再校验
    return 0;
}

main();
