const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getCompanyBalanceStatements, derived from tool.json
const getCompanyBalanceStatementsRef = {
	id: "@arrays/data/stock/company/balance/getCompanyBalanceStatements",
	module_name: "@arrays/data/stock/company/balance",
	module_display_name: "Company Financials - Balance Sheets",
	sdk_name: "getCompanyBalanceStatements",
	sdk_display_name: "Company Financials - Balance Sheets",
	source_name: "Financial Modeling Prep",
	source: "https://site.financialmodelingprep.com/developer/docs/stable/balance-sheet-statement",
};

// Base description and dynamic call description builder for getCompanyBalanceStatements (derived from doc)
const getCompanyBalanceStatementsBaseDesc = "Retrieve company balance statements";
function buildGetCompanyBalanceStatementsCallDescription(actualParams = {}) {
    const parts = [getCompanyBalanceStatementsBaseDesc];

    // Attach primary identifier if provided
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }

    // Collect filters/details
    const details = [];
    if (actualParams.period) {
        details.push(`Period: ${actualParams.period}`);
    }
    if (actualParams.limit) {
        details.push(`Limit: ${actualParams.limit}`);
    }
    if (actualParams.cursor) {
        details.push(`Cursor: ${actualParams.cursor}`);
    }

    if (details.length > 0) {
        parts.push(`(${details.join(', ')})`);
    }

    return parts.join(' ').trim();
}

// Utility to create a reference object with a dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getCompanyBalanceStatements(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/company/balance_statements';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function makeCompanyBalanceStatementsNode(params) {
    function parseYyyyMmDdToUtcMs(s) {
        if (typeof s !== 'string') return undefined;
        const parts = s.split('-');
        if (parts.length !== 3) return undefined;
        const y = Number(parts[0]);
        const m = Number(parts[1]);
        const d = Number(parts[2]);
        if (!Number.isFinite(y) || !Number.isFinite(m) || !Number.isFinite(d)) return undefined;
        return Date.UTC(y, m - 1, d, 0, 0, 0, 0);
    }

    return {
        inputs: {
            company_balance_statements_raw: () => getCompanyBalanceStatements(params),
        },
        outputs: {
            balance_statements: {
                name: 'balance_statements',
                description: 'Company balance statements (one record per reported period).',
                fields: [
                    { name: 'date', type: 'number', description: 'statement date ms (UTC) derived from YYYY-MM-DD' },
                    { name: 'symbol', type: 'string', description: 'company symbol' },
                    { name: 'fiscal_year', type: 'string', description: 'fiscal year' },
                    { name: 'period', type: 'string', description: 'FY/Q1/Q2/Q3/Q4' },
                    { name: 'cash_and_cash_equivalents', type: 'string', description: 'cash and equivalents USD' },
                    { name: 'short_term_investments', type: 'string', description: 'short-term investments USD' },
                    { name: 'cash_and_short_term_investments', type: 'string', description: 'cash and short-term investments USD' },
                    { name: 'net_receivables', type: 'string', description: 'net receivables USD' },
                    { name: 'accounts_receivables', type: 'string', description: 'accounts receivables USD' },
                    { name: 'other_receivables', type: 'string', description: 'other receivables USD' },
                    { name: 'inventory', type: 'string', description: 'inventory USD' },
                    { name: 'prepaids', type: 'string', description: 'prepaid expenses USD' },
                    { name: 'other_current_assets', type: 'string', description: 'other current assets USD' },
                    { name: 'total_current_assets', type: 'string', description: 'total current assets USD' },
                    { name: 'property_plant_equipment_net', type: 'string', description: 'property, plant & equipment, net USD' },
                    { name: 'goodwill', type: 'string', description: 'goodwill USD' },
                    { name: 'intangible_assets', type: 'string', description: 'intangible assets USD' },
                    { name: 'goodwill_and_intangible_assets', type: 'string', description: 'goodwill and intangible assets USD' },
                    { name: 'long_term_investments', type: 'string', description: 'long-term investments USD' },
                    { name: 'tax_assets', type: 'string', description: 'tax assets USD' },
                    { name: 'other_non_current_assets', type: 'string', description: 'other non-current assets USD' },
                    { name: 'total_non_current_assets', type: 'string', description: 'total non-current assets USD' },
                    { name: 'other_assets', type: 'string', description: 'other assets USD' },
                    { name: 'total_assets', type: 'string', description: 'total assets USD' },
                    { name: 'total_payables', type: 'string', description: 'total payables USD' },
                    { name: 'account_payables', type: 'string', description: 'accounts payables USD' },
                    { name: 'other_payables', type: 'string', description: 'other payables USD' },
                    { name: 'accrued_expenses', type: 'string', description: 'accrued expenses USD' },
                    { name: 'short_term_debt', type: 'string', description: 'short-term debt USD' },
                    { name: 'capital_lease_obligations_current', type: 'string', description: 'current capital lease obligations USD' },
                    { name: 'tax_payables', type: 'string', description: 'tax payables USD' },
                    { name: 'deferred_revenue', type: 'string', description: 'deferred revenue USD' },
                    { name: 'other_current_liabilities', type: 'string', description: 'other current liabilities USD' },
                    { name: 'total_current_liabilities', type: 'string', description: 'total current liabilities USD' },
                    { name: 'long_term_debt', type: 'string', description: 'long-term debt USD' },
                    { name: 'capital_lease_obligations_non_current', type: 'string', description: 'non-current capital lease obligations USD' },
                    { name: 'deferred_revenue_non_current', type: 'string', description: 'non-current deferred revenue USD' },
                    { name: 'deferred_tax_liabilities_non_current', type: 'string', description: 'non-current deferred tax liabilities USD' },
                    { name: 'other_non_current_liabilities', type: 'string', description: 'other non-current liabilities USD' },
                    { name: 'total_non_current_liabilities', type: 'string', description: 'total non-current liabilities USD' },
                    { name: 'other_liabilities', type: 'string', description: 'other liabilities USD' },
                    { name: 'capital_lease_obligations', type: 'string', description: 'total capital lease obligations USD' },
                    { name: 'total_liabilities', type: 'string', description: 'total liabilities USD' },
                    { name: 'treasury_stock', type: 'string', description: 'treasury stock USD' },
                    { name: 'preferred_stock', type: 'string', description: 'preferred stock USD' },
                    { name: 'common_stock', type: 'string', description: 'common stock USD' },
                    { name: 'retained_earnings', type: 'string', description: 'retained earnings USD' },
                    { name: 'additional_paid_in_capital', type: 'string', description: 'additional paid-in capital USD' },
                    { name: 'accumulated_other_comprehensive_income_loss', type: 'string', description: 'accumulated other comprehensive income (loss) USD' },
                    { name: 'other_total_stockholders_equity', type: 'string', description: 'other total stockholders equity USD' },
                    { name: 'total_stockholders_equity', type: 'string', description: 'total stockholders equity USD' },
                    { name: 'total_equity', type: 'string', description: 'total equity USD' },
                    { name: 'minority_interest', type: 'string', description: 'minority interest USD' },
                    { name: 'total_liabilities_and_total_equity', type: 'string', description: 'total liabilities and total equity USD' },
                    { name: 'total_investments', type: 'string', description: 'total investments USD' },
                    { name: 'total_debt', type: 'string', description: 'total debt USD' },
                    { name: 'net_debt', type: 'string', description: 'net debt USD' },
                ],
                ref: createReferenceWithTitle(getCompanyBalanceStatementsRef, params, buildGetCompanyBalanceStatementsCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.company_balance_statements_raw;
            if (!raw || !raw.success || !raw.response) {
                throw new Error('Company balance statements raw data is invalid');
            }
            const metrics = Array.isArray(raw.response?.metrics) ? raw.response.metrics : [];
            if (metrics.length === 0) {
                throw new Error('Company balance statements metrics is invalid');
            }

            let latestMs = undefined;
            for (const m of metrics) {
                const ms = parseYyyyMmDdToUtcMs(m.date);
                if (ms != null) {
                    if (latestMs == null || ms > latestMs) latestMs = ms;
                }
            }
            if (latestMs == null) {
                throw new Error('Unable to derive latest date from metrics.date');
            }

            const series = metrics.map((m) => ({
                date: parseYyyyMmDdToUtcMs(m.date),
                symbol: params.symbol || '',
                fiscal_year: m.fiscal_year,
                period: m.period,
                cash_and_cash_equivalents: m.cash_and_cash_equivalents,
                short_term_investments: m.short_term_investments,
                cash_and_short_term_investments: m.cash_and_short_term_investments,
                net_receivables: m.net_receivables,
                accounts_receivables: m.accounts_receivables,
                other_receivables: m.other_receivables,
                inventory: m.inventory,
                prepaids: m.prepaids,
                other_current_assets: m.other_current_assets,
                total_current_assets: m.total_current_assets,
                property_plant_equipment_net: m.property_plant_equipment_net,
                goodwill: m.goodwill,
                intangible_assets: m.intangible_assets,
                goodwill_and_intangible_assets: m.goodwill_and_intangible_assets,
                long_term_investments: m.long_term_investments,
                tax_assets: m.tax_assets,
                other_non_current_assets: m.other_non_current_assets,
                total_non_current_assets: m.total_non_current_assets,
                other_assets: m.other_assets,
                total_assets: m.total_assets,
                total_payables: m.total_payables,
                account_payables: m.account_payables,
                other_payables: m.other_payables,
                accrued_expenses: m.accrued_expenses,
                short_term_debt: m.short_term_debt,
                capital_lease_obligations_current: m.capital_lease_obligations_current,
                tax_payables: m.tax_payables,
                deferred_revenue: m.deferred_revenue,
                other_current_liabilities: m.other_current_liabilities,
                total_current_liabilities: m.total_current_liabilities,
                long_term_debt: m.long_term_debt,
                capital_lease_obligations_non_current: m.capital_lease_obligations_non_current,
                deferred_revenue_non_current: m.deferred_revenue_non_current,
                deferred_tax_liabilities_non_current: m.deferred_tax_liabilities_non_current,
                other_non_current_liabilities: m.other_non_current_liabilities,
                total_non_current_liabilities: m.total_non_current_liabilities,
                other_liabilities: m.other_liabilities,
                capital_lease_obligations: m.capital_lease_obligations,
                total_liabilities: m.total_liabilities,
                treasury_stock: m.treasury_stock,
                preferred_stock: m.preferred_stock,
                common_stock: m.common_stock,
                retained_earnings: m.retained_earnings,
                additional_paid_in_capital: m.additional_paid_in_capital,
                accumulated_other_comprehensive_income_loss: m.accumulated_other_comprehensive_income_loss,
                other_total_stockholders_equity: m.other_total_stockholders_equity,
                total_stockholders_equity: m.total_stockholders_equity,
                total_equity: m.total_equity,
                minority_interest: m.minority_interest,
                total_liabilities_and_total_equity: m.total_liabilities_and_total_equity,
                total_investments: m.total_investments,
                total_debt: m.total_debt,
                net_debt: m.net_debt,
            }));

            return {
                balance_statements: series,
            };
        },
    };
}

function getRefs() {
    return [
        getCompanyBalanceStatementsRef,
    ];
}

module.exports = {
    getCompanyBalanceStatements,
    makeCompanyBalanceStatementsNode,
    getRefs,
};
