const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getCompanyIncomeStatements derived from tool.json
const getCompanyIncomeStatementsRef = {
	id: "@arrays/data/stock/company/income/getCompanyIncomeStatements",
	module_name: "@arrays/data/stock/company/income",
	module_display_name: "Company Financials - Income Statement",
	sdk_name: "getCompanyIncomeStatements",
	sdk_display_name: "Company Financials - Income Statements",
	source_name: "Financial Modeling Prep",
	source: "https://site.financialmodelingprep.com/developer/docs/stable/income-statement",
};

// Base description derived from doc for getCompanyIncomeStatements
const getCompanyIncomeStatementsBaseDesc = "Get company income statements";

// Dynamic call description builder for getCompanyIncomeStatements
function buildGetCompanyIncomeStatementsCallDescription(actualParams = {}) {
    const parts = [getCompanyIncomeStatementsBaseDesc];

    // Core identifiers
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }
    if (actualParams.period) {
        parts.push(`period: ${actualParams.period}`);
    }

    // Optional filters
    const filters = [];
    if (actualParams.limit) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (actualParams.cursor) {
        filters.push(`Cursor: ${actualParams.cursor}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getCompanyIncomeStatements(params) {
	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/company/income_statements';
	const keyValuePairs = Object.keys(params || {}).map((key) => {
		const value = params[key];
		return encodeURIComponent(key) + '=' + encodeURIComponent(value);
	});
	const queryString = keyValuePairs.join('&');
	const fullUrl = `${baseUrl}?${queryString}`;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

function ymdToMs(s) {
	if (typeof s !== 'string') return null;
	const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s.trim());
	if (!m) return null;
	const y = +m[1];
	const mo0 = +m[2] - 1;
	const d = +m[3];
	return Date.UTC(y, mo0, d, 0, 0, 0, 0);
}

function makeCompanyIncomeStatementsNode(params) {
	return {
		inputs: {
			company_income_statements_raw: () => getCompanyIncomeStatements(params),
		},
		outputs: {
			income_statements: {
				name: 'income_statements',
				description: 'Company income statements, one record per statement (date = statement date, ms)',
				fields: [
					{ name: 'date', type: 'number', description: 'statement date ms (UTC), derived from YYYY-MM-DD' },
					{ name: 'fiscal_year', type: 'string', description: 'fiscal year' },
					{ name: 'period', type: 'string', description: 'FY/Q1/Q2/Q3/Q4' },
					{ name: 'symbol', type: 'string', description: 'stock symbol' },
					{ name: 'reported_currency', type: 'string', description: 'reported currency' },
					{ name: 'cik', type: 'string', description: 'Central Index Key' },
					{ name: 'filing_date', type: 'string', description: 'SEC filing date (YYYY-MM-DD)' },
					{ name: 'accepted_date', type: 'string', description: 'SEC acceptance datetime' },
					{ name: 'revenue', type: 'number', description: 'total revenue USD' },
					{ name: 'cost_of_revenue', type: 'number', description: 'cost of revenue USD' },
					{ name: 'gross_profit', type: 'number', description: 'gross profit USD' },
					{ name: 'research_and_development_expenses', type: 'number', description: 'R&D expenses USD' },
					{ name: 'selling_general_and_administrative_expenses', type: 'number', description: 'SG&A expenses USD' },
					{ name: 'operating_expenses', type: 'number', description: 'operating expenses USD' },
					{ name: 'cost_and_expenses', type: 'number', description: 'total cost and expenses USD' },
					{ name: 'depreciation_and_amortization', type: 'number', description: 'depreciation and amortization USD' },
					{ name: 'ebitda', type: 'number', description: 'EBITDA USD' },
					{ name: 'ebit', type: 'number', description: 'EBIT USD' },
					{ name: 'operating_income', type: 'number', description: 'operating income USD' },
					{ name: 'total_other_income_expenses_net', type: 'number', description: 'total other income expenses net USD' },
					{ name: 'income_before_tax', type: 'number', description: 'income before tax USD' },
					{ name: 'income_tax_expense', type: 'number', description: 'income tax expense USD' },
					{ name: 'net_income_from_continuing_operations', type: 'number', description: 'net income from continuing operations USD' },
					{ name: 'net_income', type: 'number', description: 'net income USD' },
					{ name: 'bottom_line_net_income', type: 'number', description: 'bottom line net income USD' },
					{ name: 'eps', type: 'number', description: 'earnings per share basic' },
					{ name: 'eps_diluted', type: 'number', description: 'earnings per share diluted' },
					{ name: 'weighted_average_shs_out', type: 'number', description: 'weighted average shares outstanding basic' },
					{ name: 'weighted_average_shs_out_dil', type: 'number', description: 'weighted average shares outstanding diluted' },
				],
				ref: createReferenceWithTitle(getCompanyIncomeStatementsRef, params, buildGetCompanyIncomeStatementsCallDescription),
			},
		},
		run: (inputs) => {
			const raw = inputs.company_income_statements_raw;
			if (!raw || raw.success !== true || !raw.response) {
				throw new Error('Company income statements raw data is invalid');
			}
			const metrics = Array.isArray(raw.response?.metrics) ? raw.response.metrics : [];
			if (metrics.length === 0) {
				throw new Error('Company income statements metrics is invalid');
			}

			const arr = metrics.map((m) => {
				const ms = ymdToMs(m.date);
				if (ms == null) {
					throw new Error('Invalid statement date: ' + JSON.stringify(m.date));
				}
				return {
					date: ms,
					fiscal_year: m.fiscal_year ?? null,
					period: m.period ?? null,
					symbol: m.symbol ?? null,
					reported_currency: m.reported_currency ?? null,
					cik: m.cik ?? null,
					filing_date: m.filing_date ?? null,
					accepted_date: m.accepted_date ?? null,
					revenue: m.revenue ?? null,
					cost_of_revenue: m.cost_of_revenue ?? null,
					gross_profit: m.gross_profit ?? null,
					research_and_development_expenses: m.research_and_development_expenses ?? null,
					selling_general_and_administrative_expenses: m.selling_general_and_administrative_expenses ?? null,
					operating_expenses: m.operating_expenses ?? null,
					cost_and_expenses: m.cost_and_expenses ?? null,
					depreciation_and_amortization: m.depreciation_and_amortization ?? null,
					ebitda: m.ebitda ?? null,
					ebit: m.ebit ?? null,
					operating_income: m.operating_income ?? null,
					total_other_income_expenses_net: m.total_other_income_expenses_net ?? null,
					income_before_tax: m.income_before_tax ?? null,
					income_tax_expense: m.income_tax_expense ?? null,
					net_income_from_continuing_operations: m.net_income_from_continuing_operations ?? null,
					net_income: m.net_income ?? null,
					bottom_line_net_income: m.bottom_line_net_income ?? null,
					eps: m.eps ?? null,
					eps_diluted: m.eps_diluted ?? null,
					weighted_average_shs_out: m.weighted_average_shs_out ?? null,
					weighted_average_shs_out_dil: m.weighted_average_shs_out_dil ?? null,
				};
			});

			// Sort ascending and de-duplicate dates with minimal 1ms shift (rare case)
			arr.sort((a, b) => a.date - b.date);
			for (let i = 0; i < arr.length - 1; i++) {
				if (arr[i].date === arr[i + 1].date) {
					arr[i + 1].date = arr[i + 1].date + 1;
				}
			}

			return { income_statements: arr };
		},
	};
}

function getRefs() {
	return [
		getCompanyIncomeStatementsRef,
	];
}

module.exports = {
	getCompanyIncomeStatements,
	makeCompanyIncomeStatementsNode,
	getRefs,
};
