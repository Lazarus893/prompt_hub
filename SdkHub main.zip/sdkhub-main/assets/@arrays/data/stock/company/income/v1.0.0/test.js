function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
}

function runGetCompanyIncomeStatementsTests() {
    console.log('\n=== Testing getCompanyIncomeStatements (Direct Calls) ===');

    const { getCompanyIncomeStatements } = require('@arrays/data/stock/company/income:v1.0.0');

    const PERIODS = ['quarterly', 'annual', 'Q1', 'Q2', 'Q3', 'Q4'];
    const PERIOD_ENUM = new Set(['FY', 'Q1', 'Q2', 'Q3', 'Q4']);

    let totalTests = 0;
    let passedTests = 0;

    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    function checkIncomeStatementShape(item) {
        // Required minimal fields and types based on doc
        const requiredFields = ['date', 'fiscal_year', 'period', 'symbol'];
        requiredFields.forEach((k) => assert(k in item, `missing field: ${k}`));
        assert(typeof item.date === 'string', 'date should be string (YYYY-MM-DD)');
        assert(typeof item.fiscal_year === 'string', 'fiscal_year should be string');
        assert(typeof item.symbol === 'string', 'symbol should be string');
        assert(typeof item.period === 'string', 'period should be string');
        assert(PERIOD_ENUM.has(item.period), 'period value should be one of FY/Q1/Q2/Q3/Q4');
    }

    // --- Happy Path: cover all period enum values ---
    for (const period of PERIODS) {
        runTest(`Happy path: AAPL period=${period} limit=2`, () => {
            const res = getCompanyIncomeStatements({ symbol: 'AAPL', period, limit: '2' });
            assert(res && typeof res === 'object', 'should return object');
            assert(res.success === true, 'success should be true');
            assert(res.response && Array.isArray(res.response.metrics), 'response.metrics must be an array');
            assert(res.response.metrics.length <= 2, 'should respect limit=2');
            if (res.response.metrics.length > 0) {
                const first = res.response.metrics[0];
                checkIncomeStatementShape(first);
                // Period-specific assertions
                if (period === 'annual') {
                    assert(first.period === 'FY', 'annual period should return FY items');
                }
                if (period === 'quarterly') {
                    assert(['Q1', 'Q2', 'Q3', 'Q4'].includes(first.period), 'quarterly should return quarterly periods');
                }
                if (['Q1', 'Q2', 'Q3', 'Q4'].includes(period)) {
                    assert(first.period === period, `Explicit ${period} should return ${period} items`);
                }
            }
        });
    }

    // --- Boundary Value Analysis ---
    runTest('Boundary: limit=1 (minimum)', () => {
        const res = getCompanyIncomeStatements({ symbol: 'AAPL', period: 'quarterly', limit: '1' });
        assert(res.success === true, 'success should be true');
        assert(res.response && Array.isArray(res.response.metrics), 'metrics array required');
        assert(res.response.metrics.length <= 1, 'should respect limit=1');
    });

    runTest('Boundary: large limit=100', () => {
        const res = getCompanyIncomeStatements({ symbol: 'AAPL', period: 'annual', limit: '100' });
        assert(res.success === true, 'success should be true');
        assert(Array.isArray(res.response.metrics), 'metrics array required');
        assert(res.response.metrics.length <= 100, 'should not exceed limit=100');
    });

    runTest('Boundary: undefined limit (no limit provided)', () => {
        const res = getCompanyIncomeStatements({ symbol: 'AAPL', period: 'quarterly' });
        assert(res.success === true, 'success should be true');
        assert(Array.isArray(res.response.metrics), 'metrics array required');
        assert(res.response.metrics.length >= 1, 'should return some data when available');
    });

    // --- Pagination via cursor ---
    runTest('Pagination: next_cursor and cursor usage', () => {
        const first = getCompanyIncomeStatements({ symbol: 'AAPL', period: 'quarterly', limit: '2' });
        assert(first.success === true, 'first call success');
        const cursor = first.response.next_cursor;
        if (cursor) {
            assert(typeof cursor === 'string', 'next_cursor should be string when present');
            const second = getCompanyIncomeStatements({ symbol: 'AAPL', period: 'quarterly', limit: '2', cursor });
            assert(second.success === true, 'second call success with cursor');
            assert(Array.isArray(second.response.metrics), 'second metrics array required');
        } else {
            // Acceptable if pagination cursor not available for current dataset
            assert(true, 'no next_cursor provided; pagination not applicable');
        }
    });

    // --- Special values ---
    runTest('Special: null cursor should be treated as absent or rejected', () => {
        try {
            const res = getCompanyIncomeStatements({ symbol: 'AAPL', period: 'quarterly', limit: '2', cursor: null });
            // Either success (treated as absent) or explicit error; both acceptable per implementation.
            if (res && res.success === true) {
                assert(Array.isArray(res.response.metrics), 'metrics array required');
            } else {
                throw new Error('Expected success with null cursor treated as absent');
            }
        } catch (e) {
            // If implementation throws, it's also acceptable
            assert(e.message, 'should provide an error message');
        }
    });

    runTest('Special: empty string cursor', () => {
        const res = getCompanyIncomeStatements({ symbol: 'AAPL', period: 'quarterly', limit: '2', cursor: '' });
        assert(res && typeof res === 'object', 'should return object');
        // Treat empty cursor like no cursor
        assert(res.success === true, 'success should be true');
    });

    // --- Negative/Error-path tests ---
    runTest('Error: invalid symbol', () => {
        try {
            getCompanyIncomeStatements({ symbol: 'INVALID', period: 'annual', limit: '2' });
            throw new Error('Expected error due to invalid symbol, but function succeeded');
        } catch (e) {
            assert(e.message.toLowerCase().includes('error') || e.message.toLowerCase().includes('invalid'), 'should indicate invalid symbol');
        }
    });

    runTest('Error: empty symbol', () => {
        try {
            getCompanyIncomeStatements({ symbol: '', period: 'annual', limit: '2' });
            throw new Error('Expected error due to empty symbol');
        } catch (e) {
            assert(e.message.toLowerCase().includes('error') || e.message.toLowerCase().includes('symbol'), 'should reject empty symbol');
        }
    });

    runTest('Error: missing symbol', () => {
        try {
            // @ts-ignore - intentionally missing symbol
            getCompanyIncomeStatements({ period: 'annual', limit: '2' });
            throw new Error('Expected error due to missing symbol');
        } catch (e) {
            assert(e.message.toLowerCase().includes('error') || e.message.toLowerCase().includes('symbol'), 'should reject missing symbol');
        }
    });

    runTest('Error: invalid period value', () => {
        try {
            getCompanyIncomeStatements({ symbol: 'AAPL', period: 'FY', limit: '2' });
            throw new Error('Expected error due to invalid period');
        } catch (e) {
            assert(e.message.toLowerCase().includes('error') || e.message.toLowerCase().includes('period'), 'should reject invalid period');
        }
    });

    runTest('Error: lowercase period not allowed', () => {
        try {
            // @ts-ignore - intentionally invalid
            getCompanyIncomeStatements({ symbol: 'AAPL', period: 'q1', limit: '2' });
            throw new Error('Expected error due to lowercase period');
        } catch (e) {
            assert(e.message.toLowerCase().includes('error') || e.message.toLowerCase().includes('invalid'), 'should reject lowercase period');
        }
    });

    runTest('Error: zero limit', () => {
        try {
            getCompanyIncomeStatements({ symbol: 'AAPL', period: 'annual', limit: '0' });
            throw new Error('Expected error due to zero limit');
        } catch (e) {
            assert(e.message.toLowerCase().includes('error') || e.message.toLowerCase().includes('limit'), 'should reject zero limit');
        }
    });

    // --- Additional Happy Path with different symbol ---
    runTest('Happy path: MSFT annual limit=3', () => {
        const res = getCompanyIncomeStatements({ symbol: 'MSFT', period: 'annual', limit: '3' });
        assert(res.success === true, 'success should be true');
        assert(Array.isArray(res.response.metrics), 'metrics array required');
        res.response.metrics.forEach((m) => checkIncomeStatementShape(m));
    });

    // Print and enforce summary
    console.log('\n--- getCompanyIncomeStatements Test Summary ---');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    const rate = ((passedTests / totalTests) * 100).toFixed(1);
    console.log(`Success rate: ${rate}%`);
    if (passedTests !== totalTests) {
        throw new Error('Some getCompanyIncomeStatements tests failed');
    }
}

function runGraphNodeTests() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeCompanyIncomeStatementsNode } = require('@arrays/data/stock/company/income:v1.0.0');

    const g = new Graph(jagentId);
    g.addNode('income_aapl', makeCompanyIncomeStatementsNode({ symbol: 'AAPL', period: 'quarterly', limit: '4' }));

    g.run();

    // Validate refs for income_statements output
    const refsIncome = g.getRefsForOutput('income_aapl', 'income_statements');
    if (refsIncome.length > 0) {
        const ref = refsIncome[0];
        const expected = {
            id: '@arrays/data/stock/company/income/getCompanyIncomeStatements',
            module_name: '@arrays/data/stock/company/income',
            module_display_name: 'Company Financials - Income Statement',
            sdk_name: 'getCompanyIncomeStatements',
            sdk_display_name: 'Company Financials - Income Statements',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stable/income-statement',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for income_statements');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for income_statements');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for income_statements');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for income_statements');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for income_statements');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for income_statements');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for income_statements');
        console.log('✓ income_statements refs validated');
    } else {
        throw new Error('Assertion failed: refsIncome array is empty.');
    }

    // Existing data shape tests
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'income_aapl', 'income_statements', { last: '10' }), g.store);
    ts.init();

    if (!Array.isArray(ts.data) || !ts.data.length) throw new Error('income_statements empty');
    const r = ts.data[0];
    [
        'date',
        'fiscal_year',
        'period',
        'symbol',
        'reported_currency',
        'cik',
        'filing_date',
        'accepted_date',
        'revenue',
        'cost_of_revenue',
        'gross_profit',
        'research_and_development_expenses',
        'selling_general_and_administrative_expenses',
        'operating_expenses',
        'cost_and_expenses',
        'depreciation_and_amortization',
        'ebitda',
        'ebit',
        'operating_income',
        'total_other_income_expenses_net',
        'income_before_tax',
        'income_tax_expense',
        'net_income_from_continuing_operations',
        'net_income',
        'bottom_line_net_income',
        'eps',
        'eps_diluted',
        'weighted_average_shs_out',
        'weighted_average_shs_out_dil',
    ].forEach((k) => {
        if (!(k in r)) throw new Error('missing field: ' + k);
    });
    if (typeof r.date !== 'number') throw new Error('date must be number(ms)');
}

function main() {
    // Run graph node tests (existing)
    runGraphNodeTests();

    // Run direct function tests for getCompanyIncomeStatements
    runGetCompanyIncomeStatementsTests();

    return 0;
}

main();