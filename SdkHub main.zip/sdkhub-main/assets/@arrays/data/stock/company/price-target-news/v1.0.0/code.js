function getCompanyPriceTargetNews(params) {
	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/company/price_target_news';
	const keyValuePairs = Object.keys(params || {}).map((key) => {
		const value = params[key];
		return encodeURIComponent(key) + '=' + encodeURIComponent(value);
	});
	const queryString = keyValuePairs.join('&');
	const fullUrl = `${baseUrl}?${queryString}`;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': 'c84b079d-3888-4366-9752-10bb6c51543d',
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

// Reference metadata for tooling and discoverability, generated from tool.json
const getCompanyPriceTargetNewsRef = {
    id: "@arrays/data/stock/company/price-target-news/getCompanyPriceTargetNews",
    module_name: "@arrays/data/stock/company/price-target-news",
    module_display_name: "Stock Price Target News",
    sdk_name: "getCompanyPriceTargetNews",
    sdk_display_name: "Price Target News",
    source_name: "Financial Modeling Prep",
    source: "https://site.financialmodelingprep.com/developer/docs/stable/price-target-news",
};

// Base description (concise) derived from doc for getCompanyPriceTargetNews
const getCompanyPriceTargetNewsBaseFuncDesc = "Get analysts' price target news";

// Dynamic call description builder for getCompanyPriceTargetNews
function buildGetCompanyPriceTargetNewsCallDescription(actualParams = {}) {
    const parts = [getCompanyPriceTargetNewsBaseFuncDesc];

    // Add symbol context
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }

    // Additional filters
    const filters = [];
    if (Number.isFinite(actualParams.limit)) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (Number.isFinite(actualParams.page)) {
        filters.push(`Page: ${actualParams.page}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

// Utility to create reference object with a generated title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function makeCompanyPriceTargetNewsNode(params) {
	return {
		inputs: {
			company_price_target_news_raw: () => getCompanyPriceTargetNews(params),
		},
		outputs: {
			company_price_target_news: {
				name: 'company_price_target_news',
				description: 'Company Price Target News snapshot',
				fields: [
					{
						name: 'date',
						type: 'number',
						description: 'publication time ms (derived from published_date)',
					},
					{ name: 'symbol', type: 'string', description: 'stock symbol' },
					{ name: 'news_url', type: 'string', description: 'URL to full news' },
					{ name: 'news_title', type: 'string', description: 'news title' },
					{ name: 'analyst_name', type: 'string', description: 'analyst name' },
					{ name: 'price_target', type: 'number', description: 'price target' },
					{ name: 'adj_price_target', type: 'number', description: 'adjusted price target' },
					{ name: 'price_when_posted', type: 'number', description: 'stock price when posted' },
					{ name: 'news_publisher', type: 'string', description: 'publisher name' },
					{ name: 'news_base_url', type: 'string', description: 'publisher base domain' },
					{ name: 'analyst_company', type: 'string', description: 'analyst company' },
				],
				ref: createReferenceWithTitle(getCompanyPriceTargetNewsRef, params, buildGetCompanyPriceTargetNewsCallDescription),
			},
		},
		run: (inputs) => {
			const raw = inputs.company_price_target_news_raw || {};
			const arr = Array.isArray(raw.response) ? raw.response.slice() : [];
			arr.sort((a, b) => {
				const ta = Date.parse(a && a.published_date ? a.published_date : 0) || 0;
				const tb = Date.parse(b && b.published_date ? b.published_date : 0) || 0;
				return ta - tb;
			});
			let lastMs = -Infinity;
			const out = arr.map((n) => {
				const baseMs = Date.parse(n && n.published_date ? n.published_date : 0) || 0;
				let dateMs = baseMs;
				if (!Number.isFinite(dateMs)) dateMs = 0;
				if (dateMs <= lastMs) dateMs = lastMs + 1;
				lastMs = dateMs;
				return {
					date: dateMs,
					symbol: typeof n.symbol === 'string' ? n.symbol : '',
					news_url: typeof n.news_url === 'string' ? n.news_url : '',
					news_title: typeof n.news_title === 'string' ? n.news_title : '',
					analyst_name: typeof n.analyst_name === 'string' ? n.analyst_name : '',
					price_target: Number.isFinite(n.price_target) ? n.price_target : 0,
					adj_price_target: Number.isFinite(n.adj_price_target) ? n.adj_price_target : 0,
					price_when_posted: Number.isFinite(n.price_when_posted) ? n.price_when_posted : 0,
					news_publisher: typeof n.news_publisher === 'string' ? n.news_publisher : '',
					news_base_url: typeof n.news_base_url === 'string' ? n.news_base_url : '',
					analyst_company: typeof n.analyst_company === 'string' ? n.analyst_company : '',
				};
			});
			return { company_price_target_news: out };
		},
	};
}
function getRefs() {
    return [getCompanyPriceTargetNewsRef];
}

module.exports = {
	getCompanyPriceTargetNews,
	makeCompanyPriceTargetNewsNode,
	getRefs,
};
