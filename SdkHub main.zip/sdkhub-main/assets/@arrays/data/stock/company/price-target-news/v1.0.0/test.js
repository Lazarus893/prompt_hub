'use strict';

// Graph/Node testing (existing)
const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');
// Manual import for get* function as required
const { makeCompanyPriceTargetNewsNode, getCompanyPriceTargetNews } = require('@arrays/data/stock/company/price-target-news:v1.0.0');

function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

function validateNewsItem(item, expectedSymbolUpper) {
  assert(item && typeof item === 'object', 'news item must be an object');
  assert(typeof item.symbol === 'string', 'symbol must be string');
  if (expectedSymbolUpper) {
    assert(item.symbol.toUpperCase() === expectedSymbolUpper, 'symbol should match requested (uppercased)');
  }
  assert(typeof item.published_date === 'string', 'published_date must be string');
  const ts = Date.parse(item.published_date);
  assert(!Number.isNaN(ts), 'published_date must be a valid ISO 8601 date string');
  assert(typeof item.news_url === 'string', 'news_url must be string');
  assert(typeof item.news_title === 'string', 'news_title must be string');
  assert(typeof item.analyst_name === 'string', 'analyst_name must be string');
  assert(typeof item.price_target === 'number', 'price_target must be number');
  assert(typeof item.adj_price_target === 'number', 'adj_price_target must be number');
  assert(typeof item.price_when_posted === 'number', 'price_when_posted must be number');
  assert(typeof item.news_publisher === 'string', 'news_publisher must be string');
  assert(typeof item.news_base_url === 'string', 'news_base_url must be string');
  assert(typeof item.analyst_company === 'string', 'analyst_company must be string');
}

function testGetCompanyPriceTargetNews() {
  console.log('\n=== Testing getCompanyPriceTargetNews (Direct API) ===');

  const TICKERS = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'TSLA', 'NVDA'];
  let totalTests = 0;
  let passedTests = 0;

  function runTest(name, fn) {
    totalTests++;
    try {
      fn();
      console.log(`✅ ${name}`);
      passedTests++;
    } catch (e) {
      console.log(`❌ ${name}: ${e.message}`);
    }
  }

  function validateResult(res, limit, expectedSymbolUpper) {
    assert(res && typeof res === 'object', 'Result must be an object');
    assert(Array.isArray(res.response), 'Result.response must be an array');
    if (typeof limit === 'number') {
      assert(res.response.length <= limit, 'Should respect limit parameter');
    }
    if (res.response.length > 0) {
      for (let i = 0; i < Math.min(res.response.length, 3); i++) {
        validateNewsItem(res.response[i], expectedSymbolUpper);
      }
    }
  }

  // Happy Path: multiple valid tickers, typical params
  for (const sym of TICKERS) {
    runTest(`[Happy] ${sym} limit=5 page=0`, () => {
      const res = getCompanyPriceTargetNews({ symbol: sym, limit: 5, page: 0 });
      validateResult(res, 5, sym);
    });

    runTest(`[Happy] ${sym} limit=3 page=1`, () => {
      const res = getCompanyPriceTargetNews({ symbol: sym, limit: 3, page: 1 });
      validateResult(res, 3, sym);
    });
  }

  // Boundary Value Analysis: limit and page
  runTest('[Boundary] limit=1 (min), page=0', () => {
    const res = getCompanyPriceTargetNews({ symbol: 'AAPL', limit: 1, page: 0 });
    validateResult(res, 1, 'AAPL');
  });

  runTest('[Boundary] limit=25 (large), page=0', () => {
    const res = getCompanyPriceTargetNews({ symbol: 'AAPL', limit: 25, page: 0 });
    validateResult(res, 25, 'AAPL');
  });

  runTest('[Boundary] page=0 (min)', () => {
    const res = getCompanyPriceTargetNews({ symbol: 'MSFT', limit: 5, page: 0 });
    validateResult(res, 5, 'MSFT');
  });

  runTest('[Boundary] page=5 (higher page)', () => {
    const res = getCompanyPriceTargetNews({ symbol: 'MSFT', limit: 5, page: 5 });
    validateResult(res, 5, 'MSFT');
  });

  // Special/Invalid values
  runTest('[Special] lowercase symbol normalization or error', () => {
    try {
      const res = getCompanyPriceTargetNews({ symbol: 'aapl', limit: 5, page: 0 });
      // Either normalized to AAPL or handled with empty set
      assert(res && Array.isArray(res.response), 'response should be an array');
      if (res.response.length > 0) {
        validateNewsItem(res.response[0], 'AAPL');
      }
    } catch (e) {
      // Acceptable if implementation requires uppercase strictly
      assert(e.message, 'Should throw an error for lowercase symbol or handle it gracefully');
    }
  });

  runTest('[Special] invalid symbol should error or return empty', () => {
    try {
      const res = getCompanyPriceTargetNews({ symbol: 'INVALID', limit: 5, page: 0 });
      assert(Array.isArray(res.response), 'response should be an array');
      assert(res.response.length === 0, 'invalid symbol should return empty response');
    } catch (e) {
      // Also acceptable: throw error
      assert(e.message, 'Should throw for invalid symbol');
    }
  });

  runTest('[Special] symbol = empty string', () => {
    try {
      const res = getCompanyPriceTargetNews({ symbol: '', limit: 5, page: 0 });
      assert(Array.isArray(res.response), 'response should be an array');
      assert(res.response.length === 0, 'empty symbol should return empty response');
    } catch (e) {
      assert(e.message, 'Should throw for empty symbol');
    }
  });

  runTest('[Special] symbol = null', () => {
    try {
      getCompanyPriceTargetNews({ symbol: null, limit: 5, page: 0 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message, 'Should throw for null symbol');
    }
  });

  runTest('[Special] symbol = undefined', () => {
    try {
      getCompanyPriceTargetNews({ symbol: undefined, limit: 5, page: 0 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message, 'Should throw for undefined symbol');
    }
  });

  runTest('[Special] limit = 0', () => {
    try {
      const res = getCompanyPriceTargetNews({ symbol: 'AAPL', limit: 0, page: 0 });
      assert(Array.isArray(res.response), 'response should be an array');
      assert(res.response.length === 0, 'limit=0 should return empty response');
    } catch (e) {
      assert(e.message, 'Should throw or handle limit=0 gracefully');
    }
  });

  runTest('[Special] limit = -5', () => {
    try {
      getCompanyPriceTargetNews({ symbol: 'AAPL', limit: -5, page: 0 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message, 'Should throw for negative limit');
    }
  });

  runTest('[Special] page = -1', () => {
    try {
      getCompanyPriceTargetNews({ symbol: 'AAPL', limit: 5, page: -1 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message, 'Should throw for negative page');
    }
  });

  runTest('[Special] page = 0.5 (non-integer)', () => {
    try {
      const res = getCompanyPriceTargetNews({ symbol: 'AAPL', limit: 5, page: 0.5 });
      // Some implementations may floor/round; we only require valid response or throw
      validateResult(res, 5, 'AAPL');
    } catch (e) {
      assert(e.message, 'Should throw or coerce non-integer page');
    }
  });

  // Print summary
  console.log('\n=== getCompanyPriceTargetNews Test Summary ===');
  console.log(`Total tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${totalTests - passedTests}`);
  console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function main() {
  // Existing Graph-based node test
  const g = new Graph(jagentId);
  g.addNode('company_price_target_news', makeCompanyPriceTargetNewsNode({ symbol: 'AAPL', limit: 5, page: 0 }));
  g.run();

  // Assert node output via TimeSeries API
  const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'company_price_target_news', 'company_price_target_news', { last: '5' }), g.store);
  ts.init();
  if (!Array.isArray(ts.data)) throw new Error('output must be an array');
  if (ts.data.length > 0) {
    const r0 = ts.data[0];
    if (typeof r0.date !== 'number') throw new Error('date must be number (ms)');
    if (typeof r0.symbol !== 'string') throw new Error('symbol must be string');
    if (typeof r0.news_url !== 'string') throw new Error('news_url must be string');
    if (typeof r0.news_title !== 'string') throw new Error('news_title must be string');
    if (typeof r0.analyst_name !== 'string') throw new Error('analyst_name must be string');
    if (typeof r0.price_target !== 'number') throw new Error('price_target must be number');
    if (typeof r0.adj_price_target !== 'number') throw new Error('adj_price_target must be number');
    if (typeof r0.price_when_posted !== 'number') throw new Error('price_when_posted must be number');
    if (typeof r0.news_publisher !== 'string') throw new Error('news_publisher must be string');
    if (typeof r0.news_base_url !== 'string') throw new Error('news_base_url must be string');
    if (typeof r0.analyst_company !== 'string') throw new Error('analyst_company must be string');
    if (ts.data.length > 1 && !(ts.data[0].date > ts.data[1].date)) throw new Error('TimeSeries must be date-descending when read');
  }

  // Validate reference metadata for the output
  const refs = g.getRefsForOutput('company_price_target_news', 'company_price_target_news');
  if (refs.length > 0) {
    const ref = refs[0];
    const expected = {
      id: '@arrays/data/stock/company/price-target-news/getCompanyPriceTargetNews',
      module_name: '@arrays/data/stock/company/price-target-news',
      module_display_name: 'Stock Price Target News',
      sdk_name: 'getCompanyPriceTargetNews',
      sdk_display_name: 'Price Target News',
      source_name: 'Financial Modeling Prep',
      source: 'https://site.financialmodelingprep.com/developer/docs/stable/price-target-news',
    };

    if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for company_price_target_news');
    if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for company_price_target_news');
    if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for company_price_target_news');
    if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for company_price_target_news');
    if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for company_price_target_news');
    if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for company_price_target_news');
    if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for company_price_target_news');
    console.log('✓ company_price_target_news refs validated');
  } else {
    throw new Error('Assertion failed: refs array is empty for company_price_target_news.');
  }

  // Run direct get* function test suite
  testGetCompanyPriceTargetNews();
  return 0;
}

main();
