const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');
const { makeCompanyPriceTargetSummaryNode, getCompanyPriceTargetSummary } = require('@arrays/data/stock/company/price-target-summary:v1.0.0');

// Simple assert helper to align with example.js style
function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
}

function testGetCompanyPriceTargetSummary() {
    console.log('\n=== Testing getCompanyPriceTargetSummary (Direct) ===');

    let totalTests = 0;
    let passedTests = 0;

    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    const VALID_SYMBOLS = ['AAPL', 'MSFT', 'META', 'TSLA', 'GOOGL'];

    // Happy path tests across multiple valid symbols (enumeration coverage)
    for (const symbol of VALID_SYMBOLS) {
        runTest(`Happy path with ${symbol}`, () => {
            const res = getCompanyPriceTargetSummary({ symbol });
            assert(res && typeof res === 'object', 'Should return an object');
            const r = res.response;
            assert(r && typeof r === 'object', 'response must be an object');
            assert(r.symbol === symbol, 'response.symbol should equal the input symbol (uppercase)');

            const numericKeys = [
                'last_month_count',
                'last_month_avg_price_target',
                'last_quarter_count',
                'last_quarter_avg_price_target',
                'last_year_count',
                'last_year_avg_price_target',
                'all_time_count',
                'all_time_avg_price_target',
            ];
            for (const k of numericKeys) {
                assert(typeof r[k] === 'number' && Number.isFinite(r[k]), `${k} must be a finite number`);
            }

            assert(typeof r.publishers === 'string', 'publishers must be a string (JSON)');
            let pubs;
            try {
                pubs = JSON.parse(r.publishers);
            } catch (e) {
                throw new Error('publishers must be a valid JSON string');
            }
            assert(Array.isArray(pubs), 'publishers JSON must parse to an array');
        });
    }

    // Boundary Value Analysis
    runTest('Boundary: single-letter uppercase symbol', () => {
        // Single-letter tickers do exist (e.g., F), treat as valid boundary
        const res = getCompanyPriceTargetSummary({ symbol: 'F' });
        assert(res && typeof res === 'object', 'Should return an object');
        const r = res.response;
        assert(r && typeof r === 'object', 'response must be an object');
        assert(r.symbol === 'F', 'response.symbol should echo input');
        assert(typeof r.last_month_count === 'number', 'last_month_count must be number');
    });

    runTest('Boundary: overly long symbol should error', () => {
        try {
            getCompanyPriceTargetSummary({ symbol: 'THISISAVERYLONGSYMBOL123456' });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e && e.message, 'Should throw error for overly long symbol');
            const m = String(e.message).toLowerCase();
            assert(m.includes('error') || m.includes('invalid') || m.includes('required'), 'Should report invalid/required error');
        }
    });

    // Special values and invalid inputs
    runTest('Invalid: lowercase symbol should error', () => {
        try {
            getCompanyPriceTargetSummary({ symbol: 'aapl' });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e && e.message, 'Should throw error for lowercase input');
            const m = String(e.message).toLowerCase();
            assert(m.includes('error') || m.includes('invalid') || m.includes('required'), 'Should report invalid/required error');
        }
    });

    runTest('Invalid: empty string symbol should error', () => {
        try {
            getCompanyPriceTargetSummary({ symbol: '' });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e && e.message, 'Should throw error for empty symbol');
            const m = String(e.message).toLowerCase();
            assert(m.includes('error') || m.includes('invalid') || m.includes('required'), 'Should report invalid/required error');
        }
    });

    runTest('Invalid: symbol null should error', () => {
        try {
            getCompanyPriceTargetSummary({ symbol: null });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e && e.message, 'Should throw error for null symbol');
            const m = String(e.message).toLowerCase();
            assert(m.includes('error') || m.includes('invalid') || m.includes('required'), 'Should report invalid/required error');
        }
    });

    runTest('Invalid: symbol undefined should error', () => {
        try {
            getCompanyPriceTargetSummary({ symbol: undefined });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e && e.message, 'Should throw error for undefined symbol');
            const m = String(e.message).toLowerCase();
            assert(m.includes('error') || m.includes('invalid') || m.includes('required'), 'Should report invalid/required error');
        }
    });

    runTest('Invalid: missing symbol should error', () => {
        try {
            // @ts-ignore intent: missing parameter
            getCompanyPriceTargetSummary({});
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e && e.message, 'Should throw error when symbol is missing');
            const m = String(e.message).toLowerCase();
            assert(m.includes('error') || m.includes('invalid') || m.includes('required'), 'Should report invalid/required error');
        }
    });

    runTest('Invalid: non-string symbol (number) should error', () => {
        try {
            // @ts-ignore intent: wrong type
            getCompanyPriceTargetSummary({ symbol: 0 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e && e.message, 'Should throw error for non-string symbol');
            const m = String(e.message).toLowerCase();
            assert(m.includes('error') || m.includes('invalid') || m.includes('required'), 'Should report invalid/required error');
        }
    });

    console.log('\n--- getCompanyPriceTargetSummary Test Summary ---');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function testNodeAndTimeSeries() {
    const g = new Graph(jagentId);
    g.addNode('company_price_target_summary', makeCompanyPriceTargetSummaryNode({ symbol: 'AAPL' }));
    g.run();

    // Assert node output via TimeSeries API
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'company_price_target_summary', 'company_price_target_summary', { last: '1' }), g.store);
    ts.init();
    if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('expected at least 1 record');
    const r = ts.data[0];
    if (typeof r.date !== 'number') throw new Error('date must be number (ms)');
    if (typeof r.symbol !== 'string') throw new Error('symbol must be string');
    if (typeof r.last_month_count !== 'number') throw new Error('last_month_count must be number');
    if (typeof r.last_month_avg_price_target !== 'number') throw new Error('last_month_avg_price_target must be number');
    if (typeof r.last_quarter_count !== 'number') throw new Error('last_quarter_count must be number');
    if (typeof r.last_quarter_avg_price_target !== 'number') throw new Error('last_quarter_avg_price_target must be number');
    if (typeof r.last_year_count !== 'number') throw new Error('last_year_count must be number');
    if (typeof r.last_year_avg_price_target !== 'number') throw new Error('last_year_avg_price_target must be number');
    if (typeof r.all_time_count !== 'number') throw new Error('all_time_count must be number');
    if (typeof r.all_time_avg_price_target !== 'number') throw new Error('all_time_avg_price_target must be number');
    if (typeof r.publishers !== 'string') throw new Error('publishers must be string (JSON)');

    // Validate refs for output company_price_target_summary
    const refsCompanyPriceTargetSummary = g.getRefsForOutput('company_price_target_summary', 'company_price_target_summary');
    if (refsCompanyPriceTargetSummary.length > 0) {
        const ref = refsCompanyPriceTargetSummary[0];
        const expected = {
            id: '@arrays/data/stock/company/price-target-summary/getCompanyPriceTargetSummary',
            module_name: '@arrays/data/stock/company/price-target-summary',
            module_display_name: 'Stock Price Target Summary',
            sdk_name: 'getCompanyPriceTargetSummary',
            sdk_display_name: 'Price Target Summary',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stable/price-target-summary',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for company_price_target_summary');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for company_price_target_summary');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for company_price_target_summary');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for company_price_target_summary');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for company_price_target_summary');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for company_price_target_summary');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for company_price_target_summary');
    } else {
        throw new Error('Assertion failed: refsCompanyPriceTargetSummary array is empty.');
    }
}

function main(){
    // Direct get* API tests
    testGetCompanyPriceTargetSummary();

    // Node + TimeSeries tests
    testNodeAndTimeSeries();

    return 0;
}

main();
