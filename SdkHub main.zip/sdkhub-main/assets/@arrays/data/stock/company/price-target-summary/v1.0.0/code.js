const { load } = require('@alva/secret');

const apiKeyFromSecret = (() => {
    try {
        return load('X-ARRAY-KEY');
    } catch (_e) {
        return undefined;
    }
})();

// Ref object generated from tool.json metadata for getCompanyPriceTargetSummary
const getCompanyPriceTargetSummaryRef = {
    id: '@arrays/data/stock/company/price-target-summary/getCompanyPriceTargetSummary',
    module_name: '@arrays/data/stock/company/price-target-summary',
    module_display_name: 'Stock Price Target Summary',
    sdk_name: 'getCompanyPriceTargetSummary',
    sdk_display_name: 'Price Target Summary',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/stable/price-target-summary',
};

// Base description (from doc summary) for getCompanyPriceTargetSummary
const baseGetCompanyPriceTargetSummaryDescription = 'Get company price target summary';

// Dynamic call description builder for getCompanyPriceTargetSummary
function buildGetCompanyPriceTargetSummaryCallDescription(actualParams = {}) {
    const parts = [baseGetCompanyPriceTargetSummaryDescription];

    // Add symbol context if provided (required by doc)
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }

    return parts.join(' ').trim();
}

// Helper to create ref with dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title,
    };

    // 3. 返回新对象
    return newObject;
}

function getCompanyPriceTargetSummary(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/company/price_target_summary';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': apiKeyFromSecret || 'c84b079d-3888-4366-9752-10bb6c51543d',
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function makeCompanyPriceTargetSummaryNode(params) {
    return {
        inputs: {
            company_price_target_summary_raw: () => getCompanyPriceTargetSummary(params),
        },
        outputs: {
            company_price_target_summary: {
                name: 'company_price_target_summary',
                description: 'Company Price Target Summary snapshot',
                fields: [
                    { name: 'date', type: 'number', description: 'snapshot time ms' },
                    { name: 'symbol', type: 'string', description: 'queried stock symbol' },
                    { name: 'last_month_count', type: 'number', description: 'count of price targets in the last month' },
                    { name: 'last_month_avg_price_target', type: 'number', description: 'average target price for the last month' },
                    { name: 'last_quarter_count', type: 'number', description: 'count of price targets in the last quarter' },
                    { name: 'last_quarter_avg_price_target', type: 'number', description: 'average target price for the last quarter' },
                    { name: 'last_year_count', type: 'number', description: 'count of price targets in the last year' },
                    { name: 'last_year_avg_price_target', type: 'number', description: 'average target price for the last year' },
                    { name: 'all_time_count', type: 'number', description: 'total number of price targets published all time' },
                    { name: 'all_time_avg_price_target', type: 'number', description: 'average target price for all time' },
                    { name: 'publishers', type: 'string', description: 'JSON stringified array of publisher names' },
                ],
                ref: createReferenceWithTitle(
                    getCompanyPriceTargetSummaryRef,
                    params,
                    buildGetCompanyPriceTargetSummaryCallDescription
                ),
            },
        },
        run: (inputs) => {
            const raw = inputs.company_price_target_summary_raw || {};
            const response = (raw && raw.response) || {};
            return {
                company_price_target_summary: [
                    {
                        // Snapshot record: no upstream per-event timestamp available
                        date: Date.now(),
                        symbol: response.symbol,
                        last_month_count: response.last_month_count,
                        last_month_avg_price_target: response.last_month_avg_price_target,
                        last_quarter_count: response.last_quarter_count,
                        last_quarter_avg_price_target: response.last_quarter_avg_price_target,
                        last_year_count: response.last_year_count,
                        last_year_avg_price_target: response.last_year_avg_price_target,
                        all_time_count: response.all_time_count,
                        all_time_avg_price_target: response.all_time_avg_price_target,
                        publishers: response.publishers,
                    },
                ],
            };
        },
    };
}

function getRefs() {
    return [
        getCompanyPriceTargetSummaryRef,
    ];
}

module.exports = {
    getCompanyPriceTargetSummary,
    makeCompanyPriceTargetSummaryNode,
    getRefs,
};