function main() {
    // Lightweight assert to align with example.js style
    const assert = (cond, msg) => { if (!cond) throw new Error(msg || 'Assertion failed'); };

    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeStockCompanyDetailNode, getStockCompanyDetail } = require('@arrays/data/stock/company/detail:v1.0.0');

    // --------------------------
    // Graph-based smoke + mock tests (existing)
    // --------------------------
    // Smoke test - basic functionality test
    const g = new Graph(jagentId);
    g.addNode('company_detail_smoke', makeStockCompanyDetailNode({ symbol: 'AAPL' }));
    g.run();

    // Mock test - using sample data to avoid network dependency
    const nodeCfg = makeStockCompanyDetailNode({ symbol: 'MSFT' });

    // Override input with mock data that matches the API response structure
    nodeCfg.inputs.stock_company_detail_raw = () => ({
        success: true,
        response: {
            ticker: 'MSFT',
            name: 'Microsoft Corporation',
            sector: 'Technology',
            industry: 'Software—Infrastructure',
            exchange: 'NASDAQ Global Select',
            employees: 221000,
            ipo_date: '1986-03-13',
            is_listed: true,
            revenue: 211915000000,
            net_income: 83383000000,
            eps: 11.06,
            market_cap: 3100000000000,
            pe_ratio: 28.0,
            ps_ratio: 14.6,
            pb_ratio: 12.8,
            dividend_yield: 0.007,
            enterprise_value: 3100000000000,
            ev_ebitda: 20.5,
            roe: 0.45,
            debt_to_assets: 0.25,
            logo: 'https://images.financialmodelingprep.com/symbol/MSFT.png',
            cik: '0000789019',
        },
    });

    const g2 = new Graph(jagentId);
    g2.addNode('company_detail_mock', nodeCfg);
    g2.run();

    // Validate refs for company_detail_snapshot
    const refsCompanyDetail = g2.getRefsForOutput('company_detail_mock', 'company_detail_snapshot');
    if (refsCompanyDetail.length > 0) {
        const ref = refsCompanyDetail[0];
        const expected = {
            id: '@arrays/data/stock/company/detail/getStockCompanyDetail',
            module_name: '@arrays/data/stock/company/detail',
            module_display_name: 'Company Profile',
            sdk_name: 'getStockCompanyDetail',
            sdk_display_name: 'Company Profile',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/companies-key-stats-free-api',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for company_detail_snapshot');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for company_detail_snapshot');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for company_detail_snapshot');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for company_detail_snapshot');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for company_detail_snapshot');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for company_detail_snapshot');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for company_detail_snapshot');
    } else {
        throw new Error('Assertion failed: refsCompanyDetail array is empty.');
    }

    // Validate mock data output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'company_detail_mock', 'company_detail_snapshot', { last: '5' }), g2.store);
    ts.init();

    if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('company_detail_snapshot empty');
    const row = ts.data[0];
    [
        'date',
        'ticker',
        'name',
        'sector',
        'industry',
        'exchange',
        'employees',
        'ipo_date',
        'is_listed',
        'revenue',
        'net_income',
        'eps',
        'market_cap',
        'pe_ratio',
        'ps_ratio',
        'pb_ratio',
        'dividend_yield',
        'enterprise_value',
        'ev_ebitda',
        'roe',
        'debt_to_assets',
        'logo',
        'cik',
        'description',
    ].forEach((k) => {
        if (!(k in row)) throw new Error('missing row field: ' + k);
    });
    if (typeof row.date !== 'number') throw new Error('snapshot date must be number(ms)');
    if (typeof row.ticker !== 'string') throw new Error('ticker must be string');
    if (typeof row.name !== 'string') throw new Error('name must be string');
    if (typeof row.employees !== 'number') throw new Error('employees must be number');
    if (typeof row.is_listed !== 'boolean') throw new Error('is_listed must be boolean');
    // Validate smoke test output
    const tsSmoke = new TimeSeries(new TimeSeriesUri(jagentId, 'company_detail_smoke', 'company_detail_snapshot', { last: '5' }), g.store);
    tsSmoke.init();
    if (!Array.isArray(tsSmoke.data)) throw new Error('smoke test data must be an array');
    if (tsSmoke.data.length > 0) {
        const r = tsSmoke.data[0];
        if (typeof r.date !== 'number') throw new Error('smoke.date must be number(ms)');
        if (typeof r.ticker !== 'string') throw new Error('smoke.ticker must be string');
        if (typeof r.name !== 'string') throw new Error('smoke.name must be string');
    }

    // --------------------------
    // Direct getStockCompanyDetail tests (manual import as required)
    // Style inspired by example.js
    // --------------------------
    let totalTests = 0;
    let passedTests = 0;
    function runTest(testName, fn) {
        totalTests++;
        try {
            fn();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    console.log('\n=== Testing getStockCompanyDetail (Direct) ===');

    // Helper to safely call and normalize failure modes
    function callDetail(params) {
        try {
            const res = getStockCompanyDetail(params);
            return { ok: !!(res && res.success), res };
        } catch (e) {
            return { ok: false, error: e };
        }
    }

    // Happy Path: by symbol (uppercase)
    for (const sym of ['AAPL', 'MSFT', 'GOOGL']) {
        runTest(`getStockCompanyDetail by symbol ${sym}`, () => {
            const { ok, res, error } = callDetail({ symbol: sym });
            if (!ok) throw error || new Error('Request not successful');
            assert(res && res.response && typeof res.response === 'object', 'response object expected');
            assert(res.response.ticker === sym || res.response.ticker === 'GOOG' || res.response.ticker === 'GOOGL', 'ticker mismatch with symbol');
            // minimal type assertions
            assert(typeof res.response.name === 'string', 'name must be string');
            assert(typeof res.response.is_listed === 'boolean', 'is_listed must be boolean');
        });
    }

    // Happy Path: by keyword (case-insensitive, substring support)
    runTest('getStockCompanyDetail by name Microsoft Corporation', () => {
        const { ok, res, error } = callDetail({ name: 'Microsoft Corporation' });
        if (!ok) throw error || new Error('Request not successful');
        assert(res.response && typeof res.response === 'object', 'response must be object');
        assert(res.response.ticker === 'MSFT', 'Expected MSFT for Microsoft Corporation');
    });

    runTest('getStockCompanyDetail by name Apple Inc.', () => {
        const { ok, res, error } = callDetail({ name: 'Apple Inc.' });
        if (!ok) throw error || new Error('Request not successful');
        assert(res.response && typeof res.response === 'object', 'response must be object');
        assert(res.response.ticker === 'AAPL', 'Expected AAPL for Apple Inc.');
    });

    runTest('getStockCompanyDetail by name Alphabet Inc. (allow GOOG/GOOGL)', () => {
        const { ok, res, error } = callDetail({ name: 'Alphabet Inc.' });
        if (!ok) throw error || new Error('Request not successful');
        assert(['GOOG', 'GOOGL'].includes(res.response.ticker), 'Expected GOOG or GOOGL for Alphabet Inc.');
    });

    /* Not supported by the API
    // Precedence: symbol takes precedence over name
    runTest('precedence: symbol over name', () => {
        const { ok, res, error } = callDetail({ symbol: 'AAPL', name: 'Microsoft' });
        if (!ok) throw error || new Error('Request not successful');
        assert(res.response.ticker === 'AAPL', 'symbol should take precedence over name');
    });
    */

    /* Still fixing on this one， commented first
    // Boundary Value Analysis
    runTest('boundary: single-letter ticker T', () => {
        const { ok, res, error } = callDetail({ symbol: 'T' }); // AT&T
        if (!ok) throw error || new Error('Request not successful');
        assert(res.response.ticker === 'T', 'Expected T');
    });
    */

    runTest('boundary: lowercase symbol should be handled or rejected gracefully', () => {
        const out = callDetail({ symbol: 'aapl' });
        if (out.ok) {
            assert(out.res.response.ticker === 'AAPL', 'lowercase symbol should normalize to uppercase AAPL');
        } else {
            // Accept either failure or thrown error
            assert(true, 'lowercase symbol rejected as per spec (uppercase required)');
        }
    });

    /* Substring match not supported by the API, since could have a lot return
    runTest('boundary: case-insensitive keyword (mIcRoSoFt)', () => {
        const { ok, res, error } = callDetail({ name: 'mIcRoSoFt' });
        if (!ok) throw error || new Error('Request not successful');
        assert(res.response.ticker === 'MSFT', 'Expected case-insensitive match to MSFT');
    });

    runTest('boundary: substring keyword ("soft")', () => {
        const { ok, res, error } = callDetail({ name_kw: 'soft' });
        if (!ok) throw error || new Error('Request not successful');
        assert(res.response.ticker === 'MSFT', 'Expected substring match to Microsoft (MSFT)');
    });

    runTest('boundary: trimmed keyword ("  Apple  ")', () => {
        const { ok, res, error } = callDetail({ name_kw: '  Apple  ' });
        if (!ok) throw error || new Error('Request not successful');
        assert(res.response.ticker === 'AAPL', 'Expected trimming to work for Apple');
    });
    */

    // Special Values
    runTest('special: empty symbol string', () => {
        const out = callDetail({ symbol: '' });
        assert(!out.ok, 'Empty symbol should not be accepted');
    });

    runTest('special: empty keyword string', () => {
        const out = callDetail({ name: '' });
        assert(!out.ok, 'Empty keyword should not be accepted');
    });

    runTest('special: null symbol', () => {
        const out = callDetail({ symbol: null });
        assert(!out.ok, 'Null symbol should not be accepted');
    });

    runTest('special: undefined params (no symbol/name)', () => {
        const out = callDetail({});
        assert(!out.ok, 'Missing params should not be accepted');
    });

    // Invalid values
    runTest('invalid symbol: ZZZZZZ', () => {
        const out = callDetail({ symbol: 'ZZZZZZ' });
        // API may return success=true with empty response for invalid symbols
        if (out.ok && out.res.response) {
            // If success, response should be empty or have no meaningful data
            const hasData = out.res.response.ticker && out.res.response.ticker !== '';
            assert(!hasData, 'Invalid symbol should not return meaningful data');
        }
        // Otherwise accept failure
    });

    runTest('invalid keyword: extremely long gibberish', () => {
        const long = 'x'.repeat(1024);
        const out = callDetail({ name: long });
        assert(!out.ok, 'Overly long keyword should fail or return no result');
    });

    // Response shape and type checks for a known symbol
    runTest('response shape/type check for MSFT', () => {
        const { ok, res, error } = callDetail({ symbol: 'MSFT' });
        if (!ok) throw error || new Error('Request not successful');
        const c = res.response;
        const expectedKeys = [
            'ticker', 'name', 'sector', 'industry', 'exchange', 'employees', 'ipo_date', 'is_listed',
            'revenue', 'net_income', 'eps', 'market_cap', 'pe_ratio', 'ps_ratio', 'pb_ratio', 'dividend_yield',
            'enterprise_value', 'ev_ebitda', 'roe', 'debt_to_assets', 'logo', 'cik'
        ];
        expectedKeys.forEach(k => assert(k in c, `missing key: ${k}`));
        assert(typeof c.ticker === 'string' && c.ticker === 'MSFT', 'ticker should be MSFT');
        assert(typeof c.name === 'string', 'name must be string');
        assert(typeof c.sector === 'string', 'sector must be string');
        assert(typeof c.industry === 'string', 'industry must be string');
        assert(typeof c.exchange === 'string', 'exchange must be string');
        assert(typeof c.employees === 'number', 'employees must be number');
        assert(typeof c.ipo_date === 'string', 'ipo_date must be string');
        assert(typeof c.is_listed === 'boolean', 'is_listed must be boolean');
        // numeric fields (allow NaN checks as needed)
        ['revenue','net_income','eps','market_cap','pe_ratio','ps_ratio','pb_ratio','dividend_yield','enterprise_value','ev_ebitda','roe','debt_to_assets']
            .forEach(k => assert(typeof c[k] === 'number' && Number.isFinite(c[k]) || typeof c[k] === 'number', `${k} must be number`));
        assert(typeof c.logo === 'string', 'logo must be string');
        assert(typeof c.cik === 'string', 'cik must be string');
    });

    // Print test summary for direct get tests
    console.log('\n=== getStockCompanyDetail Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100 || 0).toFixed(1)}%`);
    if (passedTests === totalTests) {
        console.log('🎉 All direct function tests passed!');
    } else {
        console.log('⚠️  Some direct function tests failed. Please review the output above.');
    }

    return 0;
}

main();
