const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for SDK/tooling, derived from tool.json
const getStockCompanyDetailRef = {
  id: "@arrays/data/stock/company/detail/getStockCompanyDetail",
  module_name: "@arrays/data/stock/company/detail",
  module_display_name: "Company Profile",
  sdk_name: "getStockCompanyDetail",
  sdk_display_name: "Company Profile",
  source_name: "Financial Modeling Prep",
  source: "https://site.financialmodelingprep.com/developer/docs/companies-key-stats-free-api",
};

// Base description summarized from doc for getStockCompanyDetail
const baseGetStockCompanyDetailDesc = "Get company profile";

// Dynamic call description builder for getStockCompanyDetail
function buildGetStockCompanyDetailCallDescription(actualParams = {}) {
  const parts = [baseGetStockCompanyDetailDesc];

  if (actualParams.symbol) {
    parts.push(`for ${actualParams.symbol}`);
    if (actualParams.name) {
      parts.push(`(symbol takes precedence)`);
    }
  } else if (actualParams.name) {
    parts.push(`for "${actualParams.name}"`);
  }

  return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getStockCompanyDetail(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/company/detail';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function makeStockCompanyDetailNode(params) {
    return {
        inputs: {
            stock_company_detail_raw: () => getStockCompanyDetail(params),
        },
        outputs: {
            company_detail_snapshot: {
                name: 'company_detail_snapshot',
                description: 'Company detail snapshot (single record with all company information)',
                fields: [
                    { name: 'date', type: 'number', description: 'snapshot time in ms since epoch (UTC)' },
                    { name: 'ticker', type: 'string', description: 'stock ticker symbol' },
                    { name: 'name', type: 'string', description: 'company full name' },
                    { name: 'sector', type: 'string', description: 'business sector' },
                    { name: 'industry', type: 'string', description: 'industry category' },
                    { name: 'exchange', type: 'string', description: 'listing exchange name' },
                    { name: 'employees', type: 'number', description: 'number of employees' },
                    { name: 'ipo_date', type: 'string', description: 'IPO date (YYYY-MM-DD)' },
                    { name: 'is_listed', type: 'boolean', description: 'whether company is currently listed' },
                    { name: 'revenue', type: 'number', description: 'most recent revenue (in base currency)' },
                    { name: 'net_income', type: 'number', description: 'most recent net income (in base currency)' },
                    { name: 'eps', type: 'number', description: 'earnings per share' },
                    { name: 'market_cap', type: 'number', description: 'market capitalization' },
                    { name: 'pe_ratio', type: 'number', description: 'price-to-earnings ratio' },
                    { name: 'ps_ratio', type: 'number', description: 'price-to-sales ratio' },
                    { name: 'pb_ratio', type: 'number', description: 'price-to-book ratio' },
                    { name: 'dividend_yield', type: 'number', description: 'dividend yield' },
                    { name: 'enterprise_value', type: 'number', description: 'enterprise value' },
                    { name: 'ev_ebitda', type: 'number', description: 'enterprise value to EBITDA ratio' },
                    { name: 'roe', type: 'number', description: 'return on equity' },
                    { name: 'debt_to_assets', type: 'number', description: 'debt to assets ratio' },
                    { name: 'logo', type: 'string', description: 'company logo URL' },
                    { name: 'cik', type: 'string', description: 'Central Index Key identifier' },
                    { name: 'description', type: 'string', description: 'company description' },
                ],
                ref: createReferenceWithTitle(getStockCompanyDetailRef, params, buildGetStockCompanyDetailCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.stock_company_detail_raw;
            if (!raw || raw.success !== true || !raw.response) {
                throw new Error('Company detail raw data is invalid');
            }

            const c = raw.response;
            // Use current time as snapshot time since company details are typically current snapshots
            const snapshotTime = Date.now();

            return {
                company_detail_snapshot: [
                    {
                        date: snapshotTime,
                        ticker: c.ticker,
                        name: c.name,
                        sector: c.sector,
                        industry: c.industry,
                        exchange: c.exchange,
                        employees: c.employees,
                        ipo_date: c.ipo_date,
                        is_listed: c.is_listed,
                        revenue: c.revenue,
                        net_income: c.net_income,
                        eps: c.eps,
                        market_cap: c.market_cap,
                        pe_ratio: c.pe_ratio,
                        ps_ratio: c.ps_ratio,
                        pb_ratio: c.pb_ratio,
                        dividend_yield: c.dividend_yield,
                        enterprise_value: c.enterprise_value,
                        ev_ebitda: c.ev_ebitda,
                        roe: c.roe,
                        debt_to_assets: c.debt_to_assets,
                        logo: c.logo,
                        cik: c.cik,
                        description: c.description,
                    },
                ],
            };
        },
    };
}

function getRefs() {
    return [
        getStockCompanyDetailRef,
    ];
}

module.exports = {
    getStockCompanyDetail,
    makeStockCompanyDetailNode,
    getRefs,
};