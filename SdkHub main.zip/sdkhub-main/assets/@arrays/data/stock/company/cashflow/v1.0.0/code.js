const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for SDKs (auto-generated from tool.json)
const getCompanyCashFlowStatementsRef = {
    id: '@arrays/data/stock/company/cashflow/getCompanyCashFlowStatements',
    module_name: '@arrays/data/stock/company/cashflow',
    module_display_name: 'Company Financials - Cash Flow Statements',
    sdk_name: 'getCompanyCashFlowStatements',
    sdk_display_name: 'Company Financials - Cash Flow Statements',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/stable/cashflow-statement',
};

// Base description (from doc summary) and dynamic description builder (internal only)
const getCompanyCashFlowStatementsBaseDescription = 'Get company cash flow statements';

function buildGetCompanyCashFlowStatementsCallDescription(actualParams = {}) {
    const parts = [getCompanyCashFlowStatementsBaseDescription];

    // Add company symbol context
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }

    // Collect filters
    const filters = [];
    if (actualParams.period) {
        filters.push(`Period: ${actualParams.period}`);
    }
    if (actualParams.limit) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (actualParams.cursor) {
        filters.push(`Cursor: ${actualParams.cursor}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getCompanyCashFlowStatements(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/company/cashflow_statements';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function ymdToUtcMs(ymd) {
    if (typeof ymd !== 'string') {
        throw new Error('Invalid date string: ' + String(ymd));
    }
    const parts = ymd.split('-');
    if (parts.length !== 3) {
        throw new Error('Invalid date format (expected YYYY-MM-DD): ' + ymd);
    }
    const y = Number(parts[0]);
    const m = Number(parts[1]);
    const d = Number(parts[2]);
    if (!Number.isFinite(y) || !Number.isFinite(m) || !Number.isFinite(d)) {
        throw new Error('Invalid date components: ' + ymd);
    }
    return Date.UTC(y, m - 1, d, 0, 0, 0, 0);
}

function makeCompanyCashFlowStatementsNode(params) {
    return {
        inputs: {
            company_cash_flow_statements_raw: () => getCompanyCashFlowStatements(params),
        },
        outputs: {
            cashflow_statements: {
                name: 'cashflow_statements',
                description: 'Company cash flow statements (one record per reported period).',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'report date ms (UTC) derived from YYYY-MM-DD',
                    },
                    { name: 'symbol', type: 'string', description: 'company symbol' },
                    { name: 'fiscal_year', type: 'string', description: 'fiscal year' },
                    {
                        name: 'period',
                        type: 'string',
                        description: 'FY/Q1/Q2/Q3/Q4',
                    },
                    { name: 'net_income', type: 'string', description: 'net income USD' },
                    {
                        name: 'depreciation_and_amortization',
                        type: 'string',
                        description: 'depreciation and amortization USD',
                    },
                    {
                        name: 'deferred_income_tax',
                        type: 'string',
                        description: 'deferred income tax USD',
                    },
                    {
                        name: 'stock_based_compensation',
                        type: 'string',
                        description: 'stock-based compensation USD',
                    },
                    {
                        name: 'change_in_working_capital',
                        type: 'string',
                        description: 'change in working capital USD',
                    },
                    {
                        name: 'accounts_receivables',
                        type: 'string',
                        description: 'change in accounts receivables USD',
                    },
                    { name: 'inventory', type: 'string', description: 'change in inventory USD' },
                    {
                        name: 'accounts_payables',
                        type: 'string',
                        description: 'change in accounts payables USD',
                    },
                    {
                        name: 'other_working_capital',
                        type: 'string',
                        description: 'other working capital changes USD',
                    },
                    {
                        name: 'other_non_cash_items',
                        type: 'string',
                        description: 'other non-cash items USD',
                    },
                    {
                        name: 'net_cash_provided_by_operating_activities',
                        type: 'string',
                        description: 'net cash provided by operating activities USD',
                    },
                    {
                        name: 'investments_in_property_plant_and_equipment',
                        type: 'string',
                        description: 'investments in property, plant and equipment USD',
                    },
                    {
                        name: 'acquisitions_net',
                        type: 'string',
                        description: 'acquisitions, net USD',
                    },
                    {
                        name: 'purchases_of_investments',
                        type: 'string',
                        description: 'purchases of investments USD',
                    },
                    {
                        name: 'sales_maturities_of_investments',
                        type: 'string',
                        description: 'sales/maturities of investments USD',
                    },
                    {
                        name: 'other_investing_activities',
                        type: 'string',
                        description: 'other investing activities USD',
                    },
                    {
                        name: 'net_cash_provided_by_investing_activities',
                        type: 'string',
                        description: 'net cash provided by investing activities USD',
                    },
                    {
                        name: 'net_debt_issuance',
                        type: 'string',
                        description: 'net debt issuance USD',
                    },
                    {
                        name: 'long_term_net_debt_issuance',
                        type: 'string',
                        description: 'long-term net debt issuance USD',
                    },
                    {
                        name: 'short_term_net_debt_issuance',
                        type: 'string',
                        description: 'short-term net debt issuance USD',
                    },
                    {
                        name: 'net_stock_issuance',
                        type: 'string',
                        description: 'net stock issuance USD',
                    },
                    {
                        name: 'net_common_stock_issuance',
                        type: 'string',
                        description: 'net common stock issuance USD',
                    },
                    {
                        name: 'common_stock_issuance',
                        type: 'string',
                        description: 'common stock issuance USD',
                    },
                    {
                        name: 'common_stock_repurchased',
                        type: 'string',
                        description: 'common stock repurchased USD',
                    },
                    {
                        name: 'net_preferred_stock_issuance',
                        type: 'string',
                        description: 'net preferred stock issuance USD',
                    },
                    {
                        name: 'net_dividends_paid',
                        type: 'string',
                        description: 'net dividends paid USD',
                    },
                    {
                        name: 'common_dividends_paid',
                        type: 'string',
                        description: 'common dividends paid USD',
                    },
                    {
                        name: 'preferred_dividends_paid',
                        type: 'string',
                        description: 'preferred dividends paid USD',
                    },
                    {
                        name: 'other_financing_activities',
                        type: 'string',
                        description: 'other financing activities USD',
                    },
                    {
                        name: 'net_cash_provided_by_financing_activities',
                        type: 'string',
                        description: 'net cash provided by financing activities USD',
                    },
                    {
                        name: 'effect_of_forex_changes_on_cash',
                        type: 'string',
                        description: 'effect of foreign exchange changes on cash USD',
                    },
                    {
                        name: 'net_change_in_cash',
                        type: 'string',
                        description: 'net change in cash USD',
                    },
                    {
                        name: 'cash_at_end_of_period',
                        type: 'string',
                        description: 'cash at end of period USD',
                    },
                    {
                        name: 'cash_at_beginning_of_period',
                        type: 'string',
                        description: 'cash at beginning of period USD',
                    },
                    {
                        name: 'operating_cash_flow',
                        type: 'string',
                        description: 'operating cash flow USD',
                    },
                    {
                        name: 'capital_expenditure',
                        type: 'string',
                        description: 'capital expenditure USD',
                    },
                    {
                        name: 'free_cash_flow',
                        type: 'string',
                        description: 'free cash flow USD',
                    },
                    {
                        name: 'income_taxes_paid',
                        type: 'string',
                        description: 'income taxes paid USD',
                    },
                    {
                        name: 'interest_paid',
                        type: 'string',
                        description: 'interest paid USD',
                    },
                ],
                ref: createReferenceWithTitle(getCompanyCashFlowStatementsRef, params, buildGetCompanyCashFlowStatementsCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.company_cash_flow_statements_raw;
            if (!raw || raw.success !== true || !raw.response) {
                throw new Error('Company cash flow statements raw data is invalid');
            }
            const metrics = Array.isArray(raw.response?.metrics) ? raw.response.metrics : [];
            if (metrics.length === 0) {
                throw new Error('Company cash flow statements metrics is invalid');
            }

            const symbol = params && params.symbol ? params.symbol : '';
            const period = params && params.period ? params.period : '';

            const series = metrics.map((m) => {
                const ms = ymdToUtcMs(m.date);
                return {
                    date: ms,
                    symbol,
                    fiscal_year: m.fiscal_year,
                    period: m.period,
                    net_income: m.net_income,
                    depreciation_and_amortization: m.depreciation_and_amortization,
                    deferred_income_tax: m.deferred_income_tax,
                    stock_based_compensation: m.stock_based_compensation,
                    change_in_working_capital: m.change_in_working_capital,
                    accounts_receivables: m.accounts_receivables,
                    inventory: m.inventory,
                    accounts_payables: m.accounts_payables,
                    other_working_capital: m.other_working_capital,
                    other_non_cash_items: m.other_non_cash_items,
                    net_cash_provided_by_operating_activities: m.net_cash_provided_by_operating_activities,
                    investments_in_property_plant_and_equipment: m.investments_in_property_plant_and_equipment,
                    acquisitions_net: m.acquisitions_net,
                    purchases_of_investments: m.purchases_of_investments,
                    sales_maturities_of_investments: m.sales_maturities_of_investments,
                    other_investing_activities: m.other_investing_activities,
                    net_cash_provided_by_investing_activities: m.net_cash_provided_by_investing_activities,
                    net_debt_issuance: m.net_debt_issuance,
                    long_term_net_debt_issuance: m.long_term_net_debt_issuance,
                    short_term_net_debt_issuance: m.short_term_net_debt_issuance,
                    net_stock_issuance: m.net_stock_issuance,
                    net_common_stock_issuance: m.net_common_stock_issuance,
                    common_stock_issuance: m.common_stock_issuance,
                    common_stock_repurchased: m.common_stock_repurchased,
                    net_preferred_stock_issuance: m.net_preferred_stock_issuance,
                    net_dividends_paid: m.net_dividends_paid,
                    common_dividends_paid: m.common_dividends_paid,
                    preferred_dividends_paid: m.preferred_dividends_paid,
                    other_financing_activities: m.other_financing_activities,
                    net_cash_provided_by_financing_activities: m.net_cash_provided_by_financing_activities,
                    effect_of_forex_changes_on_cash: m.effect_of_forex_changes_on_cash,
                    net_change_in_cash: m.net_change_in_cash,
                    cash_at_end_of_period: m.cash_at_end_of_period,
                    cash_at_beginning_of_period: m.cash_at_beginning_of_period,
                    operating_cash_flow: m.operating_cash_flow,
                    capital_expenditure: m.capital_expenditure,
                    free_cash_flow: m.free_cash_flow,
                    income_taxes_paid: m.income_taxes_paid,
                    interest_paid: m.interest_paid,
                };
            });

            let pagination = [];
            if (series.length > 0) {
                let newest = series[0].date;
                for (let i = 1; i < series.length; i++) {
                    if (series[i].date > newest) newest = series[i].date;
                }
                pagination = [
                    {
                        date: newest,
                        symbol,
                        period,
                        next_cursor: raw.response?.next_cursor || '',
                    },
                ];
            }

            return {
                cashflow_statements: series,
            };
        },
    };
}

// 新增：统一获取所有 Ref 对象的方法
function getRefs() {
    return [
        getCompanyCashFlowStatementsRef,
    ];
}

module.exports = {
    getCompanyCashFlowStatements,
    makeCompanyCashFlowStatementsNode,
    getRefs, // 新增导出
};