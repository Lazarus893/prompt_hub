function assert(condition, message) {
	if (!condition) throw new Error(message || 'Assertion failed');
}

function testGraphNode() {
	const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
	const { jagentId } = require('env');
	const { makeCompanyCashFlowStatementsNode } = require('@arrays/data/stock/company/cashflow:v1.0.0');

	const g = new Graph(jagentId);
	g.addNode(
		'cashflow_aapl',
		makeCompanyCashFlowStatementsNode({
			symbol: 'AAPL',
			period: 'quarterly',
			limit: '4',
		})
	);

	g.run();

	const ts = new TimeSeries(
		new TimeSeriesUri(jagentId, 'cashflow_aapl', 'cashflow_statements', { last: '10' }),
		g.store
	);
	ts.init();

	if (!Array.isArray(ts.data) || !ts.data.length) throw new Error('cashflow_statements empty');
	const r = ts.data[0];
	[
		'date',
		'fiscal_year',
		'period',
		'net_income',
		'depreciation_and_amortization',
		'deferred_income_tax',
		'stock_based_compensation',
		'change_in_working_capital',
		'accounts_receivables',
		'inventory',
		'accounts_payables',
		'other_working_capital',
		'other_non_cash_items',
		'net_cash_provided_by_operating_activities',
		'investments_in_property_plant_and_equipment',
		'acquisitions_net',
		'purchases_of_investments',
		'sales_maturities_of_investments',
		'other_investing_activities',
		'net_cash_provided_by_investing_activities',
		'net_debt_issuance',
		'long_term_net_debt_issuance',
		'short_term_net_debt_issuance',
		'net_stock_issuance',
		'net_common_stock_issuance',
		'common_stock_issuance',
		'common_stock_repurchased',
		'net_preferred_stock_issuance',
		'net_dividends_paid',
		'common_dividends_paid',
		'preferred_dividends_paid',
		'other_financing_activities',
		'net_cash_provided_by_financing_activities',
		'effect_of_forex_changes_on_cash',
		'net_change_in_cash',
		'cash_at_end_of_period',
		'cash_at_beginning_of_period',
		'operating_cash_flow',
		'capital_expenditure',
		'free_cash_flow',
		'income_taxes_paid',
		'interest_paid',
	].forEach((k) => {
		if (!(k in r)) throw new Error('missing field: ' + k);
	});
	if (typeof r.date !== 'number') throw new Error('date must be number(ms)');

	// Validate refs for the output 'cashflow_statements'
	const refsCashflow = g.getRefsForOutput('cashflow_aapl', 'cashflow_statements');
	if (refsCashflow.length > 0) {
		const ref = refsCashflow[0];
		const expected = {
			id: '@arrays/data/stock/company/cashflow/getCompanyCashFlowStatements',
			module_name: '@arrays/data/stock/company/cashflow',
			module_display_name: 'Company Financials - Cash Flow Statements',
			sdk_name: 'getCompanyCashFlowStatements',
			sdk_display_name: 'Company Financials - Cash Flow Statements',
			source_name: 'Financial Modeling Prep',
			source: 'https://site.financialmodelingprep.com/developer/docs/stable/cashflow-statement',
		};

		if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for cashflow_statements');
		if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for cashflow_statements');
		if (ref.module_display_name !== expected.module_display_name)
			throw new Error('Assertion failed: ref.module_display_name mismatch for cashflow_statements');
		if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for cashflow_statements');
		if (ref.sdk_display_name !== expected.sdk_display_name)
			throw new Error('Assertion failed: ref.sdk_display_name mismatch for cashflow_statements');
		if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for cashflow_statements');
		if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for cashflow_statements');
	} else {
		throw new Error('Assertion failed: refsCashflow array is empty.');
	}
}

function testDirectGetFunction() {
	console.log('\n=== Testing getCompanyCashFlowStatements (Direct Import) ===');

	// Manual import for get* function (as required)
	const { getCompanyCashFlowStatements } = require('@arrays/data/stock/company/cashflow:v1.0.0');

	const PERIODS = ['quarterly', 'annual', 'Q1', 'Q2', 'Q3', 'Q4'];

	let totalTests = 0;
	let passedTests = 0;

	function runTest(testName, testFunc) {
		totalTests++;
		try {
			testFunc();
			console.log(`✅ ${testName}`);
			passedTests++;
		} catch (e) {
			console.log(`❌ ${testName}: ${e.message}`);
		}
	}

	function assertResultShape(result, msgPrefix = '') {
		assert(result && typeof result === 'object', `${msgPrefix}Result should be an object`);
		assert('success' in result, `${msgPrefix}Result should contain success flag`);
		assert(typeof result.success === 'boolean', `${msgPrefix}success should be boolean`);
		assert(result.response && typeof result.response === 'object', `${msgPrefix}response should be an object`);
		assert(Array.isArray(result.response.metrics), `${msgPrefix}response.metrics should be an array`);
		// next_cursor may be absent or string; ensure not crashing the API contract
		if ('next_cursor' in result.response && result.response.next_cursor != null) {
			assert(typeof result.response.next_cursor === 'string', `${msgPrefix}next_cursor should be string when provided`);
		}
	}

	function assertMetricFields(metrics, msgPrefix = '') {
		if (!metrics.length) return; // Allow empty array depending on data window
		const m = metrics[0];
		const required = ['date', 'fiscal_year', 'period'];
		for (const k of required) {
			assert(k in m, `${msgPrefix}metric missing field: ${k}`);
			assert(typeof m[k] === 'string', `${msgPrefix}${k} should be string`);
		}
	}

	// Happy Path: test all period enum values
	console.log('\n--- Happy Path: period enumerations coverage ---');
	for (const period of PERIODS) {
		runTest(`getCompanyCashFlowStatements AAPL period=${period}`, () => {
			const res = getCompanyCashFlowStatements({ symbol: 'AAPL', period, limit: '2' });
			assertResultShape(res, `[${period}] `);
			assert(res.success === true, `[${period}] success should be true`);
			assertMetricFields(res.response.metrics, `[${period}] `);
		});
	}

	// Boundary Value Analysis
	console.log('\n--- Boundary Value Analysis ---');
	runTest('limit minimum ("1")', () => {
		const res = getCompanyCashFlowStatements({ symbol: 'AAPL', period: 'annual', limit: '1' });
		assertResultShape(res, '[limit=1] ');
		assert(res.response.metrics.length <= 1, 'Should respect minimum limit');
	});

	runTest('limit typical large ("100")', () => {
		const res = getCompanyCashFlowStatements({ symbol: 'AAPL', period: 'quarterly', limit: '100' });
		assertResultShape(res, '[limit=100] ');
	});

	runTest('cursor provided (YYYY-MM-DD)', () => {
		const res = getCompanyCashFlowStatements({ symbol: 'AAPL', period: 'quarterly', limit: '2', cursor: '2025-06-28' });
		assertResultShape(res, '[cursor] ');
	});

	runTest('cursor omitted (undefined)', () => {
		const res = getCompanyCashFlowStatements({ symbol: 'AAPL', period: 'quarterly', limit: '2' });
		assertResultShape(res, '[cursor omitted] ');
	});

	// Special Values & Error Handling
	console.log('\n--- Special Values & Error Handling ---');
	runTest('invalid symbol (lowercase)', () => {
		try {
			getCompanyCashFlowStatements({ symbol: 'aapl', period: 'annual', limit: '2' });
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message, 'Should throw or provide error for invalid symbol');
		}
	});

	runTest('invalid symbol (empty string)', () => {
		try {
			getCompanyCashFlowStatements({ symbol: '', period: 'annual', limit: '2' });
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message, 'Should handle empty symbol');
		}
	});

	runTest('missing symbol (undefined)', () => {
		try {
			getCompanyCashFlowStatements({ period: 'annual', limit: '2' });
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message, 'Should handle missing symbol');
		}
	});

	runTest('invalid period (unsupported value)', () => {
		try {
			getCompanyCashFlowStatements({ symbol: 'AAPL', period: 'monthly', limit: '2' });
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message, 'Should handle invalid period value');
		}
	});

	runTest('missing period (undefined)', () => {
		try {
			getCompanyCashFlowStatements({ symbol: 'AAPL', limit: '2' });
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message, 'Should handle missing period');
		}
	});

	runTest('empty period ("")', () => {
		try {
			getCompanyCashFlowStatements({ symbol: 'AAPL', period: '', limit: '2' });
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message, 'Should handle empty period');
		}
	});

	runTest('null period', () => {
		try {
			getCompanyCashFlowStatements({ symbol: 'AAPL', period: null, limit: '2' });
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message, 'Should handle null period');
		}
	});

	runTest('limit omitted (undefined)', () => {
		const res = getCompanyCashFlowStatements({ symbol: 'AAPL', period: 'annual' });
		assertResultShape(res, '[limit omitted] ');
	});

	runTest('cursor empty string', () => {
		const res = getCompanyCashFlowStatements({ symbol: 'AAPL', period: 'quarterly', limit: '2', cursor: '' });
		// Some implementations may treat empty cursor as "no cursor"; just assert shape
		assertResultShape(res, '[cursor empty] ');
	});

	// Print test summary for direct get function tests
	console.log('\n=== getCompanyCashFlowStatements Test Summary ===');
	console.log(`Total tests: ${totalTests}`);
	console.log(`Passed: ${passedTests}`);
	console.log(`Failed: ${totalTests - passedTests}`);
	console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function main() {
	// Graph node integration tests (existing coverage)
	testGraphNode();

	// Direct get* API tests with enumeration, boundary, and special values coverage
	testDirectGetFunction();
}

main();
