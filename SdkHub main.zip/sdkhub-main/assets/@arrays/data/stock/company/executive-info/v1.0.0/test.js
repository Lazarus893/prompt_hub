function assert(cond, msg) {
    if (!cond) throw new Error(msg || 'Assertion failed');
}

function testGetExecutivesInfo() {
    console.log('\n=== Testing getExecutivesInfo (Direct Calls) ===');

    const { getExecutivesInfo } = require('@arrays/data/stock/company/executive-info:v1.0.0');

    let totalTests = 0;
    let passedTests = 0;

    function runTest(name, fn) {
        totalTests++;
        try {
            fn();
            console.log(`✅ ${name}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${name}: ${e.message}`);
        }
    }

    // Happy path: common well-known tickers should work
    const HAPPY_SYMBOLS = ['AAPL', 'MSFT'];
    for (const sym of HAPPY_SYMBOLS) {
        runTest(`getExecutivesInfo happy path for ${sym}`, () => {
            const res = getExecutivesInfo({ symbol: sym });
            assert(res && typeof res === 'object', 'Result should be an object');
            assert(typeof res.success === 'boolean', 'Result should contain success boolean');
            assert(res.success === true, 'Happy path should succeed');
            assert(res.response && typeof res.response === 'object', 'Response container should exist');
            assert(Array.isArray(res.response.data), 'Response data should be an array');
            if (res.response.data.length > 0) {
                const item = res.response.data[0];
                // Validate a subset of documented fields when data exists
                ['cik', 'symbol', 'company_name', 'filing_date', 'accepted_date', 'name_and_position', 'year', 'total', 'link'].forEach((k) => {
                    assert(k in item, `Missing field in ExecutiveCompensation: ${k}`);
                });
                assert(typeof item.year === 'number', 'year should be number');
                assert(typeof item.total === 'number', 'total should be number');
                assert(typeof item.name_and_position === 'string', 'name_and_position should be string');
                assert(/^https?:\/\//.test(item.link), 'link should be a valid URL');
            }
        });
    }

    // Enumeration coverage for various ticker formats
    const ENUM_SYMBOLS = [
        'AAPL',   // 4 letters
        'MSFT',   // 4 letters
        'GOOGL',  // 5 letters
        'TSLA',   // 4 letters
        'F',      // 1 letter
        'BRK.A',  // dot class share
        'BRK.B'   // another class
    ];
    for (const sym of ENUM_SYMBOLS) {
        runTest(`getExecutivesInfo enumeration symbol ${sym}`, () => {
            const res = getExecutivesInfo({ symbol: sym });
            assert(res && typeof res === 'object', 'Result should be an object');
            assert(typeof res.success === 'boolean', 'Result should contain success boolean');
            // Even if API has no data for some symbols, it should still return structured response
            if (res.success && res.response && res.response.data !== undefined) {
                assert(Array.isArray(res.response.data), 'When success=true and data present, data must be an array');
            }
        });
    }

    // Boundary Value Analysis: shortest and longer ticker lengths
    runTest('getExecutivesInfo boundary: single-letter symbol F', () => {
        const res = getExecutivesInfo({ symbol: 'F' });
        assert(res && typeof res === 'object', 'Result should be an object');
        assert(typeof res.success === 'boolean', 'Result should contain success boolean');
    });

    runTest('getExecutivesInfo boundary: five-letter symbol GOOGL', () => {
        const res = getExecutivesInfo({ symbol: 'GOOGL' });
        assert(res && typeof res === 'object', 'Result should be an object');
        assert(typeof res.success === 'boolean', 'Result should contain success boolean');
    });

    // Case variants (expect either success or graceful handling)
    const CASE_VARIANTS = ['aapl', 'msft'];
    for (const sym of CASE_VARIANTS) {
        runTest(`getExecutivesInfo case-variant ${sym}`, () => {
            const res = getExecutivesInfo({ symbol: sym });
            assert(res && typeof res === 'object', 'Result should be an object');
            assert(typeof res.success === 'boolean', 'Result should contain success boolean');
            if (res.success && res.response && Array.isArray(res.response.data) && res.response.data.length > 0) {
                const item = res.response.data[0];
                assert(typeof item.symbol === 'string', 'executive.symbol should be string');
                assert(item.symbol.toUpperCase() === sym.toUpperCase(), 'Returned symbol should match (case-insensitive)');
            }
        });
    }

    // Special values and invalid inputs - expect throw or explicit failure/empty
    const INVALID_INPUTS = [null, undefined, '', 0];
    for (const inval of INVALID_INPUTS) {
        runTest(`getExecutivesInfo invalid input symbol=${String(inval)}`, () => {
            let handled = false;
            try {
                const res = getExecutivesInfo({ symbol: inval });
                // Consider handled if function returns a structured failure or empty dataset
                if (res && typeof res === 'object') {
                    if (res.success === false) handled = true;
                    else if (res.response && Array.isArray(res.response.data) && res.response.data.length === 0) handled = true;
                    // Also accept if response is empty object or data is undefined
                    else if (res.success && (!res.response || !res.response.data)) handled = true;
                }
            } catch (e) {
                handled = true;
            }
            assert(handled, 'Should throw or indicate failure/empty for invalid inputs');
        });
    }

    console.log('\n--- getExecutivesInfo Test Summary ---');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
}

function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeExecutivesInfoNode } = require('@arrays/data/stock/company/executive-info:v1.0.0');

    // Smoke test - basic functionality test (may hit network)
    const gSmoke = new Graph(jagentId);
    gSmoke.addNode('executive_compensation_smoke', makeExecutivesInfoNode({ symbol: 'AAPL' }));
    gSmoke.run();

    // Mock test - use sample data to avoid network dependency
    const nodeCfg = makeExecutivesInfoNode({ symbol: 'MSFT' });
    nodeCfg.inputs.executives_info_raw = () => ({
        success: true,
        response: {
            data: [
                {
                    cik: '0000789019',
                    symbol: 'MSFT',
                    company_name: 'Microsoft Corporation',
                    filing_date: '2024-01-15',
                    accepted_date: '2024-01-15 16:30:00',
                    name_and_position: 'Satya Nadella Chief Executive Officer',
                    year: 2023,
                    salary: 2500000,
                    stock_award: 50000000,
                    incentive_plan_compensation: 10000000,
                    all_other_compensation: 50000,
                    total: 62550000,
                    link: 'https://www.sec.gov/Archives/edgar/data/789019/000078901924000001/0000789019-24-000001-index.htm',
                },
                {
                    cik: '0000789019',
                    symbol: 'MSFT',
                    company_name: 'Microsoft Corporation',
                    filing_date: '2024-01-15',
                    accepted_date: '2024-01-15 16:30:00',
                    name_and_position: 'Amy Hood Chief Financial Officer',
                    year: 2023,
                    salary: 1000000,
                    stock_award: 15000000,
                    incentive_plan_compensation: 5000000,
                    all_other_compensation: 25000,
                    total: 21025000,
                    link: 'https://www.sec.gov/Archives/edgar/data/789019/000078901924000001/0000789019-24-000001-index.htm',
                },
            ],
        },
    });

    const g = new Graph(jagentId);
    g.addNode('executive_compensation_mock', nodeCfg);
    g.run();

    // Validate mock data output
    const ts = new TimeSeries(
        new TimeSeriesUri(jagentId, 'executive_compensation_mock', 'executive_compensation_snapshot', { last: '5' }),
        g.store
    );
    ts.init();

    if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('snapshot empty');
    const snap = ts.data[0];
    ['date', 'symbol', 'executives'].forEach((k) => {
        if (!(k in snap)) throw new Error('missing snapshot field: ' + k);
    });
    if (!Array.isArray(snap.executives) || snap.executives.length !== 2) throw new Error('executives length must be 2 in mock');

    const e0 = snap.executives[0];
    ['cik', 'company_name', 'filing_date', 'accepted_date', 'name_and_position', 'year', 'salary', 'total', 'link'].forEach((k) => {
        if (!(k in e0)) throw new Error('missing executive field: ' + k);
    });

    // Validate smoke test output
    const tsSmoke = new TimeSeries(
        new TimeSeriesUri(jagentId, 'executive_compensation_smoke', 'executive_compensation_snapshot', { last: '5' }),
        gSmoke.store
    );
    tsSmoke.init();
    if (!Array.isArray(tsSmoke.data)) throw new Error('smoke test data must be an array');
    if (tsSmoke.data.length > 0) {
        const r = tsSmoke.data[0];
        if (typeof r.date !== 'number') throw new Error('smoke.date must be number(ms)');
        if (typeof r.symbol !== 'string') throw new Error('smoke.symbol must be string');
        if (!Array.isArray(r.executives)) throw new Error('smoke.executives must be array');
        if (r.executives.length > 0) {
            const exec = r.executives[0];
            if (typeof exec.name_and_position !== 'string') throw new Error('smoke.executive.name_and_position must be string');
        }
    }

    // Validate refs for executive_compensation_snapshot
    const refsExec = g.getRefsForOutput('executive_compensation_mock', 'executive_compensation_snapshot');
    if (!Array.isArray(refsExec) || refsExec.length === 0) throw new Error('Assertion failed: refsExec array is empty.');
    const ref = refsExec[0];
    const expected = {
        id: '@arrays/data/stock/company/executive-info/getExecutivesInfo',
        module_name: '@arrays/data/stock/company/executive-info',
        module_display_name: 'Company Executive Information',
        sdk_name: 'getExecutivesInfo',
        sdk_display_name: 'Company Executive Information',
        source_name: 'Financial Modeling Prep',
        source: 'https://site.financialmodelingprep.com/developer/docs/stable/company-executives',
    };
    if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for executive_compensation_snapshot');
    if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for executive_compensation_snapshot');
    if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for executive_compensation_snapshot');
    if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for executive_compensation_snapshot');
    if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for executive_compensation_snapshot');
    if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for executive_compensation_snapshot');
    if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for executive_compensation_snapshot');

    // Direct get* API tests (manual import required)
    testGetExecutivesInfo();

    return 0;
}

main();
