const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getExecutivesInfo following tool.json and global uniqueness rule
const getExecutivesInfoRef = {
    id: '@arrays/data/stock/company/executive-info/getExecutivesInfo',
    module_name: '@arrays/data/stock/company/executive-info',
    module_display_name: 'Company Executive Information',
    sdk_name: 'getExecutivesInfo',
    sdk_display_name: 'Company Executive Information',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/stable/company-executives',
};

// Utility to create a ref object with a generated title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title,
    };

    // 3. 返回新对象
    return newObject;
}

function getExecutivesInfo(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/company/executives_info';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

// Base description for getExecutivesInfo (derived from doc)
const getExecutivesInfoBaseFuncDesc = 'Get executive compensation data';

// Dynamic call description builder for getExecutivesInfo
function buildGetExecutivesInfoCallDescription(actualParams = {}) {
    const parts = [getExecutivesInfoBaseFuncDesc];
    // Add symbol if provided
    if (actualParams && typeof actualParams.symbol === 'string' && actualParams.symbol.trim()) {
        parts.push(`for ${actualParams.symbol}`);
    }
    return parts.join(' ').trim();
}

function parseDateOnlyToMs(s) {
    // Expect "YYYY-MM-DD"
    if (typeof s !== 'string') return undefined;
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s.trim());
    if (!m) return undefined;
    const y = Number(m[1]);
    const mo = Number(m[2]) - 1;
    const d = Number(m[3]);
    return Date.UTC(y, mo, d, 0, 0, 0, 0);
}

function parseAcceptedDateToMs(s) {
    // Expect "YYYY-MM-DD HH:mm:ss" or "YYYY-MM-DDTHH:mm:ss"
    if (typeof s !== 'string') return undefined;
    const t = s.trim().replace('T', ' ');
    const m = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/.exec(t);
    if (!m) return undefined;
    const y = Number(m[1]);
    const mo = Number(m[2]) - 1;
    const d = Number(m[3]);
    const hh = Number(m[4]);
    const mm = Number(m[5]);
    const ss = Number(m[6]);
    return Date.UTC(y, mo, d, hh, mm, ss, 0);
}

function makeExecutivesInfoNode(params) {
    return {
        inputs: {
            executives_info_raw: () => getExecutivesInfo(params),
        },
        outputs: {
            executive_compensation_snapshot: {
                name: 'executive_compensation_snapshot',
                description: 'Single snapshot with all executive compensation data',
                fields: [
                    { name: 'date', type: 'number', description: 'snapshot time in ms since epoch (UTC)' },
                    { name: 'symbol', type: 'string', description: 'stock ticker symbol' },
                    {
                        name: 'executives',
                        type: 'array',
                        description: 'all executive compensation records',
                        fields: [
                            { name: 'cik', type: 'string', description: 'company CIK' },
                            { name: 'company_name', type: 'string', description: 'company name' },
                            { name: 'filing_date', type: 'string', description: 'YYYY-MM-DD' },
                            { name: 'accepted_date', type: 'string', description: 'YYYY-MM-DD HH:mm:ss' },
                            { name: 'name_and_position', type: 'string', description: 'executive name and position' },
                            { name: 'year', type: 'number', description: 'fiscal year' },
                            { name: 'salary', type: 'number', description: 'USD' },
                            { name: 'bonus', type: 'number', description: 'USD' },
                            { name: 'stock_award', type: 'number', description: 'USD' },
                            { name: 'option_award', type: 'number', description: 'USD' },
                            { name: 'incentive_plan_compensation', type: 'number', description: 'USD' },
                            { name: 'all_other_compensation', type: 'number', description: 'USD' },
                            { name: 'total', type: 'number', description: 'USD' },
                            { name: 'link', type: 'string', description: 'SEC filing URL' },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getExecutivesInfoRef, params, buildGetExecutivesInfoCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.executives_info_raw;
            if (!raw || raw.success !== true || !raw.response || !Array.isArray(raw.response.data)) {
                throw new Error('Executive compensation raw data is invalid');
            }

            const rows = raw.response.data;
            if (rows.length === 0) {
                // 没有数据就不追加
                return undefined;
            }

            // 1) 选定一个确定时间 - 使用 accepted_date
            let snapshotTime = Number.NEGATIVE_INFINITY;
            for (const r of rows) {
                const t = parseAcceptedDateToMs(r.accepted_date);
                if (Number.isFinite(t) && t > snapshotTime) snapshotTime = t;
            }
            if (!Number.isFinite(snapshotTime)) {
                throw new Error('No valid accepted_date found in executive compensation data');
            }

            // 2) symbol: 优先 params.symbol，否则用第一行
            const symbol = (params && typeof params.symbol === 'string' && params.symbol) || (rows[0] && typeof rows[0].symbol === 'string' && rows[0].symbol) || '';

            // 3) executives 嵌套数组
            const executives = rows.map((exec) => ({
                cik: exec.cik,
                company_name: exec.company_name,
                filing_date: exec.filing_date,
                accepted_date: exec.accepted_date,
                name_and_position: exec.name_and_position,
                year: exec.year,
                salary: exec.salary,
                bonus: exec.bonus,
                stock_award: exec.stock_award,
                option_award: exec.option_award,
                incentive_plan_compensation: exec.incentive_plan_compensation,
                all_other_compensation: exec.all_other_compensation,
                total: exec.total,
                link: exec.link,
            }));

            // 4) 返回单条快照（外层唯一 date，内层嵌套数组）
            return {
                executive_compensation_snapshot: [
                    {
                        date: snapshotTime,
                        symbol,
                        executives,
                    },
                ],
            };
        },
    };
}

function getRefs() {
    return [
        getExecutivesInfoRef,
    ];
}

module.exports = {
    getExecutivesInfo,
    makeExecutivesInfoNode,
    getRefs,
};
