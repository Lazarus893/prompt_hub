const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

const getCompanyPriceTargetConsensusRef = {
    id: "@arrays/data/stock/company/price-target-consensus/getCompanyPriceTargetConsensus",
    module_name: "@arrays/data/stock/company/price-target-consensus",
    module_display_name: "Stock Price Target Consensus",
    sdk_name: "getCompanyPriceTargetConsensus",
    sdk_display_name: "Price Target Consensus",
    source_name: "Financial Modeling Prep",
    source: "https://site.financialmodelingprep.com/developer/docs/stable/price-target-consensus",
};

// Base description derived from doc for getCompanyPriceTargetConsensus
const baseGetCompanyPriceTargetConsensusDescription = "Get analysts' price target consensus";

// Build a dynamic call description for getCompanyPriceTargetConsensus using provided params
function buildGetCompanyPriceTargetConsensusCallDescription(actualParams = {}) {
    const parts = [baseGetCompanyPriceTargetConsensusDescription];

    // Add symbol context if provided
    if (actualParams && typeof actualParams.symbol === 'string' && actualParams.symbol.trim()) {
        parts.push(`for ${actualParams.symbol}`);
    }

    // No additional params specified in doc
    return parts.join(' ').trim();
}

// Create a reference object with a dynamic title built from params
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getCompanyPriceTargetConsensus(params) {
	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/company/price_target_consensus';

	const entries = Object.keys(params || {});
	const queryString = entries.length > 0 ? '?' + entries.map((k) => encodeURIComponent(k) + '=' + encodeURIComponent(params[k])).join('&') : '';

	const fullUrl = `${baseUrl}${queryString}`;
	const apiKey = key || 'c84b079d-3888-4366-9752-10bb6c51543d';
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': apiKey,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

function makeCompanyPriceTargetConsensusNode(params) {
	return {
		inputs: {
			company_price_target_consensus_raw: () => getCompanyPriceTargetConsensus(params),
		},
		outputs: {
			company_price_target_consensus: {
				name: 'company_price_target_consensus',
				description: 'Company Price Target Consensus snapshot',
				fields: [
					{ name: 'date', type: 'number', description: 'snapshot time ms' },
					{ name: 'symbol', type: 'string', description: 'queried stock symbol' },
					{ name: 'target_high', type: 'number', description: 'highest target price' },
					{ name: 'target_low', type: 'number', description: 'lowest target price' },
					{ name: 'target_consensus', type: 'number', description: 'average target price consensus' },
					{ name: 'target_median', type: 'number', description: 'median target price' },
				],
				ref: createReferenceWithTitle(getCompanyPriceTargetConsensusRef, params, buildGetCompanyPriceTargetConsensusCallDescription),
			},
		},
		run: (inputs) => {
			const raw = inputs.company_price_target_consensus_raw || {};
			const response = (raw && raw.response) || {};
			return {
				company_price_target_consensus: [
					{
						date: Date.now(),
						symbol: typeof response.symbol === 'string' ? response.symbol : typeof params?.symbol === 'string' ? params.symbol : undefined,
						target_high: Number.isFinite(response.target_high) ? response.target_high : undefined,
						target_low: Number.isFinite(response.target_low) ? response.target_low : undefined,
						target_consensus: Number.isFinite(response.target_consensus) ? response.target_consensus : undefined,
						target_median: Number.isFinite(response.target_median) ? response.target_median : undefined,
					},
				],
			};
		},
	};
}

function getRefs() {
	return [
		getCompanyPriceTargetConsensusRef,
	];
}

module.exports = {
	getCompanyPriceTargetConsensus,
	makeCompanyPriceTargetConsensusNode,
	getRefs,
};