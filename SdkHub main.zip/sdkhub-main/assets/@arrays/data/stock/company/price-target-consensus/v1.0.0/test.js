function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    // Manual import for get* function per instruction
    const { makeCompanyPriceTargetConsensusNode, getCompanyPriceTargetConsensus } = require('@arrays/data/stock/company/price-target-consensus:v1.0.0');

    let totalTests = 0;
    let passedTests = 0;

    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    function assertFiniteNumber(n, name) {
        if (typeof n !== 'number' || !Number.isFinite(n)) {
            throw new Error(`${name} must be a finite number`);
        }
    }

    console.log('\n=== Testing getCompanyPriceTargetConsensus ===');

    // ---------------- Happy Path ----------------
    const VALID_SYMBOLS = ['AAPL', 'META', 'MSFT', 'GOOGL', 'AMZN'];
    for (const symbol of VALID_SYMBOLS) {
        runTest(`Happy Path - ${symbol}`, () => {
            const result = getCompanyPriceTargetConsensus({ symbol });
            if (!result || typeof result !== 'object') throw new Error('Should return an object');
            if (!result.response || typeof result.response !== 'object') throw new Error('Missing response object');
            const r = result.response;
            if (r.symbol !== symbol) throw new Error(`symbol mismatch: expected ${symbol}, got ${r.symbol}`);
            assertFiniteNumber(r.target_high, 'target_high');
            assertFiniteNumber(r.target_low, 'target_low');
            assertFiniteNumber(r.target_consensus, 'target_consensus');
            assertFiniteNumber(r.target_median, 'target_median');
            if (r.target_high < r.target_low) throw new Error('target_high should be >= target_low');
        });
    }

    // ---------------- Boundary Value Analysis ----------------
    runTest('Boundary - minimum typical length symbol ("T")', () => {
        const symbol = 'T';
        const result = getCompanyPriceTargetConsensus({ symbol });
        const r = result.response;
        if (r.symbol !== symbol) throw new Error(`symbol mismatch: expected ${symbol}, got ${r.symbol}`);
        assertFiniteNumber(r.target_high, 'target_high');
        assertFiniteNumber(r.target_low, 'target_low');
        assertFiniteNumber(r.target_consensus, 'target_consensus');
        assertFiniteNumber(r.target_median, 'target_median');
    });

    runTest('Boundary - maximum common length symbol ("GOOGL")', () => {
        const symbol = 'GOOGL';
        const result = getCompanyPriceTargetConsensus({ symbol });
        const r = result.response;
        if (r.symbol !== symbol) throw new Error(`symbol mismatch: expected ${symbol}, got ${r.symbol}`);
        assertFiniteNumber(r.target_high, 'target_high');
        assertFiniteNumber(r.target_low, 'target_low');
        assertFiniteNumber(r.target_consensus, 'target_consensus');
        assertFiniteNumber(r.target_median, 'target_median');
    });

    // Lowercase input: accept either normalization to uppercase or an error
    runTest('Boundary - lowercase symbol normalization or error ("aapl")', () => {
        try {
            const result = getCompanyPriceTargetConsensus({ symbol: 'aapl' });
            const r = result.response;
            if (r.symbol !== 'AAPL') throw new Error(`expected normalized symbol AAPL, got ${r.symbol}`);
            assertFiniteNumber(r.target_high, 'target_high');
            assertFiniteNumber(r.target_low, 'target_low');
            assertFiniteNumber(r.target_consensus, 'target_consensus');
            assertFiniteNumber(r.target_median, 'target_median');
        } catch (e) {
            // Acceptable path: function enforces uppercase and throws on invalid case
        }
    });

    // Whitespace around input: accept normalization or error
    runTest('Boundary - surrounding whitespace normalization or error ("  AAPL  ")', () => {
        try {
            const result = getCompanyPriceTargetConsensus({ symbol: '  AAPL  ' });
            const r = result.response;
            if (r.symbol !== 'AAPL') throw new Error(`expected trimmed symbol AAPL, got ${r.symbol}`);
            assertFiniteNumber(r.target_high, 'target_high');
            assertFiniteNumber(r.target_low, 'target_low');
            assertFiniteNumber(r.target_consensus, 'target_consensus');
            assertFiniteNumber(r.target_median, 'target_median');
        } catch (e) {
            // Acceptable if implementation rejects whitespace
        }
    });

    // Very long symbol should be rejected
    runTest('Boundary - overly long symbol should error or return well-formed response (length 256)', () => {
        try {
            const result = getCompanyPriceTargetConsensus({ symbol: 'A'.repeat(256) });
            const r = result && result.response;
            if (!r) throw new Error('Missing response object');
            assertFiniteNumber(r.target_high, 'target_high');
            assertFiniteNumber(r.target_low, 'target_low');
            assertFiniteNumber(r.target_consensus, 'target_consensus');
            assertFiniteNumber(r.target_median, 'target_median');
        } catch (e) {
            // Acceptable path: implementation throws for invalid length
        }
    });

    // ---------------- Special Values ----------------
    runTest('Special - empty string should error or return well-formed response', () => {
        try {
            const result = getCompanyPriceTargetConsensus({ symbol: '' });
            const r = result && result.response;
            if (!r) throw new Error('Missing response object');
            assertFiniteNumber(r.target_high, 'target_high');
            assertFiniteNumber(r.target_low, 'target_low');
            assertFiniteNumber(r.target_consensus, 'target_consensus');
            assertFiniteNumber(r.target_median, 'target_median');
        } catch (e) {
            // Acceptable path: implementation throws for empty symbol
        }
    });

    runTest('Special - null symbol should error or return well-formed response', () => {
        try {
            const result = getCompanyPriceTargetConsensus({ symbol: null });
            const r = result && result.response;
            if (!r) throw new Error('Missing response object');
            assertFiniteNumber(r.target_high, 'target_high');
            assertFiniteNumber(r.target_low, 'target_low');
            assertFiniteNumber(r.target_consensus, 'target_consensus');
            assertFiniteNumber(r.target_median, 'target_median');
        } catch (e) {
            // Acceptable path: implementation throws for null
        }
    });

    runTest('Special - undefined symbol (missing) should error or return well-formed response', () => {
        try {
            const result = getCompanyPriceTargetConsensus({});
            const r = result && result.response;
            if (!r) throw new Error('Missing response object');
            assertFiniteNumber(r.target_high, 'target_high');
            assertFiniteNumber(r.target_low, 'target_low');
            assertFiniteNumber(r.target_consensus, 'target_consensus');
            assertFiniteNumber(r.target_median, 'target_median');
        } catch (e) {
            // Acceptable path: implementation throws for missing symbol
        }
    });

    for (const bad of [0, 1, false, true, [], {}, NaN]) {
        runTest(`Special - invalid type symbol should error or return well-formed response (${String(bad)})`, () => {
            try {
                const result = getCompanyPriceTargetConsensus({ symbol: bad });
                const r = result && result.response;
                if (!r) throw new Error('Missing response object');
                assertFiniteNumber(r.target_high, 'target_high');
                assertFiniteNumber(r.target_low, 'target_low');
                assertFiniteNumber(r.target_consensus, 'target_consensus');
                assertFiniteNumber(r.target_median, 'target_median');
            } catch (e) {
                // Acceptable path: implementation throws for invalid type
            }
        });
    }

    // Non-existent/unsupported symbol: accept either a thrown error or a well-formed response
    runTest('Special - non-existent symbol behavior ("ZZZZZ")', () => {
        const symbol = 'ZZZZZ';
        try {
            const result = getCompanyPriceTargetConsensus({ symbol });
            const r = result.response;
            if (r.symbol !== symbol) throw new Error(`symbol mismatch: expected ${symbol}, got ${r.symbol}`);
            assertFiniteNumber(r.target_high, 'target_high');
            assertFiniteNumber(r.target_low, 'target_low');
            assertFiniteNumber(r.target_consensus, 'target_consensus');
            assertFiniteNumber(r.target_median, 'target_median');
        } catch (e) {
            // Acceptable if implementation validates against known tickers
        }
    });

    // ---------------- Integration: Graph/Node + TimeSeries ----------------
    runTest('Integration - graph node, refs, and timeseries for AAPL', () => {
        const g = new Graph(jagentId);
        g.addNode('company_price_target_consensus', makeCompanyPriceTargetConsensusNode({ symbol: 'AAPL' }));
        g.run();

        const refs = g.getRefsForOutput('company_price_target_consensus', 'company_price_target_consensus');
        if (!Array.isArray(refs) || refs.length === 0) throw new Error('refs array should be non-empty');
        const ref = refs[0];
        const expected = {
            id: '@arrays/data/stock/company/price-target-consensus/getCompanyPriceTargetConsensus',
            module_name: '@arrays/data/stock/company/price-target-consensus',
            module_display_name: 'Stock Price Target Consensus',
            sdk_name: 'getCompanyPriceTargetConsensus',
            sdk_display_name: 'Price Target Consensus',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stable/price-target-consensus',
        };

        if (ref.id !== expected.id) throw new Error('ref.id mismatch');
        if (ref.module_name !== expected.module_name) throw new Error('ref.module_name mismatch');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('ref.module_display_name mismatch');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('ref.sdk_name mismatch');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('ref.sdk_display_name mismatch');
        if (ref.source_name !== expected.source_name) throw new Error('ref.source_name mismatch');
        if (ref.source !== expected.source) throw new Error('ref.source mismatch');

        const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'company_price_target_consensus', 'company_price_target_consensus', { last: '1' }), g.store);
        ts.init();
        if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('expected at least 1 record');
        const r = ts.data[0];
        if (typeof r.date !== 'number') throw new Error('date must be number (ms)');
        if (typeof r.symbol !== 'string') throw new Error('symbol must be string');
        if (r.symbol !== 'AAPL') throw new Error('symbol mismatch: ' + r.symbol);
        assertFiniteNumber(r.target_high, 'target_high');
        assertFiniteNumber(r.target_low, 'target_low');
        assertFiniteNumber(r.target_consensus, 'target_consensus');
        assertFiniteNumber(r.target_median, 'target_median');
    });

    // ---------------- Summary ----------------
    console.log('\n=== Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    if (passedTests === totalTests) {
        console.log('🎉 All tests passed!');
    } else {
        console.log('⚠️  Some tests failed. Please review the output above.');
    }

    return 0;
}

main();
