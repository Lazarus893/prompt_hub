function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeSharesFloatNode, getSharesFloat } = require('@arrays/data/stock/shares-float:v1.0.0');

    // Smoke test - basic functionality test
    const g = new Graph(jagentId);
    g.addNode('shares_float_smoke', makeSharesFloatNode({ symbol: 'AAPL' }));
    g.run();

    // Mock test - using sample data to avoid network dependency
    const nodeCfg = makeSharesFloatNode({ symbol: 'AAPL' });

    // Override input with mock data that matches the API response structure
    nodeCfg.inputs.shares_float_raw = () => ({
        success: true,
        response: {
            shares_float: [
                {
                    symbol: 'AAPL',
                    date: '2025-09-23 04:17:20',
                    free_float: 99.82500000336918,
                    float_shares: 14814419318,
                    outstanding_shares: 14840390000,
                    source: 'https://www.sec.gov/Archives/edgar/data/320193/000032019324000123/aapl-20240928.htm',
                },
            ],
        },
    });

    const g2 = new Graph(jagentId);
    g2.addNode('shares_float_mock', nodeCfg);
    g2.run();

    // Validate mock data output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'shares_float_mock', 'shares_float_snapshot', { last: '5' }), g2.store);
    ts.init();

    if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('snapshot empty');
    const snap = ts.data[0];
    ['date', 'shares_float'].forEach((k) => {
        if (!(k in snap)) throw new Error('missing snapshot field: ' + k);
    });
    if (!Array.isArray(snap.shares_float) || snap.shares_float.length !== 1) throw new Error('shares_float length must be 1 in mock');

    const s0 = snap.shares_float[0];
    ['symbol', 'date', 'free_float', 'float_shares', 'outstanding_shares', 'source'].forEach((k) => {
        if (!(k in s0)) throw new Error('missing shares float field: ' + k);
    });

    // Validate smoke test output
    const tsSmoke = new TimeSeries(new TimeSeriesUri(jagentId, 'shares_float_smoke', 'shares_float_snapshot', { last: '5' }), g.store);
    tsSmoke.init();
    if (!Array.isArray(tsSmoke.data)) throw new Error('smoke test data must be an array');
    if (tsSmoke.data.length > 0) {
        const r = tsSmoke.data[0];
        if (typeof r.date !== 'number') throw new Error('smoke.date must be number(ms)');
        if (!Array.isArray(r.shares_float)) throw new Error('smoke.shares_float must be array');
        if (r.shares_float.length > 0) {
            const share = r.shares_float[0];
            if (typeof share.symbol !== 'string') throw new Error('smoke.shares_float.symbol must be string');
        }
    }

    // Validate refs metadata for shares_float_snapshot output
    const refsSharesFloat = g2.getRefsForOutput('shares_float_mock', 'shares_float_snapshot');
    if (refsSharesFloat.length > 0) {
        const ref = refsSharesFloat[0];
        const expected = {
            id: '@arrays/data/stock/shares-float/getSharesFloat',
            module_name: '@arrays/data/stock/shares-float',
            module_display_name: 'Company Outstanding Shares ',
            sdk_name: 'getSharesFloat',
            sdk_display_name: 'Company Outstanding Shares',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stable/shares-float',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for shares_float_snapshot');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for shares_float_snapshot');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for shares_float_snapshot');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for shares_float_snapshot');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for shares_float_snapshot');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for shares_float_snapshot');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for shares_float_snapshot');
    } else {
        throw new Error('Assertion failed: refsSharesFloat array is empty.');
    }

    // ================= Direct getSharesFloat() Tests =================
    console.log('\n=== Direct getSharesFloat Tests ===');

    // Simple assert helper to avoid external dependencies
    function assert(condition, message) {
        if (!condition) throw new Error(message || 'Assertion failed');
    }

    let totalTests = 0;
    let passedTests = 0;
    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    // Helper: validate APIResponse shape per doc
    function validateAPIResponseShape(res) {
        assert(res && typeof res === 'object', 'Response should be an object');
        assert(typeof res.success === 'boolean', 'success must be boolean');
        assert(res.response && typeof res.response === 'object', 'response must be an object');
        assert(Array.isArray(res.response.shares_float), 'response.shares_float must be an array');
        if (res.response.shares_float.length > 0) {
            const it = res.response.shares_float[0];
            assert(typeof it.symbol === 'string', 'shares_float[0].symbol must be string');
            assert(typeof it.date === 'string', 'shares_float[0].date must be string');
            // Validate date format roughly: YYYY-MM-DD HH:mm:ss
            const dateRegex = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/;
            assert(dateRegex.test(it.date), 'date should match YYYY-MM-DD HH:mm:ss');
            assert(typeof it.free_float === 'number', 'free_float must be number');
            assert(it.free_float >= 0 && it.free_float <= 100, 'free_float should be in [0,100]');
            assert(typeof it.float_shares === 'number', 'float_shares must be number');
            assert(it.float_shares >= 0, 'float_shares should be >= 0');
            assert(typeof it.outstanding_shares === 'number', 'outstanding_shares must be number');
            assert(it.outstanding_shares >= 0, 'outstanding_shares should be >= 0');
            // float shares should not exceed outstanding shares (allow equality)
            assert(it.outstanding_shares >= it.float_shares, 'outstanding_shares should be >= float_shares');
            assert(typeof it.source === 'string' && it.source.length > 0, 'source must be non-empty string');
            assert(/^https?:\/\//.test(it.source), 'source should be a URL');
        }
    }

    // Happy Path: test multiple well-known symbols
    const VALID_SYMBOLS = ['AAPL', 'MSFT', 'TSLA', 'A']; // include 1-char symbol boundary (e.g., Agilent 'A')
    for (const sym of VALID_SYMBOLS) {
        runTest(`getSharesFloat happy path - ${sym}`, () => {
            const res = getSharesFloat({ symbol: sym });
            validateAPIResponseShape(res);
        });
    }

    // Boundary Value Analysis
    runTest('getSharesFloat boundary - class symbol with dot (BRK.B)', () => {
        try {
            const res = getSharesFloat({ symbol: 'BRK.B' });
            // Accept either valid result or empty array depending on provider support
            validateAPIResponseShape(res);
        } catch (e) {
            // Some providers may reject dot symbols; failure acceptable if throws
        }
    });

    runTest('getSharesFloat boundary - lowercase symbol (aapl)', () => {
        try {
            const res = getSharesFloat({ symbol: 'aapl' });
            // Some APIs normalize case; validate shape if not throwing
            validateAPIResponseShape(res);
        } catch (e) {
            // Accept throw for case-sensitive APIs
        }
    });

    runTest('getSharesFloat boundary - very long symbol', () => {
        const sym = 'THISISVERYLONGSYMBOLNAME12345';
        try {
            const res = getSharesFloat({ symbol: sym });
            assert(res && typeof res === 'object', 'Should return object when not throwing');
            // Either success=false or empty dataset is acceptable for invalid symbol
            const ok = (res.success === false) || (res.response && Array.isArray(res.response.shares_float) && res.response.shares_float.length === 0);
            assert(ok, 'Should handle invalid long symbol gracefully (throw, success=false, or empty shares_float)');
        } catch (e) {
            // Throwing is acceptable
        }
    });

    // Special Values Tests
    runTest('getSharesFloat special - null symbol', () => {
        try {
            const res = getSharesFloat({ symbol: null });
            const ok = res && typeof res === 'object' && (
                res.success === false ||
                (res.response && Array.isArray(res.response.shares_float) && res.response.shares_float.length === 0)
            );
            assert(ok, 'Should handle null symbol gracefully');
        } catch (e) {
            // Throwing is acceptable too
        }
    });

    runTest('getSharesFloat special - undefined params', () => {
        try {
            const res = getSharesFloat();
            const ok = res && typeof res === 'object' && (
                res.success === false ||
                (res.response && Array.isArray(res.response.shares_float) && res.response.shares_float.length === 0)
            );
            assert(ok, 'Should handle undefined params gracefully');
        } catch (e) {
            // Throwing is acceptable too
        }
    });

    runTest('getSharesFloat special - missing symbol in params', () => {
        try {
            const res = getSharesFloat({});
            const ok = res && typeof res === 'object' && (
                res.success === false ||
                (res.response && Array.isArray(res.response.shares_float) && res.response.shares_float.length === 0)
            );
            assert(ok, 'Should handle missing symbol gracefully');
        } catch (e) {
            // Throwing is acceptable too
        }
    });

    runTest('getSharesFloat special - empty string symbol', () => {
        try {
            const res = getSharesFloat({ symbol: '' });
            // Either throw, success=false, or empty array
            const ok = (res && res.success === false) || (res && res.response && Array.isArray(res.response.shares_float) && res.response.shares_float.length === 0);
            assert(ok, 'Should handle empty string symbol gracefully');
        } catch (e) {
            // Throwing is acceptable
        }
    });

    runTest('getSharesFloat special - non-string symbol (0)', () => {
        try {
            const res = getSharesFloat({ symbol: 0 });
            const ok = res && typeof res === 'object' && (
                res.success === false ||
                (res.response && Array.isArray(res.response.shares_float) && res.response.shares_float.length === 0)
            );
            assert(ok, 'Should handle non-string symbol gracefully');
        } catch (e) {
            // Throwing is acceptable too
        }
    });

    runTest('getSharesFloat special - params not object', () => {
        try {
            const res = getSharesFloat('AAPL');
            const ok = res && typeof res === 'object' && (
                res.success === false ||
                (res.response && Array.isArray(res.response.shares_float) && res.response.shares_float.length === 0)
            );
            assert(ok, 'Should handle non-object params gracefully');
        } catch (e) {
            // Throwing is acceptable too
        }
    });

    // Print test summary for direct getSharesFloat tests
    console.log('\n=== getSharesFloat Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    return 0;
}

main();
