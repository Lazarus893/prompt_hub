const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getSharesFloat, derived from tool.json
const getSharesFloatRef = {
    id: '@arrays/data/stock/shares-float/getSharesFloat',
    module_name: '@arrays/data/stock/shares-float',
    module_display_name: 'Company Outstanding Shares ',
    sdk_name: 'getSharesFloat',
    sdk_display_name: 'Company Outstanding Shares',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/stable/shares-float',
};

// Internal description builder snippets derived from doc (do not export)
// Base description for getSharesFloat
const baseGetSharesFloatDescription = 'Get float shares data';

// Dynamic description builder for getSharesFloat
function buildGetSharesFloatCallDescription(actualParams = {}) {
    const parts = [baseGetSharesFloatDescription];

    // symbol (documented param)
    if (actualParams && typeof actualParams === 'object') {
        if (actualParams.symbol) {
            parts.push(`for ${actualParams.symbol}`);
        }

        // No additional documented params beyond symbol; keep extensible
        const filters = [];
        if (filters.length > 0) {
            parts.push(`(${filters.join(', ')})`);
        }
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getSharesFloat(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/shares-float';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

/**
 * Parse various timestamp string formats to epoch ms (UTC).
 * Supported:
 * - ISO 8601 strings parsable by Date.parse
 * - 'YYYY-MM-DD HH:mm:ss'
 * - 'YYYY-MM-DD'
 * - 'MM-DD-YYYY' or 'MM/DD/YYYY'
 */
function parseToMs(s) {
    if (s == null) return undefined;
    if (typeof s !== 'string') return undefined;

    // Try native Date.parse first (handles many ISO variants)
    const parsed = Date.parse(s);
    if (!Number.isNaN(parsed)) return parsed;

    // 'YYYY-MM-DD HH:mm:ss'
    let m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/);
    if (m) {
        const y = +m[1];
        const mo = +m[2] - 1;
        const d = +m[3];
        const hh = +m[4];
        const mm = +m[5];
        const ss = +m[6];
        return Date.UTC(y, mo, d, hh, mm, ss, 0);
    }

    // 'YYYY-MM-DD'
    m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (m) {
        const y = +m[1];
        const mo = +m[2] - 1;
        const d = +m[3];
        return Date.UTC(y, mo, d, 0, 0, 0, 0);
    }

    // 'MM-DD-YYYY' or 'MM/DD/YYYY'
    m = s.match(/^(\d{2})[-\/](\d{2})[-\/](\d{4})$/);
    if (m) {
        const mo = +m[1] - 1;
        const d = +m[2];
        const y = +m[3];
        return Date.UTC(y, mo, d, 0, 0, 0, 0);
    }

    return undefined;
}

function makeSharesFloatNode(params) {
    return {
        inputs: {
            shares_float_raw: () => getSharesFloat(params),
        },
        outputs: {
            shares_float_snapshot: {
                name: 'shares_float_snapshot',
                description: 'Single snapshot with all shares float data',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'snapshot time in ms since epoch (UTC), derived from latest date',
                    },
                    {
                        name: 'shares_float',
                        type: 'array',
                        description: 'all shares float records',
                        fields: [
                            { name: 'symbol', type: 'string', description: 'stock ticker symbol' },
                            { name: 'date', type: 'string', description: 'date of the record in YYYY-MM-DD HH:mm:ss format' },
                            { name: 'free_float', type: 'number', description: 'free float percentage' },
                            { name: 'float_shares', type: 'number', description: 'total float shares' },
                            { name: 'outstanding_shares', type: 'number', description: 'total outstanding shares' },
                            { name: 'source', type: 'string', description: 'URL link to the SEC filing source' },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getSharesFloatRef, params, buildGetSharesFloatCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.shares_float_raw;

            // 兼容 {success, response:{data}} 和 {data:{data}} 两种结构
            const container = (raw && (raw.response || raw.data)) || {};
            const sharesFloat = Array.isArray(container.shares_float) ? container.shares_float : [];
            if (sharesFloat.length === 0) {
                // 没有数据就不追加
                return undefined;
            }

            // 1) 从数据里推导一个确定性的 snapshot 时间（最新 date）
            let snapshotTime = Number.NEGATIVE_INFINITY;
            for (const s of sharesFloat) {
                const t = parseToMs(s.date);
                if (Number.isFinite(t) && t > snapshotTime) snapshotTime = t;
            }
            if (!Number.isFinite(snapshotTime)) {
                throw new Error('No valid snapshot time found in shares float data');
            }

            // 2) Map all shares float into the nested array
            const sharesFloatData = sharesFloat.map((s) => ({
                symbol: s.symbol,
                date: s.date,
                free_float: s.free_float,
                float_shares: s.float_shares,
                outstanding_shares: s.outstanding_shares,
                source: s.source,
            }));

            // 可选：排序，便于下游一致性
            sharesFloatData.sort((a, b) => {
                const ta = parseToMs(a.date) ?? -1;
                const tb = parseToMs(b.date) ?? -1;
                if (tb !== ta) return tb - ta;
                return (a.symbol || '').localeCompare(b.symbol || '');
            });

            // 3) 返回单条快照（外层唯一 date，内层嵌套数组）
            return {
                shares_float_snapshot: [
                    {
                        date: snapshotTime,
                        shares_float: sharesFloatData,
                    },
                ],
            }; 
        },
    };
}

// Export all Ref-suffixed objects in this module
function getRefs() {
    return [
        getSharesFloatRef,
    ];
}

module.exports = {
    getSharesFloat,
    makeSharesFloatNode,
    getRefs,
};
