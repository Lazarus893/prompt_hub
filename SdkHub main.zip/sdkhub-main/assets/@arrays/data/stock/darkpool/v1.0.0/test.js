function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
}
assert.strictEqual = function (actual, expected, message) {
    if (actual !== expected) {
        throw new Error(message || `Assertion failed: expected ${String(actual)} === ${String(expected)}`);
    }
};

function testGetDarkpoolData() {
    console.log('\n=== Testing getDarkpoolData (Direct Function) ===');

    const { getDarkpoolData } = require('@arrays/data/stock/darkpool:v1.0.0');

    let totalTests = 0;
    let passedTests = 0;

    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    // Helpers
    const now = new Date();
    const endDate = now.toISOString().split('T')[0]; // YYYY-MM-DD
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 3600 * 1000);
    const startDate = sevenDaysAgo.toISOString().split('T')[0];

    function isNumericString(s) {
        return typeof s === 'string' && /^-?\d+(?:\.\d+)?$/.test(s);
    }

    function isNumericStringOrNumber(v) {
        return (typeof v === 'number' && Number.isFinite(v)) || isNumericString(String(v));
    }

    function isIntegerish(v) {
        return (typeof v === 'number' && Number.isInteger(v)) || (typeof v === 'string' && /^-?\d+$/.test(v));
    }

    function validateRecordShape(record) {
        assert(typeof record.ticker === 'string', 'ticker should be string');

        // hour timestamp variants: hour_timestamp | timestamp | date (ms)
        const timeCandidates = ['hour_timestamp', 'timestamp', 'date'];
        for (const k of timeCandidates) {
            if (record[k] !== undefined && record[k] !== null) {
                let tsNum = NaN;
                const val = record[k];
                if (typeof val === 'number' && Number.isFinite(val)) {
                    tsNum = val;
                } else if (typeof val === 'string') {
                    if (isNumericString(val)) tsNum = Number(val);
                    else {
                        const parsed = Date.parse(val);
                        if (!Number.isNaN(parsed)) tsNum = parsed / 1000;
                    }
                }
                // some sources might be ms
                if (tsNum > 1e12) tsNum = tsNum / 1000;
                assert(Number.isFinite(tsNum) && tsNum > 0, `${k} should be a valid positive timestamp`);
                break;
            }
        }

        // price variants: *_price or plain names
        const priceMap = {
            open: ['open_price', 'open', 'o'],
            high: ['high_price', 'high', 'h'],
            low: ['low_price', 'low', 'l'],
            close: ['close_price', 'close', 'c'],
        };
        for (const key in priceMap) {
            const names = priceMap[key];
            const found = names.find((n) => record[n] !== undefined && record[n] !== null);
            if (found) {
                assert(isNumericStringOrNumber(record[found]), `${found} should be numeric string or number`);
            }
        }

        // volume variants
        const volKey = ['volume', 'vol'].find((n) => record[n] !== undefined && record[n] !== null);
        if (volKey) {
            const v = record[volKey];
            assert(isNumericStringOrNumber(v), `${volKey} should be numeric`);
        }

        // trade count variants
        const tcKey = ['trade_count', 'trades', 'count'].find((n) => record[n] !== undefined && record[n] !== null);
        if (tcKey) {
            assert(isIntegerish(record[tcKey]), `${tcKey} should be integer-ish`);
        }

        // total value and vwap if present
        const totalKey = ['total_value', 'total'].find((n) => record[n] !== undefined && record[n] !== null);
        if (totalKey) assert(isNumericStringOrNumber(record[totalKey]), `${totalKey} should be numeric`);

        if (record.vwap !== undefined && record.vwap !== null) {
            assert(isNumericStringOrNumber(record.vwap), 'vwap should be numeric');
        }
    }

    function validateSuccessResult(res) {
        assert(res && typeof res === 'object', 'result should be object');
        assert(typeof res.success === 'boolean', 'success should be boolean');
        assert.strictEqual(res.success, true, 'success should be true');
        assert(res.error === null || typeof res.error === 'undefined', 'error should be null on success');
        assert(res.response && typeof res.response === 'object', 'response should be object');
        assert(Array.isArray(res.response.data), 'response.data should be an array');
        if (res.response.data.length > 0) {
            validateRecordShape(res.response.data[0]);
        }
    }

    function validateFailureResultOrThrow(call) {
        try {
            const res = call();
            // If no exception, we expect a structured failure
            assert(res && typeof res === 'object', 'result should be object on failure');
            assert(typeof res.success === 'boolean', 'success should be boolean');
            assert.strictEqual(res.success, false, 'success should be false');
            assert(res.error && typeof res.error === 'object', 'error should be an object on failure');
            assert(typeof res.error.code === 'string', 'error.code should be string');
            assert(typeof res.error.message === 'string', 'error.message should be string');
        } catch (e) {
            // Exception is acceptable failure mode
            assert(e instanceof Error, 'Should throw an Error for invalid input');
        }
    }

    // ============ Happy Path Tests ============
    runTest('getDarkpoolData: happy path with ticker AAPL', () => {
        const res = getDarkpoolData({ ticker: 'AAPL', start_date: startDate, end_date: endDate });
        validateSuccessResult(res);
        if (res.response.data.length > 0) {
            assert.strictEqual(res.response.data[0].ticker.toUpperCase(), 'AAPL', 'ticker should match filter');
        }
    });

    runTest('getDarkpoolData: happy path with ticker TSLA', () => {
        const res = getDarkpoolData({ ticker: 'TSLA', start_date: startDate, end_date: endDate });
        validateSuccessResult(res);
        if (res.response.data.length > 0) {
            assert.strictEqual(res.response.data[0].ticker.toUpperCase(), 'TSLA', 'ticker should match filter');
        }
    });

    runTest('getDarkpoolData: happy path without ticker (all tickers)', () => {
        const res = getDarkpoolData({ start_date: startDate, end_date: endDate });
        validateSuccessResult(res);
    });

    // ============ Boundary Value Analysis ============
    runTest('getDarkpoolData: boundary start_date == end_date', () => {
        const res = getDarkpoolData({ ticker: 'AAPL', start_date: endDate, end_date: endDate });
        validateSuccessResult(res);
    });

    runTest('getDarkpoolData: boundary start_date after end_date should fail', () => {
        validateFailureResultOrThrow(() => getDarkpoolData({ ticker: 'AAPL', start_date: endDate, end_date: startDate }));
    });

    runTest('getDarkpoolData: invalid date format should fail', () => {
        validateFailureResultOrThrow(() => getDarkpoolData({ ticker: 'AAPL', start_date: '2025/01/01', end_date: endDate }));
    });

    runTest('getDarkpoolData: impossible date (YYYY-MM-DD out of range) should fail', () => {
        validateFailureResultOrThrow(() => getDarkpoolData({ ticker: 'AAPL', start_date: '2025-13-40', end_date: endDate }));
    });

    // ============ Special Values ============
    runTest('getDarkpoolData: invalid ticker should fail', () => {
        validateFailureResultOrThrow(() => getDarkpoolData({ ticker: 'INVALID_TICKER_XXX', start_date: startDate, end_date: endDate }));
    });

    runTest('getDarkpoolData: ticker null should fail', () => {
        validateFailureResultOrThrow(() => getDarkpoolData({ ticker: null, start_date: startDate, end_date: endDate }));
    });

    runTest('getDarkpoolData: ticker empty string should fail or be rejected', () => {
        validateFailureResultOrThrow(() => getDarkpoolData({ ticker: '', start_date: startDate, end_date: endDate }));
    });

    runTest('getDarkpoolData: ticker whitespace should fail or be rejected', () => {
        validateFailureResultOrThrow(() => getDarkpoolData({ ticker: '   ', start_date: startDate, end_date: endDate }));
    });

    runTest('getDarkpoolData: ticker 0 should fail', () => {
        // @ts-ignore intentionally wrong type
        validateFailureResultOrThrow(() => getDarkpoolData({ ticker: 0, start_date: startDate, end_date: endDate }));
    });

    runTest('getDarkpoolData: ticker undefined should behave like omitted (success)', () => {
        const res = getDarkpoolData({ ticker: undefined, start_date: startDate, end_date: endDate });
        validateSuccessResult(res);
    });

    runTest('getDarkpoolData: null start_date should fail', () => {
        validateFailureResultOrThrow(() => getDarkpoolData({ ticker: 'AAPL', start_date: null, end_date: endDate }));
    });

    runTest('getDarkpoolData: undefined end_date should fail', () => {
        validateFailureResultOrThrow(() => getDarkpoolData({ ticker: 'AAPL', start_date: startDate, end_date: undefined }));
    });

    runTest('getDarkpoolData: empty string dates should fail', () => {
        validateFailureResultOrThrow(() => getDarkpoolData({ ticker: 'AAPL', start_date: '', end_date: '' }));
    });

    runTest('getDarkpoolData: both start_date and end_date missing should fail', () => {
        // Missing required params
        validateFailureResultOrThrow(() => getDarkpoolData({}));
    });

    runTest('getDarkpoolData: small range (yesterday to today)', () => {
        const yesterday = new Date(now.getTime() - 24 * 3600 * 1000).toISOString().split('T')[0];
        const res = getDarkpoolData({ ticker: 'AAPL', start_date: yesterday, end_date: endDate });
        validateSuccessResult(res);
    });

    // Print summary
    console.log('\n=== getDarkpoolData Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function testMakeDarkpoolNode() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeDarkpoolNode } = require('@arrays/data/stock/darkpool:v1.0.0');

    const graph = new Graph(jagentId);

    // Use YYYY-MM-DD format for start_date and end_date
    const now = new Date();
    const endDate = now.toISOString().split('T')[0]; // Today in YYYY-MM-DD
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 3600 * 1000);
    const startDate = sevenDaysAgo.toISOString().split('T')[0]; // 7 days ago in YYYY-MM-DD

    graph.addNode(
        'darkpool_data',
        makeDarkpoolNode({
            ticker: 'AAPL',
            start_date: startDate,
            end_date: endDate,
        })
    );

    graph.run();

    // Materialize and validate the darkpool output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'darkpool_data', 'darkpool', { last: '10' }), graph.store);
    ts.init();

    if (!Array.isArray(ts.data)) {
        throw new Error('Expected darkpool data to be an array');
    }

    if (ts.data.length > 0) {
        const record = ts.data[0];

        if (typeof record.date !== 'number') {
            throw new Error('Expected record.date to be a number (timestamp in ms)');
        }

        if (typeof record.ticker !== 'string') {
            throw new Error('Expected record.ticker to be a string');
        }

        if (typeof record.open !== 'number') {
            throw new Error('Expected record.open to be a number');
        }

        if (typeof record.high !== 'number') {
            throw new Error('Expected record.high to be a number');
        }

        if (typeof record.low !== 'number') {
            throw new Error('Expected record.low to be a number');
        }

        if (typeof record.close !== 'number') {
            throw new Error('Expected record.close to be a number');
        }

        if (typeof record.volume !== 'number') {
            throw new Error('Expected record.volume to be a number');
        }

        if (typeof record.trade_count !== 'number') {
            throw new Error('Expected record.trade_count to be a number');
        }

        if (typeof record.total_value !== 'number') {
            throw new Error('Expected record.total_value to be a number');
        }

        if (typeof record.vwap !== 'number') {
            throw new Error('Expected record.vwap to be a number');
        }

        console.log(`✅ Darkpool validation passed: ${record.ticker} OHLC(${record.open}/${record.high}/${record.low}/${record.close}) Volume: ${record.volume}, VWAP: ${record.vwap}`);
    }

    // Validate refs metadata for the darkpool output
    const refsDarkpool = graph.getRefsForOutput('darkpool_data', 'darkpool');
    if (refsDarkpool.length > 0) {
        const ref = refsDarkpool[0];
        const expected = {
            id: '@arrays/data/stock/darkpool/getDarkpoolData',
            module_name: '@arrays/data/stock/darkpool',
            module_display_name: 'Dark Pool Trading Data',
            sdk_name: 'getDarkpoolData',
            sdk_display_name: 'Dark Pool Trading Data',
            source_name: 'Polygon.io',
            source: 'https://polygon.io/docs/flat-files/stocks/trades',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for darkpool');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for darkpool');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for darkpool');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for darkpool');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for darkpool');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for darkpool');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for darkpool');
        console.log('✓ darkpool refs validated');
    } else {
        throw new Error('Assertion failed: refsDarkpool array is empty.');
    }

    console.log('✅ Darkpool Data make*Node tests passed');
}

function main() {
    testGetDarkpoolData();
    testMakeDarkpoolNode();
    return 0;
}

main();
