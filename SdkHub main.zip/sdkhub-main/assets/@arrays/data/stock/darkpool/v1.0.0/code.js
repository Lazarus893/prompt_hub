const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// SDK Reference metadata for getDarkpoolData (sourced from tool.json)
const getDarkpoolDataRef = {
    id: '@arrays/data/stock/darkpool/getDarkpoolData',
    module_name: '@arrays/data/stock/darkpool',
    module_display_name: 'Dark Pool Trading Data',
    sdk_name: 'getDarkpoolData',
    sdk_display_name: 'Dark Pool Trading Data',
    source_name: 'Polygon.io',
    source: 'https://polygon.io/docs/flat-files/stocks/trades',
};
// Base description and dynamic call description builder (internal)
const baseGetDarkpoolDataDescription = "Get dark pool trading data";
function buildGetDarkpoolDataCallDescription(actualParams = {}) {
    const parts = [baseGetDarkpoolDataDescription];
    if (actualParams.ticker) parts.push(`for ${actualParams.ticker}`);
    const filters = [];
    if (actualParams.start_date && actualParams.end_date) {
        filters.push(`Date: ${actualParams.start_date} to ${actualParams.end_date}`);
    } else if (actualParams.start_date) {
        filters.push(`From: ${actualParams.start_date}`);
    } else if (actualParams.end_date) {
        filters.push(`Until: ${actualParams.end_date}`);
    }
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getDarkpoolData(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/darkpool';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function makeDarkpoolNode(params) {
    return {
        inputs: {
            darkpool_raw: () => getDarkpoolData(params),
        },
        outputs: {
            darkpool: {
                name: 'darkpool_ohlcv',
                description: 'Dark pool trading data with OHLCV, volume, trade count, and VWAP',
                fields: [
                    { name: 'date', type: 'number', description: 'hour timestamp ms since epoch (UTC)' },
                    { name: 'ticker', type: 'string', description: 'stock ticker symbol' },
                    { name: 'open', type: 'number', description: 'opening price' },
                    { name: 'high', type: 'number', description: 'highest price' },
                    { name: 'low', type: 'number', description: 'lowest price' },
                    { name: 'close', type: 'number', description: 'closing price' },
                    { name: 'volume', type: 'number', description: 'trading volume' },
                    { name: 'trade_count', type: 'number', description: 'number of trades' },
                    { name: 'total_value', type: 'number', description: 'total trade value in USD' },
                    { name: 'vwap', type: 'number', description: 'volume weighted average price' },
                ],
                ref: createReferenceWithTitle(getDarkpoolDataRef, params, buildGetDarkpoolDataCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.darkpool_raw;

            if (raw?.error) {
                throw new Error(`API Error: ${raw.error.message || 'Unknown error'}`);
            }

            if (!raw?.response?.data) {
                return { darkpool: [] };
            }

            if (!Array.isArray(raw.response.data)) {
                throw new Error('Invalid API response: response.data is not an array');
            }

            const records = raw.response.data
                .map((item) => ({
                    date: typeof item.hour_timestamp === 'number' ? item.hour_timestamp * 1000 : undefined,
                    ticker: item.ticker || '',
                    open: parseFloat(item.open_price),
                    high: parseFloat(item.high_price),
                    low: parseFloat(item.low_price),
                    close: parseFloat(item.close_price),
                    volume: item.volume,
                    trade_count: item.trade_count,
                    total_value: parseFloat(item.total_value),
                    vwap: parseFloat(item.vwap),
                }))
                .filter((r) => typeof r.date === 'number');

            // Deduplicate by date (keep last), then sort ascending by date
            const dedup = new Map();
            for (const r of records) dedup.set(r.date, r);
            const out = Array.from(dedup.values()).sort((a, b) => a.date - b.date);

            return { darkpool: out };
        },
    };
}

function makeDarkpoolDataNode(params) {
    return makeDarkpoolNode(params);
}

function getRefs() {
    return [
        getDarkpoolDataRef,
    ];
}

module.exports = {
    getDarkpoolData,
    makeDarkpoolNode,
    makeDarkpoolDataNode,
    getRefs,
};

