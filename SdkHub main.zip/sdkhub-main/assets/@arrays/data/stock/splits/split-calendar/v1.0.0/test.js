function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeSplitCalendarNode, getSplitCalendar } = require('@arrays/data/stock/splits/split-calendar:v1.0.0');

    // -------------------------
    // Graph/Node based tests
    // -------------------------
    // Smoke test - basic functionality test
    const g = new Graph(jagentId);
    g.addNode('split_calendar_smoke', makeSplitCalendarNode({ from: '2024-01-01', to: '2024-12-31' }));
    g.run();

    // Mock test - using sample data to avoid network dependency
    const nodeCfg = makeSplitCalendarNode({ from: '2024-01-01', to: '2024-12-31' });

    // Override input with mock data that matches the API response structure
    nodeCfg.inputs.split_calendar_raw = () => ({
        data: {
            calendar: [
                {
                    symbol: 'KOMOF',
                    date: '2023-01-30',
                    numerator: 1,
                    denominator: 10,
                },
                {
                    symbol: 'ENLTF',
                    date: '2023-01-30',
                    numerator: 10,
                    denominator: 1,
                },
                {
                    symbol: 'SEYE.ST',
                    date: '2023-01-30',
                    numerator: 247,
                    denominator: 200,
                },
                {
                    symbol: 'CLA.L',
                    date: '2023-01-30',
                    numerator: 1,
                    denominator: 2000,
                },
                {
                    symbol: 'RKSLF',
                    date: '2023-01-30',
                    numerator: 2,
                    denominator: 1,
                },
            ],
        },
        success: true,
    });

    const g2 = new Graph(jagentId);
    g2.addNode('split_calendar_mock', nodeCfg);
    g2.run();

    // Validate mock data output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'split_calendar_mock', 'split_calendar_snapshot', { last: '5' }), g2.store);
    ts.init();

    if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('snapshot empty');
    const snap = ts.data[0];
    ['date', 'calendar'].forEach((k) => {
        if (!(k in snap)) throw new Error('missing snapshot field: ' + k);
    });
    if (!Array.isArray(snap.calendar) || snap.calendar.length !== 5) throw new Error('calendar length must be 5 in mock');

    const s0 = snap.calendar[0];
    ['symbol', 'date', 'numerator', 'denominator'].forEach((k) => {
        if (!(k in s0)) throw new Error('missing calendar field: ' + k);
    });

    // Validate smoke test output
    const tsSmoke = new TimeSeries(new TimeSeriesUri(jagentId, 'split_calendar_smoke', 'split_calendar_snapshot', { last: '5' }), g.store);
    tsSmoke.init();
    if (!Array.isArray(tsSmoke.data)) throw new Error('smoke test data must be an array');
    if (tsSmoke.data.length > 0) {
        const r = tsSmoke.data[0];
        if (typeof r.date !== 'number') throw new Error('smoke.date must be number(ms)');
        if (!Array.isArray(r.calendar)) throw new Error('smoke.calendar must be array');
        if (r.calendar.length > 0) {
            const event = r.calendar[0];
            if (typeof event.symbol !== 'string') throw new Error('smoke.calendar.symbol must be string');
        }
    }

    // Validate refs for split_calendar_snapshot output
    const refsSplitCalendar = g.getRefsForOutput('split_calendar_smoke', 'split_calendar_snapshot');
    if (refsSplitCalendar.length > 0) {
        const ref = refsSplitCalendar[0];
        const expected = {
            id: '@arrays/data/stock/splits/split-calendar/getSplitCalendar',
            module_name: '@arrays/data/stock/splits/split-calendar',
            module_display_name: 'Stock Split Calendar',
            sdk_name: 'getSplitCalendar',
            sdk_display_name: 'Stock Splits Calendar',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stock-split-calendar-api',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for split_calendar_snapshot');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for split_calendar_snapshot');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for split_calendar_snapshot');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for split_calendar_snapshot');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for split_calendar_snapshot');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for split_calendar_snapshot');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for split_calendar_snapshot');
    } else {
        throw new Error('Assertion failed: refsSplitCalendar array is empty.');
    }

    // -------------------------
    // Direct get function tests
    // -------------------------
    console.log('\n=== Testing getSplitCalendar (Direct Call) ===');

    // minimal local assert
    function assert(cond, msg) {
        if (!cond) throw new Error(msg || 'assertion failed');
    }

    let totalTests = 0;
    let passedTests = 0;
    function runTest(name, fn) {
        totalTests++;
        try {
            fn();
            console.log(`✅ ${name}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${name}: ${e && e.message ? e.message : e}`);
        }
    }

    // Helper to validate a standard successful-ish response shape without being too strict
    function validateResponseShape(res, { allowEmpty = true } = {}) {
        assert(res && typeof res === 'object', 'response should be an object');
        if ('success' in res) {
            assert(typeof res.success === 'boolean', 'success should be boolean');
        }
        // If success === false, allow early return
        if (res.success === false) return;
        // If data present, validate calendar array
        if (res.data !== undefined) {
            assert(typeof res.data === 'object' && res.data !== null, 'data should be object');
            if ('calendar' in res.data) {
                assert(Array.isArray(res.data.calendar), 'data.calendar should be array');
                if (!allowEmpty) assert(res.data.calendar.length >= 0, 'calendar should be array');
                // If there is at least one item, validate fields on the first item
                if (res.data.calendar.length > 0) {
                    const c0 = res.data.calendar[0];
                    assert(typeof c0.symbol === 'string', 'calendar[0].symbol should be string');
                    assert(typeof c0.date === 'string', 'calendar[0].date should be string');
                    assert(typeof c0.numerator === 'number', 'calendar[0].numerator should be number');
                    assert(typeof c0.denominator === 'number', 'calendar[0].denominator should be number');
                }
            }
        }
    }

    // Happy Path: no params
    runTest('getSplitCalendar() without params', () => {
        const res = getSplitCalendar();
        validateResponseShape(res);
    });

    // Happy Path: with from/to range (typical year range)
    runTest('getSplitCalendar({ from: 2023-01-01, to: 2023-12-31 })', () => {
        const res = getSplitCalendar({ from: '2023-01-01', to: '2023-12-31' });
        validateResponseShape(res);
    });

    // Happy Path: only from
    runTest('getSplitCalendar({ from only })', () => {
        const res = getSplitCalendar({ from: '2023-06-01' });
        validateResponseShape(res);
    });

    // Happy Path: only to
    runTest('getSplitCalendar({ to only })', () => {
        const res = getSplitCalendar({ to: '2023-12-31' });
        validateResponseShape(res);
    });

    // Boundary: from == to (single-day window)
    runTest('Boundary: from === to', () => {
        const res = getSplitCalendar({ from: '2023-01-30', to: '2023-01-30' });
        validateResponseShape(res);
    });

    // Boundary: very old date to near future
    runTest('Boundary: wide range 1900-01-01 to 2100-12-31', () => {
        const res = getSplitCalendar({ from: '1900-01-01', to: '2100-12-31' });
        validateResponseShape(res);
    });

    // Special values: undefined should behave like omitted
    runTest('Special: undefined params', () => {
        const res = getSplitCalendar({ from: undefined, to: undefined });
        validateResponseShape(res);
    });

    // Special values: null/empty string should be handled gracefully or error
    runTest('Special: null params', () => {
        try {
            const res = getSplitCalendar({ from: null, to: null });
            // Either returns a handled response or throws; both acceptable
            validateResponseShape(res);
        } catch (e) {
            // acceptable path: API/client rejects invalid params
            assert(e.message, 'Should throw an error message for null params');
        }
    });

    runTest('Special: empty string params', () => {
        try {
            const res = getSplitCalendar({ from: '', to: '' });
            validateResponseShape(res);
        } catch (e) {
            assert(e.message, 'Should throw an error message for empty params');
        }
    });

    // Invalid: malformed dates
    runTest('Invalid: malformed month (2023-13-01)', () => {
        try {
            const res = getSplitCalendar({ from: '2023-13-01', to: '2023-12-31' });
            // Consider pass if API marks as unsuccessful or returns handled response
            if (res && typeof res === 'object' && 'success' in res && res.success === false) return;
            // Else must have thrown earlier; validate shape if not
            validateResponseShape(res);
        } catch (e) {
            assert(e.message, 'Should throw on invalid month');
        }
    });

    runTest('Invalid: malformed day (2023-02-30)', () => {
        try {
            const res = getSplitCalendar({ from: '2023-02-30', to: '2023-03-01' });
            if (res && typeof res === 'object' && 'success' in res && res.success === false) return;
            validateResponseShape(res);
        } catch (e) {
            assert(e.message, 'Should throw on invalid day');
        }
    });

    // Invalid: from > to
    runTest('Invalid: from greater than to', () => {
        try {
            const res = getSplitCalendar({ from: '2024-12-31', to: '2024-01-01' });
            if (res && typeof res === 'object' && 'success' in res && res.success === false) return;
            validateResponseShape(res);
        } catch (e) {
            assert(e.message, 'Should throw when from > to');
        }
    });

    // Invalid: numeric-like string '0'
    runTest('Invalid: numeric-like strings', () => {
        try {
            const res = getSplitCalendar({ from: '0', to: '0' });
            if (res && typeof res === 'object' && 'success' in res && res.success === false) return;
            validateResponseShape(res);
        } catch (e) {
            assert(e.message, 'Should throw on invalid date strings like "0"');
        }
    });

    // Print test summary for direct get function tests
    console.log('\n=== getSplitCalendar Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    return 0;
}

main();
