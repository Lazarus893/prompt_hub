function testGetSplitEventDirect() {
    // Manual import for get* function per instruction
    const { getSplitEvent } = require('@arrays/data/stock/splits/split-event:v1.0.0');

    // Simple assert helper (avoid external deps)
    function assert(cond, msg) {
        if (!cond) throw new Error(msg || 'Assertion failed');
    }

    let totalTests = 0;
    let passedTests = 0;

    function runTest(name, fn) {
        totalTests++;
        try {
            fn();
            console.log(`✅ ${name}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${name}: ${e.message}`);
        }
    }

    console.log('\n=== Testing getSplitEvent (Direct) ===');

    // Happy path: test multiple well-known tickers (enumeration-style coverage)
    const TICKERS = ['AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA', 'NVDA', 'META', 'AMD'];
    for (const symbol of TICKERS) {
        runTest(`getSplitEvent happy path for ${symbol}`, () => {
            const res = getSplitEvent({ symbol });
            assert(res && typeof res === 'object', 'Should return an object');
            if ('success' in res) assert(typeof res.success === 'boolean', 'success should be boolean');
            assert('data' in res && res.data && typeof res.data === 'object', 'data container should exist');
            assert('count' in res.data && typeof res.data.count === 'number', 'data.count should be number');
            assert(Array.isArray(res.data.data), 'data.data should be an array');

            if (res.data.data.length > 0) {
                const ev = res.data.data[0];
                assert(typeof ev.symbol === 'string', 'event.symbol should be string');
                assert(typeof ev.date === 'string', 'event.date should be string YYYY-MM-DD');
                assert(typeof ev.numerator === 'number', 'event.numerator should be number');
                assert(typeof ev.denominator === 'number', 'event.denominator should be number');
            }
        });
    }

    // Boundary Value Analysis
    // - Minimal length ticker (1 char)
    runTest('getSplitEvent boundary: single-letter ticker F', () => {
        const res = getSplitEvent({ symbol: 'F' }); // Ford
        assert(res && typeof res === 'object', 'Should return object for single-letter ticker');
        if ('success' in res && res.success) {
            assert(res.data && typeof res.data.count === 'number', 'Should provide count');
            assert(Array.isArray(res.data.data), 'Should provide data array');
        }
    });

    // - Case sensitivity check (lowercase)
    runTest('getSplitEvent boundary: lowercase ticker aapl', () => {
        try {
            const res = getSplitEvent({ symbol: 'aapl' });
            // Accept either behavior: normalize or error/unsuccessful
            if (res && typeof res === 'object') {
                if ('success' in res && res.success === false) return; // acceptable unsuccessful
                // If successful, validate structure
                if ('success' in res) assert(typeof res.success === 'boolean', 'success should be boolean');
                assert(res.data && typeof res.data.count === 'number', 'count should be number');
                assert(Array.isArray(res.data.data), 'data array should exist');
            } else {
                throw new Error('Function did not return an object');
            }
        } catch (e) {
            // Also acceptable: throw error for invalid case
            assert(e.message, 'Should provide an error message');
        }
    });

    // Special value tests and invalids
    const INVALID_SYMBOLS = [
        { label: 'empty string', value: '' },
        { label: 'null', value: null },
        { label: 'undefined', value: undefined },
        { label: 'numeric zero', value: 0 },
        { label: 'nonsense symbol', value: 'ZZZZZZ' },
    ];
    for (const { label, value } of INVALID_SYMBOLS) {
        runTest(`getSplitEvent invalid: ${label}`, () => {
            try {
                const res = getSplitEvent({ symbol: value });
                // Two acceptable outcomes: throw error OR success=false
                if (res && typeof res === 'object' && 'success' in res) {
                    assert(res.success === false || res.data?.count === 0, 'Should be unsuccessful or return zero data');
                } else {
                    // If no structured response, expect an error throw
                    throw new Error('Expected error or unsuccessful response for invalid input');
                }
            } catch (e) {
                assert(e.message, 'Should provide an error message on invalid input');
            }
        });
    }

    // Print summary
    console.log('\n=== getSplitEvent (Direct) Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeSplitEventNode } = require('@arrays/data/stock/splits/split-event:v1.0.0');

    // Smoke test - basic functionality test
    const g = new Graph(jagentId);
    g.addNode('split_events_smoke', makeSplitEventNode({ symbol: 'AAPL' }));
    g.run();

    // Mock test - using sample data to avoid network dependency
    const nodeCfg = makeSplitEventNode({ symbol: 'AAPL' });

    // Override input with mock data that matches the API response structure
    nodeCfg.inputs.split_event_raw = () => ({
        data: {
            count: 5,
            data: [
                {
                    date: '2020-08-31',
                    denominator: 1,
                    numerator: 4,
                    symbol: 'AAPL',
                },
                {
                    date: '2014-06-09',
                    denominator: 1,
                    numerator: 7,
                    symbol: 'AAPL',
                },
                {
                    date: '2005-02-28',
                    denominator: 1,
                    numerator: 2,
                    symbol: 'AAPL',
                },
                {
                    date: '2000-06-21',
                    denominator: 1,
                    numerator: 2,
                    symbol: 'AAPL',
                },
                {
                    date: '1987-06-16',
                    denominator: 1,
                    numerator: 2,
                    symbol: 'AAPL',
                },
            ],
        },
        success: true,
    });

    const g2 = new Graph(jagentId);
    g2.addNode('split_events_mock', nodeCfg);
    g2.run();

    // Validate mock data output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'split_events_mock', 'split_events_snapshot', { last: '5' }), g2.store);
    ts.init();

    if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('snapshot empty');
    const snap = ts.data[0];
    ['date', 'split_events'].forEach((k) => {
        if (!(k in snap)) throw new Error('missing snapshot field: ' + k);
    });
    if (!Array.isArray(snap.split_events) || snap.split_events.length !== 5) throw new Error('split_events length must be 5 in mock');

    const s0 = snap.split_events[0];
    ['symbol', 'date', 'numerator', 'denominator'].forEach((k) => {
        if (!(k in s0)) throw new Error('missing split event field: ' + k);
    });

    // Validate smoke test output
    const tsSmoke = new TimeSeries(new TimeSeriesUri(jagentId, 'split_events_smoke', 'split_events_snapshot', { last: '5' }), g.store);
    tsSmoke.init();
    if (!Array.isArray(tsSmoke.data)) throw new Error('smoke test data must be an array');
    if (tsSmoke.data.length > 0) {
        const r = tsSmoke.data[0];
        if (typeof r.date !== 'number') throw new Error('smoke.date must be number(ms)');
        if (!Array.isArray(r.split_events)) throw new Error('smoke.split_events must be array');
        if (r.split_events.length > 0) {
            const event = r.split_events[0];
            if (typeof event.symbol !== 'string') throw new Error('smoke.split_events.symbol must be string');
        }
    }

    // Validate refs for split_events_snapshot
    const refsSplit = g2.getRefsForOutput('split_events_mock', 'split_events_snapshot');
    if (refsSplit.length > 0) {
        const ref = refsSplit[0];
        const expected = {
            id: '@arrays/data/stock/splits/split-event/getSplitEvent',
            module_name: '@arrays/data/stock/splits/split-event',
            module_display_name: 'Stock Splits Events',
            sdk_name: 'getSplitEvent',
            sdk_display_name: 'Stock Splits Events',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stock-split-calendar-api',
        };
        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for split_events_snapshot');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for split_events_snapshot');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for split_events_snapshot');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for split_events_snapshot');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for split_events_snapshot');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for split_events_snapshot');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for split_events_snapshot');
        if (typeof console !== 'undefined' && console.log) console.log('✓ split_events_snapshot refs validated');
    } else {
        throw new Error('Assertion failed: refsSplit array is empty.');
    }

    // Run direct getSplitEvent tests modeled after example.js style
    testGetSplitEventDirect();

    return 0;
}

main();
