const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

const getSplitEventRef = {
    id: "@arrays/data/stock/splits/split-event/getSplitEvent",
    module_name: "@arrays/data/stock/splits/split-event",
    module_display_name: "Stock Splits Events",
    sdk_name: "getSplitEvent",
    sdk_display_name: "Stock Splits Events",
    source_name: "Financial Modeling Prep",
    source: "https://site.financialmodelingprep.com/developer/docs/stock-split-calendar-api",
};

function getSplitEvent(params) {
	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/splits';
	const keyValuePairs = Object.keys(params || {}).map((key) => {
		const value = params[key];
		return encodeURIComponent(key) + '=' + encodeURIComponent(value);
	});
	const queryString = keyValuePairs.join('&');
	const fullUrl = queryString ? `${baseUrl}?${queryString}` : baseUrl;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

// Base description for getSplitEvent derived from doc
const baseGetSplitEventDescription = "Get stock split history";

// Dynamic description builder for getSplitEvent
function buildGetSplitEventCallDescription(actualParams = {}) {
    const parts = [baseGetSplitEventDescription];

    // Add symbol if provided (required by doc)
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }

    return parts.join(' ').trim();
}

// Create a reference object with a dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

/**
 * Parse various timestamp string formats to epoch ms (UTC).
 * Supported:
 * - ISO 8601 strings parsable by Date.parse
 * - 'YYYY-MM-DD HH:mm:ss'
 * - 'YYYY-MM-DD'
 * - 'MM-DD-YYYY' or 'MM/DD/YYYY'
 */
function parseToMs(s) {
	if (s == null) return undefined;
	if (typeof s !== 'string') return undefined;

	// Try native Date.parse first (handles many ISO variants)
	const parsed = Date.parse(s);
	if (!Number.isNaN(parsed)) return parsed;

	// 'YYYY-MM-DD HH:mm:ss'
	let m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/);
	if (m) {
		const y = +m[1];
		const mo = +m[2] - 1;
		const d = +m[3];
		const hh = +m[4];
		const mm = +m[5];
		const ss = +m[6];
		return Date.UTC(y, mo, d, hh, mm, ss, 0);
	}

	// 'YYYY-MM-DD'
	m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
	if (m) {
		const y = +m[1];
		const mo = +m[2] - 1;
		const d = +m[3];
		return Date.UTC(y, mo, d, 0, 0, 0, 0);
	}

	// 'MM-DD-YYYY' or 'MM/DD/YYYY'
	m = s.match(/^(\d{2})[-\/](\d{2})[-\/](\d{4})$/);
	if (m) {
		const mo = +m[1] - 1;
		const d = +m[2];
		const y = +m[3];
		return Date.UTC(y, mo, d, 0, 0, 0, 0);
	}

	return undefined;
}

function makeSplitEventNode(params) {
	return {
		inputs: {
			split_event_raw: () => getSplitEvent(params),
		},
		outputs: {
			split_events_snapshot: {
				name: 'split_events_snapshot',
				description: 'Single snapshot with all split event data',
				ref: createReferenceWithTitle(getSplitEventRef, params, buildGetSplitEventCallDescription),
				fields: [
					{
						name: 'date',
						type: 'number',
						description: 'snapshot time in ms since epoch (UTC), derived from latest date',
					},
					{
						name: 'split_events',
						type: 'array',
						description: 'all split event records',
						fields: [
							{ name: 'symbol', type: 'string', description: 'stock symbol' },
							{ name: 'date', type: 'string', description: 'split date in YYYY-MM-DD format' },
							{ name: 'numerator', type: 'number', description: 'split ratio numerator' },
							{ name: 'denominator', type: 'number', description: 'split ratio denominator' },
						],
					},
				],
			},
		},
		run: (inputs) => {
			const raw = inputs.split_event_raw;

			// 兼容 {success, response:{data}} 和 {data:{data}} 两种结构
			const container = (raw && (raw.response || raw.data)) || {};
			const events = Array.isArray(container.data) ? container.data : [];
			if (events.length === 0) {
				// 没有数据就不追加
				return undefined;
			}

			// 1) 从数据里推导一个确定性的 snapshot 时间（最新 date）
			let snapshotTime = Number.NEGATIVE_INFINITY;
			for (const e of events) {
				const t = parseToMs(e.date);
				if (Number.isFinite(t) && t > snapshotTime) snapshotTime = t;
			}
			if (!Number.isFinite(snapshotTime)) {
				throw new Error('No valid snapshot time found in split event data');
			}

			// 2) Map all events into the nested array
			const eventsData = events.map((e) => ({
				symbol: e.symbol,
				date: e.date,
				numerator: e.numerator,
				denominator: e.denominator,
			}));

			// 可选：排序，便于下游一致性
			eventsData.sort((a, b) => {
				const ta = parseToMs(a.date) ?? -1;
				const tb = parseToMs(b.date) ?? -1;
				if (tb !== ta) return tb - ta;
				return (a.symbol || '').localeCompare(b.symbol || '');
			});

			// 3) 返回单条快照（外层唯一 date，内层嵌套数组）
			return {
				split_events_snapshot: [
					{
						date: snapshotTime,
						split_events: eventsData,
					},
				],
			};
		},
	};
}

function getRefs() {
    return [
        getSplitEventRef,
    ];
}

module.exports = {
	getSplitEvent,
	makeSplitEventNode,
    getRefs,
};
