const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Helper to create reference with dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

// Reference metadata for getConfirmedIPOFilingevents
const getConfirmedIPOFilingeventsRef = {
    id: '@arrays/data/stock/ipo-confirmed-calendar/getConfirmedIPOFilingevents',
    module_name: '@arrays/data/stock/ipo-confirmed-calendar',
    module_display_name: 'Company IPO Confirmed Calendar',
    sdk_name: 'getConfirmedIPOFilingevents',
    sdk_display_name: 'Company IPO Confirmed Calendar',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/legacy#ipo-confirmed-ipo-calendar',
};

// Base description derived from doc for getConfirmedIPOFilingevents
const baseGetConfirmedIPOFilingeventsDescription = 'Get confirmed IPO filing events';

// Dynamic description builder for getConfirmedIPOFilingevents
function buildGetConfirmedIPOFilingeventsCallDescription(actualParams = {}) {
    const parts = [baseGetConfirmedIPOFilingeventsDescription];

    const filters = [];
    if (actualParams && typeof actualParams === 'object') {
        const { from, to } = actualParams;
        if (from && to) {
            filters.push(`Time: ${from} to ${to}`);
        } else if (from) {
            filters.push(`From: ${from}`);
        } else if (to) {
            filters.push(`To: ${to}`);
        }
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function getConfirmedIPOFilingevents(params) {
    // Input validation
    if (!params || typeof params !== 'object') {
        return {
            success: false,
            error: { code: 'INVALID_PARAMS', message: 'Invalid parameters: params must be an object' },
            response: null
        };
    }

    // Validate date format if provided (both from and to are optional)
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (params.from !== undefined && params.from !== null && params.from !== '') {
        if (typeof params.from !== 'string' || !dateRegex.test(params.from)) {
            return {
                success: false,
                error: { code: 'INVALID_DATE', message: 'Invalid parameters: from must be in YYYY-MM-DD format' },
                response: null
            };
        }
    }

    if (params.to !== undefined && params.to !== null && params.to !== '') {
        if (typeof params.to !== 'string' || !dateRegex.test(params.to)) {
            return {
                success: false,
                error: { code: 'INVALID_DATE', message: 'Invalid parameters: to must be in YYYY-MM-DD format' },
                response: null
            };
        }
    }

    // Validate date range if both dates are provided
    if (params.from && params.to) {
        if (params.from > params.to) {
            return {
                success: false,
                error: { code: 'INVALID_DATE_RANGE', message: 'Invalid parameters: from must not be later than to' },
                response: null
            };
        }
    }

    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/ipo-confirmed-calendar';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function makeConfirmedIPOFilingeventsNode(params) {
    return {
        inputs: {
            confirmed_ipo_filingevents_raw: () => getConfirmedIPOFilingevents(params),
        },
        outputs: {
            confirmed_ipo_calendar: {
                name: 'confirmed_ipo_calendar',
                description: 'Daily confirmed IPO filing calendar (one record per date).',
                fields: [
                    { name: 'date', type: 'number', description: 'filing date ms (UTC day start)' },
                    {
                        name: 'entries',
                        type: 'array',
                        description: 'all IPO filing entries on this date',
                        fields: [
                            { name: 'symbol', type: 'string', description: 'Stock symbol of the company' },
                            { name: 'cik', type: 'string', description: 'Central Index Key' },
                            { name: 'form', type: 'string', description: 'Form type of the filing' },
                            { name: 'filingDate', type: 'string', description: 'Date the filing was submitted' },
                            { name: 'acceptedDate', type: 'string', description: 'Date and time the filing was accepted' },
                            { name: 'effectivenessDate', type: 'string', description: 'Date the filing became effective' },
                            { name: 'url', type: 'string', description: 'Direct URL to the filing document' },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(
                    getConfirmedIPOFilingeventsRef,
                    params,
                    buildGetConfirmedIPOFilingeventsCallDescription
                ),
            },
        },
        run: (inputs) => {
            const raw = inputs.confirmed_ipo_filingevents_raw;

            if (raw?.error) {
                throw new Error(`API Error: ${raw.error.message || 'Unknown error'}`);
            }

            if (!raw?.data) {
                return { confirmed_ipo_calendar: [] };
            }

            if (!Array.isArray(raw.data)) {
                throw new Error('Invalid API response: data is not an array');
            }

            // Prefer deterministic UTC conversion for date-only strings
            const parseFilingDateMs = (s) => {
                if (!s) return null;
                const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s).trim());
                if (m) {
                    const y = Number(m[1]);
                    const mon0 = Number(m[2]) - 1;
                    const d = Number(m[3]);
                    return Date.UTC(y, mon0, d, 0, 0, 0, 0);
                }
                const t = Date.parse(s);
                return Number.isFinite(t) ? t : null;
            };

            // Group by date (ms, UTC day start)
            const byDate = new Map();
            for (const item of raw.data) {
                const date = parseFilingDateMs(item.filingDate);
                if (date == null) continue;

                const normalized = {
                    symbol: item.symbol,
                    cik: item.cik,
                    form: item.form,
                    filingDate: item.filingDate,
                    acceptedDate: item.acceptedDate,
                    effectivenessDate: item.effectivenessDate,
                    url: item.url,
                };

                if (!byDate.has(date)) byDate.set(date, []);
                byDate.get(date).push(normalized);
            }

            const series = Array.from(byDate.entries())
                .sort((a, b) => a[0] - b[0])
                .map(([date, entries]) => ({
                    date,
                    entries,
                }));

            return { confirmed_ipo_calendar: series };
        },
    };
}

function getRefs() {
    return [
        getConfirmedIPOFilingeventsRef,
    ];
}

module.exports = {
    getConfirmedIPOFilingevents,
    makeConfirmedIPOFilingeventsNode,
    getRefs,
};