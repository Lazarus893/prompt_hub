// Manual import for get* function per requirement
const { getConfirmedIPOFilingevents } = require('@arrays/data/stock/ipo-confirmed-calendar:v1.0.0');

function testGetConfirmedIPOFilingevents() {
    console.log('\n=== Testing getConfirmedIPOFilingevents (Direct Function) ===');

    let totalTests = 0;
    let passedTests = 0;

    function assert(condition, message) {
        if (!condition) throw new Error(message || 'Assertion failed');
    }

    function runTest(name, fn) {
        totalTests++;
        try {
            fn();
            console.log(`✅ ${name}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${name}: ${e.message}`);
        }
    }

    function validateRecord(rec) {
        assert(rec && typeof rec === 'object', 'Record should be an object');
        assert(typeof rec.symbol === 'string', 'symbol should be string');
        assert(typeof rec.cik === 'string', 'cik should be string');
        assert(typeof rec.form === 'string', 'form should be string');
        assert(typeof rec.filing_date === 'string', 'filing_date should be string');
        assert(typeof rec.accepted_date === 'string', 'accepted_date should be string');
        assert(typeof rec.effectiveness_date === 'string', 'effectiveness_date should be string');
        assert(typeof rec.url === 'string', 'url should be string');

        // Optional format checks based on doc
        const dateRe = /^\d{4}-\d{2}-\d{2}$/;
        const dateTimeRe = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/;
        assert(dateRe.test(rec.filing_date), 'filing_date should match YYYY-MM-DD');
        assert(dateTimeRe.test(rec.accepted_date), 'accepted_date should match YYYY-MM-DD HH:mm:ss');
        assert(dateRe.test(rec.effectiveness_date), 'effectiveness_date should match YYYY-MM-DD');
        assert(rec.url.startsWith('http'), 'url should be http/https URL');
    }

    function validateResponse(obj) {
        assert(obj && typeof obj === 'object', 'Response should be an object');
        assert(obj.success === true, 'success should be true');
        assert(obj.response && typeof obj.response === 'object', 'response should be an object');
        assert(Array.isArray(obj.response.events), 'response.events should be an array');
        if (obj.response.events.length > 0) {
            validateRecord(obj.response.events[0]);
        }
    }

    const VALID_FROM = '2025-09-01';
    const VALID_TO = '2025-09-07';

    // Happy path: valid from/to window
    runTest('Happy path: with from and to', () => {
        const res = getConfirmedIPOFilingevents({ from: VALID_FROM, to: VALID_TO });
        validateResponse(res);
    });

    // Happy path: same-day window (boundary)
    runTest('Boundary: from equals to (same day)', () => {
        const res = getConfirmedIPOFilingevents({ from: VALID_FROM, to: VALID_FROM });
        validateResponse(res);
    });

    // Happy path: only from
    runTest('Happy path: only from provided', () => {
        const res = getConfirmedIPOFilingevents({ from: VALID_FROM });
        validateResponse(res);
    });

    // Happy path: only to
    runTest('Happy path: only to provided', () => {
        const res = getConfirmedIPOFilingevents({ to: VALID_TO });
        validateResponse(res);
    });

    // Happy path: no params
    runTest('Happy path: no params', () => {
        const res = getConfirmedIPOFilingevents({});
        validateResponse(res);
    });

    // Special values: null, undefined, empty string
    const SPECIALS = [null, undefined, ''];

    for (const val of SPECIALS) {
        runTest(`Special value for from: ${String(val)}`, () => {
            try {
                const res = getConfirmedIPOFilingevents({ from: val, to: VALID_TO });
                validateResponse(res);
            } catch (e) {
                assert(/invalid|format|date/i.test(e.message), 'Should gracefully handle invalid from value');
            }
        });
    }

    for (const val of SPECIALS) {
        runTest(`Special value for to: ${String(val)}`, () => {
            try {
                const res = getConfirmedIPOFilingevents({ from: VALID_FROM, to: val });
                validateResponse(res);
            } catch (e) {
                assert(/invalid|format|date/i.test(e.message), 'Should gracefully handle invalid to value');
            }
        });
    }

    console.log('\n=== getConfirmedIPOFilingevents Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeConfirmedIPOFilingeventsNode } = require('@arrays/data/stock/ipo-confirmed-calendar:v1.0.0');

    const graph = new Graph(jagentId);
    graph.addNode(
        'confirmed_ipo_calendar',
        makeConfirmedIPOFilingeventsNode({
            from: '2025-09-01',
            to: '2025-09-07',
        })
    );

    graph.run();

    // Materialize and validate the IPO calendar output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'confirmed_ipo_calendar', 'confirmed_ipo_calendar', { last: '10' }), graph.store);
    ts.init();

    if (!Array.isArray(ts.data)) {
        throw new Error('Expected IPO calendar data to be an array');
    }

    if (ts.data.length > 0) {
        const dayRecord = ts.data[0];

        if (typeof dayRecord.date !== 'number') {
            throw new Error('Expected dayRecord.date to be a number (timestamp in ms)');
        }

        if (!Array.isArray(dayRecord.entries)) {
            throw new Error('Expected dayRecord.entries to be an array');
        }

        // Validate entries if any exist
        if (dayRecord.entries.length > 0) {
            const entry = dayRecord.entries[0];

            if (typeof entry.symbol !== 'string') {
                throw new Error('Expected entry.symbol to be a string');
            }

            if (typeof entry.cik !== 'string') {
                throw new Error('Expected entry.cik to be a string');
            }

            if (typeof entry.form !== 'string') {
                throw new Error('Expected entry.form to be a string');
            }

            if (typeof entry.filingDate !== 'string') {
                throw new Error('Expected entry.filingDate to be a string');
            }

            if (typeof entry.acceptedDate !== 'string') {
                throw new Error('Expected entry.acceptedDate to be a string');
            }

            if (typeof entry.effectivenessDate !== 'string') {
                throw new Error('Expected entry.effectivenessDate to be a string');
            }

            if (typeof entry.url !== 'string') {
                throw new Error('Expected entry.url to be a string');
            }

            log(`✅ IPO calendar validation passed: ${dayRecord.entries.length} entries on ${new Date(dayRecord.date).toISOString().split('T')[0]}`);
            log('   Entry fields validated: symbol, cik, form, filingDate, acceptedDate, effectivenessDate, url');
        }
    }

    // Validate refs for the confirmed_ipo_calendar output
    const refsIPO = graph.getRefsForOutput('confirmed_ipo_calendar', 'confirmed_ipo_calendar');
    if (refsIPO.length > 0) {
        const ref = refsIPO[0];
        const expected = {
            id: '@arrays/data/stock/ipo-confirmed-calendar/getConfirmedIPOFilingevents',
            module_name: '@arrays/data/stock/ipo-confirmed-calendar',
            module_display_name: 'Company IPO Confirmed Calendar',
            sdk_name: 'getConfirmedIPOFilingevents',
            sdk_display_name: 'Company IPO Confirmed Calendar',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/legacy#ipo-confirmed-ipo-calendar',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for confirmed_ipo_calendar');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for confirmed_ipo_calendar');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for confirmed_ipo_calendar');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for confirmed_ipo_calendar');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for confirmed_ipo_calendar');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for confirmed_ipo_calendar');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for confirmed_ipo_calendar');
        log('✓ confirmed_ipo_calendar refs validated');
    } else {
        throw new Error('Assertion failed: refsIPO array is empty.');
    }

    log('✅ Confirmed IPO Filingevents make*Node tests passed');

    // Now run direct get* function tests
    testGetConfirmedIPOFilingevents();

    return 0;
}

main();
