const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');
const { makeStockKlineNode, getStockKline } = require('@arrays/data/stock/spot/ohlcv:v1.0.0');

// Simple assertion helper to mimic example.js style
function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

function testGraphAndNodeIntegration() {
  // Offline formatting test (deterministic)
  const nodeCfg = makeStockKlineNode({
    ticker: 'AAPL',
    start_time: 1723000000,
    end_time: 1723100000,
    interval: '1h',
    limit: 10,
  });
  // Override input to avoid network dependency; matches getStockKline response shape
  nodeCfg.inputs.stock_kline_raw = () => ({
    success: true,
    response: {
      data: [
        {
          time_open: 1723008800,
          time_close: 1723012400,
          time_period_start: '1723008800',
          time_period_end: '1723012400',
          price_open: 180.1,
          price_close: 181.2,
          price_low: 179.9,
          price_high: 182.0,
          trades_count: 1200,
          volume_traded: 345678,
        },
        {
          time_open: 1723012400,
          time_close: 1723016000,
          time_period_start: '1723012400',
          time_period_end: '1723016000',
          price_open: 181.2,
          price_close: 183.5,
          price_low: 180.8,
          price_high: 184.0,
          trades_count: 1100,
          volume_traded: 289012,
        },
      ],
      count: 2,
      cursor: '',
    },
  });

  const g = new Graph(jagentId);
  g.addNode('stock_kline_offline', nodeCfg);
  g.run();

  const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'stock_kline_offline', 'ohlcv', { last: '10' }), g.store);
  ts.init();
  if (!Array.isArray(ts.data) || ts.data.length < 2) throw new Error('Expected at least 2 OHLCV records');
  const latest = ts.data[0];
  const older = ts.data[1];
  if (typeof latest.date !== 'number') throw new Error('date must be number (ms)');
  if (typeof latest.open !== 'number') throw new Error('open must be number');
  if (typeof latest.high !== 'number') throw new Error('high must be number');
  if (typeof latest.low !== 'number') throw new Error('low must be number');
  if (typeof latest.time_period_start !== 'string') throw new Error('time_period_start must be string');
  if (typeof latest.time_period_end !== 'string') throw new Error('time_period_end must be string');
  if (typeof latest.close !== 'number') throw new Error('close must be number');
  if (typeof latest.volume !== 'number') throw new Error('volume must be number');
  if (typeof latest.trades_count !== 'number') throw new Error('trades_count must be number');
  if (!(latest.date > older.date)) throw new Error('TimeSeries must be date-descending when read');

  // Validate refs metadata for ohlcv output
  const refsOhlcv = g.getRefsForOutput('stock_kline_offline', 'ohlcv');
  if (refsOhlcv.length > 0) {
    const ref = refsOhlcv[0];
    const expected = {
      id: '@arrays/data/stock/spot/ohlcv/getStockKline',
      module_name: '@arrays/data/stock/spot/ohlcv',
      module_display_name: 'Stock Market Price',
      sdk_name: 'getStockKline',
      sdk_display_name: 'Stock Market Price',
      source_name: 'Polygon',
      source: 'https://polygon.io/docs/rest/stocks/aggregates/custom-bars',
    };

    if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for ohlcv');
    if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for ohlcv');
    if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for ohlcv');
    if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for ohlcv');
    if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for ohlcv');
    if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for ohlcv');
    if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for ohlcv');
    console.log('✓ ohlcv refs validated');
  } else {
    throw new Error('Assertion failed: refsOhlcv array is empty.');
  }

  // Online API test using real gateway data for NVDA
  const nodeCfgOnline = makeStockKlineNode({
    ticker: 'NVDA',
    start_time: 1758807000,
    end_time: 1758916800,
    interval: '1h',
    limit: 200,
  });
  const g2 = new Graph(jagentId);
  g2.addNode('stock_kline_online', nodeCfgOnline);
  g2.run();
  const ts2 = new TimeSeries(new TimeSeriesUri(jagentId, 'stock_kline_online', 'ohlcv', { last: '200' }), g2.store);
  ts2.init();
  if (!Array.isArray(ts2.data)) throw new Error('online data must be an array');
  if (ts2.data.length > 0) {
    const r = ts2.data[0];
    if (typeof r.date !== 'number') throw new Error('online.date must be number (ms)');
    if (typeof r.open !== 'number') throw new Error('online.open must be number');
    if (typeof r.high !== 'number') throw new Error('online.high must be number');
    if (typeof r.low !== 'number') throw new Error('online.low must be number');
    if (typeof r.time_period_start !== 'string') throw new Error('online.time_period_start must be string');
    if (typeof r.time_period_end !== 'string') throw new Error('online.time_period_end must be string');
    if (typeof r.close !== 'number') throw new Error('online.close must be number');
    if (typeof r.volume !== 'number') throw new Error('online.volume must be number');
    if (typeof r.trades_count !== 'number') throw new Error('online.trades_count must be number');
    if (ts2.data.length > 1 && !(ts2.data[0].date > ts2.data[1].date)) throw new Error('Online TimeSeries must be date-descending when read');
  }
}

function testGetStockKlineDirect() {
  console.log('\n=== Testing getStockKline Direct Function ===');

  let totalTests = 0;
  let passedTests = 0;
  function runTest(name, fn) {
    totalTests++;
    try {
      fn();
      console.log(`✅ ${name}`);
      passedTests++;
    } catch (e) {
      console.log(`❌ ${name}: ${e.message}`);
    }
  }

  const INTERVALS = [
    '1min', '2min', '3min', '5min', '10min', '15min', '30min', '45min',
    '1h', '2h', '4h', '1d', '1w', '1m', '3m', '6m'
  ];

  // Use example window from doc: Aug 1, 2025 - Aug 8, 2025 (UTC)
  const START = Math.floor(Date.UTC(2025, 7, 1, 0, 0, 0) / 1000);
  const END = Math.floor(Date.UTC(2025, 7, 8, 0, 0, 0) / 1000);

  // Happy Path: iterate all interval values
  for (const interval of INTERVALS) {
    runTest(`happy path interval=${interval}`, () => {
      const res = getStockKline({
        ticker: 'AAPL',
        start_time: START,
        end_time: END,
        interval,
        limit: 10,
      });
      assert(res && typeof res === 'object', 'Result must be an object');
      assert(typeof res.success === 'boolean', 'success must be boolean');
      if (res.success) {
        assert(res.response && typeof res.response === 'object', 'response must be object when success');
        assert(Array.isArray(res.response.data), 'response.data must be array');
        assert(typeof res.response.count === 'number', 'response.count must be number');
        if (res.response.data.length > 0) {
          const c = res.response.data[0];
          assert(typeof c.time_open === 'number', 'time_open must be number');
          assert(typeof c.time_close === 'number', 'time_close must be number');
          assert(typeof c.time_period_start === 'string', 'time_period_start must be string');
          assert(typeof c.time_period_end === 'string', 'time_period_end must be string');
          assert(typeof c.price_open === 'number', 'price_open must be number');
          assert(typeof c.price_close === 'number', 'price_close must be number');
          assert(typeof c.price_low === 'number', 'price_low must be number');
          assert(typeof c.price_high === 'number', 'price_high must be number');
          assert(typeof c.trades_count === 'number', 'trades_count must be number');
          assert(typeof c.volume_traded === 'number', 'volume_traded must be number');
          if (res.response.data.length > 1) {
            // Newest first as per doc
            assert(
              res.response.data[0].time_open >= res.response.data[1].time_open,
              'data should be sorted newest-first by time_open'
            );
          }
        }
      }
    });
  }

  // Boundary: limit at minimum and maximum
  runTest('boundary limit=5000 (min)', () => {
    const r = getStockKline({
      ticker: 'AAPL', start_time: START, end_time: END, interval: '1h', limit: 5000,
    });
    assert(r && typeof r === 'object', 'result object expected');
  });
  runTest('boundary limit=10000 (max)', () => {
    const r = getStockKline({
      ticker: 'AAPL', start_time: START, end_time: END, interval: '1h', limit: 10000,
    });
    assert(r && typeof r === 'object', 'result object expected');
  });
  runTest('boundary limit default (omitted)', () => {
    const r = getStockKline({
      ticker: 'AAPL', start_time: START, end_time: END, interval: '1h',
    });
    assert(r && typeof r === 'object', 'result object expected');
  });

  // Boundary: minimal valid window (end_time just after start_time)
  runTest('boundary minimal valid time window', () => {
    const r = getStockKline({
      ticker: 'AAPL', start_time: START, end_time: START + 1, interval: '1min', limit: 5000,
    });
    assert(r && typeof r === 'object', 'result object expected');
  });

  // Cursor handling: empty string should be acceptable
  runTest('cursor empty string', () => {
    const r = getStockKline({
      ticker: 'AAPL', start_time: START, end_time: END, interval: '1h', limit: 5000, cursor: ''
    });
    assert(r && typeof r === 'object', 'result object expected');
  });

  // Error Handling / Special Values
  runTest('invalid interval value', () => {
    try {
      getStockKline({ ticker: 'AAPL', start_time: START, end_time: END, interval: '7min', limit: 5000 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(
        (e && e.message && (e.message.toLowerCase().includes('invalid') || e.message.toLowerCase().includes('error'))),
        'Should handle invalid interval'
      );
    }
  });
  runTest('invalid limit below range (4999)', () => {
    try {
      getStockKline({ ticker: 'AAPL', start_time: START, end_time: END, interval: '1h', limit: 4999 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(
        (e && e.message && (e.message.toLowerCase().includes('invalid') || e.message.toLowerCase().includes('error'))),
        'Should handle invalid limit < 5000'
      );
    }
  });
  runTest('invalid limit above range (10001)', () => {
    try {
      getStockKline({ ticker: 'AAPL', start_time: START, end_time: END, interval: '1h', limit: 10001 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(
        (e && e.message && (e.message.toLowerCase().includes('invalid') || e.message.toLowerCase().includes('error'))),
        'Should handle invalid limit > 10000'
      );
    }
  });
  runTest('invalid time window (end_time <= start_time)', () => {
    try {
      getStockKline({ ticker: 'AAPL', start_time: START, end_time: START, interval: '1h', limit: 5000 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(
        (e && e.message && (e.message.toLowerCase().includes('after') || e.message.toLowerCase().includes('error') || e.message.toLowerCase().includes('invalid'))),
        'Should handle invalid time ordering'
      );
    }
  });
  runTest('ticker is empty string', () => {
    try {
      getStockKline({ ticker: '', start_time: START, end_time: END, interval: '1h', limit: 5000 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert((e && e.message && (e.message.toLowerCase().includes('ticker') || e.message.toLowerCase().includes('invalid') || e.message.toLowerCase().includes('error'))), 'Should reject empty ticker');
    }
  });
  runTest('ticker is undefined', () => {
    try {
      getStockKline({ start_time: START, end_time: END, interval: '1h', limit: 5000 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert((e && e.message && (e.message.toLowerCase().includes('ticker') || e.message.toLowerCase().includes('invalid') || e.message.toLowerCase().includes('error'))), 'Should reject undefined ticker');
    }
  });
  runTest('ticker is null', () => {
    try {
      getStockKline({ ticker: null, start_time: START, end_time: END, interval: '1h', limit: 5000 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert((e && e.message && (e.message.toLowerCase().includes('ticker') || e.message.toLowerCase().includes('invalid') || e.message.toLowerCase().includes('error'))), 'Should reject null ticker');
    }
  });

  // Print test summary
  console.log('\n=== getStockKline Test Summary ===');
  console.log(`Total tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${totalTests - passedTests}`);
  console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
  if (passedTests !== totalTests) {
    console.log('⚠️  Some getStockKline tests failed. Check logs above.');
  }
}

function testCursorHandling() {
  const START = Math.floor(Date.UTC(2025, 7, 1, 0, 0, 0) / 1000);
  const END = Math.floor(Date.UTC(2025, 7, 8, 0, 0, 0) / 1000);
  console.log('\n=== Testing cursor handling ===');
  const res = getStockKline({
    ticker: 'AAPL',
    start_time: START,
    end_time: END,
    interval: '1min',
    limit: 100,
    cursor: '',
  });
  assert(res && typeof res === 'object', 'result object expected');
  assert(res.response && typeof res.response === 'object', 'response must be object when success');
  assert(Array.isArray(res.response.data), 'response.data must be array');
  assert(typeof res.response.count === 'number', 'response.count must be number');
  assert(res.response.cursor != '', 'response.cursor must beg not empty string');
  if (res.response.data.length > 0) {
    const c = res.response.data[0];
    assert(typeof c.time_open === 'number', 'time_open must be number');
    assert(typeof c.time_close === 'number', 'time_close must be number');
    assert(typeof c.time_period_start === 'string', 'time_period_start must be string');
    assert(typeof c.time_period_end === 'string', 'time_period_end must be string');
    assert(typeof c.price_open === 'number', 'price_open must be number');
    assert(typeof c.price_close === 'number', 'price_close must be number');
    assert(typeof c.price_low === 'number', 'price_low must be number');
    assert(typeof c.price_high === 'number', 'price_high must be number');
  }
}


function main() {
  testGraphAndNodeIntegration();
  testGetStockKlineDirect();
  testCursorHandling();
  return 0;
}

main();
