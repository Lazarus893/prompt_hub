const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata (from tool.json) for getStockKline
const getStockKlineRef = {
    id: '@arrays/data/stock/spot/ohlcv/getStockKline',
    module_name: '@arrays/data/stock/spot/ohlcv',
    module_display_name: 'Stock Market Price',
    sdk_name: 'getStockKline',
    sdk_display_name: 'Stock Market Price',
    source_name: 'Polygon',
    source: 'https://polygon.io/docs/rest/stocks/aggregates/custom-bars',
};

// Base description (summary from doc) for getStockKline
// Doc summary: Fetch adjusted candlestick (OHLCV) data for a stock or ETF ticker within a time range, supporting granular intervals and cursor-based pagination. Newest first.
const getStockKlineBaseDesc = 'Fetch adjusted OHLCV for a stock or ETF within a time range (newest first)';

// Dynamic description builder for getStockKline based on provided params
function buildGetStockKlineCallDescription(actualParams = {}) {
    const parts = [getStockKlineBaseDesc];

    // Ticker context
    if (actualParams.ticker) {
        parts.push(`for ${actualParams.ticker}`);
    }

    // Interval context
    if (actualParams.interval) {
        parts.push(`at ${actualParams.interval}`);
    }

    // Collect filters/details
    const details = [];

    if (actualParams.start_time && actualParams.end_time) {
        details.push(`Time: ${actualParams.start_time} -> ${actualParams.end_time}`);
    } else if (actualParams.start_time) {
        details.push(`From: ${actualParams.start_time}`);
    } else if (actualParams.end_time) {
        details.push(`Until: ${actualParams.end_time}`);
    }

    if (typeof actualParams.limit === 'number' && actualParams.limit !== 5000) {
        details.push(`Limit: ${actualParams.limit}`);
    }

    if (actualParams.cursor) {
        details.push(`Cursor: ${actualParams.cursor}`);
    }

    if (details.length > 0) {
        parts.push(`(${details.join(', ')})`);
    }

    return parts.join(' ').trim();
}

// Helper to compose reference with a dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getStockKline(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/kline';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    const originalData = r.json();
    return {
        success: originalData.success,
        response: {
            ...originalData.response,
            data: originalData?.response?.data || [],
            cursor: originalData?.response?.cursor || ""
        },
    };
}

function makeStockKlineNode(params) {
    return {
        inputs: {
            stock_kline_raw: () => getStockKline(params),
        },
        outputs: {
            ohlcv: {
                name: 'stock_ohlcv',
                description: 'Stock or ETF adjusted candlestick data for the requested ticker and interval',
                fields: [
                    { name: 'date', type: 'number', description: 'ms since epoch (UTC), beginning of the interval' },
                    { name: 'open', type: 'number', description: 'open price of the interval' },
                    { name: 'high', type: 'number', description: 'high price of the interval' },
                    { name: 'low', type: 'number', description: 'low price of the interval' },
                    { name: 'time_period_start', type: 'string', description: 'ISO 8601, e.g. 2024-08-07T23:56:00Z' },
                    { name: 'time_period_end', type: 'string', description: 'ISO 8601, e.g. 2024-08-08T00:01:00Z' },
                    { name: 'close', type: 'number', description: 'close price of the interval' },
                    { name: 'volume', type: 'number', description: 'traded volume of the interval' },
                    { name: 'trades_count', type: 'number', description: 'number of trades within the interval' },
                ],
                ref: createReferenceWithTitle(getStockKlineRef, params, buildGetStockKlineCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.stock_kline_raw;
            const arr = raw && raw.response && Array.isArray(raw.response.data) ? raw.response.data : [];
            const mapped = arr
                .map((d) => ({
                    date: typeof d.time_open === 'number' ? d.time_open * 1000 : undefined,
                    open: d.price_open,
                    high: d.price_high,
                    low: d.price_low,
                    time_period_start: d.time_period_start != null ? String(d.time_period_start) : undefined,
                    time_period_end: d.time_period_end != null ? String(d.time_period_end) : undefined,
                    close: d.price_close,
                    volume: d.volume_traded,
                    trades_count: d.trades_count,
                }))
                .filter((r) => typeof r.date === 'number');

            // Deduplicate by date (keep last), then sort descending by date
            const dedup = new Map();
            for (const r of mapped) dedup.set(r.date, r);
            const out = Array.from(dedup.values()).sort((a, b) => b.date - a.date);

            return { ohlcv: out };
        },
    };
}

// Collect all reference metadata objects defined in this module
function getRefs() {
    return [
        getStockKlineRef,
    ];
}

module.exports = {
    getStockKline,
    makeStockKlineNode,
    getRefs,
};