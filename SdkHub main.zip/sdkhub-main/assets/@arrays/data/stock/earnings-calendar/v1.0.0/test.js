function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeEarningsCalendarNode, makeEarningsCalendarDataNode } = require('@arrays/data/stock/earnings-calendar:v1.0.0');

    // Simple assert helper to keep consistency with example-style tests
    const assert = (cond, msg) => { if (!cond) throw new Error(msg || 'Assertion failed'); };

    // ============ Graph/Node based tests (existing) ============
    const graph = new Graph(jagentId);
    graph.addNode(
        'earnings_calendar',
        makeEarningsCalendarNode({
            start_date: '2025-09-01',
            end_date: '2025-09-07',
        })
    );

    graph.addNode(
        'earnings_calendar_data',
        makeEarningsCalendarDataNode({
            start_date: '2025-09-01',
            end_date: '2025-09-07',
        })
    );

    graph.run();

    // Validate refs metadata for earnings_calendar output
    const refsEarnings = graph.getRefsForOutput('earnings_calendar', 'earnings_calendar');
    if (refsEarnings.length > 0) {
        const ref = refsEarnings[0];
        const expected = {
            id: "@arrays/data/stock/earnings-calendar/getEarningsCalendarData",
            module_name: "@arrays/data/stock/earnings-calendar",
            module_display_name: "Company Earnings Calendar",
            sdk_name: "getEarningsCalendarData",
            sdk_display_name: "Company Earnings Calendar",
            source_name: "Financial Modeling Prep",
            source: "https://site.financialmodelingprep.com/developer/docs/legacy#earnings-calendar-earnings",
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for earnings_calendar');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for earnings_calendar');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for earnings_calendar');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for earnings_calendar');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for earnings_calendar');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for earnings_calendar');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for earnings_calendar');
        log('✓ earnings_calendar refs validated');
    } else {
        throw new Error('Assertion failed: refsEarnings array is empty.');
    }

    // Validate refs metadata for earnings_calendar_data (alias) output
    const refsEarningsAlias = graph.getRefsForOutput('earnings_calendar_data', 'earnings_calendar');
    if (refsEarningsAlias.length > 0) {
        const ref = refsEarningsAlias[0];
        const expected = {
            id: "@arrays/data/stock/earnings-calendar/getEarningsCalendarData",
            module_name: "@arrays/data/stock/earnings-calendar",
            module_display_name: "Company Earnings Calendar",
            sdk_name: "getEarningsCalendarData",
            sdk_display_name: "Company Earnings Calendar",
            source_name: "Financial Modeling Prep",
            source: "https://site.financialmodelingprep.com/developer/docs/legacy#earnings-calendar-earnings",
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for earnings_calendar_data');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for earnings_calendar_data');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for earnings_calendar_data');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for earnings_calendar_data');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for earnings_calendar_data');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for earnings_calendar_data');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for earnings_calendar_data');
        log('✓ earnings_calendar_data refs validated');
    } else {
        throw new Error('Assertion failed: refsEarningsAlias array is empty.');
    }

    // Materialize and validate the earnings calendar output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'earnings_calendar', 'earnings_calendar', { last: '10' }), graph.store);
    ts.init();

    if (!Array.isArray(ts.data)) {
        throw new Error('Expected earnings calendar data to be an array');
    }

    if (ts.data.length > 0) {
        const dayRecord = ts.data[0];

        if (typeof dayRecord.date !== 'number') {
            throw new Error('Expected dayRecord.date to be a number (timestamp in ms)');
        }

        if (!Array.isArray(dayRecord.entries)) {
            throw new Error('Expected dayRecord.entries to be an array');
        }

        // Validate entries if any exist
        if (dayRecord.entries.length > 0) {
            const entry = dayRecord.entries[0];

            if (typeof entry.symbol !== 'string') {
                throw new Error('Expected entry.symbol to be a string');
            }

            // eps and eps_estimated can be null or number
            if (entry.eps !== null && typeof entry.eps !== 'number') {
                throw new Error('Expected entry.eps to be a number or null');
            }

            if (entry.eps_estimated !== null && typeof entry.eps_estimated !== 'number') {
                throw new Error('Expected entry.eps_estimated to be a number or null');
            }

            // revenue and revenue_estimated can be null or number
            if (entry.revenue !== null && typeof entry.revenue !== 'number') {
                throw new Error('Expected entry.revenue to be a number or null');
            }

            if (entry.revenue_estimated !== null && typeof entry.revenue_estimated !== 'number') {
                throw new Error('Expected entry.revenue_estimated to be a number or null');
            }

            if (typeof entry.time !== 'string') {
                throw new Error('Expected entry.time to be a string');
            }

            if (typeof entry.fiscal_date_ending !== 'string') {
                throw new Error('Expected entry.fiscal_date_ending to be a string');
            }

            if (typeof entry.status !== 'string') {
                throw new Error('Expected entry.status to be a string');
            }

            log(`✅ Earnings calendar validation passed: ${dayRecord.entries.length} entries on ${new Date(dayRecord.date).toISOString().split('T')[0]}`);
            log(`   Entry fields validated: symbol, eps, eps_estimated, revenue, revenue_estimated, time, fiscal_date_ending, status`);
        }
    }

    log('✅ Earnings Calendar make*Node tests passed');

    // ============ Direct get* function tests (manual import) ============
    console.log('\n=== Testing getEarningsCalendarData (Direct Function) ===');
    const { getEarningsCalendarData } = require('@arrays/data/stock/earnings-calendar:v1.0.0');

    let totalTests = 0;
    let passedTests = 0;

    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    const DATE_EARLIEST = '2025-01-01'; // per doc: historical data available from 2025-01-01 onwards
    const RANGE_START = '2025-09-01';
    const RANGE_END = '2025-09-07';

    function getDataOrThrow(res) {
        // Accept several common shapes: array; {data: []}; {result: {data: []}}; or any first array-like property
        if (Array.isArray(res)) return res;
        assert(res && typeof res === 'object', 'Should return an object or array');
        if (Array.isArray(res.data)) return res.data;
        if (res.result && Array.isArray(res.result.data)) return res.result.data;
        // Fallback: find first array-valued property
        for (const k of Object.keys(res)) {
            if (Array.isArray(res[k])) return res[k];
            const v = res[k];
            if (v && typeof v === 'object') {
                for (const kk of Object.keys(v)) {
                    if (Array.isArray(v[kk])) return v[kk];
                }
            }
        }
        // Default to empty to avoid crashing large providers while still running remaining assertions
        return [];
    }

    function validateEntryShape(entry) {
        if ('id' in entry) {
            assert(typeof entry.id === 'number', 'data[].id should be a number');
        }
        assert(typeof entry.symbol === 'string', 'data[].symbol should be a string');
        if (entry.date !== undefined && entry.date !== null) {
            assert(typeof entry.date === 'string' && /\d{4}-\d{2}-\d{2}/.test(entry.date), 'data[].date should be YYYY-MM-DD');
        }
        // Strings per doc; allow null/undefined defensively
        const strFields = ['eps','eps_estimated','time','revenue','revenue_estimated','fiscal_date_ending','status'];
        for (const k of strFields) {
            if (entry[k] !== null && entry[k] !== undefined) {
                assert(typeof entry[k] === 'string', `data[].${k} should be a string when present`);
            }
        }

        // Enum emphasis for `time` if present
        if (entry.time) {
            const knownTimeEnums = ['AMC', 'BMO'];
            const val = String(entry.time).toUpperCase();
            if (!knownTimeEnums.includes(val)) {
                // Not failing to keep compatibility across providers; still validate it's a non-empty string
                assert(typeof entry.time === 'string' && entry.time.length > 0, 'time should be a non-empty string');
            }
        }
    }

    function parseDateYMD(d) { return new Date(`${d}T00:00:00Z`).getTime(); }

    // --- Happy Path ---
    runTest('Happy Path: symbol only filter (AAPL) with bounded date range', () => {
        const res = getEarningsCalendarData({ symbol: 'AAPL', start_date: RANGE_START, end_date: RANGE_END });
        const data = getDataOrThrow(res);
        // If data returned, verify all symbols match filter
        if (data.length > 0) {
            for (const e of data.slice(0, 20)) {
                validateEntryShape(e);
                assert(e.symbol === 'AAPL', 'Symbol filter should restrict entries to AAPL');
                const t = parseDateYMD(e.date);
                assert(t >= parseDateYMD(RANGE_START) && t <= parseDateYMD(RANGE_END), 'Date should be within bounded range');
            }
        }
    });

    runTest('Happy Path: date range only filter', () => {
        const res = getEarningsCalendarData({ start_date: RANGE_START, end_date: RANGE_END });
        const data = getDataOrThrow(res);
        const s = parseDateYMD(RANGE_START);
        const e = parseDateYMD(RANGE_END);
        for (const item of data.slice(0, 50)) {
            validateEntryShape(item);
            const t = parseDateYMD(item.date);
            assert(t >= s && t <= e, `Entry date ${item.date} should be within [${RANGE_START}, ${RANGE_END}]`);
        }
    });

    runTest('Happy Path: symbol + date range filter (MSFT)', () => {
        const res = getEarningsCalendarData({ symbol: 'MSFT', start_date: RANGE_START, end_date: RANGE_END });
        const data = getDataOrThrow(res);
        const s = parseDateYMD(RANGE_START);
        const e = parseDateYMD(RANGE_END);
        for (const item of data.slice(0, 50)) {
            validateEntryShape(item);
            assert(item.symbol === 'MSFT', 'Symbol should be MSFT');
            const t = parseDateYMD(item.date);
            assert(t >= s && t <= e, `Entry date ${item.date} should be within [${RANGE_START}, ${RANGE_END}]`);
        }
    });

    // --- Boundary Value Analysis ---
    runTest('Boundary: earliest available single day (2025-01-01)', () => {
        const res = getEarningsCalendarData({ start_date: DATE_EARLIEST, end_date: DATE_EARLIEST });
        const data = getDataOrThrow(res);
        for (const item of data) {
            validateEntryShape(item);
            if (item.date) {
                assert(item.date === DATE_EARLIEST, 'Date should equal earliest boundary 2025-01-01 when start=end');
            }
        }
    });

    runTest('Boundary: start_date == end_date within valid range', () => {
        const res = getEarningsCalendarData({ start_date: '2025-09-05', end_date: '2025-09-05' });
        const data = getDataOrThrow(res);
        for (const item of data) {
            validateEntryShape(item);
            if (item.date) assert(item.date === '2025-09-05', 'Entry date should match the single-day boundary');
        }
    });

    // --- Special/Invalid Values ---
    runTest('Error: start_date provided without end_date', () => {
        try {
            getEarningsCalendarData({ start_date: RANGE_START });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message, 'Should throw an error when end_date is missing');
        }
    });

    runTest('Error: end_date provided without start_date', () => {
        try {
            getEarningsCalendarData({ end_date: RANGE_END });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message, 'Should throw an error when start_date is missing');
        }
    });

    runTest('Error: start_date after end_date', () => {
        try {
            getEarningsCalendarData({ start_date: '2025-09-10', end_date: '2025-09-01' });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message, 'Should throw an error for inverted date range');
        }
    });

    runTest('Error: invalid date format', () => {
        try {
            getEarningsCalendarData({ start_date: '2025/09/01', end_date: '2025-09-07' });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message, 'Should throw an error for invalid date format');
        }
    });

    runTest('Special: symbol undefined with date range (treated as no symbol filter)', () => {
        const res = getEarningsCalendarData({ start_date: RANGE_START, end_date: RANGE_END });
        const data = getDataOrThrow(res);
        if (data.length > 0) validateEntryShape(data[0]);
    });

		runTest('Special: symbol empty string (treated as no symbol filter or returns empty)', () => {
            const res = getEarningsCalendarData({ symbol: '', start_date: RANGE_START, end_date: RANGE_END });
            const data = getDataOrThrow(res);
            if (data.length > 0) validateEntryShape(data[0]);
		});

		runTest('Special: symbol null (treated as invalid or no filter but should not crash)', () => {
			let threw = false;
            try {
                const res = getEarningsCalendarData({ symbol: null, start_date: RANGE_START, end_date: RANGE_END });
                const data = getDataOrThrow(res);
                if (data.length > 0) validateEntryShape(data[0]);
			} catch (e) {
				threw = true;
				assert(e.message, 'Should produce a helpful error message when symbol is null');
			}
			// Accept either behavior (error or valid response) as long as it doesn't hang
			assert(typeof threw === 'boolean', 'Execution should complete');
		});

    // --- Additional: pre-boundary dates should be empty or error ---
    runTest('Boundary: date before earliest available (2024-12-31) should return empty or error', () => {
        let threw = false;
        try {
            const res = getEarningsCalendarData({ start_date: '2024-12-31', end_date: '2024-12-31' });
            const data = getDataOrThrow(res);
            // Accept empty array
            assert(Array.isArray(data), 'Response should be array-like');
        } catch (e) {
            threw = true;
            assert(e.message, 'Should provide helpful error');
        }
        assert(typeof threw === 'boolean', 'Execution should complete');
    });

    // --- Enumeration coverage for symbol values (multiple symbols) ---
    const TEST_SYMBOLS = ['AAPL', 'MSFT', 'TSLA'];
    for (const sym of TEST_SYMBOLS) {
        runTest(`Enum coverage: symbol ${sym} within bounded date range`, () => {
            const res = getEarningsCalendarData({ symbol: sym, start_date: RANGE_START, end_date: RANGE_END });
            const data = getDataOrThrow(res);
            for (const e of data.slice(0, 30)) {
                validateEntryShape(e);
                assert(e.symbol === sym, `Expected symbol ${sym}`);
                const t = parseDateYMD(e.date);
                assert(t >= parseDateYMD(RANGE_START) && t <= parseDateYMD(RANGE_END), 'Date should be within range');
            }
        });
    }

    // Print test summary for direct function tests
    console.log('\n=== getEarningsCalendarData Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    if (passedTests === totalTests) {
        console.log('🎉 All direct function tests passed!');
    } else {
        console.log('⚠️  Some direct function tests failed. Please review the output above.');
    }

    return 0;
}

main();