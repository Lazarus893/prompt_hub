const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for SDK function getEarningsCalendarData
const getEarningsCalendarDataRef = {
    id: "@arrays/data/stock/earnings-calendar/getEarningsCalendarData",
    module_name: "@arrays/data/stock/earnings-calendar",
    module_display_name: "Company Earnings Calendar",
    sdk_name: "getEarningsCalendarData",
    sdk_display_name: "Company Earnings Calendar",
    source_name: "Financial Modeling Prep",
    source: "https://site.financialmodelingprep.com/developer/docs/legacy#earnings-calendar-earnings",
};

function getEarningsCalendarData(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/earnings-calendar';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function toMs(value) {
    if (!value) {
        return null;
    }
    const parsed = Date.parse(value);
    return Number.isNaN(parsed) ? null : parsed;
}

function toNumber(value) {
    if (value == null || value === '') {
        return null;
    }
    const num = Number(value);
    return Number.isNaN(num) ? null : num;
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function makeEarningsCalendarNode(params) {
    return {
        inputs: {
            earnings_raw: () => getEarningsCalendarData(params),
        },
        outputs: {
            earnings_calendar: {
                name: 'earnings_calendar',
                description: 'Daily earnings calendar (one record per date).',
                ref: createReferenceWithTitle(getEarningsCalendarDataRef, params, buildGetEarningsCalendarDataCallDescription),
                fields: [
                    { name: 'date', type: 'number', description: 'earnings date ms (UTC day start)' },
                    {
                        name: 'entries',
                        type: 'array',
                        description: 'all earnings entries on this date',
                        fields: [
                            { name: 'symbol', type: 'string', description: 'stock symbol' },
                            { name: 'eps', type: 'number', description: 'actual EPS' },
                            { name: 'eps_estimated', type: 'number', description: 'estimated EPS' },
                            { name: 'revenue', type: 'number', description: 'actual revenue' },
                            { name: 'revenue_estimated', type: 'number', description: 'estimated revenue' },
                            { name: 'time', type: 'string', description: 'earnings call time' },
                            { name: 'fiscal_date_ending', type: 'string', description: 'fiscal period end' },
                            { name: 'status', type: 'string', description: 'earnings status' },
                        ],
                    },
                ],
            },
        },
        run: (inputs) => {
            const raw = inputs.earnings_raw;

            if (raw?.error) {
                throw new Error(`API Error: ${raw.error.message || 'Unknown error'}`);
            }

            if (!raw?.data) {
                return { earnings_calendar: [] };
            }

            if (!Array.isArray(raw.data)) {
                throw new Error('Invalid API response: data is not an array');
            }

            // Normalize rows and group by date (ms, UTC day start)
            const byDate = new Map();
            for (const item of raw.data) {
                const date = toMs(item.date);
                if (date == null) continue;

                const normalized = {
                    symbol: item.symbol,
                    eps: toNumber(item.eps),
                    eps_estimated: toNumber(item.eps_estimated),
                    revenue: toNumber(item.revenue),
                    revenue_estimated: toNumber(item.revenue_estimated),
                    time: item.time,
                    fiscal_date_ending: item.fiscal_date_ending,
                    status: item.status,
                };

                if (!byDate.has(date)) byDate.set(date, []);
                byDate.get(date).push(normalized);
            }

            const series = Array.from(byDate.entries())
                .sort((a, b) => a[0] - b[0])
                .map(([date, entries]) => ({
                    date,
                    entries,
                }));

            return { earnings_calendar: series };
        },
    };
}

function makeEarningsCalendarDataNode(params) {
    return makeEarningsCalendarNode(params);
}

// Internal-only description helpers (do not export)
const getEarningsCalendarDataBaseFuncDesc = "Get earnings calendar";
function buildGetEarningsCalendarDataCallDescription(actualParams = {}) {
  const parts = [getEarningsCalendarDataBaseFuncDesc];
  if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
  const filters = [];
  if (actualParams.start_date && actualParams.end_date) filters.push(`Date: ${actualParams.start_date} to ${actualParams.end_date}`);
  else if (actualParams.start_date) filters.push(`From: ${actualParams.start_date}`);
  else if (actualParams.end_date) filters.push(`Until: ${actualParams.end_date}`);
  if (filters.length > 0) parts.push(`(${filters.join(', ')})`);
  return parts.join(' ').trim();
}

// Export all Ref-suffixed objects
function getRefs() {
    return [
        getEarningsCalendarDataRef,
    ];
}

module.exports = {
    getEarningsCalendarData,
    makeEarningsCalendarNode,
    makeEarningsCalendarDataNode,
    getRefs,
};