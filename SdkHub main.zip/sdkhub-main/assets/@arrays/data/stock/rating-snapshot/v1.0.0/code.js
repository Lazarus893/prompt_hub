const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getRatingsSnapshot based on tool.json
const getRatingsSnapshotRef = {
	id: '@arrays/data/stock/rating-snapshot/getRatingsSnapshot',
	module_name: '@arrays/data/stock/rating-snapshot',
	module_display_name: 'Analyst Rating Real-Time Data',
	sdk_name: 'getRatingsSnapshot',
	sdk_display_name: 'Analyst Rating Real-Time Data',
	source_name: 'Financial Modeling Prep',
	source: 'https://site.financialmodelingprep.com/developer/docs/stable/ratings-snapshot',
};

// Base description and dynamic call description builder for getRatingsSnapshot (internal only)
const getRatingsSnapshotBaseFuncDesc = 'Get current stock ratings snapshot';

function buildGetRatingsSnapshotCallDescription(actualParams = {}) {
    const parts = [getRatingsSnapshotBaseFuncDesc];

    // Attach symbol context if provided (required by doc, but optional in builder)
    if (actualParams && actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }

    // Optional filters
    const filters = [];
    if (actualParams && actualParams.limit != null) {
        const n = Number(actualParams.limit);
        if (!Number.isNaN(n) && n !== 10) {
            filters.push(`Limit: ${n}`);
        }
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getRatingsSnapshot(params) {
	// Parameter validation
	if (!params || typeof params !== 'object') {
		return {
			success: false,
			response: {
				ratings: [],
				limit: 0,
				error: 'Invalid parameters: params must be an object'
			}
		};
	}

	const symbol = params.symbol;
	if (!symbol || typeof symbol !== 'string' || symbol.trim() === '') {
		return {
			success: false,
			response: {
				ratings: [],
				limit: 0,
				error: 'Invalid parameters: symbol is required and must be a non-empty string'
			}
		};
	}

	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/ratings-snapshot';
	const keyValuePairs = Object.keys(params || {}).map((key) => {
		const value = params[key];
		return encodeURIComponent(key) + '=' + encodeURIComponent(value);
	});
	const queryString = keyValuePairs.join('&');
	const fullUrl = `${baseUrl}?${queryString}`;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

function makeRatingsSnapshotNode(params) {
	return {
		inputs: {
			ratings_snapshot_raw: () => getRatingsSnapshot(params),
		},
		outputs: {
			current_ratings_snapshot: {
				name: 'current_ratings_snapshot',
				description: 'Current stock ratings snapshot with ratings list',
				fields: [
					{ name: 'date', type: 'number', description: 'snapshot time ms (UTC)' },
					{ name: 'symbols', type: 'string', description: 'symbols filter for this snapshot' },
					{ name: 'limit', type: 'number', description: 'limit requested' },
					{
						name: 'ratings',
						type: 'array',
						description: 'current rating records',
						fields: [
							{ name: 'symbol', type: 'string', description: 'stock symbol' },
							{ name: 'rating', type: 'string', description: 'A/B/C letter rating' },
							{ name: 'overallScore', type: 'number', description: 'overall score 0-100' },
							{ name: 'discountedCashFlowScore', type: 'number', description: 'DCF score' },
							{ name: 'returnOnEquityScore', type: 'number', description: 'ROE score' },
							{ name: 'returnOnAssetsScore', type: 'number', description: 'ROA score' },
							{ name: 'debtToEquityScore', type: 'number', description: 'debt to equity score' },
							{ name: 'priceToEarningsScore', type: 'number', description: 'P/E score' },
							{ name: 'priceToBookScore', type: 'number', description: 'P/B score' },
						],
					},
				],
				ref: createReferenceWithTitle(getRatingsSnapshotRef, params, buildGetRatingsSnapshotCallDescription),
			},
		},
		run: (inputs) => {
			const raw = inputs.ratings_snapshot_raw || {};
			const ratingsArr = Array.isArray(raw?.response?.ratings) ? raw.response.ratings : [];
			if (ratingsArr.length === 0) {
				throw new Error('Ratings snapshot array is empty');
			}

			const outRatings = ratingsArr.map((r) => ({
				symbol: typeof r.symbol === 'string' ? r.symbol : undefined,
				rating: typeof r.rating === 'string' ? r.rating : undefined,
				overallScore: typeof r.overallScore === 'number' ? r.overallScore : undefined,
				discountedCashFlowScore: typeof r.discountedCashFlowScore === 'number' ? r.discountedCashFlowScore : undefined,
				returnOnEquityScore: typeof r.returnOnEquityScore === 'number' ? r.returnOnEquityScore : undefined,
				returnOnAssetsScore: typeof r.returnOnAssetsScore === 'number' ? r.returnOnAssetsScore : undefined,
				debtToEquityScore: typeof r.debtToEquityScore === 'number' ? r.debtToEquityScore : undefined,
				priceToEarningsScore: typeof r.priceToEarningsScore === 'number' ? r.priceToEarningsScore : undefined,
				priceToBookScore: typeof r.priceToBookScore === 'number' ? r.priceToBookScore : undefined,
			}));

			const symbolsParam = typeof params?.symbols === 'string' ? params.symbols : typeof params?.symbol === 'string' ? params.symbol : '';

			const limitParam = params && params.limit != null ? Number(params.limit) : undefined;

			return {
				current_ratings_snapshot: [
					{
						date: Date.now(),
						symbols: symbolsParam,
						limit: limitParam,
						ratings: outRatings,
					},
				],
			};
		},
	};
}

function getRefs() {
    return [
        getRatingsSnapshotRef,
    ];
}

module.exports = {
	getRatingsSnapshot,
	makeRatingsSnapshotNode,
    getRefs,
};