function assert(condition, message) {
	if (!condition) throw new Error(message || 'Assertion failed');
}

function testGetRatingsSnapshotDirect() {
	console.log('\n=== Testing getRatingsSnapshot (Direct Calls) ===');

	// Manual import for get* function as required
	const { getRatingsSnapshot } = require('@arrays/data/stock/rating-snapshot:v1.0.0');

	let totalTests = 0;
	let passedTests = 0;

	function runTest(name, fn) {
		totalTests++;
		try {
			fn();
			console.log(`✅ ${name}`);
			passedTests++;
		} catch (e) {
			console.log(`❌ ${name}: ${e.message}`);
		}
	}

	function assertNumberInRange(name, value, min = 0, max = 100) {
		assert(typeof value === 'number', `${name} should be a number`);
		assert(!Number.isNaN(value), `${name} should not be NaN`);
		assert(value >= min && value <= max, `${name} should be in [${min}, ${max}]`);
	}

	function assertRatingRecord(rec, expectedSymbol) {
		assert(rec && typeof rec === 'object', 'rating record should be object');
		assert(rec.symbol === expectedSymbol, 'symbol should match requested');
		assert(typeof rec.rating === 'string', 'rating should be string');
		assert(rec.rating.length > 0, 'rating should be non-empty');
		// Allow standard letter grades with optional +/- suffix
		assert(/^[A-F](\+|-)?$/.test(rec.rating), `rating should be letter grade (A-F with optional +/-), got: ${rec.rating}`);

		assertNumberInRange('overallScore', rec.overallScore);
		assertNumberInRange('discountedCashFlowScore', rec.discountedCashFlowScore);
		assertNumberInRange('returnOnEquityScore', rec.returnOnEquityScore);
		assertNumberInRange('returnOnAssetsScore', rec.returnOnAssetsScore);
		assertNumberInRange('debtToEquityScore', rec.debtToEquityScore);
		assertNumberInRange('priceToEarningsScore', rec.priceToEarningsScore);
		assertNumberInRange('priceToBookScore', rec.priceToBookScore);
	}

	function assertResponseShape(res) {
		assert(res && typeof res === 'object', 'result should be object');
		assert(typeof res.success === 'boolean', 'success should be boolean');
		assert(res.response && typeof res.response === 'object', 'response should exist');
		assert(Array.isArray(res.response.ratings), 'response.ratings should be array');
		assert(typeof res.response.limit === 'number', 'response.limit should be number');
		assert(res.response.ratings.length <= res.response.limit, 'ratings length should be <= limit');
	}

	const SYMBOLS = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA'];

	// Happy Path: multiple valid symbols
	for (const symbol of SYMBOLS) {
		runTest(`getRatingsSnapshot happy path (${symbol}, limit=3)`, () => {
			const res = getRatingsSnapshot({ symbol, limit: 3 });
			assertResponseShape(res);
			// When data exists, validate first record thoroughly
			if (res.response.ratings.length > 0) {
				assert(res.response.limit >= res.response.ratings.length, 'limit should be >= returned count');
				assertRatingRecord(res.response.ratings[0], symbol);
			}
		});
	}

	// Default limit behavior
	runTest('getRatingsSnapshot default limit (AAPL)', () => {
		const res = getRatingsSnapshot({ symbol: 'AAPL' });
		assertResponseShape(res);
		assert(res.response.limit <= 10, 'default limit should be <= 10');
		assert(res.response.ratings.length <= res.response.limit, 'ratings length should be <= response.limit');
		if (res.response.ratings.length > 0) {
			assertRatingRecord(res.response.ratings[0], 'AAPL');
		}
	});

	// Boundary Value: minimum limit
	runTest('getRatingsSnapshot boundary limit=1 (MSFT)', () => {
		const res = getRatingsSnapshot({ symbol: 'MSFT', limit: 1 });
		assertResponseShape(res);
		assert(res.response.limit <= 1, 'limit should be <= 1');
		assert(res.response.ratings.length <= 1, 'ratings length should be <= 1');
	});

	// Boundary Value: larger limit
	runTest('getRatingsSnapshot boundary large limit=50 (GOOGL)', () => {
		const res = getRatingsSnapshot({ symbol: 'GOOGL', limit: 50 });
		assertResponseShape(res);
		assert(res.response.ratings.length <= 50, 'ratings length should be <= 50');
	});

	// Special Values: invalid symbols
	runTest('getRatingsSnapshot invalid symbol should throw or be unsuccessful', () => {
		try {
			const res = getRatingsSnapshot({ symbol: 'INVALID_SYMBOL_12345', limit: 5 });
			// If it does not throw, ensure it indicates failure or returns empty data
			assert(res && typeof res === 'object', 'should return object');
			const empty = !res.response || !Array.isArray(res.response.ratings) || res.response.ratings.length === 0;
			assert(res.success === false || empty, 'should be unsuccessful or return empty ratings');
		} catch (e) {
			// thrown error is acceptable path
		}
	});

	runTest('getRatingsSnapshot empty symbol should throw', () => {
		let handled = false;
		try {
			const res = getRatingsSnapshot({ symbol: '' });
			// For invalid parameters, should explicitly return success=false
			// (not just return empty data, which indicates valid query but no results)
			if (res && typeof res === 'object' && res.success === false) {
				handled = true;
			}
		} catch (e) {
			// Or throw an error
			handled = true;
		}
		assert(handled, 'should return error (success=false) or throw for empty symbol');
	});

	runTest('getRatingsSnapshot null/undefined symbol should throw', () => {
		let handledNull = false;
		let handledUndef = false;

		try {
			const res = getRatingsSnapshot({ symbol: null });
			// For invalid parameters, should explicitly return success=false
			if (res && typeof res === 'object' && res.success === false) {
				handledNull = true;
			}
		} catch (e) {
			handledNull = true;
		}

		try {
			const res = getRatingsSnapshot({ symbol: undefined });
			// For invalid parameters, should explicitly return success=false
			if (res && typeof res === 'object' && res.success === false) {
				handledUndef = true;
			}
		} catch (e) {
			handledUndef = true;
		}

		assert(handledNull && handledUndef, 'should return error (success=false) or throw for null and undefined symbol');
	});

	// Special/Boundary: invalid limits should not crash
	runTest('getRatingsSnapshot limit=0 should not crash (AAPL)', () => {
		const res = getRatingsSnapshot({ symbol: 'AAPL', limit: 0 });
		assert(res && typeof res === 'object', 'should return object');
		assert(res.response && Array.isArray(res.response.ratings), 'should return ratings array');
		// Accept either empty sanitized result or fallback to default
		assert(res.response.ratings.length >= 0, 'ratings should be an array of length >= 0');
	});

	runTest('getRatingsSnapshot negative limit should not crash (AAPL)', () => {
		const res = getRatingsSnapshot({ symbol: 'AAPL', limit: -5 });
		assert(res && typeof res === 'object', 'should return object');
		assert(res.response && Array.isArray(res.response.ratings), 'should return ratings array');
	});

	runTest('getRatingsSnapshot non-numeric limit should not crash (AAPL)', () => {
		const res = getRatingsSnapshot({ symbol: 'AAPL', limit: '5' });
		assert(res && typeof res === 'object', 'should return object');
		assert(res.response && Array.isArray(res.response.ratings), 'should return ratings array');
	});

	// Print test summary
	console.log('\n=== getRatingsSnapshot Test Summary ===');
	console.log(`Total tests: ${totalTests}`);
	console.log(`Passed: ${passedTests}`);
	console.log(`Failed: ${totalTests - passedTests}`);
	console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function main() {
	// Direct function tests
	testGetRatingsSnapshotDirect();

	// Existing graph-based test
	const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
	const { jagentId } = require('env');
	const { makeRatingsSnapshotNode } = require('@arrays/data/stock/rating-snapshot:v1.0.0');

	const g = new Graph(jagentId);
	g.addNode('current_ratings', makeRatingsSnapshotNode({ symbol: 'AAPL', limit: 1 }));
	g.run();

	const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'current_ratings', 'current_ratings_snapshot', { last: '5' }), g.store);
	ts.init();

	if (!ts.data.length) throw new Error('current_ratings_snapshot empty');
	const row = ts.data[0];
	;['date', 'symbols', 'limit', 'ratings'].forEach((k) => {
		if (!(k in row)) throw new Error('missing row field: ' + k);
	});
	if (!Array.isArray(row.ratings) || !row.ratings.length) throw new Error('ratings empty');

	const r = row.ratings[0];
	;['symbol', 'rating', 'overallScore', 'discountedCashFlowScore', 'returnOnEquityScore', 'returnOnAssetsScore', 'debtToEquityScore', 'priceToEarningsScore', 'priceToBookScore'].forEach((k) => {
		if (!(k in r)) throw new Error('missing rating field: ' + k);
	});

	// Validate refs for current_ratings_snapshot output
	const refsRatings = g.getRefsForOutput('current_ratings', 'current_ratings_snapshot');
	if (refsRatings.length > 0) {
		const ref = refsRatings[0];
		const expected = {
			id: '@arrays/data/stock/rating-snapshot/getRatingsSnapshot',
			module_name: '@arrays/data/stock/rating-snapshot',
			module_display_name: 'Analyst Rating Real-Time Data',
			sdk_name: 'getRatingsSnapshot',
			sdk_display_name: 'Analyst Rating Real-Time Data',
			source_name: 'Financial Modeling Prep',
			source: 'https://site.financialmodelingprep.com/developer/docs/stable/ratings-snapshot',
		};

		if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for current_ratings_snapshot');
		if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for current_ratings_snapshot');
		if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for current_ratings_snapshot');
		if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for current_ratings_snapshot');
		if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for current_ratings_snapshot');
		if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for current_ratings_snapshot');
		if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for current_ratings_snapshot');
	} else {
		throw new Error('Assertion failed: refsRatings array is empty.');
	}
	return 0;
}

main();
