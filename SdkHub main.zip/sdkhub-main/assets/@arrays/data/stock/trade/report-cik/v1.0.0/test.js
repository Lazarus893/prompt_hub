function assert(condition, message) {
	if (!condition) throw new Error(message || 'Assertion failed');
}

function runTest(testName, fn, ctx) {
	ctx.totalTests++;
	try {
		fn();
		console.log(`✅ ${testName}`);
		ctx.passedTests++;
	} catch (e) {
		console.log(`❌ ${testName}: ${e.message}`);
	}
}

function testDirectGetReportCikByName(ctx) {
	console.log('\n=== Testing Direct Function Calls: getReportCikByName ===');

	// Manual import for get* function per instruction
	const { getReportCikByName } = require('@arrays/data/stock/trade/report-cik:v1.0.0');

	// Helper to validate a well-formed successful response
	function expectValidResponse(res) {
		assert(res && typeof res === 'object', 'Should return an object');
		assert(typeof res.success === 'boolean', 'res.success should be boolean');

		// API might return different response structures
		if (res.response) {
			assert(typeof res.response === 'object', 'res.response should be object');
			// Check if response has list property
			if (res.response.list !== undefined) {
				assert(Array.isArray(res.response.list), 'res.response.list should be array');
			}
		}

		// Alternative: response might be directly an array
		if (Array.isArray(res.response)) {
			// This is also valid
		}
	}

	function validateReportCikShape(item) {
		// Required fields that must exist
		const requiredFields = ['reporting_cik', 'reporting_name'];
		requiredFields.forEach((k) => assert(k in item, `missing item field: ${k}`));

		// Basic type checks for required fields
		assert(typeof item.reporting_cik === 'string', 'item.reporting_cik should be string');
		assert(typeof item.reporting_name === 'string', 'item.reporting_name should be string');

		// CIK should be a valid format (10 digits)
		assert(/^\d{10}$/.test(item.reporting_cik), 'reporting_cik should be 10 digits');
		assert(item.reporting_name.length > 0, 'reporting_name should not be empty');
	}

	// Happy Path: enumerate valid names
	const VALID_NAMES = ['COOK TIMOTHY D', 'Timothy D. Cook', "Patrick O'Connor"];
	for (const name of VALID_NAMES) {
		runTest(
			`getReportCikByName happy path with "${name}"`,
			() => {
				const res = getReportCikByName({ name });
				expectValidResponse(res);
				assert(res.success === true, 'success should be true for valid inputs');

				// Handle different response structures
				let items = [];
				if (res.response && Array.isArray(res.response.list)) {
					items = res.response.list;
				} else if (Array.isArray(res.response)) {
					items = res.response;
				}

				if (items.length > 0) {
					validateReportCikShape(items[0]);
				}
			},
			ctx
		);
	}

	// Normalization tests
	runTest(
		'getReportCikByName normalization: lowercase + punctuation',
		() => {
			const res = getReportCikByName({ name: 'timothy d. cook' });
			expectValidResponse(res);
			assert(res.success === true, 'success should be true');
		},
		ctx
	);

	runTest(
		'getReportCikByName normalization: extra spaces collapsed',
		() => {
			const res = getReportCikByName({ name: '  Mr.   Timothy    Donald   Cook  ' });
			expectValidResponse(res);
			assert(res.success === true, 'success should be true');
		},
		ctx
	);

	runTest(
		'getReportCikByName normalization: apostrophes preserved',
		() => {
			const res = getReportCikByName({ name: "Patrick O'Connor" });
			expectValidResponse(res);
			assert(res.success === true, 'success should be true');
		},
		ctx
	);

	runTest(
		'getReportCikByName normalization: hyphenated names',
		() => {
			const res = getReportCikByName({ name: 'Jean-Luc Picard' });
			expectValidResponse(res);
			assert(res.success === true, 'success should be true');
		},
		ctx
	);

	runTest(
		'getReportCikByName normalization: particles with surname',
		() => {
			const res = getReportCikByName({ name: 'Oscar de la Hoya' });
			expectValidResponse(res);
			assert(res.success === true, 'success should be true');
		},
		ctx
	);

	runTest(
		'getReportCikByName normalization: complex name with suffix',
		() => {
			const res = getReportCikByName({ name: "Mary-Jane O'Neill III" });
			expectValidResponse(res);
			assert(res.success === true, 'success should be true');
		},
		ctx
	);

	// Suffix coverage tests
	const SUFFIX_CASES = [
		{ name: 'Robert Downey Jr', expectedSuffix: 'JR' },
		{ name: 'John Smith Sr', expectedSuffix: 'SR' },
		{ name: 'Henry Ford II', expectedSuffix: 'II' },
		{ name: 'Jane Doe III', expectedSuffix: 'III' },
	];

	for (const c of SUFFIX_CASES) {
		runTest(
			`getReportCikByName suffix handling: ${c.expectedSuffix}`,
			() => {
				const res = getReportCikByName({ name: c.name });
				expectValidResponse(res);
				assert(res.success === true, 'success should be true');

				// Handle different response structures
				let items = [];
				if (res.response && Array.isArray(res.response.list)) {
					items = res.response.list;
				} else if (Array.isArray(res.response)) {
					items = res.response;
				}

				if (items.length > 0) {
					const item = items[0];
					if (item.reporting_name) {
						assert(item.reporting_name.endsWith(` ${c.expectedSuffix}`), `reporting_name should end with suffix ${c.expectedSuffix}`);
					}
				}
			},
			ctx
		);
	}

	// Boundary tests
	runTest(
		'getReportCikByName boundary: minimum length',
		() => {
			const res = getReportCikByName({ name: 'A' });
			expectValidResponse(res);
			assert(res.success === true, 'success should be true');
		},
		ctx
	);

	runTest(
		'getReportCikByName boundary: very long name',
		() => {
			const res = getReportCikByName({ name: 'A'.repeat(300) });
			// Very long names might be rejected by the API, so we accept both success and failure
			assert(res && typeof res === 'object', 'Should return an object');
			assert(typeof res.success === 'boolean', 'success should be boolean');
			// API should handle long names gracefully (either accept or reject, but not crash)
			if (res.success === true) {
				// If successful, validate response structure
				expectValidResponse(res);
			}
			// If failed, that's also acceptable for very long names
		},
		ctx
	);

	// Special values and invalid inputs
	runTest(
		'getReportCikByName with missing params',
		() => {
			let handled = false;
			try {
				const res = getReportCikByName();
				if (res && typeof res === 'object' && res.success === false) handled = true;
			} catch (e) {
				handled = true;
			}
			assert(handled, 'Should handle missing params gracefully');
		},
		ctx
	);

	runTest(
		'getReportCikByName with null params',
		() => {
			let handled = false;
			try {
				const res = getReportCikByName(null);
				if (res && typeof res === 'object' && res.success === false) handled = true;
			} catch (e) {
				handled = true;
			}
			assert(handled, 'Should handle null params gracefully');
		},
		ctx
	);

	runTest(
		'getReportCikByName with empty name',
		() => {
			let handled = false;
			try {
				const res = getReportCikByName({ name: '' });
				if (res && typeof res === 'object' && res.success === false) handled = true;
			} catch (e) {
				handled = true;
			}
			assert(handled, 'Should handle empty name');
		},
		ctx
	);

	runTest(
		'getReportCikByName with undefined name',
		() => {
			let handled = false;
			try {
				const res = getReportCikByName({ name: undefined });
				if (res && typeof res === 'object' && res.success === false) handled = true;
			} catch (e) {
				handled = true;
			}
			assert(handled, 'Should handle undefined name');
		},
		ctx
	);

	runTest(
		'getReportCikByName with null name',
		() => {
			let handled = false;
			try {
				const res = getReportCikByName({ name: null });
				if (res && typeof res === 'object' && res.success === false) handled = true;
			} catch (e) {
				handled = true;
			}
			assert(handled, 'Should handle null name');
		},
		ctx
	);

	runTest(
		'getReportCikByName with whitespace only name',
		() => {
			let handled = false;
			try {
				const res = getReportCikByName({ name: '   ' });
				if (res && typeof res === 'object' && res.success === false) handled = true;
			} catch (e) {
				handled = true;
			}
			assert(handled, 'Should handle whitespace only name');
		},
		ctx
	);

	runTest(
		'getReportCikByName with non-string name (number)',
		() => {
			let handled = false;
			try {
				const res = getReportCikByName({ name: 12345 });
				if (res && typeof res === 'object' && res.success === false) handled = true;
			} catch (e) {
				handled = true;
			}
			assert(handled, 'Should handle non-string name');
		},
		ctx
	);

	runTest(
		'getReportCikByName with non-string name (object)',
		() => {
			let handled = false;
			try {
				const res = getReportCikByName({ name: { first: 'Timothy', last: 'Cook' } });
				if (res && typeof res === 'object' && res.success === false) handled = true;
			} catch (e) {
				handled = true;
			}
			assert(handled, 'Should handle non-string name');
		},
		ctx
	);

	// Output schema validation
	runTest(
		'getReportCikByName output schema validation',
		() => {
			const res = getReportCikByName({ name: 'COOK TIMOTHY D' });
			assert(typeof res.success === 'boolean', 'success should be boolean');

			// Handle different response structures
			let items = [];
			if (res.response && Array.isArray(res.response.list)) {
				items = res.response.list;
			} else if (Array.isArray(res.response)) {
				items = res.response;
			}

			if (items.length > 0) {
				validateReportCikShape(items[0]);
			}
		},
		ctx
	);
}

function testGraphNodeIntegration(ctx) {
	console.log('\n=== Testing Graph Node Integration ===');
	const { Graph } = require('@alva/graph:v1.0.0');
	const { jagentId } = require('env');
	const { makeReportCikByNameNode } = require('@arrays/data/stock/trade/report-cik:v1.0.0');

	const g = new Graph(jagentId);
	const nodeName = 'report_cik_by_name';
	g.addNode(nodeName, makeReportCikByNameNode({ name: 'COOK TIMOTHY D' }));

	g.run();

	// Validate refs for the output using the established if/throw structure
	const refsReportCikByName = g.getRefsForOutput(nodeName, 'report_cik_by_name');
	if (refsReportCikByName.length > 0) {
		const ref = refsReportCikByName[0];
		const expected = {
			id: '@arrays/data/stock/trade/report-cik/getReportCikByName',
			module_name: '@arrays/data/stock/trade/report-cik',
			module_display_name: 'Stock Trade Insider Reports',
			sdk_name: 'getReportCikByName',
			sdk_display_name: 'Insider Trading Report by Name',
			source_name: 'SPACE ID Data Gateway',
			source: 'https://site.financialmodelingprep.com/developer/docs/stable/search-reporting-name',
		};

		if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for report_cik_by_name');
		if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for report_cik_by_name');
		if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for report_cik_by_name');
		if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for report_cik_by_name');
		if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for report_cik_by_name');
		if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for report_cik_by_name');
		if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for report_cik_by_name');
		console.log('✓ report_cik_by_name refs validated');
	} else {
		throw new Error('Assertion failed: refsReportCikByName array is empty.');
	}
}

function main() {
	const ctx = { totalTests: 0, passedTests: 0 };

	// Direct function tests for getReportCikByName
	testDirectGetReportCikByName(ctx);

	// Graph node integration tests
	runTest('Graph Node Integration: Report CIK by Name Node', () => testGraphNodeIntegration(ctx), ctx);

	// Summary
	console.log('\n=== Test Summary ===');
	console.log(`Total tests: ${ctx.totalTests}`);
	console.log(`Passed: ${ctx.passedTests}`);
	console.log(`Failed: ${ctx.totalTests - ctx.passedTests}`);
	console.log(`Success rate: ${((ctx.passedTests / ctx.totalTests) * 100).toFixed(1)}%`);
}

main();
