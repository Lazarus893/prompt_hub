const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for the SDK function and module
const getReportCikByNameRef = {
	id: '@arrays/data/stock/trade/report-cik/getReportCikByName',
	module_name: '@arrays/data/stock/trade/report-cik',
	module_display_name: 'Stock Trade Insider Reports',
	sdk_name: 'getReportCikByName',
	sdk_display_name: 'Insider Trading Report by Name',
	source_name: 'SPACE ID Data Gateway',
	source: 'https://site.financialmodelingprep.com/developer/docs/stable/search-reporting-name',
};

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

/**
 * Fetch insider trading report details by reporting person's name.
 * Params are passed through to the upstream API as query string.
 * @param {Object} params
 * @returns {Object} raw API JSON
 */
function getReportCikByName(params) {
	// Validate required parameters
	if (!params || typeof params !== 'object') {
		throw new Error('Invalid params: must be an object');
	}
	
	const { name } = params;
	if (name === null || name === undefined) {
		throw new Error('Invalid name: name parameter is required and cannot be null or undefined');
	}
	
	if (typeof name !== 'string') {
		throw new Error('Invalid name: name parameter must be a string');
	}
	
	if (name.trim() === '') {
		throw new Error('Invalid name: name parameter cannot be empty or whitespace only');
	}

	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/trade/insider_trades/report_detail_by_name';
	const keyValuePairs = Object.keys(params || {}).map((k) => {
		const v = params[k];
		// Skip null and undefined values
		if (v === null || v === undefined) return null;
		return encodeURIComponent(k) + '=' + encodeURIComponent(v);
	}).filter(Boolean);
	const queryString = keyValuePairs.join('&');
	const fullUrl = `${baseUrl}?${queryString}`;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

/**
 * Node factory for fetching insider trading report details by reporting person's name.
 * Parameters are exactly the same as getReportCikByName.
 */
function makeReportCikByNameNode(params) {
	return {
		inputs: {
			report_cik_by_name_raw: () => getReportCikByName(params),
		},
		outputs: {
			report_cik_by_name: {
				name: 'report_cik_by_name',
				description: 'Insider trading report lookup by reporting person name (snapshot).',
				fields: [
					{ name: 'date', type: 'number', description: 'snapshot time ms' },
					{ name: 'success', type: 'boolean', description: 'API success flag' },
					{
						name: 'payload',
						type: 'object',
						description: 'Raw API response payload from getReportCikByName',
						fields: [
							{
								name: 'success',
								type: 'boolean',
								description: 'Indicates if the request was successful.',
							},
							{
								name: 'response',
								type: 'object',
								description: 'Response details',
								fields: [
									{
										name: 'list',
										type: 'array',
										description: 'Array of insider trading report details.',
										fields: [
											{ name: 'reporting_cik', type: 'string', description: 'The Central Index Key (CIK) of the reporting person.' },
											{ name: 'reporting_name', type: 'string', description: 'The name of the reporting person.' },
										],
									},
									{ name: 'count', type: 'number', description: 'The number of reports found.' },
								],
							},
						],
					},
				],
				ref: createReferenceWithTitle(
					getReportCikByNameRef,
					params,
					buildGetInsiderTradingReportDetailbyNameCallDescription
				),
			},
			run: (inputs) => {
				const raw = inputs.report_cik_by_name_raw;
				const success = raw && typeof raw === 'object' && !Array.isArray(raw) && 'success' in raw ? !!raw.success : false;
				return {
					report_cik_by_name: [
						{
							date: Date.now(),
							success,
							payload: raw,
						},
					],
				};
			},
		},
	};
}

// ------------------------------
// Auto-generated from doc: base descriptions and dynamic builders
// Doc function: getInsiderTradingReportDetailbyName(params)

// Base description (concise summary)
const baseGetInsiderTradingReportDetailbyNameDescription = "Retrieve insider trading reports by reporting person's name";

// Dynamic call description builder based on actual params
function buildGetInsiderTradingReportDetailbyNameCallDescription(actualParams = {}) {
	const parts = [baseGetInsiderTradingReportDetailbyNameDescription];

	// Add required/optional parameters context
	if (actualParams && typeof actualParams === 'object') {
		if (actualParams.name) {
			parts.push(`for ${actualParams.name}`);
		}
	}

	return parts.join(' ').trim();
}

function getRefs() {
	return [
		getReportCikByNameRef,
	];
}

module.exports = {
	getReportCikByName,
	makeReportCikByNameNode,
	getRefs,
};