const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getInsiderTrades derived from tool.json
const getInsiderTradesRef = {
	id: '@arrays/data/stock/trade/insider-trades/getInsiderTrades',
	module_name: '@arrays/data/stock/trade/insider-trades',
	module_display_name: 'Stock Insider Trades',
	sdk_name: 'getInsiderTrades',
	sdk_display_name: 'Stock Insider Trades ',
	source_name: 'Financial Modeling Prep',
	source: 'https://site.financialmodelingprep.com/developer/docs/stable/search-insider-trades',
};

// Base description strings (not exported)
// Summary for getInsiderTrades based on doc:
const getInsiderTradesBaseFuncDesc = 'Track recent insider stock trades';

// Dynamic description builder (not exported)
function buildGetInsiderTradesCallDescription(actualParams = {}) {
	const parts = [getInsiderTradesBaseFuncDesc];
	const p = actualParams || {};

	// Primary subject qualifiers
	if (p.symbol) {
		parts.push(`for ${p.symbol}`);
	} else if (p.company_cik) {
		parts.push(`for company CIK ${p.company_cik}`);
	} else if (p.reporting_cik) {
		parts.push(`by reporter CIK ${p.reporting_cik}`);
	}

	// Additional filters
	const filters = [];
	if (p.transaction_type) {
		filters.push(`Type: ${p.transaction_type}`);
	}
	if (typeof p.page === 'number' && p.page > 0) {
		filters.push(`Page: ${p.page}`);
	}
	if (typeof p.limit === 'number' && p.limit !== 100) {
		filters.push(`Limit: ${p.limit}`);
	}

	if (filters.length > 0) {
		parts.push(`(${filters.join(', ')})`);
	}

	return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
	// 1. 使用传入的 titleBuilder 函数和 params 来生成 title
	const title = titleBuilder(params);

	// 2. 组合 refObject 和新 title
	const newObject = {
		...refObject,
		title: title,
	};

	// 3. 返回新对象
	return newObject;
}

// 获取所有 *Ref 对象的方法
function getRefs() {
	return [
		getInsiderTradesRef,
	];
}

function getInsiderTrades(params) {
	// Validate required parameters
	if (!params || typeof params !== 'object') {
		return { success: false, error: 'Invalid params: must be an object' };
	}

	const { page, limit, symbol, transaction_type, reporting_cik, company_cik } = params;

	// Validate required parameters
	if (page === undefined || page === null) {
		return { success: false, error: 'Missing required parameter: page' };
	}
	if (limit === undefined || limit === null) {
		return { success: false, error: 'Missing required parameter: limit' };
	}

	// Validate page
	if (typeof page !== 'number' || !Number.isInteger(page) || page < 0) {
		return { success: false, error: 'Invalid page: must be a non-negative integer' };
	}

	// Validate limit
	if (typeof limit !== 'number' || !Number.isInteger(limit) || limit <= 0 || limit > 100) {
		return { success: false, error: 'Invalid limit: must be an integer between 1 and 100' };
	}

	// Validate symbol if provided
	if (symbol !== undefined && symbol !== null) {
		if (typeof symbol !== 'string' || symbol.trim() === '') {
			return { success: false, error: 'Invalid symbol: must be a non-empty string' };
		}
	}

	// Validate transaction_type if provided
	if (transaction_type !== undefined) {
		if (transaction_type === null) {
			return { success: false, error: 'Invalid transaction_type: cannot be null' };
		}
		if (typeof transaction_type !== 'string') {
			return { success: false, error: 'Invalid transaction_type: must be a string' };
		}
		// Check for valid transaction types
		const validTypes = ['P-Purchase', 'S-Sale'];
		if (!validTypes.includes(transaction_type)) {
			return { success: false, error: 'Invalid transaction_type: must be one of ' + validTypes.join(', ') };
		}
	}

	// Validate reporting_cik if provided
	if (reporting_cik !== undefined && reporting_cik !== null) {
		if (typeof reporting_cik !== 'string' || reporting_cik.trim() === '') {
			return { success: false, error: 'Invalid reporting_cik: must be a non-empty string' };
		}
	}

	// Validate company_cik if provided
	if (company_cik !== undefined && company_cik !== null) {
		if (typeof company_cik !== 'string' || company_cik.trim() === '') {
			return { success: false, error: 'Invalid company_cik: must be a non-empty string' };
		}
	}

	// At least one filter parameter must be provided
	if (!symbol && !reporting_cik && !company_cik) {
		return { success: false, error: 'At least one filter parameter (symbol, reporting_cik, or company_cik) must be provided' };
	}

	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/trade/insider_trades';
	const keyValuePairs = Object.keys(params || {})
		.map((key) => {
			const value = params[key];
			// Skip null and undefined values
			if (value === null || value === undefined) return null;
			return encodeURIComponent(key) + '=' + encodeURIComponent(value);
		})
		.filter(Boolean);
	const queryString = keyValuePairs.join('&');
	const fullUrl = `${baseUrl}?${queryString}`;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

function _parseYyyyMmDdToUtcMs(s) {
	// Parse 'YYYY-MM-DD' into a UTC midnight timestamp in milliseconds.
	// Used as a fallback when numeric timestamps are not provided by the API.
	if (typeof s !== 'string') return null;
	const parts = s.split('-');
	if (parts.length !== 3) return null;
	const y = Number(parts[0]);
	const m = Number(parts[1]);
	const d = Number(parts[2]);
	if (!Number.isFinite(y) || !Number.isFinite(m) || !Number.isFinite(d)) return null;
	return Date.UTC(y, m - 1, d, 0, 0, 0, 0);
}

function makeInsiderTradesNode(params) {
	return {
		inputs: {
			insider_trades_raw: () => getInsiderTrades(params),
		},
		outputs: {
			insider_trades: {
				name: 'insider_trades',
				description: 'Insider trades grouped by transaction_timestamp (one record per timestamp)',
				fields: [
					{ name: 'date', type: 'number', description: 'transaction timestamp ms' },
					{
						name: 'insider_trade_list',
						type: 'array',
						description: 'all trades with this transaction_timestamp',
						fields: [
							{ name: 'symbol', type: 'string', description: 'Stock symbol' },
							{ name: 'reporting_cik', type: 'string', description: "Reporting person's CIK" },
							{ name: 'company_cik', type: 'string', description: 'Company CIK' },
							{ name: 'transaction_date', type: 'string', description: 'YYYY-MM-DD' },
							{ name: 'filing_date', type: 'string', description: 'YYYY-MM-DD' },
							{ name: 'transaction_type', type: 'string', description: 'Transaction type' },
							{ name: 'securities_owned', type: 'number', description: 'Securities owned after' },
							{ name: 'securities_transacted', type: 'number', description: 'Securities transacted' },
							{ name: 'price', type: 'number', description: 'Transaction price per security' },
							{ name: 'reporting_name', type: 'string', description: 'Reporting person name' },
							{ name: 'type_of_owner', type: 'string', description: 'Owner type and title' },
							{ name: 'security_name', type: 'string', description: 'Security name' },
							{ name: 'form_type', type: 'string', description: 'Filing form type' },
						],
					},
				],
				ref: createReferenceWithTitle(getInsiderTradesRef, params, buildGetInsiderTradesCallDescription),
			},
		},
		run: (inputs) => {
			const list = inputs.insider_trades_raw?.response?.list;
			const arr = Array.isArray(list) ? list : [];
			// Group by event time:
			// 1) Prefer transaction_timestamp (if numeric). Value may be seconds (e.g., 1755216000) or milliseconds (>1e12).
			// 2) Fallback to filing_timestamp (same seconds/ms heuristic).
			// 3) If both missing, parse transaction_date or filing_date (YYYY-MM-DD) as UTC midnight.
			// This produces a true time-series grouped by precise timestamps, sorted ascending.
			const byTimestamp = Object.create(null);
			for (const t of arr) {
				let timestampMs = null;
				// Try transaction_timestamp first, then filing_timestamp
				if (t.transaction_timestamp && typeof t.transaction_timestamp === 'number') {
					// Treat values < 1e12 as seconds and convert to milliseconds
					timestampMs = t.transaction_timestamp > 1e12 ? t.transaction_timestamp : t.transaction_timestamp * 1000;
				} else if (t.filing_timestamp && typeof t.filing_timestamp === 'number') {
					// Same heuristic for filing timestamp
					timestampMs = t.filing_timestamp > 1e12 ? t.filing_timestamp : t.filing_timestamp * 1000;
				} else {
					// Fallback: parse YYYY-MM-DD dates to ms for ordering/grouping
					timestampMs = _parseYyyyMmDdToUtcMs(t?.transaction_date);
					if (timestampMs == null) timestampMs = _parseYyyyMmDdToUtcMs(t?.filing_date);
				}
				if (!timestampMs || !Number.isFinite(timestampMs)) continue;

				if (!byTimestamp[timestampMs]) byTimestamp[timestampMs] = [];
				byTimestamp[timestampMs].push({
					symbol: t.symbol,
					reporting_cik: t.reporting_cik,
					company_cik: t.company_cik,
					transaction_date: t.transaction_date,
					filing_date: t.filing_date,
					transaction_type: t.transaction_type,
					securities_owned: t.securities_owned,
					securities_transacted: t.securities_transacted,
					price: t.price,
					reporting_name: t.reporting_name,
					type_of_owner: t.type_of_owner,
					security_name: t.security_name,
					form_type: t.form_type,
				});
			}
			const timestamps = Object.keys(byTimestamp)
				.map((k) => +k)
				.sort((a, b) => a - b);
			const series = timestamps.map((ms) => ({
				date: ms,
				insider_trade_list: byTimestamp[ms],
			}));
			return { insider_trades: series };
		},
	};
}
module.exports = {
	getInsiderTrades,
	makeInsiderTradesNode,
	getRefs, // 新增导出
};
