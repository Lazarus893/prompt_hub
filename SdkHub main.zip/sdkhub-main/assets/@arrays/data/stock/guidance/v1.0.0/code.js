const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getGuidanceData, derived from tool.json
const getGuidanceDataRef = {
    id: '@arrays/data/stock/guidance/getGuidanceData',
    module_name: '@arrays/data/stock/guidance',
    module_display_name: 'Company Guidance',
    sdk_name: 'getGuidanceData',
    sdk_display_name: 'Corporate Guidance',
    source_name: 'Benzinga',
    source: 'https://docs.benzinga.com/benzinga-apis/calendar/get-guidance',
};

// Helper to compose reference object with a dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title,
    };

    // 3. 返回新对象
    return newObject;
}

// Build a human-readable call description for getGuidanceData
function buildGetGuidanceDataCallDescription(params) {
    const prefix = 'Corporate Guidance';
    if (!params || typeof params !== 'object' || Object.keys(params).length === 0) {
        return prefix;
    }
    try {
        const parts = Object.entries(params).map(([k, v]) => `${k}=${v}`);
        return `${prefix} (${parts.join('&')})`;
    } catch (e) {
        return prefix;
    }
}

function getGuidanceData(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/guidance';
    const keyValuePairs = Object.keys(params || {}).map((k) => {
        const v = params[k];
        return encodeURIComponent(k) + '=' + encodeURIComponent(v);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key || 'c84b079d-3888-4366-9752-10bb6c51543d',
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function makeGuidanceDataNode(params) {
    function parseEventMs(g) {
        // Prefer explicit date + time from the record; fall back to updated (seconds) if needed
        const d = g && g.date;
        const t = g && g.time;
        if (typeof d === 'string' && d.length >= 10) {
            const [yStr, mStr, dStr] = d.split('-');
            const y = Number(yStr);
            const m0 = Number(mStr) - 1;
            const dd = Number(dStr);
            let hh = 0,
                mm = 0,
                ss = 0;
            if (typeof t === 'string' && t.length >= 5) {
                const [hStr, minStr, sStr = '0'] = t.split(':');
                hh = Number(hStr);
                mm = Number(minStr);
                ss = Number(sStr);
            }
            const ms = Date.UTC(y, m0, dd, hh, mm, ss, 0);
            if (Number.isFinite(ms)) return ms;
        }
        if (g && typeof g.updated === 'number' && Number.isFinite(g.updated)) {
            return g.updated * 1000; // convert seconds -> ms
        }
        return undefined;
    }

    return {
        inputs: {
            guidance_data_raw: () => getGuidanceData(params),
        },
        outputs: {
            guidance: {
                name: 'guidance',
                description: 'Corporate guidance events (one record per announcement).',
                fields: [
                    { name: 'date', type: 'number', description: 'announcement time ms (UTC)' },
                    { name: 'time', type: 'string', description: 'announcement time HH:MM:SS' },
                    { name: 'id', type: 'string', description: 'guidance ID' },
                    { name: 'ticker', type: 'string', description: 'stock symbol' },
                    { name: 'exchange', type: 'string', description: 'stock exchange' },
                    { name: 'name', type: 'string', description: 'company name' },
                    { name: 'currency', type: 'string', description: 'currency code' },
                    { name: 'period', type: 'string', description: 'Q4/FY/etc' },
                    { name: 'periodYear', type: 'number', description: 'reporting year' },
                    { name: 'prelim', type: 'string', description: 'preliminary indicator Y/N' },
                    { name: 'isPrimary', type: 'string', description: 'primary guidance indicator Y/N' },
                    { name: 'epsType', type: 'string', description: 'EPS type (e.g., Adj)' },
                    { name: 'epsGuidanceEst', type: 'string', description: 'EPS guidance estimate' },
                    { name: 'epsGuidanceMax', type: 'string', description: 'EPS guidance maximum' },
                    { name: 'epsGuidanceMin', type: 'string', description: 'EPS guidance minimum' },
                    { name: 'epsGuidancePriorMax', type: 'string', description: 'previous EPS guidance maximum' },
                    { name: 'epsGuidancePriorMin', type: 'string', description: 'previous EPS guidance minimum' },
                    { name: 'revenueGuidanceEst', type: 'string', description: 'revenue guidance estimate' },
                    { name: 'revenueGuidanceMax', type: 'string', description: 'revenue guidance maximum' },
                    { name: 'revenueGuidanceMin', type: 'string', description: 'revenue guidance minimum' },
                    { name: 'revenueGuidancePriorMax', type: 'string', description: 'previous revenue guidance maximum' },
                    { name: 'revenueGuidancePriorMin', type: 'string', description: 'previous revenue guidance minimum' },
                    { name: 'revenueType', type: 'string', description: 'revenue type (e.g., GAAP)' },
                    { name: 'importance', type: 'number', description: 'importance 0-5' },
                    { name: 'notes', type: 'string', description: 'additional notes' },
                    { name: 'updated', type: 'number', description: 'last update Unix timestamp ms' },
                ],
                ref: createReferenceWithTitle(getGuidanceDataRef, params, buildGetGuidanceDataCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.guidance_data_raw;
            if (!raw || raw.success !== true || !Array.isArray(raw.response.guidance)) {
                throw new Error('Guidance data raw data is invalid');
            }
            const arr = raw.response.guidance;

            // Map to per-event records with deterministic ms timestamps
            const mapped = [];
            for (const g of arr) {
                const ms = parseEventMs(g);
                if (!Number.isFinite(ms)) {
                    // skip entries that do not have a valid timestamp
                    continue;
                }
                mapped.push({
                    date: ms,
                    time: typeof g.time === 'string' ? g.time : undefined,
                    id: g.id,
                    ticker: g.ticker,
                    exchange: g.exchange,
                    name: g.name,
                    currency: g.currency,
                    period: g.period,
                    periodYear: g.periodYear,
                    prelim: g.prelim,
                    isPrimary: g.isPrimary,
                    epsType: g.epsType,
                    epsGuidanceEst: g.epsGuidanceEst,
                    epsGuidanceMax: g.epsGuidanceMax,
                    epsGuidanceMin: g.epsGuidanceMin,
                    epsGuidancePriorMax: g.epsGuidancePriorMax,
                    epsGuidancePriorMin: g.epsGuidancePriorMin,
                    revenueGuidanceEst: g.revenueGuidanceEst,
                    revenueGuidanceMax: g.revenueGuidanceMax,
                    revenueGuidanceMin: g.revenueGuidanceMin,
                    revenueGuidancePriorMax: g.revenueGuidancePriorMax,
                    revenueGuidancePriorMin: g.revenueGuidancePriorMin,
                    revenueType: g.revenueType,
                    importance: g.importance,
                    notes: g.notes,
                    updated: typeof g.updated === 'number' ? g.updated * 1000 : undefined,
                });
            }

            // Ensure ascending unique dates (no collisions within one output)
            mapped.sort((a, b) => a.date - b.date);
            for (let i = 1; i < mapped.length; i++) {
                if (mapped[i].date <= mapped[i - 1].date) {
                    mapped[i].date = mapped[i - 1].date + 1; // minimal shift to maintain uniqueness
                }
            }

            return { guidance: mapped };
        },
    };
}

function getRefs() {
    return [getGuidanceDataRef];
}

module.exports = {
    getGuidanceData,
    makeGuidanceDataNode,
    getRefs,
};
