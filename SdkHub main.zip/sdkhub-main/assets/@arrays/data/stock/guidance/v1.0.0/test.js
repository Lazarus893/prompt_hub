function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

function main() {
  const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
  const { jagentId } = require('env');
  const { makeGuidanceDataNode, getGuidanceData } = require('@arrays/data/stock/guidance:v1.0.0');

  let totalTests = 0;
  let passedTests = 0;

  function runTest(name, fn) {
    totalTests++;
    try {
      fn();
      console.log(`✅ ${name}`);
      passedTests++;
    } catch (e) {
      console.log(`❌ ${name}: ${e.message}`);
    }
  }

  function validateGuidanceStructure(res, requestedParams) {
    assert(res && typeof res === 'object', 'Result should be an object');
    assert('success' in res, 'Result should include success');
    assert(res.response && typeof res.response === 'object', 'Result should include response object');
    const r = res.response;
    assert(Array.isArray(r.guidance), 'response.guidance must be an array');
    if ('page' in r) {
      assert(typeof r.page === 'number', 'response.page should be a number');
      assert(r.page >= 0, 'response.page should be >= 0');
    }
    if ('pageSize' in r) {
      assert(typeof r.pageSize === 'number', 'response.pageSize should be a number');
      assert(r.pageSize <= 1000, 'response.pageSize should be <= 1000');
      if (requestedParams && typeof requestedParams.page_size === 'number') {
        assert(r.pageSize <= Math.min(1000, requestedParams.page_size), 'response.pageSize respects requested cap');
      }
    }
    // If we have at least one record, validate fields
    if (r.guidance.length > 0) {
      const x = r.guidance[0];
      [
        'id', 'date', 'time', 'ticker', 'exchange', 'name', 'currency', 'period', 'periodYear', 'prelim',
        'isPrimary', 'epsType', 'epsGuidanceEst', 'epsGuidanceMax', 'epsGuidanceMin', 'epsGuidancePriorMax',
        'epsGuidancePriorMin', 'revenueGuidanceEst', 'revenueGuidanceMax', 'revenueGuidanceMin',
        'revenueGuidancePriorMax', 'revenueGuidancePriorMin', 'revenueType', 'importance', 'notes', 'updated'
      ].forEach((k) => {
        assert(k in x, 'missing guidance field: ' + k);
      });
      // Basic sanity on enumerated fields if present
      assert(x.prelim === 'Y' || x.prelim === 'N' || x.prelim === '' || x.prelim === null || x.prelim === undefined, 'prelim should be Y/N or empty');
      assert(x.isPrimary === 'Y' || x.isPrimary === 'N', 'isPrimary should be Y/N');
      assert(typeof x.importance === 'number' && x.importance >= 0 && x.importance <= 5, 'importance within [0,5]');
    }
  }

  console.log('\n=== Guidance Tests ===');

  // -------- Graph Node based validation (existing behavior) --------
  runTest('Graph node: guidance refs and schema', () => {
    const g = new Graph(jagentId);
    g.addNode('guidance_test', makeGuidanceDataNode({ page: 0, page_size: 1, date: '2025-08-29' }));
    g.run();

    const refsGuidance = g.getRefsForOutput('guidance_test', 'guidance');
    assert(refsGuidance.length > 0, 'refsGuidance array is empty');
    const ref = refsGuidance[0];
    const expected = {
      id: '@arrays/data/stock/guidance/getGuidanceData',
      module_name: '@arrays/data/stock/guidance',
      module_display_name: 'Company Guidance',
      sdk_name: 'getGuidanceData',
      sdk_display_name: 'Corporate Guidance',
      source_name: 'Benzinga',
      source: 'https://docs.benzinga.com/benzinga-apis/calendar/get-guidance',
    };

    assert(ref.id === expected.id, 'ref.id mismatch for guidance');
    assert(ref.module_name === expected.module_name, 'ref.module_name mismatch for guidance');
    assert(ref.module_display_name === expected.module_display_name, 'ref.module_display_name mismatch for guidance');
    assert(ref.sdk_name === expected.sdk_name, 'ref.sdk_name mismatch for guidance');
    assert(ref.sdk_display_name === expected.sdk_display_name, 'ref.sdk_display_name mismatch for guidance');
    assert(ref.source_name === expected.source_name, 'ref.source_name mismatch for guidance');
    assert(ref.source === expected.source, 'ref.source mismatch for guidance');

    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'guidance_test', 'guidance', { last: '10' }), g.store);
    ts.init();
    assert(ts.data.length > 0, 'guidance empty');
    const x = ts.data[0];
    [
      'id', 'date', 'time', 'ticker', 'exchange', 'name', 'currency', 'period', 'periodYear', 'prelim', 'isPrimary',
      'epsType', 'epsGuidanceEst', 'epsGuidanceMax', 'epsGuidanceMin', 'epsGuidancePriorMax', 'epsGuidancePriorMin',
      'revenueGuidanceEst', 'revenueGuidanceMax', 'revenueGuidanceMin', 'revenueGuidancePriorMax',
      'revenueGuidancePriorMin', 'revenueType', 'importance', 'notes', 'updated'
    ].forEach((k) => {
      assert(k in x, 'missing guidance field: ' + k);
    });
  });

  // -------- Direct getGuidanceData tests (manual import) --------
  console.log('\n--- Direct getGuidanceData tests ---');

  // Happy path: defaults
  runTest('getGuidanceData: default params', () => {
    const res = getGuidanceData({});
    validateGuidanceStructure(res, {});
  });

  // Happy path: tickers + date range + importance + is_primary
  runTest('getGuidanceData: tickers AAPL,MSFT, Aug 2025, importance>=3, is_primary=Y', () => {
    const params = {
      tickers: 'AAPL,MSFT',
      date_from: '2025-08-01',
      date_to: '2025-08-31',
      importance: 3,
      page: 0,
      page_size: 20,
      is_primary: 'Y',
    };
    const res = getGuidanceData(params);
    validateGuidanceStructure(res, params);
    // If any results, ensure isPrimary filtering respected
    if (res.response.guidance.length > 0) {
      res.response.guidance.forEach((r) => {
        assert(r.isPrimary === 'Y', 'isPrimary should be Y when filtered');
      });
    }
  });

  // Boundary: page_size min
  runTest('getGuidanceData: boundary page_size=1', () => {
    const params = { page: 0, page_size: 1 };
    const res = getGuidanceData(params);
    validateGuidanceStructure(res, params);
    assert(res.response.guidance.length <= 1, 'guidance length should be <= 1');
  });

  // Boundary: page_size max
  runTest('getGuidanceData: boundary page_size=1000 (max)', () => {
    const params = { page: 0, page_size: 1000 };
    const res = getGuidanceData(params);
    validateGuidanceStructure(res, params);
    assert(res.response.guidance.length <= 1000, 'guidance length should be <= 1000');
  });

  // Boundary: page_size beyond max should cap at 1000
  runTest('getGuidanceData: boundary page_size=2000 (beyond max caps)', () => {
    const params = { page: 0, page_size: 2000 };
    const res = getGuidanceData(params);
    validateGuidanceStructure(res, params);
    if ('pageSize' in res.response) {
      assert(res.response.pageSize <= 1000, 'pageSize should be capped to <= 1000');
    }
    assert(res.response.guidance.length <= 1000, 'guidance length should be <= 1000');
  });

  // Boundary: page values
  runTest('getGuidanceData: boundary page=0', () => {
    const res = getGuidanceData({ page: 0, page_size: 5 });
    validateGuidanceStructure(res, { page_size: 5 });
  });

  runTest('getGuidanceData: boundary page large', () => {
    const res = getGuidanceData({ page: 100, page_size: 5 });
    validateGuidanceStructure(res, { page_size: 5 });
  });

  // Date filters: specific date
  runTest('getGuidanceData: specific date 2025-08-29', () => {
    const params = { date: '2025-08-29', page: 0, page_size: 5 };
    const res = getGuidanceData(params);
    validateGuidanceStructure(res, params);
    if (res.response.guidance.length > 0) {
      res.response.guidance.forEach((r) => assert(typeof r.date === 'string', 'date should be present'));
    }
  });

  // Date range: same day range
  runTest('getGuidanceData: date_from=date_to=2025-08-29', () => {
    const params = { date_from: '2025-08-29', date_to: '2025-08-29', page: 0, page_size: 5 };
    const res = getGuidanceData(params);
    validateGuidanceStructure(res, params);
  });

  // Updated timestamp filter
  runTest('getGuidanceData: updated minimal ("0")', () => {
    const params = { updated: '0', page: 0, page_size: 5 };
    const res = getGuidanceData(params);
    validateGuidanceStructure(res, params);
  });

  runTest('getGuidanceData: updated typical', () => {
    const params = { updated: '1700000000', page: 0, page_size: 5 };
    const res = getGuidanceData(params);
    validateGuidanceStructure(res, params);
  });

  // Enumerations: importance 0..5 coverage
  const IMPORTANCE_VALUES = [0, 1, 2, 3, 4, 5];
  for (const v of IMPORTANCE_VALUES) {
    runTest(`getGuidanceData: importance=${v}`, () => {
      const params = { importance: v, page: 0, page_size: 5 };
      const res = getGuidanceData(params);
      validateGuidanceStructure(res, params);
      if (res.response.guidance.length > 0) {
        res.response.guidance.forEach((r) => {
          assert(typeof r.importance === 'number', 'importance should be a number');
          assert(r.importance >= 0 && r.importance <= 5, 'importance within documented range');
        });
      }
    });
  }

  // Enumerations: is_primary Y, N, ALL coverage
  const IS_PRIMARY_VALUES = ['Y', 'N', 'ALL'];
  for (const s of IS_PRIMARY_VALUES) {
    runTest(`getGuidanceData: is_primary=${s}`, () => {
      const params = { is_primary: s, page: 0, page_size: 5 };
      const res = getGuidanceData(params);
      validateGuidanceStructure(res, params);
      if (res.response.guidance.length > 0) {
        if (s === 'Y' || s === 'N') {
          res.response.guidance.forEach((r) => assert(r.isPrimary === s, `isPrimary should be ${s}`));
        } else {
          res.response.guidance.forEach((r) => assert(r.isPrimary === 'Y' || r.isPrimary === 'N', 'isPrimary should be Y/N'));
        }
      }
    });
  }

  // Special values: tickers
  runTest('getGuidanceData: empty tickers string', () => {
    const res = getGuidanceData({ tickers: '', page: 0, page_size: 5 });
    validateGuidanceStructure(res, { page_size: 5 });
  });

  runTest('getGuidanceData: undefined tickers (omitted)', () => {
    const res = getGuidanceData({ page: 0, page_size: 5 });
    validateGuidanceStructure(res, { page_size: 5 });
  });

  runTest('getGuidanceData: null parameters handled (graceful or error)', () => {
    try {
      const res = getGuidanceData({
        page: null,
        page_size: null,
        date: null,
        date_from: null,
        date_to: null,
        tickers: null,
        importance: null,
        updated: null,
        is_primary: null,
      });
      // If returns, validate minimal structure
      validateGuidanceStructure(res);
    } catch (e) {
      // If throws, ensure it is a meaningful error
      assert(e && e.message, 'Should throw with a message for null parameters');
    }
  });

  // Special values: is_primary empty string and undefined
  runTest('getGuidanceData: is_primary empty string', () => {
    const res = getGuidanceData({ is_primary: '', page: 0, page_size: 5 });
    validateGuidanceStructure(res, { page_size: 5 });
  });

  runTest('getGuidanceData: updated empty string and undefined', () => {
    const res1 = getGuidanceData({ updated: '', page: 0, page_size: 5 });
    validateGuidanceStructure(res1, { page_size: 5 });
    const res2 = getGuidanceData({ page: 0, page_size: 5 });
    validateGuidanceStructure(res2, { page_size: 5 });
  });

  // Negative/invalid enum tests: expect error or failure
  runTest('getGuidanceData: invalid importance -1', () => {
    try {
      const res = getGuidanceData({ importance: -1, page: 0, page_size: 5 });
      // If API returns a result, assert it indicates failure
      assert(res.success === false || (res.response && Array.isArray(res.response.guidance)), 'Should fail or still return a structured response');
    } catch (e) {
      assert(e.message.includes('importance') || e.message.includes('Invalid') || e.message.includes('Error'), 'Should report invalid importance');
    }
  });

  runTest('getGuidanceData: invalid importance 6', () => {
    try {
      const res = getGuidanceData({ importance: 6, page: 0, page_size: 5 });
      assert(res.success === false || (res.response && Array.isArray(res.response.guidance)), 'Should fail or still return a structured response');
    } catch (e) {
      assert(e.message.includes('importance') || e.message.includes('Invalid') || e.message.includes('Error'), 'Should report invalid importance');
    }
  });

  runTest('getGuidanceData: invalid is_primary value', () => {
    try {
      const res = getGuidanceData({ is_primary: 'INVALID', page: 0, page_size: 5 });
      assert(res.success === false || (res.response && Array.isArray(res.response.guidance)), 'Should fail or still return structured response');
    } catch (e) {
      assert(e.message.includes('is_primary') || e.message.includes('Invalid') || e.message.includes('Error'), 'Should report invalid is_primary');
    }
  });

  // Print test summary
  console.log('\n=== Test Summary ===');
  console.log(`Total tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${totalTests - passedTests}`);
  console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

  if (passedTests === totalTests) {
    console.log('🎉 All tests passed!');
  } else {
    console.log('⚠️  Some tests failed. Please review the output above.');
  }

  return 0;
}

main();
