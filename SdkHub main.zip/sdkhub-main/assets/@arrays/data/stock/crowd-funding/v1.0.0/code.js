const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getCrowdFunding following the standardized pattern
const getCrowdFundingRef = {
    id: '@arrays/data/stock/crowd-funding/getCrowdFunding',
    module_name: '@arrays/data/stock/crowd-funding',
    module_display_name: 'Company Crowd Funding Calendar',
    sdk_name: 'getCrowdFunding',
    sdk_display_name: 'Company Crowd Funding Calendar',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/crowdfunding-offerings-rss-feed-api',
};

// Base description and dynamic description builder for getCrowdFunding (from doc)
const getCrowdFundingBaseDescription = "Retrieve SEC crowdfunding offerings";
function buildGetCrowdFundingCallDescription(actualParams = {}) {
    const parts = [getCrowdFundingBaseDescription];
    const filters = [];
    if (actualParams && actualParams.page !== undefined) {
        filters.push(`page ${actualParams.page}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getCrowdFunding(params) {
	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/crowdfunding/offerings';
	const keyValuePairs = Object.keys(params || {}).map((key) => {
		const value = params[key];
		return encodeURIComponent(key) + '=' + encodeURIComponent(value);
	});
	const queryString = keyValuePairs.join('&');
	const fullUrl = `${baseUrl}?${queryString}`;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

/**
 * Parse various timestamp string formats to epoch ms (UTC).
 * Supported:
 * - ISO 8601 strings parsable by Date.parse
 * - 'YYYY-MM-DD HH:mm:ss'
 * - 'YYYY-MM-DD'
 * - 'MM-DD-YYYY' or 'MM/DD/YYYY'
 */
function parseToMs(s) {
	if (s == null) return undefined;
	if (typeof s !== 'string') return undefined;

	// Try native Date.parse first (handles many ISO variants)
	const parsed = Date.parse(s);
	if (!Number.isNaN(parsed)) return parsed;

	// 'YYYY-MM-DD HH:mm:ss'
	let m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/);
	if (m) {
		const y = +m[1];
		const mo = +m[2] - 1;
		const d = +m[3];
		const hh = +m[4];
		const mm = +m[5];
		const ss = +m[6];
		return Date.UTC(y, mo, d, hh, mm, ss, 0);
	}

	// 'YYYY-MM-DD'
	m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
	if (m) {
		const y = +m[1];
		const mo = +m[2] - 1;
		const d = +m[3];
		return Date.UTC(y, mo, d, 0, 0, 0, 0);
	}

	// 'MM-DD-YYYY' or 'MM/DD/YYYY'
	m = s.match(/^(\d{2})[-/](\d{2})[-/](\d{4})$/);
	if (m) {
		const mo = +m[1] - 1;
		const d = +m[2];
		const y = +m[3];
		return Date.UTC(y, mo, d, 0, 0, 0, 0);
	}

	return undefined;
}

function makeCrowdFundingNode(params) {
	return {
		inputs: {
			crowd_funding_raw: () => getCrowdFunding(params),
		},
		outputs: {
			crowdfunding_offerings_snapshot: {
				name: 'crowdfunding_offerings_snapshot',
				description: 'Single snapshot with all crowdfunding offerings data',
				fields: [
					{ name: 'date', type: 'number', description: 'snapshot time in ms since epoch (UTC)' },
					{
						name: 'offerings',
						type: 'array',
						description: 'all crowdfunding offering records',
						fields: [
							{ name: 'cik', type: 'string', description: 'SEC CIK number' },
							{ name: 'company_name', type: 'string', description: 'company name' },
							{ name: 'url', type: 'string', description: 'SEC filing URL (if available)' },
							{ name: 'form_type', type: 'string', description: 'form type (e.g., C, C/A, C-U)' },
							{ name: 'form_signification', type: 'string', description: 'form description' },
							{ name: 'industry', type: 'string', description: 'industry' },
							{ name: 'filling_date', type: 'string', description: 'filing date in ISO 8601 format' },
							{ name: 'offering_date', type: 'string', description: 'offering reference date' },
							{ name: 'name_of_issuer', type: 'string', description: 'issuer name' },
							{ name: 'legal_status_form', type: 'string', description: 'legal form' },
							{ name: 'jurisdiction_organization', type: 'string', description: 'jurisdiction of organization' },
							{ name: 'issuer_street', type: 'string', description: 'issuer street address' },
							{ name: 'issuer_city', type: 'string', description: 'issuer city' },
							{ name: 'issuer_state_or_country', type: 'string', description: 'issuer state or country code' },
							{ name: 'issuer_zip_code', type: 'string', description: 'issuer ZIP/postal code' },
							{ name: 'issuer_website', type: 'string', description: 'issuer website' },
							{ name: 'intermediary_company_name', type: 'string', description: 'intermediary company name' },
							{ name: 'security_offered_type', type: 'string', description: 'security type' },
							{ name: 'number_of_security_offered', type: 'number', description: 'number of securities offered' },
							{ name: 'offering_price', type: 'number', description: 'offering price per security' },
							{ name: 'offering_amount', type: 'number', description: 'target offering amount' },
							{ name: 'maximum_offering_amount', type: 'number', description: 'maximum offering amount' },
							{ name: 'offering_deadline_date', type: 'string', description: 'offering deadline date' },
							{ name: 'current_number_of_employees', type: 'number', description: 'current employee count' },
							{ name: 'revenue_most_recent_fiscal_year', type: 'number', description: 'most recent revenue' },
							{ name: 'net_income_most_recent_fiscal_year', type: 'number', description: 'most recent net income' },
							{ name: 'acceptance_time', type: 'string', description: 'SEC acceptance timestamp' },
						],
					},
				],
				ref: createReferenceWithTitle(getCrowdFundingRef, params, buildGetCrowdFundingCallDescription),
			},
		},
		run: (inputs) => {
			const raw = inputs.crowd_funding_raw;
			const offerings = raw && raw.data && Array.isArray(raw.data.data) ? raw.data.data : [];
			if (!Array.isArray(offerings)) {
				throw new Error('Crowdfunding offerings is invalid');
			}

			if (offerings.length === 0) {
				throw new Error('No offerings data available');
			}

			// 1) 选定一个确定时间 - 使用 acceptance_time
			let snapshotTime = Number.NEGATIVE_INFINITY;
			for (const o of offerings) {
				const t = parseToMs(o.acceptance_time);
				if (Number.isFinite(t) && t > snapshotTime) snapshotTime = t;
			}
			if (!Number.isFinite(snapshotTime)) {
				throw new Error('No valid acceptance_time found in offerings data');
			}

			// 2) Map all offerings into the nested array
			const offeringsData = offerings.map((o) => ({
				cik: o.cik,
				company_name: o.company_name,
				url: o.url,
				form_type: o.form_type,
				form_signification: o.form_signification,
				industry: o.industry,
				filing_date: o.filing_date,
				offering_date: o.date,
				name_of_issuer: o.name_of_issuer,
				legal_status_form: o.legal_status_form,
				jurisdiction_organization: o.jurisdiction_organization,
				issuer_street: o.issuer_street,
				issuer_city: o.issuer_city,
				issuer_state_or_country: o.issuer_state_or_country,
				issuer_zip_code: o.issuer_zip_code,
				issuer_website: o.issuer_website,
				intermediary_company_name: o.intermediary_company_name,
				security_offered_type: o.security_offered_type,
				number_of_security_offered: o.number_of_security_offered,
				offering_price: o.offering_price,
				offering_amount: o.offering_amount,
				maximum_offering_amount: o.maximum_offering_amount,
				offering_deadline_date: o.offering_deadline_date,
				current_number_of_employees: o.current_number_of_employees,
				revenue_most_recent_fiscal_year: o.revenue_most_recent_fiscal_year,
				net_income_most_recent_fiscal_year: o.net_income_most_recent_fiscal_year,
				acceptance_time: o.acceptance_time,
			}));

			// 3) 返回单条快照（外层唯一 date，内层嵌套数组）
			return {
				crowdfunding_offerings_snapshot: [
					{
						date: snapshotTime,
						offerings: offeringsData,
					},
				],
			};
		},
	};
}

function getRefs() {
	return [
		getCrowdFundingRef,
	];
}

module.exports = {
	getCrowdFunding,
	makeCrowdFundingNode,
	getRefs,
};
