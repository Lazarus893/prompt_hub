function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeCrowdFundingNode } = require('@arrays/data/stock/crowd-funding:v1.0.0');

    // Smoke test - basic functionality test
    const g = new Graph(jagentId);
    g.addNode('crowdfunding_offerings_smoke', makeCrowdFundingNode({ page: 0 }));
    g.run();

    // Mock test - using sample data to avoid network dependency
    const nodeCfg = makeCrowdFundingNode({ page: 0 });

    // Override input with mock data that matches the API response structure
    nodeCfg.inputs.crowd_funding_raw = () => ({
        data: {
            count: 2,
            data: [
                {
                    cik: '0002046311',
                    company_name: 'Hoot Health Inc.',
                    form_type: 'C',
                    form_signification: 'Offering Statement',
                    filling_date: '2025-09-19T00:00:00.000Z',
                    date: '05-21-2021',
                    name_of_issuer: 'Hoot Health Inc.',
                    legal_status_form: 'Corporation',
                    jurisdiction_organization: 'NJ',
                    issuer_street: '500 STATE ROUTE 33, SUITE 2I',
                    issuer_city: 'MILLSTONE',
                    issuer_state_or_country: 'NJ',
                    issuer_zip_code: '08535',
                    issuer_website: 'https://gethoot.com/',
                    intermediary_company_name: 'PicMii Crowdfunding LLC',
                    security_offered_type: 'Common Stock',
                    number_of_security_offered: 4000,
                    offering_price: 2.5,
                    offering_amount: 10000,
                    maximum_offering_amount: 1235000,
                    offering_deadline_date: '12-31-2025',
                    current_number_of_employees: 9,
                    revenue_most_recent_fiscal_year: 587867,
                    net_income_most_recent_fiscal_year: -165306,
                    acceptance_time: '2025-09-19 15:54:35',
                },
                {
                    cik: '0002043459',
                    company_name: 'Cizzle Bio, Inc.',
                    form_type: 'C-U',
                    form_signification: 'Progress Update',
                    filling_date: '2025-09-19T00:00:00.000Z',
                    date: '02-23-2024',
                    name_of_issuer: 'Cizzle Bio, Inc.',
                    legal_status_form: 'Corporation',
                    jurisdiction_organization: 'TX',
                    issuer_street: '2040 BABCOCK ROAD',
                    issuer_city: 'SAN ANTONIO',
                    issuer_state_or_country: 'TX',
                    issuer_zip_code: '78229',
                    issuer_website: 'https://cizzlebio.com',
                    intermediary_company_name: 'DEALMAKER SECURITIES LLC',
                    security_offered_type: 'Other',
                    number_of_security_offered: 25426,
                    offering_price: 0.38,
                    offering_amount: 10000.05,
                    maximum_offering_amount: 4999999.7,
                    offering_deadline_date: '04-15-2026',
                    current_number_of_employees: 0,
                    revenue_most_recent_fiscal_year: 0,
                    net_income_most_recent_fiscal_year: -1909353,
                    acceptance_time: '2025-09-19 14:54:14',
                },
            ],
        },
    });

    const g2 = new Graph(jagentId);
    g2.addNode('crowdfunding_offerings_mock', nodeCfg);
    g2.run();

    // Validate mock data output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'crowdfunding_offerings_mock', 'crowdfunding_offerings_snapshot', { last: '5' }), g2.store);
    ts.init();

    if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('snapshot empty');
    const snap = ts.data[0];
    ['date', 'offerings'].forEach((k) => {
        if (!(k in snap)) throw new Error('missing snapshot field: ' + k);
    });
    if (!Array.isArray(snap.offerings) || snap.offerings.length !== 2) throw new Error('offerings length must be 2 in mock');

    const o0 = snap.offerings[0];
    ['cik', 'company_name', 'form_type', 'offering_amount', 'acceptance_time'].forEach((k) => {
        if (!(k in o0)) throw new Error('missing offering field: ' + k);
    });

    // Validate smoke test output
    const tsSmoke = new TimeSeries(new TimeSeriesUri(jagentId, 'crowdfunding_offerings_smoke', 'crowdfunding_offerings_snapshot', { last: '5' }), g.store);
    tsSmoke.init();
    if (!Array.isArray(tsSmoke.data)) throw new Error('smoke test data must be an array');
    if (tsSmoke.data.length > 0) {
        const r = tsSmoke.data[0];
        if (typeof r.date !== 'number') throw new Error('smoke.date must be number(ms)');
        if (!Array.isArray(r.offerings)) throw new Error('smoke.offerings must be array');
        if (r.offerings.length > 0) {
            const offering = r.offerings[0];
            if (typeof offering.company_name !== 'string') throw new Error('smoke.offering.company_name must be string');
        }
    }

    // Validate refs for outputs
    const refsCrowd = g2.getRefsForOutput('crowdfunding_offerings_mock', 'crowdfunding_offerings_snapshot');
    if (refsCrowd.length > 0) {
        const ref = refsCrowd[0];
        const expected = {
            id: '@arrays/data/stock/crowd-funding/getCrowdFunding',
            module_name: '@arrays/data/stock/crowd-funding',
            module_display_name: 'Company Crowd Funding Calendar',
            sdk_name: 'getCrowdFunding',
            sdk_display_name: 'Company Crowd Funding Calendar',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/crowdfunding-offerings-rss-feed-api',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for crowdfunding_offerings_snapshot');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for crowdfunding_offerings_snapshot');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for crowdfunding_offerings_snapshot');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for crowdfunding_offerings_snapshot');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for crowdfunding_offerings_snapshot');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for crowdfunding_offerings_snapshot');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for crowdfunding_offerings_snapshot');
    } else {
        throw new Error('Assertion failed: refsCrowd array is empty.');
    }

    // ============ Direct getCrowdFunding Tests (Manual Import) ============
    testGetCrowdFundingDirect();

    return 0;
}

function testGetCrowdFundingDirect() {
    console.log('\n=== Testing getCrowdFunding (Direct API) ===');
    const { getCrowdFunding } = require('@arrays/data/stock/crowd-funding:v1.0.0'); // Manual import per requirement

    let totalTests = 0;
    let passedTests = 0;

    // lightweight assert helper to avoid external deps
    function assert(cond, msg) { if (!cond) throw new Error(msg || 'Assertion failed'); }
    function runTest(name, fn) {
        totalTests++;
        try {
            fn();
            console.log(`✅ ${name}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${name}: ${e.message}`);
        }
    }

    function validateOffering(offering) {
        assert(offering && typeof offering === 'object', 'Offering must be an object');
        assert(typeof offering.company_name === 'string' && offering.company_name.length > 0, 'company_name must be non-empty string');
        assert(typeof offering.form_type === 'string' && offering.form_type.length > 0, 'form_type must be non-empty string');

        // Enum coverage: form_type and over_subscription_accepted
        const allowedFormTypes = new Set(['C', 'C/A', 'C-U', 'C-AR', 'C-TR', 'C-AR/A', 'C/U', 'C-U/A']);
        assert(allowedFormTypes.has(offering.form_type) || /^C/.test(offering.form_type), `Unexpected form_type: ${offering.form_type}`);

        if (offering.over_subscription_accepted !== undefined && offering.over_subscription_accepted !== null) {
            assert(
                offering.over_subscription_accepted === 'Y' || offering.over_subscription_accepted === 'N',
                `over_subscription_accepted must be 'Y' or 'N', got: ${offering.over_subscription_accepted}`
            );
        }

        // Numeric fields validation when present (nullable allowed per doc)
        const numericFields = [
            'number_of_security_offered', 'offering_price', 'offering_amount', 'maximum_offering_amount',
            'current_number_of_employees', 'total_asset_most_recent_fiscal_year', 'total_asset_prior_fiscal_year',
            'cash_and_cash_equivalent_most_recent_fiscal_year', 'cash_and_cash_equivalent_prior_fiscal_year',
            'accounts_receivable_most_recent_fiscal_year', 'accounts_receivable_prior_fiscal_year',
            'short_term_debt_most_recent_fiscal_year', 'short_term_debt_prior_fiscal_year',
            'long_term_debt_most_recent_fiscal_year', 'long_term_debt_prior_fiscal_year',
            'revenue_most_recent_fiscal_year', 'revenue_prior_fiscal_year',
            'cost_goods_sold_most_recent_fiscal_year', 'cost_goods_sold_prior_fiscal_year',
            'taxes_paid_most_recent_fiscal_year', 'taxes_paid_prior_fiscal_year',
            'net_income_most_recent_fiscal_year', 'net_income_prior_fiscal_year'
        ];
        for (const f of numericFields) {
            if (offering[f] !== undefined && offering[f] !== null) {
                assert(typeof offering[f] === 'number' && !Number.isNaN(offering[f]), `${f} must be a valid number when present`);
            }
        }

        // Basic type checks for common string fields if present
        const stringFields = [
            'filling_date', 'date', 'legal_status_form', 'jurisdiction_organization', 'issuer_city',
            'issuer_state_or_country', 'issuer_zip_code', 'issuer_website', 'intermediary_company_name',
            'security_offered_type', 'offering_deadline_date', 'acceptance_time'
        ];
        for (const s of stringFields) {
            if (offering[s] !== undefined && offering[s] !== null) {
                assert(typeof offering[s] === 'string', `${s} must be string when present`);
            }
        }
    }

    function validateAPIResponse(result) {
        assert(result && typeof result === 'object', 'Result should be an object');
        assert('success' in result, 'Result should include success flag');
        if (result.success) {
            assert(result.data && typeof result.data === 'object', 'data should be an object');
            assert('count' in result.data, 'data.count missing');
            // data.data may be null/undefined when page is out of range
            if (result.data.data !== null && result.data.data !== undefined) {
                assert(Array.isArray(result.data.data), 'data.data should be an array when present');
                const arr = result.data.data;
                if (arr.length > 0) {
                    validateOffering(arr[0]);
                }
            }
        }
    }

    // ============ Happy Path ============
    runTest('getCrowdFunding() happy path', () => {
        const res = getCrowdFunding();
        validateAPIResponse(res);
    });

    runTest('getCrowdFunding({ page: 0 }) happy path', () => {
        const res = getCrowdFunding({ page: 0 });
        validateAPIResponse(res);
    });

    // ============ Boundary Value Analysis ============
    for (const p of [0, 1, 2, 10, 1000]) {
        runTest(`Boundary: page=${p}`, () => {
            const res = getCrowdFunding({ page: p });
            validateAPIResponse(res);
        });
    }

    // ============ Special/Invalid Values Handling ============
    const specialValues = [
        -1, 1.5, Number.MAX_SAFE_INTEGER, 99999, null, undefined, '0', '', NaN, {}, []
    ];

    for (const val of specialValues) {
        runTest(`Special value for page: ${String(val)}`, () => {
            try {
                const params = (val === undefined) ? undefined : { page: val };
                const res = params ? getCrowdFunding(params) : getCrowdFunding();
                // Either handled gracefully or throws; both acceptable
                validateAPIResponse(res);
            } catch (e) {
                // Acceptable path for invalid inputs: function may throw
                assert(e && e.message, 'Should throw an error or handle gracefully');
            }
        });
    }

    // Print summary
    console.log('\n--- getCrowdFunding Direct Test Summary ---');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

main();
