const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

function getEconomicIndicators(params) {
	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/economic/indicators';

	const keyValuePairs = Object.keys(params || {}).map((k) => {
		const v = params[k];
		return encodeURIComponent(k) + '=' + encodeURIComponent(v);
	});
	const queryString = keyValuePairs.join('&');
	const fullUrl = queryString ? `${baseUrl}?${queryString}` : baseUrl;

	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

// Reference metadata for getEconomicIndicators, derived from tool.json
const getEconomicIndicatorsRef = {
  id: '@arrays/data/stock/economic/indicators/getEconomicIndicators',
  module_name: '@arrays/data/stock/economic/indicators',
  module_display_name: 'Global Economic Indicators',
  sdk_name: 'getEconomicIndicators',
  sdk_display_name: 'Global Economic Indicators',
  source_name: 'Financial Modeling Prep',
  source: 'https://site.financialmodelingprep.com/developer/docs/stable/economics-indicators',
};

// Base description (concise summary from doc) for getEconomicIndicators
const getEconomicIndicatorsBaseDesc = 'Access real-time and historical economic indicators';

// Build a dynamic call description for getEconomicIndicators based on actual params
function buildGetEconomicIndicatorsCallDescription(actualParams = {}) {
	const parts = [getEconomicIndicatorsBaseDesc];

	const filters = [];
	if (actualParams.name) {
		filters.push(`Name: ${actualParams.name}`);
	}
	if (actualParams.start_time && actualParams.end_time) {
		filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
	} else if (actualParams.start_time) {
		filters.push(`Time from: ${actualParams.start_time}`);
	} else if (actualParams.end_time) {
		filters.push(`Time to: ${actualParams.end_time}`);
	}

	if (filters.length > 0) {
		parts.push(`(${filters.join(', ')})`);
	}

	return parts.join(' ').trim();
}

// Helper to create a reference object with a dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function makeEconomicIndicatorsNode(params) {
	return {
		inputs: {
			economic_indicators_raw: () => getEconomicIndicators(params),
		},
		outputs: {
			indicators_by_date: {
				name: 'indicators_by_date',
				description: 'Economic indicators grouped by date (one record per day).',
				fields: [
					{
						name: 'date',
						type: 'number',
						description: 'day start time ms (UTC)',
					},
					{
						name: 'records',
						type: 'array',
						description: 'indicator records on this date',
						fields: [
							{ name: 'id', type: 'number', description: 'indicator record id' },
							{ name: 'name', type: 'string', description: 'indicator name' },
							{ name: 'value', type: 'number', description: 'indicator value' },
							{ name: 'date', type: 'string', description: 'YYYY-MM-DD' },
							{ name: 'created_at', type: 'number', description: 'creation time ms (UTC)' },
							{ name: 'updated_at', type: 'number', description: 'last update time ms (UTC)' },
						],
					},
				],
				ref: createReferenceWithTitle(
					getEconomicIndicatorsRef,
					params,
					buildGetEconomicIndicatorsCallDescription
				),
			},
		},
		run: (inputs) => {
			const raw = inputs.economic_indicators_raw;
			if (!raw || raw.success !== true || !Array.isArray(raw.response)) {
				throw new Error('Economic indicators raw data is invalid');
			}
			const indicators = raw.response;

			// Group by day (UTC) and emit one record per day to avoid duplicate dates
			const byDay = new Map(); // key: dayMs, value: array of records
			for (const i of indicators) {
				if (!i || typeof i.date !== 'string') continue;
				const parts = i.date.split('-');
				if (parts.length !== 3) continue;
				const y = parseInt(parts[0], 10);
				const m = parseInt(parts[1], 10);
				const d = parseInt(parts[2], 10);
				if (!Number.isFinite(y) || !Number.isFinite(m) || !Number.isFinite(d)) continue;
				const dayMs = Date.UTC(y, m - 1, d, 0, 0, 0, 0);
				if (!byDay.has(dayMs)) byDay.set(dayMs, []);
				byDay.get(dayMs).push({
					id: i.id,
					name: i.name,
					value: i.value,
					date: i.date,
					created_at: Number.isFinite(Date.parse(i.created_at)) ? Date.parse(i.created_at) : undefined,
					updated_at: Number.isFinite(Date.parse(i.updated_at)) ? Date.parse(i.updated_at) : undefined,
				});
			}

			const out = Array.from(byDay.entries())
				.sort((a, b) => a[0] - b[0]) // ascending by date
				.map(([dayMs, records]) => ({
					date: dayMs,
					records,
				}));

			return { indicators_by_date: out };
		},
	};
}

function getRefs() {
	return [getEconomicIndicatorsRef];
}

module.exports = {
	getEconomicIndicators,
	makeEconomicIndicatorsNode,
	getRefs,
};
