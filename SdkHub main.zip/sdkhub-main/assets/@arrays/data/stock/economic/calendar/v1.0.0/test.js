function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
}

function testGetEconomicCalendar() {
    console.log('\n=== Testing getEconomicCalendar (Direct SDK) ===');

    const { getEconomicCalendar } = require('@arrays/data/stock/economic/calendar:v1.0.0'); // manual import for get* fn

    // Reuse a known-good window from the node test to ensure data availability
    const startSec = 1751882292;
    const endSec = 1751887292;

    const ALLOWED_IMPACTS = new Set(['High', 'Medium', 'Low']);

    let totalTests = 0;
    let passedTests = 0;

    function runTest(name, fn) {
        totalTests++;
        try {
            fn();
            console.log(`✅ ${name}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${name}: ${e.message}`);
        }
    }

    function isEmptyOrFailure(res) {
        if (!res || typeof res !== 'object') return false;
        if (res.success === false) return true;
        if (typeof res.total === 'number' && res.total === 0) return true;
        if (Array.isArray(res.response) && res.response.length === 0) return true;
        return false;
    }

    // ============ Happy Path Tests ============
    runTest('basic shape and totals', () => {
        const res = getEconomicCalendar({ start_time: startSec, end_time: endSec });
        assert(res && typeof res === 'object', 'Should return an object');
        assert(typeof res.success === 'boolean', 'success should be a boolean');
        assert(Array.isArray(res.response), 'response should be an array');
        assert(typeof res.total === 'number', 'total should be a number');
        assert(res.total === res.response.length, 'total should equal response.length');
    });

    runTest('event objects required fields and types', () => {
        const res = getEconomicCalendar({ start_time: startSec, end_time: endSec });
        const events = res.response;
        if (events.length === 0) {
            console.log('No events in the window; skipping field checks');
            return;
        }
        const sample = events[0];
        // Required fields
        ['id', 'date', 'country', 'event', 'currency', 'impact', 'unit', 'created_at', 'updated_at'].forEach((k) => {
            assert(k in sample, `Missing required field ${k}`);
        });
        assert(typeof sample.id === 'number', 'id should be number');
        assert(typeof sample.date === 'string', 'date should be string');
        assert(!isNaN(Date.parse(sample.date)), 'date should be ISO parseable');
        assert(typeof sample.country === 'string' && sample.country.length > 0, 'country should be non-empty string');
        assert(typeof sample.event === 'string' && sample.event.length > 0, 'event should be non-empty string');
        assert(typeof sample.currency === 'string' && sample.currency.length > 0, 'currency should be non-empty string');
        assert(typeof sample.impact === 'string' && ALLOWED_IMPACTS.has(sample.impact), 'impact should be one of High/Medium/Low');
        assert(typeof sample.unit === 'string', 'unit should be string');
        assert(typeof sample.created_at === 'string' && !isNaN(Date.parse(sample.created_at)), 'created_at should be ISO string');
        assert(typeof sample.updated_at === 'string' && !isNaN(Date.parse(sample.updated_at)), 'updated_at should be ISO string');

        // Optional numeric fields if present
        ['previous', 'estimate', 'actual', 'change', 'change_percentage'].forEach((opt) => {
            if (opt in sample && sample[opt] != null) {
                assert(typeof sample[opt] === 'number', `${opt} should be number when present`);
            }
        });
    });

    runTest('impact enum coverage and validation across all events', () => {
        const res = getEconomicCalendar({ start_time: startSec, end_time: endSec });
        const seen = new Set();
        for (const ev of res.response) {
            assert(ALLOWED_IMPACTS.has(ev.impact), `Unexpected impact value: ${ev.impact}`);
            seen.add(ev.impact);
        }
        // Log coverage info (do not force presence of all to avoid flakiness)
        console.log('Impact values observed in window:', Array.from(seen).join(', ') || '(none)');
    });

    runTest('fuzzy event filter: generic substring', () => {
        // Use a common macro indicator term; only validate shape to avoid flakiness
        const res = getEconomicCalendar({ start_time: startSec, end_time: endSec, event: 'CPI' });
        assert(res && typeof res === 'object', 'Should return an object with fuzzy event');
        assert(Array.isArray(res.response), 'response should be an array with fuzzy event');
        assert(typeof res.total === 'number', 'total should be number with fuzzy event');
    });

    runTest('event filter omitted (undefined) and empty string', () => {
        const res1 = getEconomicCalendar({ start_time: startSec, end_time: endSec });
        assert(res1 && typeof res1 === 'object', 'undefined event: should succeed');
        const res2 = getEconomicCalendar({ start_time: startSec, end_time: endSec, event: '' });
        assert(res2 && typeof res2 === 'object', 'empty string event: should succeed');
    });

    // ============ Boundary Value Analysis ============
    runTest('start_time == end_time (zero-length window)', () => {
        const res = getEconomicCalendar({ start_time: startSec, end_time: startSec });
        assert(res && typeof res === 'object', 'Should return object even for zero-length window');
        if ('response' in res && Array.isArray(res.response)) {
            // acceptable; may be empty or non-empty based on provider behavior
            assert(typeof res.total === 'number', 'total should be number');
        } // else: acceptable if implementation omits response when window is zero
    });

    runTest('end_time < start_time should error', () => {
        try {
            const res = getEconomicCalendar({ start_time: endSec, end_time: startSec });
            // If no exception, it should indicate failure or return empty
            assert(isEmptyOrFailure(res), 'Should return failure or empty set for reversed window');
        } catch (e) {
            // also acceptable if implementation throws
            assert(e.message.includes('Error') || e.message.includes('invalid') || e.message.includes('start_time'), 'Should error for reversed window');
        }
    });

    // ============ Special Values Tests ============
    runTest('missing start_time should error', () => {
        try {
            const res = getEconomicCalendar({ end_time: endSec });
            assert(isEmptyOrFailure(res), 'Should indicate failure or empty for missing start_time');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('required') || e.message.includes('start_time'), 'Should error for missing start_time');
        }
    });

    runTest('missing end_time should error', () => {
        try {
            const res = getEconomicCalendar({ start_time: startSec });
            assert(isEmptyOrFailure(res), 'Should indicate failure or empty for missing end_time');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('required') || e.message.includes('end_time'), 'Should error for missing end_time');
        }
    });

    runTest('null start_time and end_time should error', () => {
        try {
            const res = getEconomicCalendar({ start_time: null, end_time: null });
            assert(isEmptyOrFailure(res), 'Should indicate failure or empty for null times');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('invalid'), 'Should error for null times');
        }
    });

    runTest('non-number time types should error', () => {
        try {
            const res = getEconomicCalendar({ start_time: '1751882292', end_time: '1751887292' });
            assert(isEmptyOrFailure(res), 'Should indicate failure or empty for non-number times');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('number') || e.message.includes('invalid'), 'Should error for non-number times');
        }
    });

    runTest('zero/negative timestamps handling', () => {
        try {
            const res1 = getEconomicCalendar({ start_time: 0, end_time: 1 });
            assert(res1 && typeof res1 === 'object', 'Zero timestamp: should return object or be handled');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('invalid') || e.message.includes('range'), 'Zero timestamp: acceptable to throw error');
        }
        try {
            const res2 = getEconomicCalendar({ start_time: -100, end_time: 1 });
            assert(res2 && typeof res2 === 'object', 'Negative timestamp: should return object or be handled');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('invalid') || e.message.includes('range'), 'Negative timestamp: acceptable to throw error');
        }
    });

    runTest('event: null handled gracefully (either error or success)', () => {
        try {
            const res = getEconomicCalendar({ start_time: startSec, end_time: endSec, event: null });
            assert(res && typeof res === 'object', 'Should return object when event=null');
        } catch (e) {
            // Acceptable if implementation chooses to reject null
            assert(e.message.includes('Error') || e.message.includes('invalid'), 'Should either succeed or error clearly for null event');
        }
    });

    // Print test summary
    console.log('\n=== getEconomicCalendar Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function testNodeIntegration() {
    console.log('\n=== Testing Node Integration (Graph) ===');
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeEconomicCalendarNode } = require('@arrays/data/stock/economic/calendar:v1.0.0');

    // Use a known-good window from dev sample (should also exist on prod)
    const startSec = 1751882292;
    const nowSec = 1751887292;

    const g = new Graph(jagentId);
    g.addNode(
        'eco_events_test',
        makeEconomicCalendarNode({
            start_time: startSec,
            end_time: nowSec,
        })
    );

    g.run();

    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'eco_events_test', 'economic_events', { last: '100' }), g.store);
    ts.init();

    if (!ts.data.length) throw new Error('economic_events empty');
    const row = ts.data[0];
    ['date', 'events'].forEach((k) => {
        if (!(k in row)) throw new Error('missing row field: ' + k);
    });
    if (!Array.isArray(row.events) || !row.events.length) throw new Error('events empty');

    const e = row.events[0];
    ['id', 'country', 'event', 'currency', 'impact', 'unit', 'change', 'change_percentage', 'previous', 'estimate', 'actual', 'created_at', 'updated_at'].forEach((k) => {
        if (!(k in e)) throw new Error('missing event field: ' + k);
    });

    // Validate refs for economic_events output
    const refsEconomicEvents = g.getRefsForOutput('eco_events_test', 'economic_events');
    if (refsEconomicEvents.length > 0) {
        const ref = refsEconomicEvents[0];
        const expected = {
            id: '@arrays/data/stock/economic/calendar/getEconomicCalendar',
            module_name: '@arrays/data/stock/economic/calendar',
            module_display_name: 'Global Economic Calendar',
            sdk_name: 'getEconomicCalendar',
            sdk_display_name: 'Global Economic Calendar',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stable/economics-calendar',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for economic_events');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for economic_events');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for economic_events');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for economic_events');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for economic_events');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for economic_events');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for economic_events');
    } else {
        throw new Error('Assertion failed: refsEconomicEvents array is empty.');
    }
}

function main() {
    testGetEconomicCalendar();
    testNodeIntegration();
    return 0;
}

main();
