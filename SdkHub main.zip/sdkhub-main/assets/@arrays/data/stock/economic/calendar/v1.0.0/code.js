const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getEconomicCalendar, sourced from tool.json
const getEconomicCalendarRef = {
    id: "@arrays/data/stock/economic/calendar/getEconomicCalendar",
    module_name: "@arrays/data/stock/economic/calendar",
    module_display_name: "Global Economic Calendar",
    sdk_name: "getEconomicCalendar",
    sdk_display_name: "Global Economic Calendar",
    source_name: "Financial Modeling Prep",
    source: "https://site.financialmodelingprep.com/developer/docs/stable/economics-calendar",
};

// Base description for getEconomicCalendar, derived from doc
const getEconomicCalendarBaseDesc = "Get economic calendar events";

// Dynamic description builder for getEconomicCalendar
function buildGetEconomicCalendarCallDescription(actualParams = {}) {
    const parts = [getEconomicCalendarBaseDesc];

    const filters = [];

    if (actualParams.start_time && actualParams.end_time) {
        filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
    } else if (actualParams.start_time) {
        filters.push(`Time from: ${actualParams.start_time}`);
    } else if (actualParams.end_time) {
        filters.push(`Time to: ${actualParams.end_time}`);
    }

    if (actualParams.event) {
        filters.push(`Event: ${actualParams.event}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getEconomicCalendar(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/economic/calendar';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function makeEconomicCalendarNode(params) {
    return {
        inputs: {
            economic_calendar_raw: () => getEconomicCalendar(params),
        },
        outputs: {
            economic_events: {
                name: 'economic_events',
                description: 'Economic calendar events grouped by exact event time; one record per event timestamp.',
                fields: [
                    { name: 'date', type: 'number', description: 'event time ms (UTC)' },
                    {
                        name: 'events',
                        type: 'array',
                        description: 'events occurring at this timestamp',
                        fields: [
                            { name: 'id', type: 'number', description: 'event ID' },
                            { name: 'country', type: 'string', description: 'country code' },
                            { name: 'event', type: 'string', description: 'event name' },
                            { name: 'currency', type: 'string', description: 'currency code' },
                            { name: 'impact', type: 'string', description: 'High/Medium/Low' },
                            { name: 'unit', type: 'string', description: 'unit of measurement' },
                            { name: 'change', type: 'number', description: 'absolute change' },
                            { name: 'change_percentage', type: 'number', description: 'percentage change' },
                            { name: 'previous', type: 'number', description: 'previous value' },
                            { name: 'estimate', type: 'number', description: 'estimated value' },
                            { name: 'actual', type: 'number', description: 'actual value' },
                            { name: 'created_at', type: 'number', description: 'creation time ms' },
                            { name: 'updated_at', type: 'number', description: 'last update time ms' },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getEconomicCalendarRef, params, buildGetEconomicCalendarCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.economic_calendar_raw;
            if (!raw || raw.success !== true || !Array.isArray(raw.response)) {
                throw new Error('Economic calendar raw data is invalid');
            }
            const events = raw.response;

            // Group events by exact event time (ms)
            const byTs = new Map();
            for (const e of events) {
                const ts = Number.isFinite(Date.parse(e.date)) ? Date.parse(e.date) : NaN;
                if (!Number.isFinite(ts)) continue; // skip records without valid timestamp

                const item = {
                    id: e.id,
                    country: e.country,
                    event: e.event,
                    currency: e.currency,
                    impact: e.impact,
                    unit: e.unit,
                    change: e.change,
                    change_percentage: e.change_percentage,
                    previous: e.previous,
                    estimate: e.estimate,
                    actual: e.actual,
                    created_at: Number.isFinite(Date.parse(e.created_at)) ? Date.parse(e.created_at) : undefined,
                    updated_at: Number.isFinite(Date.parse(e.updated_at)) ? Date.parse(e.updated_at) : undefined,
                };

                if (!byTs.has(ts)) byTs.set(ts, []);
                byTs.get(ts).push(item);
            }

            const timestamps = Array.from(byTs.keys()).sort((a, b) => a - b);
            const out = timestamps.map((t) => ({
                date: t,
                events: byTs.get(t),
            }));

            return { economic_events: out };
        },
    };
}

function getRefs() {
    return [
        getEconomicCalendarRef,
    ];
}

module.exports = {
    getEconomicCalendar,
    makeEconomicCalendarNode,
    getRefs,
};