'use strict';

// Simple assert helper to avoid external deps
function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
}

function testMakeNode() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeCommoditySymbolNode } = require('@arrays/data/stock/macro/commodity-symbol:v1.0.0');

    const graph = new Graph(jagentId);
    graph.addNode('commodity_symbols', makeCommoditySymbolNode({}));

    graph.run();

    // Materialize and validate the commodity symbol list output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'commodity_symbols', 'commodity_symbol_list', { last: '1' }), graph.store);
    ts.init();

    if (!Array.isArray(ts.data)) {
        throw new Error('Expected commodity symbol list data to be an array');
    }

    if (ts.data.length === 0) {
        throw new Error('Expected at least one snapshot record');
    }

    const snapshot = ts.data[0];

    if (typeof snapshot.date !== 'number') {
        throw new Error('Expected snapshot.date to be a number (timestamp in ms)');
    }

    if (!Array.isArray(snapshot.symbols)) {
        throw new Error('Expected snapshot.symbols to be an array');
    }

    if (snapshot.symbols.length === 0) {
        throw new Error('Expected at least one commodity symbol in the snapshot');
    }

    const symbol = snapshot.symbols[0];

    if (typeof symbol.symbol !== 'string') {
        throw new Error('Expected symbol.symbol to be a string');
    }

    if (typeof symbol.name !== 'string') {
        throw new Error('Expected symbol.name to be a string');
    }

    if (symbol.exchange !== null && typeof symbol.exchange !== 'string') {
        throw new Error('Expected symbol.exchange to be a string or null');
    }

    if (typeof symbol.tradeMonth !== 'string') {
        throw new Error('Expected symbol.tradeMonth to be a string');
    }

    if (typeof symbol.currency !== 'string') {
        throw new Error('Expected symbol.currency to be a string');
    }

    log(`✅ Commodity Symbol validation passed: ${snapshot.symbols.length} symbols, first: ${symbol.symbol} (${symbol.name}) - ${symbol.currency} - Trade Month: ${symbol.tradeMonth}`);

    // Validate refs metadata for the commodity_symbol_list output
    const refsCommoditySymbolList = graph.getRefsForOutput('commodity_symbols', 'commodity_symbol_list');
    if (refsCommoditySymbolList.length > 0) {
        const ref = refsCommoditySymbolList[0];
        const expected = {
            id: '@arrays/data/stock/macro/commodity-symbol/getCommoditySymbolList',
            module_name: '@arrays/data/stock/macro/commodity-symbol',
            module_display_name: 'Commodity Symbol List',
            sdk_name: 'getCommoditySymbolList',
            sdk_display_name: 'Commodity Symbol List',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs#commodities-list',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for commodity_symbol_list');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for commodity_symbol_list');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for commodity_symbol_list');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for commodity_symbol_list');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for commodity_symbol_list');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for commodity_symbol_list');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for commodity_symbol_list');
        log('✓ commodity_symbol_list refs validated');
    } else {
        throw new Error('Assertion failed: refsCommoditySymbolList array is empty.');
    }

    log('✅ Commodity Symbol List make*Node tests passed');
}

function testGetCommoditySymbolList() {
    console.log('\n=== Testing getCommoditySymbolList (Direct Import) ===');

    const { getCommoditySymbolList } = require('@arrays/data/stock/macro/commodity-symbol:v1.0.0');

    const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

    let totalTests = 0;
    let passedTests = 0;

    function runTest(name, fn) {
        totalTests++;
        try {
            fn();
            console.log(`✅ ${name}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${name}: ${e.message}`);
        }
    }

    // Happy Path: Basic call with empty params
    runTest('Happy Path - returns success and non-empty list', () => {
        const res = getCommoditySymbolList({});
        assert(res && typeof res === 'object', 'Should return an object');
        assert(res.success === true, 'res.success should be true');
        assert(res.error === null || res.error === undefined, 'res.error should be null or undefined');
        assert(res.response && Array.isArray(res.response.data), 'response.data should be an array');
        assert(res.response.data.length > 0, 'response.data should not be empty');

        const first = res.response.data[0];
        assert(typeof first.symbol === 'string', 'symbol must be string');
        assert(typeof first.name === 'string', 'name must be string');
        assert(first.exchange === null || typeof first.exchange === 'string', 'exchange must be string or null');
        assert(typeof first.tradeMonth === 'string', 'tradeMonth must be string');
        assert(typeof first.currency === 'string', 'currency must be string');
    });

    // Enum coverage: tradeMonth must be one of 12 months (3-letter)
    runTest('Enum coverage - tradeMonth values are valid 3-letter months', () => {
        const res = getCommoditySymbolList({});
        const data = res.response.data;
        for (const item of data) {
            assert(MONTHS.includes(item.tradeMonth), `Invalid tradeMonth: ${item.tradeMonth}`);
            assert(item.tradeMonth.length === 3, 'tradeMonth length should be 3');
        }
    });

    // Enum-ish constraints: currency format (uppercase letters 2-5) and presence of USD
    runTest('Currency format and presence', () => {
        const res = getCommoditySymbolList({});
        const data = res.response.data;
        let hasUSD = false;
        for (const item of data) {
            assert(/^[A-Z]{2,5}$/.test(item.currency), `Invalid currency format: ${item.currency}`);
            if (item.currency === 'USD') hasUSD = true;
        }
        assert(hasUSD, 'At least one symbol should have USD currency');
    });

    // Symbol format and uniqueness
    runTest('Symbol formatting and uniqueness', () => {
        const res = getCommoditySymbolList({});
        const data = res.response.data;
        const seen = new Set();
        for (const item of data) {
            assert(typeof item.symbol === 'string' && item.symbol.length >= 2, 'symbol should be a non-empty string of length >= 2');
            assert(/^[A-Z0-9]+$/.test(item.symbol), `symbol should be uppercase alphanumeric: ${item.symbol}`);
            assert(!seen.has(item.symbol), `Duplicate symbol detected: ${item.symbol}`);
            seen.add(item.symbol);
        }
    });

    // Exchange nullable or non-empty string
    runTest('Exchange is null or non-empty string', () => {
        const res = getCommoditySymbolList({});
        for (const item of res.response.data) {
            if (item.exchange !== null) {
                assert(typeof item.exchange === 'string' && item.exchange.trim().length > 0, 'exchange should be non-empty string when not null');
            }
        }
    });

    // Special value tests: undefined params
    runTest('Special values - undefined params', () => {
        let handled = false;
        try {
            const res = getCommoditySymbolList();
            if (res && typeof res === 'object') {
                assert(res.response && Array.isArray(res.response.data), 'response.data should be array when called without params');
                handled = true;
            }
        } catch (e) {
            handled = true; // acceptable to throw for invalid params
        }
        assert(handled, 'Function should either return valid object or throw an Error for undefined params');
    });

    // Special value tests: null params
    runTest('Special values - null params', () => {
        let handled = false;
        try {
            const res = getCommoditySymbolList(null);
            if (res && typeof res === 'object') {
                assert(res.response && Array.isArray(res.response.data), 'response.data should be array when called with null');
                handled = true;
            }
        } catch (e) {
            handled = true; // acceptable to throw for invalid params
        }
        assert(handled, 'Function should either return valid object or throw an Error for null params');
    });

    // Special value tests: extraneous params should be ignored
    runTest('Extraneous params are ignored', () => {
        const res = getCommoditySymbolList({ foo: 'bar', page: 1, limit: 10 });
        assert(res && res.success === true, 'success should be true with extraneous params');
        assert(res.error === null || res.error === undefined, 'error should be null or undefined with extraneous params');
        assert(Array.isArray(res.response.data), 'response.data should be array');
    });

    // Boundary value analysis on structural fields
    runTest('Boundary - tradeMonth length exactly 3, currency length 2-5', () => {
        const res = getCommoditySymbolList({});
        for (const item of res.response.data) {
            assert(item.tradeMonth.length === 3, `tradeMonth must be 3 chars: ${item.tradeMonth}`);
            assert(item.currency.length >= 2 && item.currency.length <= 5, `currency length out of bounds: ${item.currency}`);
        }
    });

    // Summary
    console.log('\n=== getCommoditySymbolList Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function main() {
    testMakeNode();
    testGetCommoditySymbolList();
    return 0;
}

main();
