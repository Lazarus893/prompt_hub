const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// SDK Reference metadata for getCommoditySymbolList (sourced from tool.json)
const getCommoditySymbolListRef = {
    id: '@arrays/data/stock/macro/commodity-symbol/getCommoditySymbolList',
    module_name: '@arrays/data/stock/macro/commodity-symbol',
    module_display_name: 'Commodity Symbol List',
    sdk_name: 'getCommoditySymbolList',
    sdk_display_name: 'Commodity Symbol List',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs#commodities-list',
};

// Internal base description and dynamic description builder for getCommoditySymbolList
// Summary from doc: Retrieves a list of available commodity symbols with their details.
const baseGetCommoditySymbolListDescription = "Retrieve commodity symbols list";

function buildGetCommoditySymbolListCallDescription(actualParams = {}) {
    // Start with core description
    const parts = [baseGetCommoditySymbolListDescription];

    // No required params per doc; if caller supplies any keys, include them as generic filters
    const filters = [];
    if (actualParams && typeof actualParams === 'object') {
        for (const [k, v] of Object.entries(actualParams)) {
            if (v !== undefined && v !== null && String(v).length > 0) {
                filters.push(`${k}: ${v}`);
            }
        }
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getCommoditySymbolList(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/macro/commodity/symbol-list';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function makeCommoditySymbolNode(params) {
    return {
        inputs: {
            commodity_symbol_raw: () => getCommoditySymbolList(params),
        },
        outputs: {
            commodity_symbol_list: {
                name: 'commodity_symbol_list_snapshot',
                description: 'Commodity symbol list snapshot (single record with nested symbols array)',
                fields: [
                    { name: 'date', type: 'number', description: 'snapshot time ms' },
                    {
                        name: 'symbols',
                        type: 'array',
                        description: 'available commodity symbols',
                        fields: [
                            { name: 'symbol', type: 'string', description: 'commodity symbol, e.g., GCUSD' },
                            { name: 'name', type: 'string', description: 'commodity name, e.g., Gold Futures' },
                            { name: 'exchange', type: 'string', description: 'exchange (may be null)' },
                            { name: 'tradeMonth', type: 'string', description: 'trade month, e.g., Dec' },
                            { name: 'currency', type: 'string', description: 'currency, e.g., USD' },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getCommoditySymbolListRef, params, buildGetCommoditySymbolListCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.commodity_symbol_raw;

            if (raw?.error) {
                throw new Error(`API Error: ${raw.error.message || 'Unknown error'}`);
            }

            if (!raw?.response?.data) {
                return { commodity_symbol_list: [] };
            }

            if (!Array.isArray(raw.response.data)) {
                throw new Error('Invalid API response: response.data is not an array');
            }

            const snapshotTime = Date.now();

            const symbols = raw.response.data.map((item) => ({
                symbol: item.symbol || '',
                name: item.name || '',
                exchange: item.exchange || null,
                tradeMonth: item.tradeMonth || '',
                currency: item.currency || '',
            }));

            return {
                commodity_symbol_list: [
                    {
                        date: snapshotTime,
                        symbols,
                    },
                ],
            };
        },
    };
}

function makeCommoditySymbolDataNode(params) {
    return makeCommoditySymbolNode(params);
}

function getRefs() {
    return [
        getCommoditySymbolListRef,
    ];
}

module.exports = {
    getCommoditySymbolList,
    makeCommoditySymbolNode,
    makeCommoditySymbolDataNode,
    getRefs,
};