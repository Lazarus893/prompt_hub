const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getIndexHistoricalData, sourced from tool.json
const getIndexHistoricalDataRef = {
  id: '@arrays/data/stock/macro/index-historical/getIndexHistoricalData',
  module_name: '@arrays/data/stock/macro/index-historical',
  module_display_name: 'Index History Price',
  sdk_name: 'getIndexHistoricalData',
  sdk_display_name: 'Index History Price',
  source_name: 'Financial Modeling Prep',
  source: 'https://site.financialmodelingprep.com/developer/docs/stable/index-historical-price-eod-full',
};

// Base description derived from doc for getIndexHistoricalData
const baseGetIndexHistoricalDataDescription = 'Get historical index OHLCV data';

// Dynamic description builder based on provided params for getIndexHistoricalData
function buildGetIndexHistoricalDataCallDescription(actualParams = {}) {
  const parts = [baseGetIndexHistoricalDataDescription];

  // Add symbol context
  if (actualParams.symbol) {
    parts.push(`for ${actualParams.symbol}`);
  }

  // Add date range filters
  const filters = [];
  if (actualParams.start_date && actualParams.end_date) {
    filters.push(`Date: ${actualParams.start_date} to ${actualParams.end_date}`);
  } else if (actualParams.start_date) {
    filters.push(`From: ${actualParams.start_date}`);
  } else if (actualParams.end_date) {
    filters.push(`Until: ${actualParams.end_date}`);
  }

  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }

  return parts.join(' ').trim();
}

// Utility to compose reference object with dynamic call title
function createReferenceWithTitle(refObject, params, titleBuilder) {
  // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
  const title = titleBuilder(params);

  // 2. 组合 refObject 和新 title
  const newObject = {
    ...refObject,
    title: title,
  };

  // 3. 返回新对象
  return newObject;
}

function getIndexHistoricalData(params) {
  const { syncFetch: fetch } = require('net/http');
  const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/macro/index/historical';
  const keyValuePairs = Object.keys(params || {}).map((key) => {
    const value = params[key];
    return encodeURIComponent(key) + '=' + encodeURIComponent(value);
  });
  const queryString = keyValuePairs.join('&');
  const fullUrl = `${baseUrl}?${queryString}`;
  const fetchOptions = {
    method: 'GET',
    headers: {
      'X-API-Key': key,
      'Content-Type': 'application/json',
    },
  };
  const r = fetch(fullUrl, fetchOptions);
  return r.json();
}

function toMs(value) {
  if (!value) {
    return null;
  }
  const parsed = Date.parse(value);
  return Number.isNaN(parsed) ? null : parsed;
}

function makeIndexHistoricalNode(params) {
  return {
    inputs: {
      index_raw: () => getIndexHistoricalData(params),
    },
    outputs: {
      index_historical: {
        name: 'index_historical',
        description: 'Historical index OHLC data',
        fields: [
          { name: 'date', type: 'number', description: 'date ms' },
          { name: 'symbol', type: 'string', description: 'index symbol' },
          { name: 'open', type: 'number', description: 'open price' },
          { name: 'high', type: 'number', description: 'high price' },
          { name: 'low', type: 'number', description: 'low price' },
          { name: 'close', type: 'number', description: 'close price' },
          { name: 'volume', type: 'number', description: 'volume' },
        ],
        ref: createReferenceWithTitle(
          getIndexHistoricalDataRef,
          params,
          buildGetIndexHistoricalDataCallDescription
        ),
      },
    },
    run: (inputs) => {
      const data = Array.isArray(inputs.index_raw?.response?.data) ? inputs.index_raw.response.data : [];

      const series = data
        .map((item) => {
          const date = toMs(item.date);
          if (date == null) return null;
          return {
            date,
            symbol: item.symbol,
            open: item.open,
            high: item.high,
            low: item.low,
            close: item.close,
            volume: item.volume,
          };
        })
        .filter(Boolean);

      // Deduplicate by date (keep the last occurrence), then sort ascending by date.
      const byDate = new Map();
      for (const r of series) byDate.set(r.date, r);
      const deduped = Array.from(byDate.values()).sort((a, b) => a.date - b.date);

      return { index_historical: deduped };
    },
  };
}

function makeIndexHistoricalDataNode(params) {
  return makeIndexHistoricalNode(params);
}

function getRefs() {
  return [getIndexHistoricalDataRef];
}

module.exports = {
  getIndexHistoricalData,
  makeIndexHistoricalNode,
  makeIndexHistoricalDataNode,
  getRefs,
};
