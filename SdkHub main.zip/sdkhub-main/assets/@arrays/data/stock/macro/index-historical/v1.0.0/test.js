function main() {
  const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
  const { jagentId } = require('env');
  const { makeIndexHistoricalNode, getIndexHistoricalData } = require('@arrays/data/stock/macro/index-historical:v1.0.0');

  // Local lightweight assert to align with example.js style
  const assert = (cond, msg) => {
    if (!cond) throw new Error(msg || 'Assertion failed');
  };

  // =========================
  // Tests for getIndexHistoricalData (manual import)
  // =========================
  console.log('\n=== Testing getIndexHistoricalData (Direct Function) ===');

  // Supported symbols (from doc) - full enumeration coverage
  const SUPPORTED_SYMBOLS = [
    '^SPX', '^GSPC', '^DJI', '^IXIC', '^NDX', '^RUA', '^RUI', '^RUT', '^W5000', '^DWCF',
    '^NYA', '^XAX', '^GSPTSE', 'TX60.TS', '^FTSE', '^FTLC', '^GDAXI', '^FCHI', '^IBEX', '^SSMI',
    'FTSEMIB.MI', 'ITLMS.MI', '^AEX', '^BFX', '^OMXS30', '^OMXH25', '^OMXC20', '^OSEAX', 'WIG.WA', 'WIG20.WA',
    'IMOEX.ME', 'RTSI.ME', '000001.SS', 'XIN9.FGI', '^HSI', '^TWII', '^TSE50', '^N225', '^N300', '^KS11',
    'KOSPI200.KS', '^STI', '^KLSE', '^SET.BK', '^JKSE', '^NZ50', '^AORD', '^AXJO', '^AFLI', '^BSESN',
    '^NSEI', '^BVSP', '^MXX', '^MERV', '^TASI.SR', '^TA125.TA', 'XU100.IS', 'XU050.IS', '^CASE30'
  ];

  let totalTests = 0;
  let passedTests = 0;

  function runTest(name, fn) {
    totalTests++;
    try {
      fn();
      console.log(`✅ ${name}`);
      passedTests++;
    } catch (e) {
      console.log(`❌ ${name}: ${e.message}`);
    }
  }

  // Helper to extract data array in a tolerant way
  function extractData(res) {
    if (!res || typeof res !== 'object') return null;
    if (res.response && Array.isArray(res.response.data)) return res.response.data;
    if (Array.isArray(res.data)) return res.data;
    if (res.result && Array.isArray(res.result.data)) return res.result.data; // fallback style
    return null;
  }

  // Helper number-ish check
  function isNumberish(v) {
    return typeof v === 'number' || (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v)));
  }

  const HAPPY_START = '2024-09-02';
  const HAPPY_END = '2024-09-06';

  // Happy Path: iterate all enumerated symbols
  for (const sym of SUPPORTED_SYMBOLS) {
    runTest(`getIndexHistoricalData happy path for ${sym}`, () => {
      const res = getIndexHistoricalData({ symbol: sym, start_date: HAPPY_START, end_date: HAPPY_END });
      assert(res && typeof res === 'object', 'Should return an object');
      // Prefer doc contract but be tolerant
      if ('success' in res) {
        assert(res.success === true, 'success should be true');
      }
      const data = extractData(res);
      assert(Array.isArray(data), 'response.data should be an array');
      if (data.length > 0) {
        const d0 = data[0];
        assert(typeof d0.symbol === 'string', 'symbol should be string');
        assert('date' in d0, 'date field should exist');
        assert(isNumberish(d0.open), 'open should be number-ish');
        assert(isNumberish(d0.high), 'high should be number-ish');
        assert(isNumberish(d0.low), 'low should be number-ish');
        assert(isNumberish(d0.close), 'close should be number-ish');
        assert(isNumberish(d0.volume), 'volume should be number-ish');
      }
    });
  }

  // Boundary Value Analysis
  console.log('\n--- Boundary Value Analysis ---');

  // start_date == end_date (single day)
  runTest('start_date equals end_date', () => {
    const res = getIndexHistoricalData({ symbol: '^GSPC', start_date: '2024-09-03', end_date: '2024-09-03' });
    const data = extractData(res);
    assert(Array.isArray(data), 'Should return data array for single day');
  });

  // Earliest allowed boundary (from 2000-01-01 onwards per doc)
  runTest('earliest supported start_date boundary', () => {
    const res = getIndexHistoricalData({ symbol: '^GSPC', start_date: '2000-01-03', end_date: '2000-01-10' });
    const data = extractData(res);
    assert(Array.isArray(data), 'Should return data array for earliest boundary');
  });

  // start_date after end_date
  runTest('start_date after end_date should fail or be empty', () => {
    try {
      const res = getIndexHistoricalData({ symbol: '^GSPC', start_date: '2024-09-10', end_date: '2024-09-02' });
      const data = extractData(res);
      // Accept either explicit failure or empty data
      if ('success' in res) {
        assert(res.success === false || (Array.isArray(data) && data.length === 0), 'Should fail or return empty dataset');
      } else {
        assert(Array.isArray(data) && data.length === 0, 'Should return empty dataset');
      }
    } catch (e) {
      // also acceptable if throws
      assert(true, 'Thrown error is acceptable');
    }
  });

  // Out-of-range before 2000-01-01
  runTest('out-of-range date before 2000-01-01', () => {
    try {
      const res = getIndexHistoricalData({ symbol: '^GSPC', start_date: '1999-12-01', end_date: '1999-12-31' });
      const data = extractData(res);
      if ('success' in res) {
        assert(res.success === false || (Array.isArray(data) && data.length === 0), 'Should fail or return empty for out-of-range');
      } else {
        assert(Array.isArray(data) && data.length === 0, 'Should return empty for out-of-range');
      }
    } catch (e) {
      assert(true, 'Thrown error is acceptable');
    }
  });

  // Invalid date format
  runTest('invalid date format should error', () => {
    try {
      const res = getIndexHistoricalData({ symbol: '^GSPC', start_date: '2024/09/01', end_date: '2024/09/02' });
      if (res && 'success' in res) {
        assert(res.success === false, 'Should indicate failure for invalid date format');
      } else {
        throw new Error('Expected error but got no explicit failure');
      }
    } catch (e) {
      assert(e instanceof Error, 'Should throw error for invalid date format');
    }
  });

  // Special value tests
  console.log('\n--- Special Value Tests ---');

  runTest('null symbol', () => {
    try {
      getIndexHistoricalData({ symbol: null, start_date: HAPPY_START, end_date: HAPPY_END });
      throw new Error('Expected error for null symbol');
    } catch (e) {
      assert(e instanceof Error || /fail/i.test(String(e.message || '')), 'Should handle null symbol');
    }
  });

  runTest('undefined symbol', () => {
    try {
      getIndexHistoricalData({ start_date: HAPPY_START, end_date: HAPPY_END });
      throw new Error('Expected error for undefined symbol');
    } catch (e) {
      assert(e instanceof Error || /fail/i.test(String(e.message || '')), 'Should handle undefined symbol');
    }
  });

  runTest('empty string symbol', () => {
    try {
      getIndexHistoricalData({ symbol: '', start_date: HAPPY_START, end_date: HAPPY_END });
      throw new Error('Expected error for empty string symbol');
    } catch (e) {
      assert(e instanceof Error || /fail/i.test(String(e.message || '')), 'Should handle empty string symbol');
    }
  });

  runTest('empty date strings', () => {
    try {
      getIndexHistoricalData({ symbol: '^GSPC', start_date: '', end_date: '' });
      throw new Error('Expected error for empty dates');
    } catch (e) {
      assert(e instanceof Error || /fail/i.test(String(e.message || '')), 'Should handle empty dates');
    }
  });

  // Print test summary for getIndexHistoricalData
  console.log('\n=== getIndexHistoricalData Test Summary ===');
  console.log(`Total tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${totalTests - passedTests}`);
  console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

  // =========================
  // Graph node tests (existing)
  // =========================
  const graph = new Graph(jagentId);
  graph.addNode(
    'index_historical',
    makeIndexHistoricalNode({
      symbol: '^GSPC',
      start_date: '2025-09-01',
      end_date: '2025-09-07',
    })
  );

  graph.run();

  // Materialize and validate the index historical OHLC output
  const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'index_historical', 'index_historical', { last: '10' }), graph.store);
  ts.init();

  if (!Array.isArray(ts.data)) {
    throw new Error('Expected index historical data to be an array');
  }

  if (ts.data.length > 0) {
    const ohlc = ts.data[0];

    if (typeof ohlc.date !== 'number') {
      throw new Error('Expected ohlc.date to be a number (timestamp in ms)');
    }

    if (typeof ohlc.symbol !== 'string') {
      throw new Error('Expected ohlc.symbol to be a string');
    }

    if (typeof ohlc.open !== 'number') {
      throw new Error('Expected ohlc.open to be a number');
    }

    if (typeof ohlc.high !== 'number') {
      throw new Error('Expected ohlc.high to be a number');
    }

    if (typeof ohlc.low !== 'number') {
      throw new Error('Expected ohlc.low to be a number');
    }

    if (typeof ohlc.close !== 'number') {
      throw new Error('Expected ohlc.close to be a number');
    }

    if (typeof ohlc.volume !== 'number') {
      throw new Error('Expected ohlc.volume to be a number');
    }

    log(`✅ Index OHLC validation passed: ${ohlc.symbol} OHLC(${ohlc.open}/${ohlc.high}/${ohlc.low}/${ohlc.close}) on ${new Date(ohlc.date).toISOString().split('T')[0]}`);
  }

  // Validate reference metadata for index_historical output
  const refsIndexHistorical = graph.getRefsForOutput('index_historical', 'index_historical');
  if (refsIndexHistorical.length > 0) {
    const ref = refsIndexHistorical[0];
    const expected = {
      id: '@arrays/data/stock/macro/index-historical/getIndexHistoricalData',
      module_name: '@arrays/data/stock/macro/index-historical',
      module_display_name: 'Index History Price',
      sdk_name: 'getIndexHistoricalData',
      sdk_display_name: 'Index History Price',
      source_name: 'Financial Modeling Prep',
      source: 'https://site.financialmodelingprep.com/developer/docs/stable/index-historical-price-eod-full',
    };

    if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for index_historical');
    if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for index_historical');
    if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for index_historical');
    if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for index_historical');
    if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for index_historical');
    if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for index_historical');
    if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for index_historical');
    log('✓ index_historical refs validated');
  } else {
    throw new Error('Assertion failed: refsIndexHistorical array is empty.');
  }

  log('✅ Index Historical make*Node tests passed');

  return 0;
}

main();
