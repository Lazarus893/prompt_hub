function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    // Manual import for get* function per requirement
    const { makeCommodityRealTimeNode, getCommodityRealTimeData } = require('@arrays/data/stock/macro/commodity-realtime:v1.0.0');

    function assert(condition, message) {
        if (!condition) throw new Error(message || 'Assertion failed');
    }

    // -------------------- make*Node tests (existing) --------------------
    const graph = new Graph(jagentId);
    graph.addNode(
        'gold_realtime',
        makeCommodityRealTimeNode({
            symbol: 'GCUSD',
        })
    );

    graph.run();

    // Validate refs for the 'quote' output
    const refsQuote = graph.getRefsForOutput('gold_realtime', 'quote');
    if (refsQuote.length > 0) {
        const ref = refsQuote[0];
        const expected = {
            id: '@arrays/data/stock/macro/commodity-realtime/getCommodityRealTimeData',
            module_name: '@arrays/data/stock/macro/commodity-realtime',
            module_display_name: 'Commodity Real-Time Price',
            sdk_name: 'getCommodityRealTimeData',
            sdk_display_name: 'Commodity Real-Time Price',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stable/commodities-intraday-1-min',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for quote');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for quote');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for quote');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for quote');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for quote');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for quote');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for quote');
        log('✓ quote refs validated');
    } else {
        throw new Error('Assertion failed: refsQuote array is empty.');
    }

    // Materialize and validate the commodity realtime quote output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'gold_realtime', 'quote', { last: '10' }), graph.store);
    ts.init();

    if (!Array.isArray(ts.data)) {
        throw new Error('Expected commodity realtime quote data to be an array');
    }

    if (ts.data.length > 0) {
        const quote = ts.data[0];

        if (typeof quote.date !== 'number') {
            throw new Error('Expected quote.date to be a number (timestamp in ms)');
        }

        if (typeof quote.symbol !== 'string') {
            throw new Error('Expected quote.symbol to be a string');
        }

        if (typeof quote.price !== 'number') {
            throw new Error('Expected quote.price to be a number');
        }

        log(`✅ Commodity realtime quote validation passed: ${quote.symbol} @ ${quote.price} on ${new Date(quote.date).toISOString()}`);
    }

    log('✅ Commodity Real Time Data make*Node tests passed');

    // -------------------- Direct get* function tests --------------------
    // Learn from example.js style: enumerate supported values, run via helper and assert
    console.log('\n=== Testing Direct getCommodityRealTimeData ===');

    const VALID_SYMBOLS = ['GCUSD', 'ZLUSX', 'SILUSD']; // from doc examples
    let totalTests = 0;
    let passedTests = 0;

    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    function safeCall(params) {
        try {
            const r = getCommodityRealTimeData(params);
            return { result: r, thrown: null };
        } catch (e) {
            return { result: null, thrown: e };
        }
    }

    // --- Happy Path: all valid symbols ---
    for (const symbol of VALID_SYMBOLS) {
        runTest(`getCommodityRealTimeData with valid symbol ${symbol}`, () => {
            const { result, thrown } = safeCall({ symbol });
            assert(thrown === null, 'Should not throw for valid symbol');
            assert(result && typeof result === 'object', 'Should return an object');
            assert(result.success === true, 'success should be true');
            assert(result.error === null || result.error === undefined, 'error should be null/undefined on success');
            assert(result.response && result.response.data, 'response.data should exist');
            const data = result.response.data;
            assert(typeof data.symbol === 'string', 'data.symbol should be string');
            assert(data.symbol.toUpperCase() === symbol, 'Returned symbol should match requested');
            assert(typeof data.date === 'string', 'date should be string');
            assert(/\d{4}-\d{2}-\d{2}/.test(data.date), 'date should look like YYYY-MM-DD ...');
            assert(typeof data.price === 'number', 'price should be a number');
            assert(Number.isFinite(data.price), 'price should be finite');
        });
    }

    // --- Boundary Value Analysis & Special Values ---
    function expectFailure(callDesc, paramsOrArg) {
        runTest(callDesc, () => {
            const { result, thrown } = safeCall(paramsOrArg);
            if (thrown) {
                // Thrown error is acceptable for invalid input
                assert(thrown.message && typeof thrown.message === 'string', 'Thrown error should have a message');
                return;
            }
            // If no exception, expect structured error response
            if (result && result.success === false && result.error) {
                assert(typeof result.error === 'object', 'error should be an object');
                return;
            }
            // If success but no data, that's also acceptable as failure indication
            if (!result || !result.response || !result.response.data) {
                return;
            }
            throw new Error('Expected failure but got success with data');
        });
    }

    // Invalid/edge symbols
    expectFailure('empty string symbol', { symbol: '' });
    expectFailure('whitespace symbol', { symbol: '   ' });

    // Special values
    expectFailure('null symbol', { symbol: null });
    expectFailure('undefined symbol', { symbol: undefined });
    expectFailure('numeric symbol (0)', { symbol: 0 });
    expectFailure('non-string symbol (array)', { symbol: ['GCUSD'] });

    // Missing params and wrong param type
    expectFailure('missing params object', {});
    expectFailure('param is not an object (string)', 'GCUSD');

    // Print test summary for direct get* tests
    console.log('\n=== Direct getCommodityRealTimeData Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    if (passedTests === totalTests) {
        console.log('🎉 All direct get* tests passed!');
    } else {
        console.log('⚠️  Some direct get* tests failed. Please review the output above.');
    }

    return 0;
}

main();
