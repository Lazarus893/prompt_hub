const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for SDK function, derived from tool.json
const getCommodityRealTimeDataRef = {
	id: "@arrays/data/stock/macro/commodity-realtime/getCommodityRealTimeData",
	module_name: "@arrays/data/stock/macro/commodity-realtime",
	module_display_name: "Commodity Real-Time Price",
	sdk_name: "getCommodityRealTimeData",
	sdk_display_name: "Commodity Real-Time Price",
	source_name: "Financial Modeling Prep",
	source: "https://site.financialmodelingprep.com/developer/docs/stable/commodities-intraday-1-min"
};

// Internal description builders (not exported)
// Base description for getCommodityRealTimeData derived from doc
const getCommodityRealTimeDataBaseDesc = "Get real-time commodity market data";

function buildGetCommodityRealTimeDataCallDescription(actualParams = {}) {
    const parts = [getCommodityRealTimeDataBaseDesc];

    // Add symbol if provided (required by doc, but keep generic if absent)
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }

    return parts.join(' ').trim();
}

// Utility to create reference object with dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getCommodityRealTimeData(params) {
	// Input validation
	if (!params || typeof params !== 'object') {
		return {
			success: false,
			error: { code: 'INVALID_PARAMS', message: 'Invalid parameters: params must be an object' },
			response: null
		};
	}

	const symbol = params.symbol;
	if (!symbol || typeof symbol !== 'string' || symbol.trim() === '') {
		return {
			success: false,
			error: { code: 'INVALID_SYMBOL', message: 'Invalid parameters: symbol is required and must be a non-empty string' },
			response: null
		};
	}

	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/macro/commodity/real-time';
	const keyValuePairs = Object.keys(params || {}).map((key) => {
		const value = params[key];
		return encodeURIComponent(key) + '=' + encodeURIComponent(value);
	});
	const queryString = keyValuePairs.join('&');
	const fullUrl = `${baseUrl}?${queryString}`;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

// Parse "YYYY-MM-DD HH:mm:ss" (or "YYYY-MM-DDTHH:mm:ss") to epoch ms (UTC)
function parseApiDateToMs(s) {
	if (typeof s !== 'string') return null;
	const m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/);
	if (m) {
		const y = Number(m[1]);
		const mon = Number(m[2]);
		const d = Number(m[3]);
		const hh = Number(m[4]);
		const mm = Number(m[5]);
		const ss = Number(m[6]);
		return Date.UTC(y, mon - 1, d, hh, mm, ss, 0);
	}
	// Fallback (less preferred): attempt Date.parse; if it yields a number, use it.
	const t = Date.parse(s);
	return Number.isFinite(t) ? t : null;
}

function makeCommodityRealTimeNode(params) {
	return {
		inputs: {
			commodity_real_time_data_raw: () => getCommodityRealTimeData(params),
		},
		outputs: {
			quote: {
				name: 'commodity_realtime_quote',
				description: 'Latest real-time quote for a commodity',
				fields: [
					{ name: 'date', type: 'number', description: 'quote time ms (UTC) parsed from API response' },
					{ name: 'symbol', type: 'string', description: 'commodity symbol, e.g., GCUSD' },
					{ name: 'price', type: 'number', description: 'current price' },
				],
				ref: createReferenceWithTitle(getCommodityRealTimeDataRef, params, buildGetCommodityRealTimeDataCallDescription),
			},
		},
		run: (inputs) => {
			const raw = inputs.commodity_real_time_data_raw;

			if (!raw?.response?.data) {
				return { commodity_realtime_quote: [] };
			}

			const data = raw.response.data;
			const dms = parseApiDateToMs(data.date);
			if (!Number.isFinite(dms)) {
				throw new Error('Failed to parse quote time: ' + JSON.stringify(data.date));
			}
			const symbol = data.symbol || (params && params.symbol) || '';
			const price = data.price;

			// Check if price is 0, which indicates the symbol doesn't exist
			if (price === 0) {
				throw new Error(`Symbol not found: ${symbol}`);
			}

			return {
				quote: [
					{
						date: dms,
						symbol,
						price,
					},
				],
			};
		},
	};
}

function makeCommodityRealTimeDataNode(params) {
	return makeCommodityRealTimeNode(params);
}

// 新增：统一获取所有 Ref 对象的方法
function getRefs() {
    return [
        getCommodityRealTimeDataRef,
    ];
}

module.exports = {
	getCommodityRealTimeData,
	makeCommodityRealTimeNode,
	makeCommodityRealTimeDataNode,
	getRefs,
};