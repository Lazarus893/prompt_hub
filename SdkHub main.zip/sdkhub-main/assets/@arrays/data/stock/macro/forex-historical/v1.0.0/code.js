const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// SDK Reference metadata for getForexHistoricalData (sourced from tool.json)
const getForexHistoricalDataRef = {
    id: '@arrays/data/stock/macro/forex-historical/getForexHistoricalData',
    module_name: '@arrays/data/stock/macro/forex-historical',
    module_display_name: 'Forex Price History',
    sdk_name: 'getForexHistoricalData',
    sdk_display_name: 'Forex Price History',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/stable/forex-historical-price-eod-full',
};

// Base description string derived from doc for getForexHistoricalData
const baseGetForexHistoricalDataDescription = 'Get historical forex time-series data';

// Dynamic call description builder for getForexHistoricalData based on provided params
function buildGetForexHistoricalDataCallDescription(actualParams = {}) {
    const parts = [baseGetForexHistoricalDataDescription];

    // Symbol context
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }

    // Date range filters
    const filters = [];
    if (actualParams.start_date && actualParams.end_date) {
        filters.push(`Time: ${actualParams.start_date} to ${actualParams.end_date}`);
    } else if (actualParams.start_date) {
        filters.push(`Time from: ${actualParams.start_date}`);
    } else if (actualParams.end_date) {
        filters.push(`Time until: ${actualParams.end_date}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getForexHistoricalData(params) {
    // Input validation
    if (!params || typeof params !== 'object') {
        return {
            success: false,
            error: { code: 'INVALID_PARAMS', message: 'Invalid parameters: params must be an object' },
            response: null
        };
    }

    const symbol = params.symbol;
    if (!symbol || typeof symbol !== 'string' || symbol.trim() === '') {
        return {
            success: false,
            error: { code: 'INVALID_SYMBOL', message: 'Invalid parameters: symbol is required and must be a non-empty string' },
            response: null
        };
    }

    // Validate date format if provided
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (params.start_date !== undefined && params.start_date !== null && params.start_date !== '') {
        if (typeof params.start_date !== 'string' || !dateRegex.test(params.start_date)) {
            return {
                success: false,
                error: { code: 'INVALID_DATE', message: 'Invalid parameters: start_date must be in YYYY-MM-DD format' },
                response: null
            };
        }
    }

    if (params.end_date !== undefined && params.end_date !== null && params.end_date !== '') {
        if (typeof params.end_date !== 'string' || !dateRegex.test(params.end_date)) {
            return {
                success: false,
                error: { code: 'INVALID_DATE', message: 'Invalid parameters: end_date must be in YYYY-MM-DD format' },
                response: null
            };
        }
    }

    // Validate date range if both dates are provided
    if (params.start_date && params.end_date) {
        if (params.start_date > params.end_date) {
            return {
                success: false,
                error: { code: 'INVALID_DATE_RANGE', message: 'Invalid parameters: start_date must not be later than end_date' },
                response: null
            };
        }
    }

    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/macro/forex/historical';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function makeForexHistoricalDataNode(params) {
    function parseYmdToUtcMs(ymd) {
        if (typeof ymd !== 'string') {
            throw new Error('Invalid date: expected string YYYY-MM-DD');
        }
        const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(ymd);
        if (!m) {
            throw new Error('Invalid date format (expected YYYY-MM-DD): ' + ymd);
        }
        const y = Number(m[1]);
        const mon0 = Number(m[2]) - 1;
        const d = Number(m[3]);
        return Date.UTC(y, mon0, d, 0, 0, 0, 0);
    }

    return {
        inputs: {
            forex_historical_data_raw: () => getForexHistoricalData(params),
        },
        outputs: {
            forex_ohlcv: {
                name: 'forex_ohlcv',
                description: 'Daily OHLCV for the requested forex pair (one record per trading day).',
                fields: [
                    { name: 'date', type: 'number', description: 'UTC start of day (ms) for the quote date' },
                    { name: 'symbol', type: 'string', description: 'Forex pair symbol, e.g., EURUSD' },
                    { name: 'open', type: 'number' },
                    { name: 'high', type: 'number' },
                    { name: 'low', type: 'number' },
                    { name: 'close', type: 'number' },
                    { name: 'volume', type: 'number' },
                ],
                ref: createReferenceWithTitle(getForexHistoricalDataRef, params, buildGetForexHistoricalDataCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.forex_historical_data_raw;

            // fail fast on explicit API errors
            if (raw && raw.error) {
                const code = raw.error.code || 'UNKNOWN';
                const msg = raw.error.message || 'Unknown error';
                throw new Error(`API Error [${code}]: ${msg}`);
            }
            if (raw && raw.success === false) {
                throw new Error('API request reported success=false');
            }

            const data = raw && raw.response && Array.isArray(raw.response.data) ? raw.response.data : [];

            if (data.length === 0) {
                // append nothing when there is no data
                return;
            }

            const symbolParam = params && params.symbol ? String(params.symbol) : undefined;

            const series = data
                .map((item) => {
                    const date = parseYmdToUtcMs(item.date);
                    if (!date) return null;
                    return {
                        date,
                        symbol: typeof item.symbol === 'string' ? item.symbol : symbolParam,
                        open: Number(item.open),
                        high: Number(item.high),
                        low: Number(item.low),
                        close: Number(item.close),
                        volume: Number(item.volume),
                    };
                })
                .filter(Boolean);

            // Deduplicate by date (keep the last occurrence), then sort ascending by date.
            const byDate = new Map();
            for (const r of series) byDate.set(r.date, r);
            const deduped = Array.from(byDate.values()).sort((a, b) => a.date - b.date);

            return { forex_ohlcv: deduped };
        },
    };
}

function getRefs() {
    return [getForexHistoricalDataRef];
}

module.exports = {
    getForexHistoricalData,
    makeForexHistoricalDataNode,
    getRefs,
};
