function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    // Manual import for get* function as requested
    const { makeForexHistoricalDataNode, getForexHistoricalData } = require('@arrays/data/stock/macro/forex-historical:v1.0.0');

    // -----------------------
    // Graph-based node tests
    // -----------------------
    const graph = new Graph(jagentId);
    graph.addNode(
        'eurusd_daily',
        makeForexHistoricalDataNode({
            symbol: 'EURUSD',
            start_date: '2025-09-01',
            end_date: '2025-09-07',
        })
    );

    graph.run();

    // Materialize and validate the forex historical OHLCV output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'eurusd_daily', 'forex_ohlcv', { last: '10' }), graph.store);
    ts.init();

    if (!Array.isArray(ts.data)) {
        throw new Error('Expected forex OHLCV data to be an array');
    }

    if (ts.data.length > 0) {
        const ohlcv = ts.data[0];

        if (typeof ohlcv.date !== 'number') {
            throw new Error('Expected ohlcv.date to be a number (timestamp in ms)');
        }

        if (typeof ohlcv.symbol !== 'string') {
            throw new Error('Expected ohlcv.symbol to be a string');
        }

        if (typeof ohlcv.open !== 'number') {
            throw new Error('Expected ohlcv.open to be a number');
        }

        if (typeof ohlcv.high !== 'number') {
            throw new Error('Expected ohlcv.high to be a number');
        }

        if (typeof ohlcv.low !== 'number') {
            throw new Error('Expected ohlcv.low to be a number');
        }

        if (typeof ohlcv.close !== 'number') {
            throw new Error('Expected ohlcv.close to be a number');
        }

        if (typeof ohlcv.volume !== 'number') {
            throw new Error('Expected ohlcv.volume to be a number');
        }

        log(`✅ Forex OHLCV validation passed: ${ohlcv.symbol} OHLC(${ohlcv.open}/${ohlcv.high}/${ohlcv.low}/${ohlcv.close}) on ${new Date(ohlcv.date).toISOString().split('T')[0]}`);
    }

    // Validate refs metadata for the forex_ohlcv output
    const refsForexOhlcv = graph.getRefsForOutput('eurusd_daily', 'forex_ohlcv');
    if (refsForexOhlcv.length > 0) {
        const ref = refsForexOhlcv[0];
        const expected = {
            id: '@arrays/data/stock/macro/forex-historical/getForexHistoricalData',
            module_name: '@arrays/data/stock/macro/forex-historical',
            module_display_name: 'Forex Price History',
            sdk_name: 'getForexHistoricalData',
            sdk_display_name: 'Forex Price History',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stable/forex-historical-price-eod-full',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for forex_ohlcv');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for forex_ohlcv');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for forex_ohlcv');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for forex_ohlcv');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for forex_ohlcv');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for forex_ohlcv');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for forex_ohlcv');
        log('✓ forex_ohlcv refs validated');
    } else {
        throw new Error('Assertion failed: refsForexOhlcv array is empty.');
    }

    log('✅ Forex Historical Data make*Node tests passed');

    // -----------------------
    // Direct get* function tests (Senior QA coverage)
    // -----------------------
    let totalTests = 0;
    let passedTests = 0;

    function assert(condition, message) {
        if (!condition) throw new Error(message || 'Assertion failed');
    }

    function runTest(name, fn) {
        totalTests++;
        try {
            fn();
            passedTests++;
            log(`✅ ${name}`);
        } catch (e) {
            log(`❌ ${name}: ${e.message}`);
        }
    }

    function expectFailure(name, params) {
        runTest(name, () => {
            let resp;
            let didThrow = false;
            try {
                resp = getForexHistoricalData(params);
            } catch (e) {
                didThrow = true;
                // Exception is acceptable for invalid input
                return;
            }

            if (!didThrow) {
                // If no exception, check for structured error response
                if (resp && resp.success === false && resp.error) {
                    return;
                }
                // If success but no valid data, that's also acceptable as failure indication
                if (!resp || !resp.response || !resp.response.data || resp.response.data.length === 0) {
                    return;
                }
                // Otherwise, the API is being lenient - just log and continue
                // (some APIs may accept invalid inputs gracefully)
                throw new Error('Expected failure, but call succeeded');
            }
        });
    }

    log('\n--- Testing getForexHistoricalData (Happy Path) ---');
    const SYMBOLS = ['EURUSD', 'GBPJPY', 'USDJPY', 'AUDUSD', 'GBPUSD'];
    for (const symbol of SYMBOLS) {
        runTest(`getForexHistoricalData happy path for ${symbol}`, () => {
            const resp = getForexHistoricalData({
                symbol,
                start_date: '2025-08-01',
                end_date: '2025-08-05',
            });
            assert(resp && typeof resp === 'object', 'Response should be an object');
            assert(resp.success === true, 'Response success should be true');
            assert(resp.response && Array.isArray(resp.response.data), 'response.data should be an array');
            if (resp.response.data.length > 0) {
                const p = resp.response.data[0];
                assert(typeof p.symbol === 'string', 'data.symbol should be a string');
                assert(p.symbol.toUpperCase() === symbol, 'data.symbol should match the requested symbol');
                // Date may be returned as number or string per docs; ensure present
                assert(p.date !== undefined && p.date !== null, 'data.date should be present');
                assert(typeof p.open === 'number', 'data.open should be number');
                assert(typeof p.high === 'number', 'data.high should be number');
                assert(typeof p.low === 'number', 'data.low should be number');
                assert(typeof p.close === 'number', 'data.close should be number');
                assert(typeof p.volume === 'number', 'data.volume should be number');
            }
        });
    }

    log('\n--- Testing getForexHistoricalData (Boundary Values) ---');
    // Boundary: earliest available date
    runTest('Boundary earliest date 2000-01-01 to 2000-01-02', () => {
        const resp = getForexHistoricalData({
            symbol: 'EURUSD',
            start_date: '2000-01-01',
            end_date: '2000-01-02',
        });
        assert(resp && resp.success === true, 'Should succeed for earliest boundary dates');
        assert(resp.response && Array.isArray(resp.response.data), 'response.data should be array');
    });

    // Boundary: single day range
    runTest('Boundary single-day range', () => {
        const resp = getForexHistoricalData({
            symbol: 'GBPUSD',
            start_date: '2025-08-03',
            end_date: '2025-08-03',
        });
        assert(resp && typeof resp === 'object', 'Response should be object');
        assert(resp.success === true, 'Should succeed for single-day range');
        assert(resp.response && Array.isArray(resp.response.data), 'response.data should be array');
    });

    // Boundary: current/near-future safe small range
    runTest('Boundary recent short range', () => {
        const resp = getForexHistoricalData({
            symbol: 'USDJPY',
            start_date: '2025-09-01',
            end_date: '2025-09-05',
        });
        assert(resp && resp.success === true, 'Should succeed for recent dates');
        assert(resp.response && Array.isArray(resp.response.data), 'response.data should be array');
    });

    log('\n--- Testing getForexHistoricalData (Invalid/Special Values) ---');
    // Invalid symbol
    expectFailure('Invalid symbol', {
        symbol: 'INVALID',
        start_date: '2025-08-01',
        end_date: '2025-08-05',
    });

    // Empty symbol
    expectFailure('Empty symbol', {
        symbol: '',
        start_date: '2025-08-01',
        end_date: '2025-08-05',
    });

    // Null/undefined symbol
    expectFailure('Null symbol', {
        symbol: null,
        start_date: '2025-08-01',
        end_date: '2025-08-05',
    });
    expectFailure('Undefined symbol', {
        // no symbol
        start_date: '2025-08-01',
        end_date: '2025-08-05',
    });

    // Invalid date format
    expectFailure('Invalid start_date format', {
        symbol: 'EURUSD',
        start_date: '2025/08/01',
        end_date: '2025-08-05',
    });
    expectFailure('Invalid end_date format', {
        symbol: 'EURUSD',
        start_date: '2025-08-01',
        end_date: '2025/08/05',
    });

    // end_date before start_date
    expectFailure('end_date earlier than start_date', {
        symbol: 'EURUSD',
        start_date: '2025-08-05',
        end_date: '2025-08-01',
    });

    // Null/undefined/empty dates
    expectFailure('Null start_date', {
        symbol: 'EURUSD',
        start_date: null,
        end_date: '2025-08-05',
    });
    expectFailure('Undefined start_date', {
        symbol: 'EURUSD',
        end_date: '2025-08-05',
    });
    expectFailure('Empty start_date', {
        symbol: 'EURUSD',
        start_date: '',
        end_date: '2025-08-05',
    });
    expectFailure('Null end_date', {
        symbol: 'EURUSD',
        start_date: '2025-08-01',
        end_date: null,
    });
    expectFailure('Undefined end_date', {
        symbol: 'EURUSD',
        start_date: '2025-08-01',
    });
    expectFailure('Empty end_date', {
        symbol: 'EURUSD',
        start_date: '2025-08-01',
        end_date: '',
    });

    log('\n=== getForexHistoricalData Test Summary ===');
    log(`Total tests: ${totalTests}`);
    log(`Passed: ${passedTests}`);
    log(`Failed: ${totalTests - passedTests}`);
    log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    if (passedTests === totalTests) {
        log('🎉 All direct get* tests passed!');
    } else {
        log('⚠️  Some direct get* tests failed. Please review the output above.');
    }

    return 0;
}

main();
