'use strict';

function assert(condition, message) {
  if (!condition) {
    throw new Error(message || 'Assertion failed');
  }
}

function testGetIndexRealTimeData() {
  console.log('\n=== Testing getIndexRealTimeData Direct Calls ===');

  // Manual import for get* function as required
  const { getIndexRealTimeData } = require('@arrays/data/stock/macro/index-realtime:v1.0.0');

  let totalTests = 0;
  let passedTests = 0;

  function runTest(testName, testFunc) {
    totalTests++;
    try {
      testFunc();
      console.log(`✅ ${testName}`);
      passedTests++;
    } catch (e) {
      console.log(`❌ ${testName}: ${e.message}`);
    }
  }

  // Happy Path: test enumerated valid symbols from docs
  const VALID_SYMBOLS = ['^GSPC', '^DJI', '^IXIC'];
  for (const symbol of VALID_SYMBOLS) {
    runTest(`getIndexRealTimeData happy path with ${symbol}`, () => {
      const res = getIndexRealTimeData({ symbol });
      assert(res && typeof res === 'object', 'Should return an object');
      assert(typeof res.success === 'boolean', 'res.success should be boolean');

      if (res.success) {
        assert(res.response && res.response.data, 'response.data should exist');
        const data = res.response.data;
        assert(typeof data.symbol === 'string', 'data.symbol should be a string');
        // Allow case-insensitive equality for safety
        assert(
          data.symbol && data.symbol.toUpperCase() === symbol.toUpperCase(),
          `data.symbol should equal ${symbol}`
        );
        assert(typeof data.price === 'number', 'data.price should be a number');
        // date may be string (per doc) or number (depending on implementation), accept both
        assert(
          typeof data.date === 'string' || typeof data.date === 'number',
          'data.date should be a string or a number'
        );
      } else {
        assert(res.error && typeof res.error === 'object', 'error object should exist when success=false');
        assert(typeof res.error.code === 'string', 'error.code should be a string');
        assert(typeof res.error.message === 'string', 'error.message should be a string');
      }
    });
  }

  // Boundary Value and Special Value Tests for symbol
  runTest('getIndexRealTimeData with empty string symbol', () => {
    let res;
    try {
      res = getIndexRealTimeData({ symbol: '' });
    } catch (e) {
      assert(e.message && typeof e.message === 'string', 'Should throw with an error message');
      return;
    }
    assert(res && typeof res === 'object', 'Should return an object');
    assert(typeof res.success === 'boolean', 'res.success should be boolean');
    if (res.success) {
      assert(res.response && res.response.data, 'response.data should exist');
      const data = res.response.data;
      assert(typeof data.symbol === 'string', 'data.symbol should be a string');
      assert(typeof data.price === 'number', 'data.price should be a number');
    } else {
      assert(res.error && typeof res.error.message === 'string', 'Should include error.message');
    }
  });

  runTest('getIndexRealTimeData with null symbol', () => {
    let res;
    try {
      res = getIndexRealTimeData({ symbol: null });
    } catch (e) {
      assert(e.message && typeof e.message === 'string', 'Should throw with an error message');
      return;
    }
    assert(res && typeof res === 'object', 'Should return an object');
    assert(typeof res.success === 'boolean', 'res.success should be boolean');
    if (res.success) {
      assert(res.response && res.response.data, 'response.data should exist');
      const data = res.response.data;
      assert(typeof data.symbol === 'string', 'data.symbol should be a string');
      assert(typeof data.price === 'number', 'data.price should be a number');
    } else {
      assert(res.error && typeof res.error.message === 'string', 'Should include error.message');
    }
  });

  runTest('getIndexRealTimeData with undefined symbol (missing param)', () => {
    let res;
    try {
      res = getIndexRealTimeData({});
    } catch (e) {
      assert(e.message && typeof e.message === 'string', 'Should throw with an error message');
      return;
    }
    assert(res && typeof res === 'object', 'Should return an object');
    assert(typeof res.success === 'boolean', 'res.success should be boolean');
    if (res.success) {
      assert(res.response && res.response.data, 'response.data should exist');
      const data = res.response.data;
      assert(typeof data.symbol === 'string', 'data.symbol should be a string');
      assert(typeof data.price === 'number', 'data.price should be a number');
    } else {
      assert(res.error && typeof res.error.message === 'string', 'Should include error.message');
    }
  });

  runTest('getIndexRealTimeData with wrong type symbol (number 0)', () => {
    let res;
    try {
      res = getIndexRealTimeData({ symbol: 0 });
    } catch (e) {
      assert(e.message && typeof e.message === 'string', 'Should throw with an error message');
      return;
    }
    assert(res && typeof res === 'object', 'Should return an object');
    assert(typeof res.success === 'boolean', 'res.success should be boolean');
    if (res.success) {
      assert(res.response && res.response.data, 'response.data should exist');
      const data = res.response.data;
      assert(typeof data.symbol === 'string', 'data.symbol should be a string');
      assert(typeof data.price === 'number', 'data.price should be a number');
    } else {
      assert(res.error && typeof res.error.message === 'string', 'Should include error.message');
    }
  });

  runTest('getIndexRealTimeData with extremely long symbol', () => {
    const longSymbol = '^' + 'A'.repeat(256);
    let res;
    try {
      res = getIndexRealTimeData({ symbol: longSymbol });
    } catch (e) {
      assert(e.message && typeof e.message === 'string', 'Should throw with an error message');
      return;
    }
    if (res.success) {
      assert(res.response && res.response.data, 'response.data should exist');
    } else {
      assert(res.error && typeof res.error.message === 'string', 'Should include error.message');
    }
  });

  console.log('\n=== getIndexRealTimeData Test Summary ===');
  console.log(`Total tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${totalTests - passedTests}`);
  console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

  if (passedTests !== totalTests) {
    throw new Error('Some getIndexRealTimeData tests failed. Please review the output above.');
  } else {
    console.log('🎉 All getIndexRealTimeData tests passed!');
  }
}

function main() {
  const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
  const { jagentId } = require('env');
  const { makeIndexRealTimeDataNode } = require('@arrays/data/stock/macro/index-realtime:v1.0.0');

  const graph = new Graph(jagentId);
  graph.addNode(
    'index_realtime_quote',
    makeIndexRealTimeDataNode({
      symbol: '^GSPC',
    })
  );

  graph.run();

  const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'index_realtime_quote', 'index_realtime_quote', { last: '10' }), graph.store);
  ts.init();

  if (!Array.isArray(ts.data)) {
    throw new Error('Expected index realtime quote data to be an array');
  }

  if (ts.data.length > 0) {
    const quote = ts.data[0];

    if (typeof quote.date !== 'number') {
      throw new Error('Expected quote.date to be a number (timestamp in ms)');
    }

    if (typeof quote.symbol !== 'string') {
      throw new Error('Expected quote.symbol to be a string');
    }

    if (typeof quote.price !== 'number') {
      throw new Error('Expected quote.price to be a number');
    }

    log(`✅ Index realtime quote validation passed: ${quote.symbol} @ ${quote.price} on ${new Date(quote.date).toISOString()}`);
  }

  log('✅ Index Real Time Data make*Node tests passed');

  // Validate refs for index_realtime_quote output
  const refsIndex = graph.getRefsForOutput('index_realtime_quote', 'index_realtime_quote');
  if (refsIndex.length > 0) {
    const ref = refsIndex[0];
    const expected = {
      id: '@arrays/data/stock/macro/index-realtime/getIndexRealTimeData',
      module_name: '@arrays/data/stock/macro/index-realtime',
      module_display_name: 'Index Real-Time Price',
      sdk_name: 'getIndexRealTimeData',
      sdk_display_name: 'Index Real-Time Price',
      source_name: 'Financial Modeling Prep',
      source: 'https://site.financialmodelingprep.com/developer/docs/stable/all-index-quotes',
    };

    if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for index_realtime_quote');
    if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for index_realtime_quote');
    if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for index_realtime_quote');
    if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for index_realtime_quote');
    if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for index_realtime_quote');
    if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for index_realtime_quote');
    if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for index_realtime_quote');
    log('✓ index_realtime_quote refs validated');
  } else {
    throw new Error('Assertion failed: refsIndex array is empty.');
  }

  // Now run direct function tests following example style and manual import
  testGetIndexRealTimeData();

  return 0;
}

main();
