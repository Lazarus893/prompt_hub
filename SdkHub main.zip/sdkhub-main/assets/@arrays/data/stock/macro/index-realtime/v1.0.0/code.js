const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

const getIndexRealTimeDataRef = {
    id: '@arrays/data/stock/macro/index-realtime/getIndexRealTimeData',
    module_name: '@arrays/data/stock/macro/index-realtime',
    module_display_name: 'Index Real-Time Price',
    sdk_name: 'getIndexRealTimeData',
    sdk_display_name: 'Index Real-Time Price',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/stable/all-index-quotes',
};

// Base description derived from doc for getIndexRealTimeData
const baseGetIndexRealTimeDataDesc = 'Get real-time index data';

// Dynamic description builder for getIndexRealTimeData
function buildGetIndexRealTimeDataCallDescription(actualParams = {}) {
    const parts = [baseGetIndexRealTimeDataDesc];

    // Add symbol if provided
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }

    return parts.join(' ').trim();
}

// Create reference with a dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getIndexRealTimeData(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/macro/index/real-time';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

// Parse "YYYY-MM-DD HH:mm:ss" (or "YYYY-MM-DDTHH:mm:ss") to epoch ms (UTC)
function parseApiDateToMs(s) {
    if (typeof s !== 'string') return null;
    const m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/);
    if (m) {
        const y = Number(m[1]);
        const mon = Number(m[2]);
        const d = Number(m[3]);
        const hh = Number(m[4]);
        const mm = Number(m[5]);
        const ss = Number(m[6]);
        return Date.UTC(y, mon - 1, d, hh, mm, ss, 0);
    }
    const t = Date.parse(s);
    return Number.isFinite(t) ? t : null;
}

function makeIndexRealTimeDataNode(params) {
    return {
        inputs: {
            index_real_time_data_raw: () => getIndexRealTimeData(params),
        },
        outputs: {
            index_realtime_quote: {
                name: 'index_realtime_quote',
                description: 'Latest real-time quote for an index',
                fields: [
                    { name: 'date', type: 'number', description: 'quote time ms (UTC) parsed from API response' },
                    { name: 'symbol', type: 'string', description: 'index symbol, e.g., SPX' },
                    { name: 'price', type: 'number', description: 'current price' },
                ],
                ref: createReferenceWithTitle(getIndexRealTimeDataRef, params, buildGetIndexRealTimeDataCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.index_real_time_data_raw;

            if (raw?.error || raw.success !== true) {
                throw new Error(`API Error: ${raw.error.message || 'Unknown error'}`);
            }

            if (!raw?.response?.data) {
                return { index_realtime_quote: [] };
            }

            const data = raw.response.data;
            const quoteTime = parseApiDateToMs(data.date);
            if (!Number.isFinite(quoteTime)) {
                throw new Error('Failed to parse quote time: ' + JSON.stringify(data.date));
            }

            const symbol = data.symbol || (params && params.symbol) || '';
            const price = data.price;

            // Check if price is 0, which indicates the symbol doesn't exist
            if (price === 0) {
                throw new Error(`Symbol not found: ${symbol}`);
            }

            return {
                index_realtime_quote: [
                    {
                        date: quoteTime,
                        symbol,
                        price,
                    },
                ],
            };
        },
    };
}

function getRefs() {
    return [
        getIndexRealTimeDataRef,
    ];
}

module.exports = {
    getIndexRealTimeData,
    makeIndexRealTimeDataNode,
    getRefs,
};
