function testGetForexRealTimeData() {
    console.log('\n=== Testing getForexRealTimeData (Direct Function) ===');

    const { getForexRealTimeData } = require('@arrays/data/stock/macro/forex-realtime:v1.0.0');

    let totalTests = 0;
    let passedTests = 0;

    function assert(condition, message) {
        if (!condition) throw new Error(message || 'Assertion failed');
    }

    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    // Happy Path: Test a comprehensive set of major FX pairs
    const MAJOR_PAIRS = [
        'EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD', 'USDCAD',
        'USDCHF', 'NZDUSD', 'EURJPY', 'GBPJPY', 'EURGBP',
        'AUDJPY', 'CADJPY'
    ];

    for (const symbol of MAJOR_PAIRS) {
        runTest(`getForexRealTimeData happy path for ${symbol}`, () => {
            const res = getForexRealTimeData({ symbol });
            assert(res && typeof res === 'object', 'Result should be an object');
            assert(res.success === true, 'success should be true');
            assert(res.error === null || res.error === undefined, 'error should be null/undefined on success');
            assert(res.response && typeof res.response === 'object', 'response should be an object');
            assert(res.response.data && typeof res.response.data === 'object', 'response.data should be an object');
            const data = res.response.data;
            assert(typeof data.symbol === 'string', 'data.symbol should be string');
            assert(data.symbol.toUpperCase() === symbol.toUpperCase(), `data.symbol should equal requested symbol (${symbol})`);
            // Doc says date is a string. Be tolerant if implementation returns a timestamp number.
            assert(
                typeof data.date === 'string' || typeof data.date === 'number',
                'data.date should be string (per doc) or number (timestamp)'
            );
            assert(typeof data.price === 'number' && !Number.isNaN(data.price), 'data.price should be a number');
        });
    }

    // Boundary Value Analysis & Special Values
    runTest('lowercase symbol should be handled or normalized', () => {
        const res = getForexRealTimeData({ symbol: 'eurusd' });
        // Accept either normalized success or structured failure
        if (res && res.success === true) {
            assert(res.response && res.response.data, 'response.data should exist');
            assert(res.response.data.symbol.toUpperCase() === 'EURUSD', 'Should normalize to EURUSD');
        } else {
            // If failure style is returned, validate error object
            assert(res && res.success === false && res.error, 'Should return structured error on failure');
            assert(typeof res.error.code === 'string', 'error.code should be string');
            assert(typeof res.error.message === 'string', 'error.message should be string');
        }
    });

    runTest('too short symbol should fail (e.g., EURUS)', () => {
        try {
            const res = getForexRealTimeData({ symbol: 'EURUS' });
            if (!(res && res.success === false && res.error)) {
                throw new Error('Expected failure but function succeeded');
            }
            assert(typeof res.error.code === 'string', 'error.code should be string');
            assert(typeof res.error.message === 'string', 'error.message should be string');
        } catch (e) {
            // Accept thrown errors as valid failure behavior
            assert(e.message && typeof e.message === 'string');
        }
    });

    runTest('too long symbol should fail', () => {
        try {
            const res = getForexRealTimeData({ symbol: 'EURUSDEURUSDEURUSD' });
            if (!(res && res.success === false && res.error)) {
                throw new Error('Expected failure but function succeeded');
            }
            assert(typeof res.error.code === 'string', 'error.code should be string');
            assert(typeof res.error.message === 'string', 'error.message should be string');
        } catch (e) {
            assert(e.message && typeof e.message === 'string');
        }
    });

    runTest('symbol with separator (EUR/USD) should fail', () => {
        try {
            const res = getForexRealTimeData({ symbol: 'EUR/USD' });
            if (!(res && res.success === false && res.error)) {
                throw new Error('Expected failure but function succeeded');
            }
        } catch (e) {
            assert(e.message && typeof e.message === 'string');
        }
    });

    runTest('invalid symbol should fail', () => {
        try {
            const res = getForexRealTimeData({ symbol: 'ZZZZZZ' });
            if (!(res && res.success === false && res.error)) {
                throw new Error('Expected failure but function succeeded');
            }
            assert(typeof res.error.code === 'string', 'error.code should be string');
            assert(typeof res.error.message === 'string', 'error.message should be string');
        } catch (e) {
            assert(e.message && typeof e.message === 'string');
        }
    });

    // Special values
    runTest('empty string symbol should fail', () => {
        try {
            const res = getForexRealTimeData({ symbol: '' });
            if (!(res && res.success === false && res.error)) {
                throw new Error('Expected failure but function succeeded');
            }
        } catch (e) {
            assert(e.message && typeof e.message === 'string');
        }
    });

    runTest('null symbol should fail', () => {
        try {
            const res = getForexRealTimeData({ symbol: null });
            if (!(res && res.success === false && res.error)) {
                throw new Error('Expected failure but function succeeded');
            }
        } catch (e) {
            assert(e.message && typeof e.message === 'string');
        }
    });

    runTest('numeric symbol should fail', () => {
        try {
            const res = getForexRealTimeData({ symbol: 0 });
            if (!(res && res.success === false && res.error)) {
                throw new Error('Expected failure but function succeeded');
            }
        } catch (e) {
            assert(e.message && typeof e.message === 'string');
        }
    });

    runTest('undefined params should fail (missing required symbol)', () => {
        try {
            const res = getForexRealTimeData();
            if (!(res && res.success === false && res.error)) {
                throw new Error('Expected failure but function succeeded');
            }
            assert(typeof res.error.code === 'string');
            assert(typeof res.error.message === 'string');
        } catch (e) {
            assert(e.message && typeof e.message === 'string');
        }
    });

    console.log('\n=== getForexRealTimeData Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function testMakeNodeFlow() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeForexRealTimeDataNode } = require('@arrays/data/stock/macro/forex-realtime:v1.0.0');

    const graph = new Graph(jagentId);
    graph.addNode(
        'forex_realtime_quote',
        makeForexRealTimeDataNode({
            symbol: 'EURUSD',
        })
    );

    graph.run();

    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'forex_realtime_quote', 'forex_realtime_quote', { last: '10' }), graph.store);
    ts.init();

    if (!Array.isArray(ts.data)) {
        throw new Error('Expected forex realtime quote data to be an array');
    }

    if (ts.data.length > 0) {
        const quote = ts.data[0];

        if (typeof quote.date !== 'number') {
            throw new Error('Expected quote.date to be a number (timestamp in ms)');
        }

        if (typeof quote.symbol !== 'string') {
            throw new Error('Expected quote.symbol to be a string');
        }

        if (typeof quote.price !== 'number') {
            throw new Error('Expected quote.price to be a number');
        }

        if (typeof log === 'function') {
            log(`✅ Forex realtime quote validation passed: ${quote.symbol} @ ${quote.price} on ${new Date(quote.date).toISOString()}`);
        } else {
            console.log(`✅ Forex realtime quote validation passed: ${quote.symbol} @ ${quote.price} on ${new Date(quote.date).toISOString()}`);
        }
    }

    // Validate refs for output 'forex_realtime_quote'
    const refsForex = graph.getRefsForOutput('forex_realtime_quote', 'forex_realtime_quote');
    if (refsForex.length > 0) {
        const ref = refsForex[0];
        const expected = {
            id: '@arrays/data/stock/macro/forex-realtime/getForexRealTimeData',
            module_name: '@arrays/data/stock/macro/forex-realtime',
            module_display_name: 'Forex Real-Time Price',
            sdk_name: 'getForexRealTimeData',
            sdk_display_name: 'Forex Real-Time Price',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stable/forex-quote',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for forex_realtime_quote');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for forex_realtime_quote');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for forex_realtime_quote');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for forex_realtime_quote');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for forex_realtime_quote');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for forex_realtime_quote');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for forex_realtime_quote');
        if (typeof log === 'function') {
            log('✓ forex_realtime_quote refs validated');
        } else {
            console.log('✓ forex_realtime_quote refs validated');
        }
    } else {
        throw new Error('Assertion failed: refsForex array is empty.');
    }

    if (typeof log === 'function') {
        log('✅ Forex Real Time Data make*Node tests passed');
    } else {
        console.log('✅ Forex Real Time Data make*Node tests passed');
    }
}

function main() {
    testGetForexRealTimeData();
    testMakeNodeFlow();
    return 0;
}

main();
