const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference object for getForexRealTimeData based on tool.json metadata
const getForexRealTimeDataRef = {
    id: '@arrays/data/stock/macro/forex-realtime/getForexRealTimeData',
    module_name: '@arrays/data/stock/macro/forex-realtime',
    module_display_name: 'Forex Real-Time Price',
    sdk_name: 'getForexRealTimeData',
    sdk_display_name: 'Forex Real-Time Price',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/stable/forex-quote',
};

// Base description and dynamic description builder derived from doc
const getForexRealTimeDataBaseDescription = 'Get real-time forex quote';
function buildGetForexRealTimeDataCallDescription(actualParams = {}) {
    const parts = [getForexRealTimeDataBaseDescription];

    if (actualParams && typeof actualParams === 'object') {
        if (typeof actualParams.symbol === 'string' && actualParams.symbol.trim() !== '') {
            parts.push(`for ${actualParams.symbol.trim()}`);
        }
    }

    return parts.join(' ').trim();
}

// Helper to create reference with dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getForexRealTimeData(params) {
    // Input validation
    if (!params || typeof params !== 'object') {
        return {
            success: false,
            error: { code: 'INVALID_PARAMS', message: 'Invalid parameters: params must be an object' },
            response: null
        };
    }

    const symbol = params.symbol;
    if (!symbol || typeof symbol !== 'string' || symbol.trim() === '') {
        return {
            success: false,
            error: { code: 'INVALID_SYMBOL', message: 'Invalid parameters: symbol is required and must be a non-empty string' },
            response: null
        };
    }

    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/macro/forex/real-time';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

// Parse "YYYY-MM-DD HH:mm:ss" (or "YYYY-MM-DDTHH:mm:ss") to epoch ms (UTC)
function parseApiDateToMs(s) {
    if (typeof s !== 'string') return null;
    const m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/);
    if (m) {
        const y = Number(m[1]);
        const mon = Number(m[2]);
        const d = Number(m[3]);
        const hh = Number(m[4]);
        const mm = Number(m[5]);
        const ss = Number(m[6]);
        return Date.UTC(y, mon - 1, d, hh, mm, ss, 0);
    }
    // Fallback: attempt Date.parse; if it yields a number, use it.
    const t = Date.parse(s);
    return Number.isFinite(t) ? t : null;
}

function makeForexRealTimeDataNode(params) {
    return {
        inputs: {
            forex_real_time_data_raw: () => getForexRealTimeData(params),
        },
        outputs: {
            forex_realtime_quote: {
                name: 'forex_realtime_quote',
                description: 'Latest real-time quote for a forex pair',
                fields: [
                    { name: 'date', type: 'number', description: 'quote time ms (UTC) parsed from API response' },
                    { name: 'symbol', type: 'string', description: 'forex pair symbol, e.g., EURUSD' },
                    { name: 'price', type: 'number', description: 'current price' },
                ],
                ref: createReferenceWithTitle(getForexRealTimeDataRef, params, buildGetForexRealTimeDataCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.forex_real_time_data_raw;

            if (raw?.error) {
                throw new Error(`API Error: ${raw.error.message || 'Unknown error'}`);
            }

            if (!raw?.response?.data) {
                return { forex_realtime_quote: [] };
            }

            const data = raw.response.data;
            const quoteTime = parseApiDateToMs(data.date);
            if (!Number.isFinite(quoteTime)) {
                throw new Error('Failed to parse quote time: ' + JSON.stringify(data.date));
            }

            const symbol = data.symbol || (params && params.symbol) || '';
            const price = data.price;

            // Check if price is 0, which indicates the symbol doesn't exist
            if (price === 0) {
                throw new Error(`Symbol not found: ${symbol}`);
            }

            return {
                forex_realtime_quote: [
                    {
                        date: quoteTime,
                        symbol,
                        price,
                    },
                ],
            };
        },
    };
}
function getRefs() {
    return [
        getForexRealTimeDataRef,
    ];
}

module.exports = {
    getForexRealTimeData,
    makeForexRealTimeDataNode,
    getRefs,
};
