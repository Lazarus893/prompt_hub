const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

const getCommodityHistoricalDataRef = {
	id: '@arrays/data/stock/macro/commodity-historical/getCommodityHistoricalData',
	module_name: '@arrays/data/stock/macro/commodity-historical',
	module_display_name: 'Commodity Price History',
	sdk_name: 'getCommodityHistoricalData',
	sdk_display_name: 'Commodity Price History',
	source_name: 'Financial Modeling Prep',
	source: "https://site.financialmodelingprep.com/developer/docs/stable/commodities-historical-price-eod-full",
};

// Base description (summarized from doc) for getCommodityHistoricalData
// Summarized: Retrieve historical OHLCV time series for a commodity within a date range.
const baseGetCommodityHistoricalDataDesc = 'Get commodity OHLCV history';

// Dynamic description builder for getCommodityHistoricalData
function buildGetCommodityHistoricalDataCallDescription(actualParams = {}) {
    const parts = [baseGetCommodityHistoricalDataDesc];

    // Symbol (required by doc, if provided we include it)
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }

    // Date filters
    const filters = [];
    const { start_date, end_date } = actualParams || {};
    if (start_date && end_date) {
        filters.push(`Time: ${start_date} to ${end_date}`);
    } else if (start_date) {
        filters.push(`Time from: ${start_date}`);
    } else if (end_date) {
        filters.push(`Time until: ${end_date}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getCommodityHistoricalData(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/macro/commodity/historical';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function toMs(value) {
    if (!value) {
        return null;
    }
    const parsed = Date.parse(value);
    return Number.isNaN(parsed) ? null : parsed;
}

function ensureUniqueDates(records) {
    const used = new Set();
    return records.map((record) => {
        let { date } = record;
        while (used.has(date)) {
            date += 1;
        }
        used.add(date);
        return { ...record, date };
    });
}

function makeCommodityHistoricalNode(params) {
    return {
        inputs: {
            commodity_raw: () => getCommodityHistoricalData(params),
        },
        outputs: {
            commodity_historical: {
                name: 'commodity_historical',
                description: 'Historical commodity prices',
                fields: [
                    { name: 'date', type: 'number', description: 'date ms' },
                    {
                        name: 'symbol',
                        type: 'string',
                        description: 'commodity symbol',
                    },
                    { name: 'open', type: 'number', description: 'open price' },
                    { name: 'high', type: 'number', description: 'high price' },
                    { name: 'low', type: 'number', description: 'low price' },
                    {
                        name: 'close',
                        type: 'number',
                        description: 'close price',
                    },
                    { name: 'volume', type: 'number', description: 'volume' },
                ],
                ref: createReferenceWithTitle(getCommodityHistoricalDataRef, params, buildGetCommodityHistoricalDataCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.commodity_raw;

            if (raw?.error) {
                throw new Error(`API Error: ${raw.error.message || 'Unknown error'}`);
            }

            if (!raw?.response?.data) {
                return { commodity_historical: [] };
            }

            if (!Array.isArray(raw.response.data)) {
                throw new Error('Invalid API response: response.data is not an array');
            }

            const series = raw.response.data
                .map((item) => {
                    const date = toMs(item.date);
                    if (date == null) {
                        return null;
                    }
                    return {
                        date,
                        symbol: item.symbol,
                        open: item.open,
                        high: item.high,
                        low: item.low,
                        close: item.close,
                        volume: item.volume,
                    };
                })
                .filter(Boolean)
                .sort((a, b) => a.date - b.date);

            return { commodity_historical: ensureUniqueDates(series) };
        },
    };
}

function makeCommodityHistoricalDataNode(params) {
    return makeCommodityHistoricalNode(params);
}

// 新增：统一获取所有以 Ref 结尾的引用对象
function getRefs() {
    return [
        getCommodityHistoricalDataRef,
    ];
}

module.exports = {
    getCommodityHistoricalData,
    makeCommodityHistoricalNode,
    makeCommodityHistoricalDataNode,
    getRefs, // 新增导出
};