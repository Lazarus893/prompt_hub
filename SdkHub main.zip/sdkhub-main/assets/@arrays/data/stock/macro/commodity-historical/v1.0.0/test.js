function assert(condition, message) {
    if (!condition) {
        throw new Error(message || 'Assertion failed');
    }
}

function testGetCommodityHistoricalData() {
    console.log('\n=== Testing getCommodityHistoricalData (Direct Function) ===');

    const { getCommodityHistoricalData } = require('@arrays/data/stock/macro/commodity-historical:v1.0.0');

    const VALID_SYMBOLS = ['GCUSD', 'ZLUSX', 'SILUSD'];

    let totalTests = 0;
    let passedTests = 0;

    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    function validateSuccessResultStructure(res, symbol) {
        assert(res && typeof res === 'object', 'Result should be an object');
        assert(typeof res.success === 'boolean', 'success should be boolean');
        assert(res.success === true, 'Expected success === true for valid request');
      // Some implementations may omit error field on success; accept null or undefined.
      assert(res.error === null || typeof res.error === 'undefined', 'error should be null or undefined on success');
      // Accept either `response` or `result` as payload container
      const payload = res.response || res.result;
      assert(payload && typeof payload === 'object', 'response/result should be an object');
      assert(Array.isArray(payload.data), 'response/result.data should be an array');

      if (payload.data.length > 0) {
          const p = payload.data[0];
          assert(typeof p.symbol === 'string', 'data[].symbol should be string');
          // Prefer matching symbol if provided, but don’t fail hard if backend normalizes
          if (symbol) {
              assert(typeof p.symbol === 'string', 'data[].symbol should be string');
          }
          // date can be a number (ms) or a string (ISO or ms string)
          const t = typeof p.date;
          assert(t === 'number' || t === 'string', 'data[].date should be number (ms) or string');
          if (t === 'string') {
              const asNum = Number(p.date);
              const asTime = Date.parse(p.date);
              assert(!Number.isNaN(asNum) || !Number.isNaN(asTime), 'date string should be parseable as ms or ISO date');
          }
          assert(typeof p.open === 'number', 'data[].open should be number');
          assert(typeof p.high === 'number', 'data[].high should be number');
          assert(typeof p.low === 'number', 'data[].low should be number');
          assert(typeof p.close === 'number', 'data[].close should be number');
          assert(typeof p.volume === 'number', 'data[].volume should be number');
      }
    }

    function validateFailureResultOrError(resOrErr) {
        if (resOrErr instanceof Error) {
            // Thrown error is acceptable failure mode
            return;
        }
        assert(resOrErr && typeof resOrErr === 'object', 'Failure result should be an object');
        assert(typeof resOrErr.success === 'boolean', 'success should be boolean');
        assert(resOrErr.success === false, 'Expected success === false for invalid request');
        assert(resOrErr.error === null || typeof resOrErr.error === 'object', 'error should be object or null');
        if (resOrErr.error) {
            if ('code' in resOrErr.error) {
                assert(typeof resOrErr.error.code === 'string', 'error.code should be string');
            }
            if ('message' in resOrErr.error) {
                assert(typeof resOrErr.error.message === 'string', 'error.message should be string');
            }
        }
    }

    // --- Happy Path: enumerate supported symbols ---
    for (const symbol of VALID_SYMBOLS) {
        runTest(`getCommodityHistoricalData happy path for ${symbol}`, () => {
            const res = getCommodityHistoricalData({
                symbol,
                start_date: '2025-08-14',
                end_date: '2025-08-17',
            });
            validateSuccessResultStructure(res, symbol);
        });
    }

    // --- Boundary Value Analysis ---
    runTest('Boundary: start_date equals end_date (single day)', () => {
        const res = getCommodityHistoricalData({
            symbol: VALID_SYMBOLS[0],
            start_date: '2025-08-14',
            end_date: '2025-08-14',
        });
        validateSuccessResultStructure(res, VALID_SYMBOLS[0]);
    });

    runTest('Boundary: earliest supported start_date (2000-01-01)', () => {
        const res = getCommodityHistoricalData({
            symbol: VALID_SYMBOLS[0],
            start_date: '2000-01-01',
            end_date: '2000-01-03',
        });
        validateSuccessResultStructure(res, VALID_SYMBOLS[0]);
    });

    // --- Special/Invalid Values ---
    runTest('Invalid: end_date before start_date', () => {
        try {
            const res = getCommodityHistoricalData({
                symbol: VALID_SYMBOLS[0],
                start_date: '2025-08-17',
                end_date: '2025-08-14',
            });
            validateFailureResultOrError(res);
        } catch (e) {
            validateFailureResultOrError(e);
        }
    });

    runTest('Invalid: symbol is empty string', () => {
        try {
            const res = getCommodityHistoricalData({
                symbol: '',
                start_date: '2025-08-14',
                end_date: '2025-08-17',
            });
            validateFailureResultOrError(res);
        } catch (e) {
            validateFailureResultOrError(e);
        }
    });

    runTest('Invalid: symbol is unrecognized', () => {
        try {
            const res = getCommodityHistoricalData({
                symbol: 'INVALID123',
                start_date: '2025-08-14',
                end_date: '2025-08-17',
            });
            validateFailureResultOrError(res);
        } catch (e) {
            validateFailureResultOrError(e);
        }
    });

    runTest('Invalid: symbol is null', () => {
        try {
            const res = getCommodityHistoricalData({
                symbol: null,
                start_date: '2025-08-14',
                end_date: '2025-08-17',
            });
            validateFailureResultOrError(res);
        } catch (e) {
            validateFailureResultOrError(e);
        }
    });

    runTest('Invalid: symbol is undefined', () => {
        try {
            const res = getCommodityHistoricalData({
                symbol: undefined,
                start_date: '2025-08-14',
                end_date: '2025-08-17',
            });
            validateFailureResultOrError(res);
        } catch (e) {
            validateFailureResultOrError(e);
        }
    });

    runTest('Invalid: start_date missing', () => {
        try {
            const res = getCommodityHistoricalData({
                symbol: VALID_SYMBOLS[0],
                end_date: '2025-08-17',
            });
            validateFailureResultOrError(res);
        } catch (e) {
            validateFailureResultOrError(e);
        }
    });

    runTest('Invalid: end_date missing', () => {
        try {
            const res = getCommodityHistoricalData({
                symbol: VALID_SYMBOLS[0],
                start_date: '2025-08-14',
            });
            validateFailureResultOrError(res);
        } catch (e) {
            validateFailureResultOrError(e);
        }
    });

    runTest('Invalid: start_date invalid format', () => {
        try {
            const res = getCommodityHistoricalData({
                symbol: VALID_SYMBOLS[0],
                start_date: '14-08-2025',
                end_date: '2025-08-17',
            });
            validateFailureResultOrError(res);
        } catch (e) {
            validateFailureResultOrError(e);
        }
    });

    runTest('Invalid: end_date invalid format', () => {
        try {
            const res = getCommodityHistoricalData({
                symbol: VALID_SYMBOLS[0],
                start_date: '2025-08-14',
                end_date: '17-08-2025',
            });
            validateFailureResultOrError(res);
        } catch (e) {
            validateFailureResultOrError(e);
        }
    });

    console.log('\n=== getCommodityHistoricalData Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function main() {
    // Direct function tests (manual import for get* function)
    testGetCommodityHistoricalData();

    // Existing graph/node tests
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeCommodityHistoricalNode } = require('@arrays/data/stock/macro/commodity-historical:v1.0.0');

    const graph = new Graph(jagentId);
    graph.addNode(
        'commodity_historical',
        makeCommodityHistoricalNode({
            symbol: 'GCUSD',
            start_date: '2025-09-01',
            end_date: '2025-09-07',
        })
    );

    graph.run();

    // Validate refs for commodity_historical output
    const refsCommodityHistorical = graph.getRefsForOutput('commodity_historical', 'commodity_historical');
    if (refsCommodityHistorical.length > 0) {
        const ref = refsCommodityHistorical[0];
        const expected = {
            id: '@arrays/data/stock/macro/commodity-historical/getCommodityHistoricalData',
            module_name: '@arrays/data/stock/macro/commodity-historical',
            module_display_name: 'Commodity Price History',
            sdk_name: 'getCommodityHistoricalData',
            sdk_display_name: 'Commodity Price History',
            source_name: 'Financial Modeling Prep',
            source: "https://site.financialmodelingprep.com/developer/docs/stable/commodities-historical-price-eod-full",
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for commodity_historical');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for commodity_historical');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for commodity_historical');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for commodity_historical');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for commodity_historical');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for commodity_historical');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for commodity_historical');
        if (typeof log === 'function') {
            log('✓ commodity_historical refs validated');
        } else {
            console.log('✓ commodity_historical refs validated');
        }
    } else {
        throw new Error('Assertion failed: refsCommodityHistorical array is empty.');
    }

    // Materialize and validate the commodity historical OHLCV output
    const ts = new TimeSeries(
        new TimeSeriesUri(jagentId, 'commodity_historical', 'commodity_historical', { last: '10' }),
        graph.store
    );
    ts.init();

    if (!Array.isArray(ts.data)) {
        throw new Error('Expected commodity historical data to be an array');
    }

    if (ts.data.length > 0) {
        const ohlcv = ts.data[0];

        if (typeof ohlcv.date !== 'number') {
            throw new Error('Expected ohlcv.date to be a number (timestamp in ms)');
        }

        if (typeof ohlcv.symbol !== 'string') {
            throw new Error('Expected ohlcv.symbol to be a string');
        }

        if (typeof ohlcv.open !== 'number') {
            throw new Error('Expected ohlcv.open to be a number');
        }

        if (typeof ohlcv.high !== 'number') {
            throw new Error('Expected ohlcv.high to be a number');
        }

        if (typeof ohlcv.low !== 'number') {
            throw new Error('Expected ohlcv.low to be a number');
        }

        if (typeof ohlcv.close !== 'number') {
            throw new Error('Expected ohlcv.close to be a number');
        }

        if (typeof ohlcv.volume !== 'number') {
            throw new Error('Expected ohlcv.volume to be a number');
        }

        const msg = `✅ Commodity OHLCV validation passed: ${ohlcv.symbol} OHLC(${ohlcv.open}/${ohlcv.high}/${ohlcv.low}/${ohlcv.close}) on ${new Date(ohlcv.date).toISOString().split('T')[0]}`;
        if (typeof log === 'function') {
            log(msg);
        } else {
            console.log(msg);
        }
    }

    if (typeof log === 'function') {
        log('✅ Commodity Historical Data make*Node tests passed');
    } else {
        console.log('✅ Commodity Historical Data make*Node tests passed');
    }

    return 0;
}

main();
