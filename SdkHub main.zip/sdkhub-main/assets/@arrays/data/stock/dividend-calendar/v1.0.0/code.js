const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getDividendCalendar, derived from tool.json
const getDividendCalendarRef = {
    id: '@arrays/data/stock/dividend-calendar/getDividendCalendar',
    module_name: '@arrays/data/stock/dividend-calendar',
    module_display_name: 'Company Dividend Calendar',
    sdk_name: 'getDividendCalendar',
    sdk_display_name: 'Company Dividends Calendar',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/dividend-calendar-api',
};

// Base function description for getDividendCalendar (summarized from doc)
const getDividendCalendarBaseFuncDesc = 'Retrieve dividend calendar';

// Dynamic description builder for getDividendCalendar based on provided params
function buildGetDividendCalendarCallDescription(actualParams = {}) {
    const parts = [getDividendCalendarBaseFuncDesc];

    // Add symbol context if provided
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }

    // Add date range filters (payment date)
    const filters = [];
    if (actualParams.from && actualParams.to) {
        filters.push(`Payment date: ${actualParams.from} to ${actualParams.to}`);
    } else if (actualParams.from) {
        filters.push(`Payment date from: ${actualParams.from}`);
    } else if (actualParams.to) {
        filters.push(`Payment date to: ${actualParams.to}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getDividendCalendar(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/dividend-calendar';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key || 'c84b079d-3888-4366-9752-10bb6c51543d',
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    return r.json();
}

function parseYMDToUtcMs(s) {
    if (!s || typeof s !== 'string') return undefined;
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s.trim());
    if (!m) return undefined;
    const y = Number(m[1]);
    const mo0 = Number(m[2]) - 1;
    const d = Number(m[3]);
    return Date.UTC(y, mo0, d, 0, 0, 0, 0);
}

/**
 * Node factory for getDividendCalendar.
 * Groups dividends by ex-dividend date to ensure unique dates per record.
 * The params are exactly the same as getDividendCalendar(params).
 */
function makeDividendCalendarNode(params) {
    return {
        inputs: {
            // Fetch raw dividends from the SDK; no transformation here.
            dividend_calendar_raw: () => getDividendCalendar(params),
        },
        outputs: {
            dividends_by_date: {
                name: 'dividends_by_date',
                description: 'Dividends grouped by ex-dividend date (one record per date).',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'payment date ms (UTC midnight)',
                    },
                    {
                        name: 'count',
                        type: 'number',
                        description: 'number of dividend items on this date',
                    },
                    {
                        name: 'items',
                        type: 'array',
                        description: 'dividend items for this payment date',
                        fields: [
                            { name: 'symbol', type: 'string' },
                            { name: 'dividend', type: 'number' },
                            { name: 'adjDividend', type: 'number' },
                            { name: 'frequency', type: 'string' },
                            { name: 'yield', type: 'number' },
                            {
                                name: 'record_date',
                                type: 'string',
                                description: 'yyyy-mm-dd',
                            },
                            {
                                name: 'payment_date',
                                type: 'string',
                                description: 'yyyy-mm-dd',
                            },
                            {
                                name: 'declaration_date',
                                type: 'string',
                                description: 'yyyy-mm-dd; may be undefined',
                            },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getDividendCalendarRef, params, buildGetDividendCalendarCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.dividend_calendar_raw || {};
            const dividends = Array.isArray(raw?.response?.dividends) ? raw.response.dividends : [];

            // Group by ex-dividend date (YYYY-MM-DD)
            const byDate = new Map(); // key: ms (UTC midnight), value: items[]

            for (const d of dividends) {
                const exDateMs = parseYMDToUtcMs(d.paymentDate);
                if (exDateMs == null) {
                    // skip records without a valid ex-dividend date
                    continue;
                }
                if (!byDate.has(exDateMs)) byDate.set(exDateMs, []);
                const item = {
                    symbol: d.symbol,
                    dividend: typeof d.dividend === 'number' ? d.dividend : d.dividend != null ? Number(d.dividend) : undefined,
                    adjDividend: typeof d.adjDividend === 'number' ? d.adjDividend : d.adjDividend != null ? Number(d.adjDividend) : undefined,
                    frequency: d.frequency,
                    yield: typeof d.yield === 'number' ? d.yield : d.yield != null ? Number(d.yield) : undefined,
                    record_date: d.recordDate,
                    payment_date: d.paymentDate,
                    declaration_date: d.declarationDate,
                };
                byDate.get(exDateMs).push(item);
            }

            // Build per-day records with nested items, order days descending
            const records = Array.from(byDate.entries())
                .sort((a, b) => b[0] - a[0])
                .map(([date, items]) => ({
                    date,
                    count: items.length,
                    items,
                }));

            if (records.length) {
                log('dividend_calendar_grouped', {
                    in_count: dividends.length,
                    group_count: records.length,
                });
            }

            return { dividends_by_date: records };
        },
    };
}

function getRefs() {
    return [getDividendCalendarRef];
}

module.exports = {
    getDividendCalendar,
    makeDividendCalendarNode,
    getRefs,
};
