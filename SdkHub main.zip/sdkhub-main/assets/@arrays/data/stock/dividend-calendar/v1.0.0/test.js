const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');

// Simple assert helper similar to example.js style
function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

function testGetDividendCalendar() {
  console.log('\n=== Testing getDividendCalendar (Direct Calls) ===');

  const { getDividendCalendar } = require('@arrays/data/stock/dividend-calendar:v1.0.0');

  let totalTests = 0;
  let passedTests = 0;

  function runTest(testName, testFunc) {
    totalTests++;
    try {
      testFunc();
      console.log(`✅ ${testName}`);
      passedTests++;
    } catch (e) {
      console.log(`❌ ${testName}: ${e.message}`);
    }
  }

  // Helpers
  function validateSchema(result) {
    assert(result && typeof result === 'object', 'Result should be an object');
    assert(typeof result.success === 'boolean', 'success should be boolean');
    assert(result.response && typeof result.response === 'object', 'response should be object');
    assert(Array.isArray(result.response.dividends), 'response.dividends should be array');
    assert(typeof result.response.count === 'number', 'response.count should be number');
    assert(result.response.count === result.response.dividends.length, 'count should equal dividends length');
    // Validate first few items for structure and enum-like frequency
    const allowedFrequencies = new Set(['Monthly', 'Quarterly', 'Irregular', 'Annual', 'Semi-Annual']); // include common possibilities
    for (const item of result.response.dividends.slice(0, 5)) {
      assert(typeof item.date === 'string', 'dividends[].date must be string');
      assert(typeof item.frequency === 'string', 'dividends[].frequency must be string');
      assert(allowedFrequencies.has(item.frequency) || typeof item.frequency === 'string', 'frequency should be a known string');
      assert(typeof item.symbol === 'string', 'dividends[].symbol must be string');
      assert(typeof item.dividend === 'number', 'dividends[].dividend must be number');
      assert(typeof item.adjDividend === 'number', 'dividends[].adjDividend must be number');
      assert(typeof item.recordDate === 'string', 'dividends[].recordDate must be string');
      assert(typeof item.paymentDate === 'string', 'dividends[].paymentDate must be string');
      assert(typeof item.declarationDate === 'string' || item.declarationDate === null, 'dividends[].declarationDate must be string|null');
      assert(typeof item.yield === 'number', 'dividends[].yield must be number');
    }
  }

  // Happy path tests
  runTest('getDividendCalendar with date range only', () => {
    const res = getDividendCalendar({ from: '2024-01-19', to: '2024-01-20' });
    validateSchema(res);
  });

  runTest('getDividendCalendar with symbol AAPL in range', () => {
    const res = getDividendCalendar({ symbol: 'AAPL', from: '2024-01-01', to: '2024-01-31' });
    validateSchema(res);
  });

  runTest('getDividendCalendar with symbol containing dot (BRK.B)', () => {
    const res = getDividendCalendar({ symbol: 'BRK.B', from: '2023-08-10', to: '2023-08-15' });
    validateSchema(res);
  });

  runTest('getDividendCalendar same-day range', () => {
    const res = getDividendCalendar({ from: '2024-01-19', to: '2024-01-19' });
    validateSchema(res);
  });

  // Boundary value tests
  // Note: Avoid omitting from/to to prevent backend default huge ranges causing heavy loads.
  // We keep boundary focused on tight ranges covered above.

  // Special/invalid value tests (expect errors)
  runTest('getDividendCalendar invalid symbol with dash (BRK-B) handled (error or valid)', () => {
    try {
      const res = getDividendCalendar({ symbol: 'BRK-B', from: '2024-01-01', to: '2024-01-02' });
      // Some backends may coerce dash to dot; if no error, ensure schema
      validateSchema(res);
    } catch (e) {
      assert(e && e.message && (e.message.includes('Error') || e.message.toLowerCase().includes('invalid') || e.message.toLowerCase().includes('dash')),
        'Should handle invalid symbol with dash');
    }
  });

  runTest('getDividendCalendar invalid date format handled (error or valid)', () => {
    try {
      const res = getDividendCalendar({ from: '2024/01/01', to: '2024-01-02' });
      validateSchema(res);
    } catch (e) {
      assert(e && e.message && (e.message.includes('Error') || e.message.toLowerCase().includes('invalid')),
        'Should handle invalid date format');
    }
  });

  runTest('getDividendCalendar to < from handled (error or valid)', () => {
    try {
      const res = getDividendCalendar({ from: '2024-02-01', to: '2024-01-31' });
      validateSchema(res);
    } catch (e) {
      assert(e && e.message && (e.message.includes('Error') || e.message.toLowerCase().includes('range')),
        'Should handle inverted date range');
    }
  });

  runTest('getDividendCalendar null symbol handled gracefully (error or valid empty result)', () => {
    try {
      const res = getDividendCalendar({ symbol: null, from: '2024-01-01', to: '2024-01-02' });
      validateSchema(res);
    } catch (e) {
      assert(e && e.message && (e.message.includes('Error') || e.message.toLowerCase().includes('invalid')),
        'Should handle null symbol');
    }
  });

  runTest('getDividendCalendar empty string symbol handled gracefully (error or valid empty result)', () => {
    try {
      const res = getDividendCalendar({ symbol: '', from: '2024-01-01', to: '2024-01-02' });
      validateSchema(res);
    } catch (e) {
      assert(e && e.message && (e.message.includes('Error') || e.message.toLowerCase().includes('invalid')),
        'Should handle empty symbol');
    }
  });

  // Print test summary
  console.log('\n=== getDividendCalendar Test Summary ===');
  console.log(`Total tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${totalTests - passedTests}`);
  console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function main() {
  // 1) Direct function tests for getDividendCalendar
  testGetDividendCalendar();

  // 2) Node + Graph based tests with stubbed and online data
  const { makeDividendCalendarNode } = require('@arrays/data/stock/dividend-calendar:v1.0.0');

  // Build node and override input lambda to avoid network dependency in test
  const nodeCfg = makeDividendCalendarNode({ from: '2023-08-10', to: '2023-08-15' });
  const sampleRaw = {
    success: true,
    response: {
      dividends: [
        {
          date: '2024-01-05',
          frequency: 'Quarterly',
          symbol: 'CEEB3.SA',
          dividend: 0.38583,
          adjDividend: 0.38583,
          recordDate: '2024-01-04',
          paymentDate: '2024-12-31',
          declarationDate: '',
          yield: 11.38544636,
        },
        {
          date: '2024-01-05',
          frequency: 'Irregular',
          symbol: 'CEEB5.SA',
          dividend: 0.38583,
          adjDividend: 0.38583,
          recordDate: '2024-01-04',
          paymentDate: '2024-12-31',
          declarationDate: '',
          yield: 11.67146885,
        },
        {
          date: '2024-01-02',
          frequency: 'Monthly',
          symbol: 'CMIN3.SA',
          dividend: 0.0674451,
          adjDividend: 0.0674451,
          recordDate: '2023-12-28',
          paymentDate: '2024-12-30',
          declarationDate: '',
          yield: 10.81935857,
        },
      ],
      count: 3,
    },
  };
  // Override to return sample data
  nodeCfg.inputs.dividend_calendar_raw = () => sampleRaw;

  const g = new Graph(jagentId);
  g.addNode('div_cal', nodeCfg);
  g.run();

  // Materialize and validate the grouped output
  const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'div_cal', 'dividends_by_date', { last: '10' }), g.store);
  ts.init();
  if (!Array.isArray(ts.data) || ts.data.length < 2) {
    throw new Error('Expected at least 2 grouped dividend date records');
  }
  const latest = ts.data[0];
  if (typeof latest.date !== 'number') {
    throw new Error('date must be a number (ms)');
  }
  if (!Array.isArray(latest.items)) {
    throw new Error('items must be an array');
  }
  const firstItem = latest.items[0];
  if (typeof firstItem.frequency !== 'string') {
    throw new Error('frequency must be a string');
  }
  if (!(typeof firstItem.yield === 'number')) {
    throw new Error('yield must be a number');
  }

  // Enumeration coverage: ensure all documented frequencies are present in stubbed dataset
  const freqSet = new Set();
  for (const group of ts.data) {
    if (Array.isArray(group.items)) {
      for (const it of group.items) {
        if (it && typeof it.frequency === 'string') freqSet.add(it.frequency);
      }
    }
  }
  if (!freqSet.has('Monthly')) throw new Error('Expected frequency Monthly to be present');
  if (!freqSet.has('Quarterly')) throw new Error('Expected frequency Quarterly to be present');
  if (!freqSet.has('Irregular')) throw new Error('Expected frequency Irregular to be present');

  // Validate refs for dividends_by_date output
  const refsDivByDate = g.getRefsForOutput('div_cal', 'dividends_by_date');
  if (refsDivByDate.length > 0) {
    const ref = refsDivByDate[0];
    const expected = {
      id: '@arrays/data/stock/dividend-calendar/getDividendCalendar',
      module_name: '@arrays/data/stock/dividend-calendar',
      module_display_name: 'Company Dividend Calendar',
      sdk_name: 'getDividendCalendar',
      sdk_display_name: 'Company Dividends Calendar',
      source_name: 'Financial Modeling Prep',
      source: 'https://site.financialmodelingprep.com/developer/docs/dividend-calendar-api',
    };

    if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for dividends_by_date');
    if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for dividends_by_date');
    if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for dividends_by_date');
    if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for dividends_by_date');
    if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for dividends_by_date');
    if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for dividends_by_date');
    if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for dividends_by_date');
  } else {
    throw new Error('Assertion failed: refsDivByDate array is empty.');
  }

  // TEST USING ONLINE DATA FOR TESTING
  const nodeCfgOnline = makeDividendCalendarNode({
    from: '2024-01-19',
    to: '2024-01-20',
  });
  const g2 = new Graph(jagentId);
  g2.addNode('div_cal_online', nodeCfgOnline);
  g2.run();

  // Validate grouping and total count for 2024-01-19 to 2024-01-20
  const ts2 = new TimeSeries(new TimeSeriesUri(jagentId, 'div_cal_online', 'dividends_by_date', { last: '10' }), g2.store);
  ts2.init();
  if (!Array.isArray(ts2.data)) {
    throw new Error('online: dividends_by_date must be an array');
  }
  if (ts2.data.length !== 2) {
    throw new Error(`online: expected 2 groups, got ${ts2.data.length}`);
  }
  const observedTotal = ts2.data.reduce((acc, r) => acc + (typeof r.count === 'number' ? r.count : Array.isArray(r.items) ? r.items.length : 0), 0);
  if (observedTotal !== 56) {
    throw new Error(`online: expected total 56 items, got ${observedTotal}`);
  }

  return 0;
}

main();
