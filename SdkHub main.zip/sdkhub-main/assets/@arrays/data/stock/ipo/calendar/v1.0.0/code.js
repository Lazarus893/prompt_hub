const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Ref object generated from tool.json entry matching SdkName: getIPOCalendar
// Note: ModuleName in tool.json may contain trailing spaces; we trim for id/module_name consistency.
const getIPOCalendarRef = {
  id: "@arrays/data/stock/ipo/calendar/getIPOCalendar",
  module_name: "@arrays/data/stock/ipo/calendar",
  module_display_name: "Company IPO Calendar",
  sdk_name: "getIPOCalendar",
  sdk_display_name: "IPO Calendar",
  source_name: "Financial Modeling Prep",
  source: "https://site.financialmodelingprep.com/developer/docs/ipo-calendar-confirmed-api",
};

// Internal base description and dynamic call description builder (derived from doc)
const getIPOCalendarBaseDesc = "Retrieve IPO calendar events";

function buildGetIPOCalendarCallDescription(actualParams = {}) {
  const parts = [getIPOCalendarBaseDesc];

  const filters = [];
  const from = actualParams.from;
  const to = actualParams.to;

  if (from && to) {
    filters.push(`Date: ${from} to ${to}`);
  } else if (from) {
    // Doc notes from/to should be used together; include partial info if only one provided
    filters.push(`From: ${from}`);
  } else if (to) {
    filters.push(`To: ${to}`);
  }

  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }

  return parts.join(' ').trim();
}
function createReferenceWithTitle(refObject, params, titleBuilder) {
  // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
  const title = titleBuilder(params);

  // 2. 组合 refObject 和新 title
  const newObject = {
    ...refObject,
    title: title
  };

  // 3. 返回新对象
  return newObject;
}

function getIPOCalendar(params) {
  const { syncFetch: fetch } = require('net/http');
  const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/ipo-calendar';
  const keyValuePairs = Object.keys(params || {}).map((key) => {
    const value = params[key];
    return encodeURIComponent(key) + '=' + encodeURIComponent(value);
  });
  const queryString = keyValuePairs.join('&');
  const fullUrl = queryString ? `${baseUrl}?${queryString}` : baseUrl;
  const fetchOptions = {
    method: 'GET',
    headers: {
      'X-API-Key': key,
      'Content-Type': 'application/json',
    },
  };
  const r = fetch(fullUrl, fetchOptions);
  return r.json();
}

/**
 * Build a node that fetches IPO calendar data and emits one time-series record per DAY,
 * grouping multiple IPO events that occur on the same day into a nested array.
 * The node fetches raw data in the input lambda and transforms it to a strict time-series in run().
 *
 * Output series date derivation (record-level):
 * - Use start of day (00:00:00 UTC) from 'date' (YYYY-MM-DD). If only 'daa' exists, derive day from it.
 * - Within a day, do NOT micro-shift. Events are grouped in a nested array field.
 */
function makeIPOCalendarNode(params) {
  function parseIsoToMs(iso) {
    if (typeof iso !== 'string' || !iso) return null;
    const t = Date.parse(iso);
    return Number.isFinite(t) ? t : null;
  }
  function parseYmdToMs(ymd) {
    if (typeof ymd !== 'string') return null;
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(ymd);
    if (!m) return null;
    const y = Number(m[1]);
    const mo = Number(m[2]);
    const d = Number(m[3]);
    if (!Number.isFinite(y) || !Number.isFinite(mo) || !Number.isFinite(d)) return null;
    return Date.UTC(y, mo - 1, d, 0, 0, 0, 0);
  }

  return {
    inputs: {
      ipo_calendar_raw: () => getIPOCalendar(params),
    },
    outputs: {
      ipo_events: {
        name: 'ipo_events',
        description: 'IPO calendar (one record per day, events grouped)',
        fields: [
          { name: 'date', type: 'number', description: 'day start (UTC) in ms' },
          {
            name: 'events',
            type: 'array',
            description: 'IPO events of the day',
            fields: [
              { name: 'symbol', type: 'string' },
              { name: 'company', type: 'string' },
              { name: 'exchange', type: 'string' },
              { name: 'actions', type: 'string' },
              { name: 'shares', type: 'number' },
              { name: 'market_cap', type: 'string' },
              { name: 'price_range', type: 'string' },
              { name: 'ipo_date', type: 'string' },
              { name: 'event_time_iso', type: 'string' },
            ],
          },
        ],
        ref: createReferenceWithTitle(getIPOCalendarRef, params, buildGetIPOCalendarCallDescription),
      },
    },
    run: (inputs) => {
      const raw = inputs.ipo_calendar_raw;
      const events = raw && raw.response && Array.isArray(raw.response.events) ? raw.response.events : [];

      // Group events by day (UTC) using provided 'date' or derived from 'daa'
      const byDay = new Map(); // dayMs -> array of events
      for (const e of events) {
        const dayMs =
          parseYmdToMs(e.date) ??
          (function () {
            const isoMs = parseIsoToMs(e.daa);
            if (isoMs == null) return null;
            const d = new Date(isoMs);
            return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 0, 0, 0, 0);
          })();
        if (dayMs == null) {
          throw new Error('IPO event missing valid date/day: ' + JSON.stringify(e));
        }
        if (!byDay.has(dayMs)) byDay.set(dayMs, []);
        byDay.get(dayMs).push(e);
      }

      // Build per-day records with nested events, order days ascending
      const out = Array.from(byDay.entries())
        .sort((a, b) => a[0] - b[0])
        .map(([dayMs, arr]) => ({
          date: dayMs,
          events: arr.map((e) => ({
            symbol: typeof e.symbol === 'string' ? e.symbol : '',
            company: typeof e.company === 'string' ? e.company : '',
            exchange: typeof e.exchange === 'string' ? e.exchange : '',
            actions: typeof e.actions === 'string' ? e.actions : '',
            shares: Number.isFinite(e.shares) ? e.shares : 0,
            market_cap: typeof e.market_cap === 'string' ? e.market_cap : '',
            price_range: typeof e.price_range === 'string' ? e.price_range : '',
            ipo_date: typeof e.date === 'string' ? e.date : '',
            event_time_iso: typeof e.daa === 'string' ? e.daa : '',
          })),
        }));

      return { ipo_events: out };
    },
  };
}

function getRefs() {
  return [
    getIPOCalendarRef,
  ];
}

module.exports = {
  getIPOCalendar,
  makeIPOCalendarNode,
  getRefs,
};
