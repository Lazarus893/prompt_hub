'use strict';

function testNodeTransformation() {
    const { makeIPOCalendarNode } = require('@arrays/data/stock/ipo/calendar:v1.0.0');

    // Build node (no network call during test; we invoke run() with a stubbed input object)
    const node = makeIPOCalendarNode({});

    // Validate refs for ipo_events output
    const outputDef = node && node.outputs && node.outputs.ipo_events ? node.outputs.ipo_events : null;
    if (!outputDef) throw new Error('Assertion failed: ipo_events output definition missing.');
    const refsIPOEvents = outputDef.ref ? [outputDef.ref] : [];
    if (refsIPOEvents.length > 0) {
        const ref = refsIPOEvents[0];
        const expected = {
            id: '@arrays/data/stock/ipo/calendar/getIPOCalendar',
            module_name: '@arrays/data/stock/ipo/calendar',
            module_display_name: 'Company IPO Calendar',
            sdk_name: 'getIPOCalendar',
            sdk_display_name: 'IPO Calendar',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/ipo-calendar-confirmed-api',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for ipo_events');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for ipo_events');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for ipo_events');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for ipo_events');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for ipo_events');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for ipo_events');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for ipo_events');
        console.log('✓ ipo_events refs validated');
    } else {
        throw new Error('Assertion failed: refsIPOEvents array is empty.');
    }

    const rawKey = 'ipo_calendar_raw';
    const sample = {
        success: true,
        response: {
            events: [
                {
                    symbol: 'ABC',
                    date: '2025-08-12',
                    daa: '2025-08-12T13:30:00Z',
                    company: 'ABC Corp',
                    exchange: 'NASDAQ',
                    actions: 'Expected',
                    shares: 1000000,
                    price_range: '$10-$12',
                    market_cap: '$1B',
                },
                {
                    symbol: 'XYZ',
                    date: '2025-08-12',
                    daa: '2025-08-12T13:30:00Z',
                    company: 'XYZ Inc',
                    exchange: 'NYSE',
                    actions: 'Expected',
                    shares: 2000000,
                    market_cap: '$2B',
                },
                {
                    symbol: 'NOP',
                    date: '2025-08-15', // no daa -> derive 00:00:00 UTC
                    company: 'NOP Ltd',
                    exchange: 'NYSE',
                    actions: 'Priced',
                    shares: 1500000,
                    market_cap: '$1.5B',
                },
                {
                    // missing many optional fields to test defaults
                    symbol: 'MNO',
                    date: '2025-08-15',
                },
            ],
        },
    };

    const outputs = node.run({ [rawKey]: sample });
    const series = outputs['ipo_events'];
    // Expect 2 days: 2025-08-12 and 2025-08-15
    if (!Array.isArray(series) || series.length !== 2) {
        throw new Error('ipo_events per-day series length mismatch');
    }
    // Validate day records and nested events
    const day1 = series[0];
    const day2 = series[1];
    if (typeof day1.date !== 'number' || typeof day2.date !== 'number') throw new Error('day date must be number');
    if (!Array.isArray(day1.events) || day1.events.length !== 2) throw new Error('day1 must have 2 events');
    if (!Array.isArray(day2.events) || day2.events.length !== 2) throw new Error('day2 must have 2 events');
    for (const e of day1.events.concat(day2.events)) {
        if (typeof e.symbol !== 'string') throw new Error('event.symbol missing');
    }
    // check defaults on missing fields event
    const missing = day2.events.find((e) => e.symbol === 'MNO');
    if (!missing) throw new Error('missing defaults test event not found');
    if (missing.company !== '') throw new Error('default company should be empty string');
    if (missing.exchange !== '') throw new Error('default exchange should be empty string');
    if (missing.actions !== '') throw new Error('default actions should be empty string');
    if (missing.shares !== 0) throw new Error('default shares should be 0');
    if (missing.market_cap !== '') throw new Error('default market_cap should be empty string');
    if (missing.price_range !== '') throw new Error('default price_range should be empty string');
    if (missing.ipo_date !== '2025-08-15') throw new Error('ipo_date should echo input date');
    if (missing.event_time_iso !== '') throw new Error('default event_time_iso should be empty string');

    console.log('✅ IPO Calendar per-day grouping test passed');
}

function testGetIPOCalendarAPI() {
    const { getIPOCalendar } = require('@arrays/data/stock/ipo/calendar:v1.0.0'); // manual import for get* API

    // lightweight assert helpers (no system assert module available in runner)
    function assert(cond, msg) { if (!cond) throw new Error(msg || 'Assertion failed'); }
    assert.strictEqual = function(a, b, msg) { if (a !== b) throw new Error(msg || `Expected ${a} === ${b}`); };

    let totalTests = 0;
    let passedTests = 0;

    function runTest(name, fn) {
        totalTests++;
        try {
            fn();
            console.log(`✅ ${name}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${name}: ${e && e.message ? e.message : e}`);
        }
    }

    // Helpers
    const isYYYYMMDD = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s);
    const toEpoch = (s) => new Date(s).getTime();

    // Happy Path: no filters (all events)
    runTest('getIPOCalendar: returns events with no filters', () => {
        const res = getIPOCalendar({});
        assert(res && typeof res === 'object', 'result must be an object');
        assert.strictEqual(typeof res.success, 'boolean', 'success flag must exist');
        assert(res.response && Array.isArray(res.response.events), 'events must be an array');
        if (res.response.events.length > 0) {
            const e = res.response.events[0];
            assert.strictEqual(typeof e.symbol, 'string', 'symbol must be string');
            assert(isYYYYMMDD(e.date), 'date must be YYYY-MM-DD');
            if (e.daa != null) assert.strictEqual(typeof e.daa, 'string', 'daa must be string when present');
            if (e.company != null) assert.strictEqual(typeof e.company, 'string');
            if (e.exchange != null) assert.strictEqual(typeof e.exchange, 'string');
            if (e.actions != null) assert.strictEqual(typeof e.actions, 'string');
            if (e.shares != null) assert.strictEqual(typeof e.shares, 'number');
            if (e.price_range != null) assert.strictEqual(typeof e.price_range, 'string');
            if (e.market_cap != null) assert.strictEqual(typeof e.market_cap, 'string');
        }
    });

    // Prepare dynamic boundaries from dataset for robust tests
    let minDate = null;
    let maxDate = null;
    let allEvents = [];
    try {
        const all = getIPOCalendar({});
        allEvents = (all && all.response && Array.isArray(all.response.events)) ? all.response.events : [];
        if (allEvents.length > 0) {
            const dates = allEvents.map(e => e.date).filter(isYYYYMMDD);
            if (dates.length > 0) {
                dates.sort();
                minDate = dates[0];
                maxDate = dates[dates.length - 1];
            }
        }
    } catch (_) {}

    // Happy Path: valid range (minDate..maxDate if available, else skip)
    if (minDate && maxDate) {
        runTest(`getIPOCalendar: valid date range ${minDate}..${maxDate}`, () => {
            const res = getIPOCalendar({ from: minDate, to: maxDate });
            assert(res && typeof res === 'object', 'result must be object');
            assert(res.response && Array.isArray(res.response.events), 'events array must exist');
            for (const ev of res.response.events) {
                assert(isYYYYMMDD(ev.date), 'date format');
                assert(toEpoch(ev.date) >= toEpoch(minDate) && toEpoch(ev.date) <= toEpoch(maxDate), 'event within range');
                if (ev.actions === 'Expected') {
                    // For Expected status, price_range should commonly be present (per doc)
                    assert(ev.price_range == null || typeof ev.price_range === 'string', 'price_range string when present');
                }
            }
        });

        // Boundary: same-day range
        runTest(`getIPOCalendar: same-day range ${minDate}`, () => {
            const res = getIPOCalendar({ from: minDate, to: minDate });
            assert(res && typeof res === 'object', 'result must be object');
            assert(res.response && Array.isArray(res.response.events), 'events array must exist');
            for (const ev of res.response.events) {
                assert.strictEqual(ev.date, minDate, 'event should equal boundary date');
            }
        });
    }

    // Special/invalid combinations
    runTest('getIPOCalendar: only from handled gracefully', () => {
        let res;
        let threw = false;
        try {
            res = getIPOCalendar({ from: (minDate || '2025-01-01') });
        } catch (e) {
            threw = true;
        }
        if (!threw) {
            assert(res && typeof res === 'object', 'should return object when not throwing');
            assert(res.response && Array.isArray(res.response.events), 'events array must exist');
        }
    });

    runTest('getIPOCalendar: only to handled gracefully', () => {
        let res;
        let threw = false;
        try {
            res = getIPOCalendar({ to: (maxDate || '2025-12-31') });
        } catch (e) {
            threw = true;
        }
        if (!threw) {
            assert(res && typeof res === 'object', 'should return object when not throwing');
            assert(res.response && Array.isArray(res.response.events), 'events array must exist');
        }
    });

    runTest('getIPOCalendar: invalid date format handled gracefully', () => {
        let res;
        let threw = false;
        try {
            res = getIPOCalendar({ from: '2025/01/01', to: '2025-01-31' });
        } catch (e) {
            threw = true;
        }
        if (!threw) {
            assert(res && typeof res === 'object', 'should return object when not throwing');
            assert(res.response && Array.isArray(res.response.events), 'events array must exist');
        }
    });

    if (minDate && maxDate) {
        runTest('getIPOCalendar: reversed range handled (no throw, valid structure)', () => {
            let res;
            let threw = false;
            try {
                res = getIPOCalendar({ from: maxDate, to: minDate });
            } catch (e) {
                threw = true;
            }
            if (!threw) {
                assert(res && typeof res === 'object', 'should return object when not throwing');
                assert(res.response && Array.isArray(res.response.events), 'events array must exist');
            }
        });
    }

    // Special values: undefined and empty strings
    runTest('getIPOCalendar: undefined params treated as no filter', () => {
        const res = getIPOCalendar({ from: undefined, to: undefined });
        assert(res && typeof res === 'object', 'result must be object');
        assert(res.response && Array.isArray(res.response.events), 'events array must exist');
    });

    runTest('getIPOCalendar: empty strings handled gracefully', () => {
        let res;
        let threw = false;
        try {
            res = getIPOCalendar({ from: '', to: '' });
        } catch (e) {
            threw = true;
        }
        if (!threw) {
            assert(res && typeof res === 'object', 'should return object when not throwing');
            assert(res.response && Array.isArray(res.response.events), 'events array must exist');
        }
    });

    // Special values: nulls
    runTest('getIPOCalendar: null params handled like no filter or error', () => {
        let res;
        let threw = false;
        try {
            res = getIPOCalendar({ from: null, to: null });
        } catch (e) {
            threw = true;
        }
        if (!threw) {
            assert(res && typeof res === 'object', 'should return object when not throwing');
            assert(res.response && Array.isArray(res.response.events), 'events array must exist');
        }
    });

    // Field validations over a sample set for robustness and enum emphasis
    runTest('getIPOCalendar: validate core fields and actions behavior', () => {
        const res = getIPOCalendar({});
        const events = res && res.response && Array.isArray(res.response.events) ? res.response.events : [];
        let checked = 0;
        for (const ev of events.slice(0, 20)) {
            assert.strictEqual(typeof ev.symbol, 'string', 'symbol type');
            assert(isYYYYMMDD(ev.date), 'date type');
            if (ev.daa != null) assert.strictEqual(typeof ev.daa, 'string');
            if (ev.company != null) assert.strictEqual(typeof ev.company, 'string');
            if (ev.exchange != null) assert.strictEqual(typeof ev.exchange, 'string');
            if (ev.actions != null) {
                assert.strictEqual(typeof ev.actions, 'string');
                if (ev.actions === 'Expected') {
                    assert(ev.price_range == null || typeof ev.price_range === 'string', 'Expected: price_range string if present');
                }
            }
            if (ev.shares != null) assert.strictEqual(typeof ev.shares, 'number');
            if (ev.market_cap != null) assert.strictEqual(typeof ev.market_cap, 'string');
            checked++;
        }
        assert(checked >= 0, 'should iterate without errors');
    });

    // Print test summary
    console.log('\n=== getIPOCalendar Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    if (passedTests === totalTests) {
        console.log('🎉 getIPOCalendar tests passed!');
    } else {
        console.log('⚠️  Some getIPOCalendar tests failed. Please review the output above.');
    }
}

function main() {
    // Node transformation tests using stubbed sample (no network)
    testNodeTransformation();
    // Direct get* API tests (manual import), following example.js style
    testGetIPOCalendarAPI();
}

main();
