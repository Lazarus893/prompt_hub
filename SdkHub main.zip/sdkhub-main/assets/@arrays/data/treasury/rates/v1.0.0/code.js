const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getTreasuryRates, derived from tool.json
const getTreasuryRatesRef = {
	id: '@arrays/data/treasury/rates/getTreasuryRates',
	module_name: '@arrays/data/treasury/rates',
	module_display_name: 'US Treasury Rates',
	sdk_name: 'getTreasuryRates',
	sdk_display_name: 'US Treasury Rates',
	source_name: 'Financial Modeling Prep',
	source: 'https://site.financialmodelingprep.com/developer/docs/stable/treasury-rates',
};

// Base description derived from doc for getTreasuryRates
const getTreasuryRatesBaseDescription = 'Fetch U.S. Treasury rates';

// Dynamic call description builder for getTreasuryRates
function buildGetTreasuryRatesCallDescription(actualParams = {}) {
    const parts = [getTreasuryRatesBaseDescription];

    const { from, to } = actualParams || {};

    if (from && to) {
        if (from === to) {
            parts.push(`for ${from}`);
        } else {
            parts.push(`from ${from} to ${to}`);
        }
    } else if (from) {
        parts.push(`from ${from}`);
    } else if (to) {
        parts.push(`until ${to}`);
    }

    return parts.join(' ').trim();
}

// Helper to create reference metadata with a computed title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getTreasuryRates(params) {
	// Parameter validation
	if (!params || typeof params !== 'object') {
		return {
			success: false,
			response: {
				rates: [],
				error: 'Invalid parameters: params must be an object'
			}
		};
	}

	const { from, to } = params;

	// Validate from and to are non-empty strings
	if (!from || typeof from !== 'string' || from.trim() === '') {
		return {
			success: false,
			response: {
				rates: [],
				error: 'Invalid parameters: from is required and must be a non-empty string'
			}
		};
	}

	if (!to || typeof to !== 'string' || to.trim() === '') {
		return {
			success: false,
			response: {
				rates: [],
				error: 'Invalid parameters: to is required and must be a non-empty string'
			}
		};
	}

	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/treasury/rates';
	const keyValuePairs = Object.keys(params || {}).map((key) => {
		const value = params[key];
		return encodeURIComponent(key) + '=' + encodeURIComponent(value);
	});
	const queryString = keyValuePairs.join('&');
	const fullUrl = `${baseUrl}?${queryString}`;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	const originalData = r.json();
	return {
		success: originalData.success,
		response: {
			...originalData.response,
			rates: originalData?.response?.rates || [],
		},
	};
}

function makeTreasuryRatesNode(params) {
	function utcMsFromYmd(ymd) {
		if (typeof ymd !== 'string') return Date.now();
		const parts = ymd.split('-').map((v) => parseInt(v, 10));
		if (parts.length !== 3 || parts.some((n) => Number.isNaN(n))) return Date.now();
		const [y, m, d] = parts;
		return Date.UTC(y, (m || 1) - 1, d || 1, 0, 0, 0, 0);
	}
	function maybeNumber(v) {
		const n = typeof v === 'number' ? v : v != null ? Number(v) : undefined;
		return Number.isFinite(n) ? n : undefined;
	}

	return {
		inputs: {
			treasury_rates_raw: () => getTreasuryRates(params),
		},
		outputs: {
			treasury_rates_snapshot: {
				name: 'treasury_rates_snapshot',
				description: 'Treasury rates snapshot with rates list',
				fields: [
					{ name: 'date', type: 'number', description: 'snapshot time ms (UTC)' },
					{ name: 'request_date', type: 'string', description: 'rates request date' },
					{
						name: 'rates',
						type: 'array',
						description: 'treasury rate records',
						fields: [
							{ name: 'period', type: 'string', description: 'rate period (1M/3M/6M/1Y/etc)' },
							{ name: 'rate', type: 'number', description: 'rate percentage' },
							{ name: 'effective_date', type: 'string', description: 'YYYY-MM-DD' },
						],
					},
				],
				ref: createReferenceWithTitle(getTreasuryRatesRef, params, buildGetTreasuryRatesCallDescription),
			},
		},
		run: (inputs) => {
			const raw = inputs.treasury_rates_raw;
			if (!raw || !raw.success || !raw.response) {
				throw new Error('Treasury rates raw data is invalid');
			}
			const ratesArr = Array.isArray(raw.response?.rates) ? raw.response.rates : [];

			// Determine request date: prefer explicit date; else use 'to' when a range is provided; else today
			let requestDateStr = new Date().toISOString().slice(0, 10);
			if (params && typeof params.to === 'string' && params.to.length) {
				requestDateStr = params.to;
			}
			const snapshotTime = utcMsFromYmd(requestDateStr);

			// API returns array of daily records, each with tenor fields
			// Choose matching date (date param or 'to' in [from,to] range), else use first
			let pick = ratesArr[0] || {};
			if (requestDateStr && ratesArr.length > 0) {
				const found = ratesArr.find((it) => it && it.date === requestDateStr);
				if (found) pick = found;
			}
			const tenorKeys = ['month1', 'month2', 'month3', 'month6', 'year1', 'year2', 'year3', 'year5', 'year7', 'year10', 'year20', 'year30'];
			const outRates = [];
			for (const k of tenorKeys) {
				if (Object.prototype.hasOwnProperty.call(pick, k)) {
					const v = maybeNumber(pick[k]);
					if (v != null) outRates.push({ period: k, rate: v, effective_date: pick.date });
				}
			}

			return {
				treasury_rates_snapshot: [
					{
						date: snapshotTime,
						request_date: requestDateStr,
						rates: outRates,
					},
				],
			};
		},
	};
}

// Unified getter for all reference metadata objects in this module
function getRefs() {
    return [getTreasuryRatesRef];
}

module.exports.getTreasuryRates = getTreasuryRates;
module.exports.makeTreasuryRatesNode = makeTreasuryRatesNode;
module.exports.getRefs = getRefs;
