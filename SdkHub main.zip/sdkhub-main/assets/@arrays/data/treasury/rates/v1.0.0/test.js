function assert(condition, message) {
	if (!condition) throw new Error(message || 'Assertion failed');
}

function runTest(testName, testFunc, ctx) {
	ctx.totalTests++;
	try {
		testFunc();
		console.log(`✅ ${testName}`);
		ctx.passedTests++;
	} catch (e) {
		console.log(`❌ ${testName}: ${e && e.message ? e.message : e}`);
	}
}

function testNodeIntegration(ctx) {
	console.log('\n=== Testing Graph/Node Integration ===');
	const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
	const { jagentId } = require('env');
	const { makeTreasuryRatesNode } = require('@arrays/data/treasury/rates:v1.0.0');

	const g = new Graph(jagentId);
	const reqDate = new Date().toISOString().slice(0, 10);
	g.addNode('tsy', makeTreasuryRatesNode({ from: reqDate, to: reqDate }));
	g.run();

	const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'tsy', 'treasury_rates_snapshot', { last: '5' }), g.store);
	ts.init();

	runTest('treasury_rates_snapshot has refs metadata', () => {
		const refsTsy = g.getRefsForOutput('tsy', 'treasury_rates_snapshot');
		assert(Array.isArray(refsTsy), 'refs should be an array');
		assert(refsTsy.length > 0, 'refs array should not be empty');
		const ref = refsTsy[0];
		const expected = {
			id: '@arrays/data/treasury/rates/getTreasuryRates',
			module_name: '@arrays/data/treasury/rates',
			module_display_name: 'US Treasury Rates',
			sdk_name: 'getTreasuryRates',
			sdk_display_name: 'US Treasury Rates',
			source_name: 'Financial Modeling Prep',
			source: 'https://site.financialmodelingprep.com/developer/docs/stable/treasury-rates',
		};
		assert(ref.id === expected.id, 'ref.id mismatch');
		assert(ref.module_name === expected.module_name, 'ref.module_name mismatch');
		assert(ref.module_display_name === expected.module_display_name, 'ref.module_display_name mismatch');
		assert(ref.sdk_name === expected.sdk_name, 'ref.sdk_name mismatch');
		assert(ref.sdk_display_name === expected.sdk_display_name, 'ref.sdk_display_name mismatch');
		assert(ref.source_name === expected.source_name, 'ref.source_name mismatch');
		assert(ref.source === expected.source, 'ref.source mismatch');
	}, ctx);

	runTest('treasury_rates_snapshot has time series data with rates', () => {
		assert(Array.isArray(ts.data), 'time series data should be an array');
		// May be empty if no data available for the date
		if (ts.data.length > 0) {
			const row = ts.data[0];
			for (const k of ['date', 'request_date', 'rates']) {
				assert(k in row, `missing row field: ${k}`);
			}
			assert(Array.isArray(row.rates), 'rates should be an array');
		}
	}, ctx);

	runTest('treasury_rates_snapshot rate object shape and effective_date uniqueness', () => {
		if (ts.data.length > 0 && ts.data[0].rates.length > 0) {
			const row = ts.data[0];
			const r = row.rates[0];
			for (const k of ['period', 'rate', 'effective_date']) {
				assert(k in r, `missing rate field: ${k}`);
			}
			const effSet = new Set(row.rates.map((x) => x.effective_date));
			assert(effSet.size >= 1, 'no effective_date found');
		}
	}, ctx);
}

function testGetTreasuryRates(ctx) {
	console.log('\n=== Testing getTreasuryRates (Direct Function) ===');
	const { getTreasuryRates } = require('@arrays/data/treasury/rates:v1.0.0');

	// API returns flat rate objects with date, month1, month2, etc.
	const validateRatesEntry = (entry) => {
		assert(entry && typeof entry === 'object', 'entry should be an object');
		assert('date' in entry, 'entry should contain date');
		// Check for typical treasury rate fields (month1, year1, etc.)
		const hasRateFields = ['month1', 'month3', 'year1', 'year10'].some(k => k in entry);
		assert(hasRateFields, 'entry should contain rate fields like month1, year1, etc.');
	};

	// Happy Path: single-day request
	runTest('single-day request returns valid structure', () => {
		const result = getTreasuryRates({ from: '2024-01-15', to: '2024-01-15' });
		assert(result && typeof result === 'object', 'result should be an object');
		assert(typeof result.success === 'boolean', 'result.success should be boolean');
		assert(result.response && typeof result.response === 'object', 'result.response should be object');
		const res = result.response.rates;
		assert(Array.isArray(res), 'rates should be an array');
		// May be empty if no data available for that date
		if (res.length > 0) {
			validateRatesEntry(res[0]);
		}
	}, ctx);

	// Happy Path: short range request (across month boundary)
	runTest('short range request returns array of valid entries', () => {
		const result = getTreasuryRates({ from: '2024-01-29', to: '2024-02-05' });
		assert(result && typeof result === 'object', 'result should be an object');
		const res = result.response.rates;
		assert(Array.isArray(res), 'result should be an array for range queries');
		// May be empty if no data available for that date range
		if (res.length > 0) {
			validateRatesEntry(res[0]);
		}
	}, ctx);

	// Boundary Value Analysis
	runTest('boundary: from equals to (same day)', () => {
		const result = getTreasuryRates({ from: '2024-06-10', to: '2024-06-10' });
		assert(result && typeof result === 'object', 'result should be an object');
		const res = result.response.rates;
		assert(Array.isArray(res), 'rates should be an array');
		// May be empty if no data available
		if (res.length > 0) {
			validateRatesEntry(res[0]);
		}
	}, ctx);

	// Edge cases - API may handle these gracefully rather than rejecting
	runTest('boundary: from later than to should not crash', () => {
		const result = getTreasuryRates({ from: '2024-02-10', to: '2024-02-01' });
		assert(result && typeof result === 'object', 'should return an object');
		assert(typeof result.success === 'boolean', 'should have success field');
		// API may accept this and return data (swapping dates or using one of them)
	}, ctx);

	runTest('boundary: invalid date format should not crash', () => {
		const result = getTreasuryRates({ from: '2024/01/15', to: '2024/01/15' });
		assert(result && typeof result === 'object', 'should return an object');
		assert(typeof result.success === 'boolean', 'should have success field');
		// API may accept this and interpret the date
	}, ctx);

	// Special Value Tests
	runTest('special: null values should throw', () => {
		// @ts-ignore
		const result = getTreasuryRates({ from: null, to: null });
		assert(result && typeof result === 'object' && result.success === false, 'should return error for null values');
	}, ctx);

	runTest('special: undefined values should throw', () => {
		// @ts-ignore
		const result = getTreasuryRates({ from: undefined, to: undefined });
		assert(result && typeof result === 'object' && result.success === false, 'should return error for undefined values');
	}, ctx);

	runTest('special: empty string values should throw', () => {
		const result = getTreasuryRates({ from: '', to: '' });
		assert(result && typeof result === 'object' && result.success === false, 'should return error for empty strings');
	}, ctx);

	runTest('special: non-string date types should throw', () => {
		// @ts-ignore
		const result = getTreasuryRates({ from: 20240115, to: 20240115 });
		assert(result && typeof result === 'object' && result.success === false, 'should return error for non-string dates');
	}, ctx);
}

function main() {
	const ctx = { totalTests: 0, passedTests: 0 };
	testNodeIntegration(ctx);
	testGetTreasuryRates(ctx);

	console.log('\n=== Test Summary ===');
	console.log(`Total tests: ${ctx.totalTests}`);
	console.log(`Passed: ${ctx.passedTests}`);
	console.log(`Failed: ${ctx.totalTests - ctx.passedTests}`);
	console.log(`Success rate: ${((ctx.passedTests / ctx.totalTests) * 100).toFixed(1)}%`);

	if (ctx.passedTests === ctx.totalTests) {
		console.log('🎉 All tests passed!');
	} else {
		console.log('⚠️  Some tests failed. Please review the output above.');
	}
}

main();
