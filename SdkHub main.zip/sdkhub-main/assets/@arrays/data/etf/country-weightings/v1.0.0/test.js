function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
}

function testGetETFCountryWeightingsDirect() {
    console.log('\n=== Testing getETFCountryWeightings (Direct) ===');

    const { getETFCountryWeightings } = require('@arrays/data/etf/country-weightings:v1.0.0');

    const ETF_SYMBOLS = [
        // Common, diverse ETFs for enumeration coverage
        'SPY', // S&P 500
        'QQQ', // Nasdaq 100
        'VTI', // Total US Stock Market
        'EFA', // MSCI EAFE
        'EEM', // MSCI Emerging Markets
        'IWM', // Russell 2000
    ];

    let totalTests = 0;
    let passedTests = 0;

    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    // --- Happy Path: Verify valid symbols return expected structure
    for (const symbol of ETF_SYMBOLS) {
        runTest(`getETFCountryWeightings happy path: ${symbol}`, () => {
            const result = getETFCountryWeightings({ symbol });
            assert(result && typeof result === 'object', 'Should return an object');
            assert('success' in result, 'Result must contain success field');
            assert('response' in result, 'Result must contain response field');
            const list = (result.response && result.response.weightings) || [];
            assert(Array.isArray(list), 'Response.weightings should be an array');

            // If data exists, validate schema of entries
            if (list.length > 0) {
                const w = list[0];
                assert(typeof w.country === 'string', 'weighting.country must be string');
                assert(typeof w.weight_percentage === 'string', 'weighting.weight_percentage must be string');
            }
        });
    }

    // --- Case and whitespace tolerance
    runTest('getETFCountryWeightings lowercase symbol', () => {
        const res = getETFCountryWeightings({ symbol: 'spy' });
        assert(res && typeof res === 'object', 'Should return object');
        const list = (res.response && res.response.weightings) || [];
        assert(Array.isArray(list), 'weightings should be array');
    });

    runTest('getETFCountryWeightings symbol with whitespace', () => {
        const res = getETFCountryWeightings({ symbol: '  SPY  ' });
        assert(res && typeof res === 'object', 'Should return object');
        const list = (res.response && res.response.weightings) || [];
        assert(Array.isArray(list), 'weightings should be array');
    });

    // --- Boundary Value: Extremely long symbol should not crash and return structured response or throw
    runTest('getETFCountryWeightings boundary: very long symbol', () => {
        const longSymbol = 'A'.repeat(128);
        try {
            const res = getETFCountryWeightings({ symbol: longSymbol });
            assert(res && typeof res === 'object', 'Should return object');
            const list = (res.response && res.response.weightings) || [];
            assert(Array.isArray(list), 'weightings should be array');
        } catch (e) {
            // Throwing is acceptable handling as well
            assert(true, 'Handled by throwing');
        }
    });

    // --- Special Values: null, undefined, '', 0
    const specialValues = [null, undefined, '', 0];
    for (const sv of specialValues) {
        runTest(`getETFCountryWeightings special value: ${String(sv)}`, () => {
            try {
                const res = getETFCountryWeightings({ symbol: sv });
                assert(res && typeof res === 'object', 'Should return object even for special values');
                const list = (res.response && res.response.weightings) || [];
                assert(Array.isArray(list), 'weightings should be array');
            } catch (e) {
                // Throwing is acceptable handling
                assert(true, 'Handled by throwing');
            }
        });
    }

    // --- Value constraints: weight_percentage should be parsable 0..100 and end with '%'
    runTest('getETFCountryWeightings value constraints (SPY percentages)', () => {
        const res = getETFCountryWeightings({ symbol: 'SPY' });
        assert(res && typeof res === 'object', 'Should return object');
        const list = (res.response && res.response.weightings) || [];
        assert(Array.isArray(list), 'Response.weightings should be an array');
        for (const w of list) {
            if (typeof w.weight_percentage === 'string') {
                const str = w.weight_percentage.trim();
                if (str.endsWith('%')) {
                    const val = parseFloat(str.replace('%', ''));
                    assert(!Number.isNaN(val), 'weight_percentage should contain a numeric value');
                    assert(val >= 0 && val <= 100, 'weight_percentage should be within [0, 100]');
                }
            }
            if (typeof w.country === 'string') {
                assert(w.country.length > 0, 'country should be non-empty string');
            }
        }
    });

    // --- Error Handling: obviously invalid symbol should not crash
    runTest('getETFCountryWeightings invalid symbol handled gracefully', () => {
        try {
            const res = getETFCountryWeightings({ symbol: 'INVALID_SYMBOL_12345' });
            assert(res && typeof res === 'object', 'Should return object');
            const list = (res.response && res.response.weightings) || [];
            assert(Array.isArray(list), 'weightings should be array');
        } catch (e) {
            // Throwing is acceptable handling as well
            assert(true, 'Handled by throwing');
        }
    });

    console.log('\n--- getETFCountryWeightings Direct Test Summary ---');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeETFCountryWeightingsNode } = require('@arrays/data/etf/country-weightings:v1.0.0');

    // Run direct get-function tests first (manual import required for get* functions)
    testGetETFCountryWeightingsDirect();

    // Smoke test - basic functionality test
    const g = new Graph(jagentId);
    g.addNode('etf_country_weightings_smoke', makeETFCountryWeightingsNode({ symbol: 'SPY' }));
    g.run();

    // Mock test - using sample data to avoid network dependency
    const nodeCfg = makeETFCountryWeightingsNode({ symbol: 'QQQ' });

    // Override input with mock data that matches the API response structure
    nodeCfg.inputs.etf_country_weightings_raw = () => ({
        success: true,
        response: {
            weightings: [
                {
                    country: 'United States',
                    weight_percentage: '95.5%',
                },
                {
                    country: 'China',
                    weight_percentage: '2.1%',
                },
                {
                    country: 'Japan',
                    weight_percentage: '1.8%',
                },
                {
                    country: 'Cash',
                    weight_percentage: '0.6%',
                },
            ],
        },
    });

    const g2 = new Graph(jagentId);
    g2.addNode('etf_country_weightings_mock', nodeCfg);
    g2.run();

    // Validate refs for country_weightings_snapshot
    const refsCountryWeightings = g2.getRefsForOutput('etf_country_weightings_mock', 'country_weightings_snapshot');
    if (refsCountryWeightings.length > 0) {
        const ref = refsCountryWeightings[0];
        const expected = {
            id: '@arrays/data/etf/country-weightings/getETFCountryWeightings',
            module_name: '@arrays/data/etf/country-weightings',
            module_display_name: 'ETF Country Weightings',
            sdk_name: 'getETFCountryWeightings',
            sdk_display_name: 'ETF Country Weightings',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stable/country-weighting',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for country_weightings_snapshot');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for country_weightings_snapshot');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for country_weightings_snapshot');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for country_weightings_snapshot');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for country_weightings_snapshot');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for country_weightings_snapshot');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for country_weightings_snapshot');
        if (typeof log === 'function') log('✓ country_weightings_snapshot refs validated');
    } else {
        throw new Error('Assertion failed: refsCountryWeightings array is empty.');
    }

    // Validate mock data output
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'etf_country_weightings_mock', 'country_weightings_snapshot', { last: '5' }), g2.store);
    ts.init();

    if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('country_weightings_snapshot empty');
    const row = ts.data[0];
    ['date', 'symbol', 'weightings'].forEach((k) => {
        if (!(k in row)) throw new Error('missing row field: ' + k);
    });
    if (typeof row.date !== 'number') throw new Error('snapshot date must be number(ms)');
    if (!Array.isArray(row.weightings) || row.weightings.length < 1) throw new Error('weightings empty');

    const w = row.weightings[0];
    ['country', 'weight_percentage'].forEach((k) => {
        if (!(k in w)) throw new Error('missing weighting field: ' + k);
    });

    // Validate smoke test output
    const tsSmoke = new TimeSeries(new TimeSeriesUri(jagentId, 'etf_country_weightings_smoke', 'country_weightings_snapshot', { last: '5' }), g.store);
    tsSmoke.init();
    if (!Array.isArray(tsSmoke.data)) throw new Error('smoke test data must be an array');
    if (tsSmoke.data.length > 0) {
        const r = tsSmoke.data[0];
        if (typeof r.date !== 'number') throw new Error('smoke.date must be number(ms)');
        if (!Array.isArray(r.weightings)) throw new Error('smoke.weightings must be an array');
        if (r.weightings.length > 0) {
            const weighting = r.weightings[0];
            if (typeof weighting.country !== 'string') throw new Error('smoke.weighting.country must be string');
            if (typeof weighting.weight_percentage !== 'string') throw new Error('smoke.weighting.weight_percentage must be string');
        }
    }

    return 0;
}

main();
