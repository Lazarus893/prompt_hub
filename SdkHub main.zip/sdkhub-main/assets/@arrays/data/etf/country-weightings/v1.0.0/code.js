const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getETFCountryWeightings, derived from tool.json
const getETFCountryWeightingsRef = {
  id: "@arrays/data/etf/country-weightings/getETFCountryWeightings",
  module_name: "@arrays/data/etf/country-weightings",
  module_display_name: "ETF Country Weightings",
  sdk_name: "getETFCountryWeightings",
  sdk_display_name: "ETF Country Weightings",
  source_name: "Financial Modeling Prep",
  source: "https://site.financialmodelingprep.com/developer/docs/stable/country-weighting",
};

// Base description and dynamic call description builder for getETFCountryWeightings (derived from doc)
const getETFCountryWeightingsBaseDesc = "Get ETF country weightings";
function buildGetETFCountryWeightingsCallDescription(actualParams = {}) {
    const parts = [getETFCountryWeightingsBaseDesc];

    // Add symbol context if provided (doc param)
    if (actualParams && typeof actualParams === 'object') {
        if (actualParams.symbol) {
            parts.push(`for ${actualParams.symbol}`);
        }
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getETFCountryWeightings(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/etf/country-weightings';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    const originalData = r.json();
    return {
        success: originalData.success,
        response: {
            ...originalData.response,
            data: originalData?.response?.data || [],
        },
    };
}

function makeETFCountryWeightingsNode(params) {
    return {
        inputs: {
            etf_country_weightings_raw: () => getETFCountryWeightings(params),
        },
        outputs: {
            country_weightings_snapshot: {
                name: 'country_weightings_snapshot',
                description: 'ETF Country Weightings snapshot (single record with nested weightings array)',
                fields: [
                    { name: 'date', type: 'number', description: 'snapshot time in ms since epoch (UTC)' },
                    { name: 'symbol', type: 'string', description: 'ETF symbol for this snapshot' },
                    {
                        name: 'weightings',
                        type: 'array',
                        description: 'array of country weightings at the snapshot time',
                        fields: [
                            { name: 'country', type: 'string', description: 'country name' },
                            { name: 'weight_percentage', type: 'string', description: 'percentage string, e.g., 93.9%' },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getETFCountryWeightingsRef, params, buildGetETFCountryWeightingsCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.etf_country_weightings_raw;
            if (!raw || !raw.success || !raw.response) {
                throw new Error('ETF country weightings raw data is invalid');
            }

            const weightingsArray = raw.response.weightings || raw.response.data || [];
            if (!Array.isArray(weightingsArray) || weightingsArray.length === 0) {
                // nothing to append - return undefined to skip this run
                return undefined;
            }

            // Use current time as snapshot time since ETF weightings are typically current snapshots
            const snapshotTime = Date.now();

            const weightings = weightingsArray.map((w) => {
                let weightStr = '';
                if (typeof w.weight_percentage === 'string') {
                    weightStr = w.weight_percentage;
                } else if (Number.isFinite(w.weight_percentage)) {
                    weightStr = String(w.weight_percentage) + '%';
                }
                return {
                    country: w.country,
                    weight_percentage: weightStr,
                };
            });

            return {
                country_weightings_snapshot: [
                    {
                        date: snapshotTime,
                        symbol: params && params.symbol ? String(params.symbol) : '',
                        weightings,
                    },
                ],
            };
        },
    };
}

function getRefs() {
    return [
        getETFCountryWeightingsRef,
    ];
}

module.exports = {
    getETFCountryWeightings,
    makeETFCountryWeightingsNode,
    getRefs,
};
