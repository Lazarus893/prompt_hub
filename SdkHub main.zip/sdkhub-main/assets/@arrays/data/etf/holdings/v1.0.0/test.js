function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
}

function runTest(testName, fn, ctx) {
    ctx.totalTests++;
    try {
        fn();
        console.log(`✅ ${testName}`);
        ctx.passedTests++;
    } catch (e) {
        console.log(`❌ ${testName}: ${e.message}`);
    }
}

function testDirectGetETFHoldings(ctx) {
    console.log('\n=== Testing Direct Function Calls: getETFHoldings ===');

    // Manual import for get* function per instruction
    const { getETFHoldings } = require('@arrays/data/etf/holdings:v1.0.0');

    // Helper to validate a well-formed successful response
    function expectValidResponse(res) {
        assert(res && typeof res === 'object', 'Should return an object');
        assert(typeof res.success === 'boolean', 'res.success should be boolean');
        assert(res.response && typeof res.response === 'object', 'res.response should be object');
        assert(Array.isArray(res.response.holdings), 'res.response.holdings should be array');
    }

    function validateHoldingShape(holding) {
        // Required fields that must exist
        const requiredFields = [
            'symbol', 'asset', 'name', 'shares_number', 'weight_percentage', 'market_value', 'updated_at'
        ];
        requiredFields.forEach((k) => assert(k in holding, `missing holding field: ${k}`));

        // Optional fields (may not exist in all API responses)
        const optionalFields = ['isin', 'security_cusip'];

        // Basic type checks for required fields
        assert(typeof holding.symbol === 'string', 'holding.symbol should be string');
        assert(typeof holding.asset === 'string', 'holding.asset should be string');
        assert(typeof holding.name === 'string', 'holding.name should be string');
        assert(typeof holding.shares_number === 'number' && Number.isFinite(holding.shares_number), 'holding.shares_number should be finite number');
        assert(typeof holding.weight_percentage === 'number' && Number.isFinite(holding.weight_percentage), 'holding.weight_percentage should be finite number');
        assert(typeof holding.market_value === 'number' && Number.isFinite(holding.market_value), 'holding.market_value should be finite number');
        assert(typeof holding.updated_at === 'string', 'holding.updated_at should be string');

        // Type checks for optional fields (only if they exist)
        if ('isin' in holding) {
            assert(typeof holding.isin === 'string', 'holding.isin should be string if present');
        }
        if ('security_cusip' in holding) {
            assert(typeof holding.security_cusip === 'string', 'holding.security_cusip should be string if present');
        }

        // Reasonable numeric ranges
        assert(holding.shares_number >= 0, 'shares_number should be >= 0');
        assert(holding.market_value >= 0, 'market_value should be >= 0');
        assert(holding.weight_percentage >= 0 && holding.weight_percentage <= 100, 'weight_percentage should be within [0, 100]');

        // updated_at should be parseable date string (not NaN)
        assert(!Number.isNaN(Date.parse(holding.updated_at)), 'updated_at should be a valid date string');
    }

    // Happy Path: enumerate valid ETF symbols
    const VALID_ETFS = ['SPY', 'QQQ', 'IWM'];
    for (const sym of VALID_ETFS) {
        runTest(`getETFHoldings happy path with ${sym}`, () => {
            const res = getETFHoldings({ symbol: sym });
            expectValidResponse(res);
            // Holdings can be empty in edge cases, but expect data for popular ETFs
            assert(Array.isArray(res.response.holdings), 'holdings must be array');
            if (res.response.holdings.length > 0) {
                validateHoldingShape(res.response.holdings[0]);
            }
        }, ctx);
    }

    // Boundary: case sensitivity - lowercase symbol should be handled (either reject or normalize)
    runTest('getETFHoldings with lowercase symbol "spy"', () => {
        let handled = false;
        try {
            const res = getETFHoldings({ symbol: 'spy' });
            if (res && typeof res === 'object') {
                if (res.success === false) handled = true;
                else if (res.response && Array.isArray(res.response.holdings)) handled = true; // accepted via normalization
            }
        } catch (e) {
            handled = true; // threw error for invalid case
        }
        assert(handled, 'Should handle lowercase symbol by either normalizing or rejecting');
    }, ctx);

    // Special values and invalid inputs
    runTest('getETFHoldings with missing params', () => {
        let handled = false;
        try {
            // @ts-ignore intentional missing params
            const res = getETFHoldings();
            if (res && typeof res === 'object' && res.success === false) handled = true;
        } catch (e) {
            handled = true;
        }
        assert(handled, 'Should handle missing params gracefully');
    }, ctx);

    runTest('getETFHoldings with null params', () => {
        let handled = false;
        try {
            const res = getETFHoldings(null);
            if (res && typeof res === 'object' && res.success === false) handled = true;
        } catch (e) {
            handled = true;
        }
        assert(handled, 'Should handle null params gracefully');
    }, ctx);

    runTest('getETFHoldings with empty symbol', () => {
        let handled = false;
        try {
            const res = getETFHoldings({ symbol: '' });
            if (res && typeof res === 'object') {
                if (res.success === false) handled = true;
                else if (res.response && Array.isArray(res.response.holdings) && res.response.holdings.length === 0) handled = true;
            }
        } catch (e) {
            handled = true;
        }
        assert(handled, 'Should handle empty symbol');
    }, ctx);

    runTest('getETFHoldings with undefined symbol', () => {
        let handled = false;
        try {
            const res = getETFHoldings({ symbol: undefined });
            if (res && typeof res === 'object') {
                if (res.success === false) handled = true;
                else if (res.response && Array.isArray(res.response.holdings) && res.response.holdings.length === 0) handled = true;
            }
        } catch (e) {
            handled = true;
        }
        assert(handled, 'Should handle undefined symbol');
    }, ctx);

    runTest('getETFHoldings with invalid symbol', () => {
        let handled = false;
        try {
            const res = getETFHoldings({ symbol: 'INVALID_ETF' });
            if (res && typeof res === 'object') {
                if (res.success === false) handled = true;
                else if (res.response && Array.isArray(res.response.holdings) && res.response.holdings.length === 0) handled = true;
            }
        } catch (e) {
            handled = true;
        }
        assert(handled, 'Should handle invalid symbol gracefully');
    }, ctx);
}

function testGraphNodeIntegration(ctx) {
    console.log('\n=== Testing Graph Node Integration ===');
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeETFHoldingsNode } = require('@arrays/data/etf/holdings:v1.0.0');

    const g = new Graph(jagentId);
    const nodeName = 'etf_holdings_spy';
    g.addNode(nodeName, makeETFHoldingsNode({ symbol: 'SPY' }));

    g.run();

    // Validate refs for the output using the established if/throw structure
    const refsHoldings = g.getRefsForOutput(nodeName, 'holdings_snapshot');
    if (refsHoldings.length > 0) {
        const ref = refsHoldings[0];
        const expected = {
            id: '@arrays/data/etf/holdings/getETFHoldings',
            module_name: '@arrays/data/etf/holdings',
            module_display_name: 'ETF Holdings',
            sdk_name: 'getETFHoldings',
            sdk_display_name: 'ETF Holdings',
            source_name: 'Financial Modeling Prep',
            source: 'https://site.financialmodelingprep.com/developer/docs/stable/holdings',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for holdings_snapshot');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for holdings_snapshot');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for holdings_snapshot');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for holdings_snapshot');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for holdings_snapshot');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for holdings_snapshot');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for holdings_snapshot');
        console.log('✓ holdings_snapshot refs validated');
    } else {
        throw new Error('Assertion failed: refsHoldings array is empty.');
    }

    const ts = new TimeSeries(new TimeSeriesUri(jagentId, nodeName, 'holdings_snapshot', { last: '5' }), g.store);
    ts.init();

    if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('holdings_snapshot empty');
    const row = ts.data[0];
    ;['date', 'symbol', 'holdings'].forEach((k) => {
        if (!(k in row)) throw new Error('missing row field: ' + k);
    });
    if (typeof row.date !== 'number') throw new Error('snapshot date must be number(ms)');
    if (!Array.isArray(row.holdings) || row.holdings.length < 1) throw new Error('holdings empty');

    const h = row.holdings[0];
    ;['symbol', 'asset', 'name', 'isin', 'security_cusip', 'shares_number', 'weight_percentage', 'market_value', 'updated_at'].forEach((k) => {
        if (!(k in h)) throw new Error('missing holding field: ' + k);
    });
    console.log('✓ graph node integration and schema validated');
}

function main() {
    const ctx = { totalTests: 0, passedTests: 0 };

    // Direct function tests for getETFHoldings
    testDirectGetETFHoldings(ctx);

    // Graph node integration tests (existing)
    runTest('Graph Node Integration: ETF Holdings Node', () => testGraphNodeIntegration(ctx), ctx);

    // Summary
    console.log('\n=== Test Summary ===');
    console.log(`Total tests: ${ctx.totalTests}`);
    console.log(`Passed: ${ctx.passedTests}`);
    console.log(`Failed: ${ctx.totalTests - ctx.passedTests}`);
    console.log(`Success rate: ${((ctx.passedTests / ctx.totalTests) * 100).toFixed(1)}%`);
}

main();
