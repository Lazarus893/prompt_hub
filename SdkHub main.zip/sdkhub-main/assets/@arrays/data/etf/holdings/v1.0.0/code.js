const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// SDK Reference metadata (auto-generated from tool.json)
const getETFHoldingsRef = {
	id: "@arrays/data/etf/holdings/getETFHoldings",
	module_name: "@arrays/data/etf/holdings",
	module_display_name: "ETF Holdings",
	sdk_name: "getETFHoldings",
	sdk_display_name: "ETF Holdings",
	source_name: "Financial Modeling Prep",
	source: "https://site.financialmodelingprep.com/developer/docs/stable/holdings",
};

// Base function description (auto-generated from doc)
const getETFHoldingsBaseFuncDesc = "Retrieve ETF holdings details";

// Dynamic call description builder for getETFHoldings
function buildGetETFHoldingsCallDescription(actualParams = {}) {
  const parts = [getETFHoldingsBaseFuncDesc];
  if (actualParams && typeof actualParams === 'object') {
    if (actualParams.symbol) {
      parts.push(`for ${actualParams.symbol}`);
    }
  }
  return parts.join(' ').trim();
}

// Helper to augment reference metadata with a dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getETFHoldings(params) {
	// Input validation
	if (!params || typeof params !== 'object') {
		return {
			success: false,
			response: {
				holdings: [],
				error: 'Invalid parameters: params must be an object'
			}
		};
	}

	const symbol = params.symbol;
	if (!symbol || typeof symbol !== 'string' || symbol.trim() === '') {
		return {
			success: false,
			response: {
				holdings: [],
				error: 'Invalid parameters: symbol is required and must be a non-empty string'
			}
		};
	}

	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/etf/holdings';
	const keyValuePairs = Object.keys(params || {}).map((k) => {
		const v = params[k];
		return encodeURIComponent(k) + '=' + encodeURIComponent(v);
	});
	const queryString = keyValuePairs.join('&');
	const fullUrl = `${baseUrl}${queryString ? '?' + queryString : ''}`;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	const originalData = r.json();

	// Normalize response to use 'holdings' field (API may return 'data' or 'holdings')
	const holdingsData = originalData?.response?.holdings || originalData?.response?.data || [];

	return {
		success: originalData.success,
		response: {
			...originalData.response,
			holdings: holdingsData,
		},
	};
}

function toMs(x) {
	if (x == null) return null;
	if (typeof x === 'number') {
		// treat < 1e11 as seconds
		return x < 1e11 ? x * 1000 : x;
	}
	if (typeof x === 'string') {
		const t = Date.parse(x);
		return Number.isFinite(t) ? t : null;
	}
	return null;
}

function makeETFHoldingsNode(params) {
	return {
		inputs: {
			etf_holdings_raw: () => getETFHoldings(params),
		},
		outputs: {
			holdings_snapshot: {
				name: 'holdings_snapshot',
				description: 'ETF holdings snapshot (single record with nested holdings array)',
				fields: [
					{ name: 'date', type: 'number', description: 'snapshot time in ms since epoch (UTC)' },
					{ name: 'symbol', type: 'string', description: 'ETF symbol for this snapshot' },
					{
						name: 'holdings',
						type: 'array',
						description: 'array of holdings at the snapshot time',
						fields: [
							{ name: 'symbol', type: 'string', description: 'ETF symbol for this holding' },
							{ name: 'asset', type: 'string', description: 'symbol of the underlying asset' },
							{ name: 'name', type: 'string', description: 'company or asset name' },
							{ name: 'isin', type: 'string', description: 'ISIN identifier' },
							{ name: 'security_cusip', type: 'string', description: 'CUSIP identifier for the security' },
							{ name: 'shares_number', type: 'number', description: 'number of shares held' },
							{ name: 'weight_percentage', type: 'number', description: 'portfolio weight as percentage' },
							{ name: 'market_value', type: 'number', description: 'market value of the holding in USD' },
							{ name: 'updated_at', type: 'number', description: 'last update time in ms since epoch (UTC)' },
						],
					},
				],
				ref: createReferenceWithTitle(getETFHoldingsRef, params, buildGetETFHoldingsCallDescription),
			},
		},
		run: (inputs) => {
			const raw = inputs.etf_holdings_raw;
			if (!raw || !raw.success || !raw.response) {
				throw new Error('ETF holdings raw data is invalid');
			}

			const holdingsArray = raw.response.holdings || raw.response.data || [];
			if (!Array.isArray(holdingsArray) || holdingsArray.length === 0) {
				// nothing to append
				throw new Error('ETF holdings array is empty');
			}

			// Determine a deterministic snapshot time from upstream fields
			const topLevelCandidates = [toMs(raw.response.as_of), toMs(raw.response.snapshot_at), toMs(raw.response.updated_at), toMs(raw.response.date), toMs(raw.response.timestamp)].filter((v) =>
				Number.isFinite(v)
			);

			const itemTimes = [];
			for (let i = 0; i < holdingsArray.length; i++) {
				const t = toMs(holdingsArray[i] && holdingsArray[i].updated_at);
				if (Number.isFinite(t)) itemTimes.push(t);
			}

			const allCandidates = topLevelCandidates.concat(itemTimes);
			const snapshotTime = allCandidates.length > 0 ? Math.max.apply(null, allCandidates) : null;
			if (!Number.isFinite(snapshotTime)) {
				// cannot derive a stable snapshot time, skip append
				return undefined;
			}

			const holdings = holdingsArray.map((holding) => ({
				symbol: holding.symbol || (params && params.symbol) || '',
				asset: holding.asset || '',
				name: holding.name || '',
				isin: holding.isin || '',
				security_cusip: holding.security_cusip || '',
				shares_number: Number(holding.shares_number || 0),
				weight_percentage: Number(holding.weight_percentage || 0),
				market_value: Number(holding.market_value || 0),
				updated_at: (() => {
					const t = toMs(holding.updated_at);
					return Number.isFinite(t) ? t : undefined;
				})(),
			}));

			return {
				holdings_snapshot: [
					{
						date: snapshotTime,
						symbol: params && params.symbol ? String(params.symbol) : '',
						holdings,
					},
				],
			};
		},
	};
}

// Get all reference metadata objects defined in this module
function getRefs() {
	return [
		getETFHoldingsRef,
	];
}

module.exports = {
	getETFHoldings,
	makeETFHoldingsNode,
	getRefs,
};
