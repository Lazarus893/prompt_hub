function main() {
	const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
	const { jagentId } = require('env');
	const { makeETFSectorWeightingsNode, getETFSectorWeightings } = require('@arrays/data/etf/sector-weightings:v1.0.0');

	// Simple assert helper to align with example style
	function assert(condition, message) {
		if (!condition) throw new Error(message || 'Assertion failed');
	}

	// ================= Direct getETFSectorWeightings Tests =================
	function testGetETFSectorWeightings() {
		console.log('\n=== Testing getETFSectorWeightings (Direct Calls) ===');

		let totalTests = 0;
		let passedTests = 0;

		function runTest(name, fn) {
			totalTests++;
			try {
				fn();
				console.log(`✅ ${name}`);
				passedTests++;
			} catch (e) {
				console.log(`❌ ${name}: ${e.message}`);
			}
		}

		// Permissive set of sector names observed from data providers (enumeration coverage)
		const ALLOWED_SECTORS = new Set([
			'Communication Services',
			'Consumer Cyclical',
			'Consumer Defensive',
			'Consumer Discretionary',
			'Consumer Staples',
			'Technology',
			'Information Technology',
			'Healthcare',
			'Health Care',
			'Industrials',
			'Basic Materials',
			'Materials',
			'Real Estate',
			'Energy',
			'Utilities',
			'Financial Services',
			'Financials',
			'Cash & Others',
		]);

		// Representative ETF symbols for happy path coverage (broad + sector ETFs)
		const ETF_SYMBOLS = [
			'SPY', 'QQQ', 'DIA', 'IWM', 'VTI',
			'XLK', 'XLF', 'XLE', 'XLY', 'XLV'
		];

		// Happy Path: validate structure and value ranges
		for (const sym of ETF_SYMBOLS) {
			runTest(`getETFSectorWeightings with ${sym}`, () => {
				const res = getETFSectorWeightings({ symbol: sym });
				assert(res && typeof res === 'object', 'Should return an object');
				assert(res.success === true, 'success flag should be true');
				assert(res.response && Array.isArray(res.response.weightings), 'response.weightings must be an array');
				const list = res.response.weightings;
				assert(list.length >= 1, 'weightings should not be empty for common ETFs');
				let sum = 0;
				for (const w of list) {
					assert(typeof w.symbol === 'string', 'Each weighting.symbol must be string');
					assert(typeof w.sector === 'string', 'Each weighting.sector must be string');
					assert(typeof w.weight_percentage === 'number', 'Each weighting.weight_percentage must be number');
					// Sector enumeration coverage
					assert(ALLOWED_SECTORS.has(w.sector), `Unexpected sector name: ${w.sector}`);
					// Boundary checks for percentage
					assert(w.weight_percentage >= 0 && w.weight_percentage <= 100, 'weight_percentage must be in [0,100]');
					sum += w.weight_percentage;
				}
				// Sum should roughly be around 100 (allow tolerance due to rounding and missing small sectors)
				assert(sum > 80 && sum <= 101, `sum of weights should be near 100, got ${sum}`);
			});
		}

		// Boundary Value Analysis: whitespace, case, and unusually long symbols
		runTest('symbol with surrounding whitespace', () => {
			try {
				const res = getETFSectorWeightings({ symbol: ' SPY ' });
				assert(res && typeof res === 'object', 'Should return an object');
				// Either trimmed internally and success, or handled gracefully as failure
				assert(
					(res.success === true && Array.isArray(res.response.weightings)) || res.success === false,
					'Should either succeed with data or mark success=false'
				);
			} catch (e) {
				// Accept thrown error as valid handling path
				assert(true, 'Throws error for invalid input is acceptable');
			}
		});

		runTest('lowercase symbol (case handling)', () => {
			try {
				const res = getETFSectorWeightings({ symbol: 'spy' });
				assert(res && typeof res === 'object', 'Should return an object');
				// Some APIs are case-insensitive, others not; accept either behavior
				assert(
					(res.success === true && Array.isArray(res.response.weightings)) || res.success === false,
					'Should either succeed with data or mark success=false'
				);
			} catch (e) {
				assert(true, 'Throws error for lowercase symbol is acceptable');
			}
		});

		runTest('unusually long symbol (likely invalid)', () => {
			try {
				const res = getETFSectorWeightings({ symbol: 'THISISAVERYLONGSYMBOL' });
				assert(res && typeof res === 'object', 'Should return an object');
				assert(
					res.success === false || (res.response && Array.isArray(res.response.weightings) && res.response.weightings.length === 0),
					'Should fail or return empty weightings for invalid symbol'
				);
			} catch (e) {
				assert(true, 'Throws error for invalid symbol is acceptable');
			}
		});

		// Special Value Tests
		runTest('symbol = empty string', () => {
			try {
				const res = getETFSectorWeightings({ symbol: '' });
				assert(res && typeof res === 'object', 'Should return an object');
				assert(res.success === false || (res.response && Array.isArray(res.response.weightings) && res.response.weightings.length === 0), 'Should not return data for empty symbol');
			} catch (e) {
				assert(true, 'Throws error for empty symbol is acceptable');
			}
		});

		runTest('symbol = null', () => {
			try {
				const res = getETFSectorWeightings({ symbol: null });
				assert(res && typeof res === 'object', 'Should return an object');
				assert(res.success === false, 'Should mark success=false for null symbol');
			} catch (e) {
				assert(true, 'Throws error for null symbol is acceptable');
			}
		});

		runTest('symbol = undefined', () => {
			try {
				const res = getETFSectorWeightings({ symbol: undefined });
				assert(res && typeof res === 'object', 'Should return an object');
				assert(res.success === false, 'Should mark success=false for undefined symbol');
			} catch (e) {
				assert(true, 'Throws error for undefined symbol is acceptable');
			}
		});

		runTest('symbol = 0 (non-string type)', () => {
			try {
				const res = getETFSectorWeightings({ symbol: 0 });
				assert(res && typeof res === 'object', 'Should return an object');
				assert(res.success === false, 'Should mark success=false for non-string symbol');
			} catch (e) {
				assert(true, 'Throws error for non-string symbol is acceptable');
			}
		});

		runTest('missing params object', () => {
			try {
				const res = getETFSectorWeightings();
				assert(res && typeof res === 'object', 'Should return an object');
				assert(res.success === false, 'Should mark success=false for missing params');
			} catch (e) {
				assert(true, 'Throws error for missing params is acceptable');
			}
		});

		runTest('invalid symbol value', () => {
			try {
				const res = getETFSectorWeightings({ symbol: 'INVALID' });
				assert(res && typeof res === 'object', 'Should return an object');
				assert(
					res.success === false || (res.response && Array.isArray(res.response.weightings) && res.response.weightings.length === 0),
					'Should fail or return empty for unknown symbol'
				);
			} catch (e) {
				assert(true, 'Throws error for invalid symbol is acceptable');
			}
		});

		console.log('\n--- getETFSectorWeightings Test Summary ---');
		console.log(`Total tests: ${totalTests}`);
		console.log(`Passed: ${passedTests}`);
		console.log(`Failed: ${totalTests - passedTests}`);
		console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
	}

	// ================= Graph Node Smoke + Mock Tests =================
	// Smoke test - basic functionality test
	const g = new Graph(jagentId);
	g.addNode('etf_sector_weightings_smoke', makeETFSectorWeightingsNode({ symbol: 'SPY' }));
	g.run();

	// Mock test - using sample data to avoid network dependency
	const nodeCfg = makeETFSectorWeightingsNode({ symbol: 'QQQ' });

	// Override input with mock data that matches the API response structure
	nodeCfg.inputs.etf_sector_weightings_raw = () => ({
		success: true,
		response: {
			weightings: [
				{
					symbol: 'QQQ',
					sector: 'Technology',
					weight_percentage: 45.2,
				},
				{
					symbol: 'QQQ',
					sector: 'Communication Services',
					weight_percentage: 15.8,
				},
				{
					symbol: 'QQQ',
					sector: 'Consumer Cyclical',
					weight_percentage: 12.1,
				},
				{
					symbol: 'QQQ',
					sector: 'Healthcare',
					weight_percentage: 8.9,
				},
				{
					symbol: 'QQQ',
					sector: 'Financial Services',
					weight_percentage: 5.3,
				},
			],
		},
	});

	const g2 = new Graph(jagentId);
	g2.addNode('etf_sector_weightings_mock', nodeCfg);
	g2.run();

	// Validate mock data output
	const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'etf_sector_weightings_mock', 'sector_weightings_snapshot', { last: '5' }), g2.store);
	ts.init();

	if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('sector_weightings_snapshot empty');
	const row = ts.data[0];
	['date', 'symbol', 'weightings'].forEach((k) => {
		if (!(k in row)) throw new Error('missing row field: ' + k);
	});
	if (typeof row.date !== 'number') throw new Error('snapshot date must be number(ms)');
	if (!Array.isArray(row.weightings) || row.weightings.length < 1) throw new Error('weightings empty');

	const w = row.weightings[0];
	['sector', 'weight_percentage'].forEach((k) => {
		if (!(k in w)) throw new Error('missing weighting field: ' + k);
	});

	// Validate smoke test output
	const tsSmoke = new TimeSeries(new TimeSeriesUri(jagentId, 'etf_sector_weightings_smoke', 'sector_weightings_snapshot', { last: '5' }), g.store);
	tsSmoke.init();
	if (!Array.isArray(tsSmoke.data)) throw new Error('smoke test data must be an array');
	if (tsSmoke.data.length > 0) {
		const r = tsSmoke.data[0];
		if (typeof r.date !== 'number') throw new Error('smoke.date must be number(ms)');
		if (!Array.isArray(r.weightings)) throw new Error('smoke.weightings must be an array');
		if (r.weightings.length > 0) {
			const weighting = r.weightings[0];
			if (typeof weighting.sector !== 'string') throw new Error('smoke.weighting.sector must be string');
			if (typeof weighting.weight_percentage !== 'number') throw new Error('smoke.weighting.weight_percentage must be number');
		}
	}

	// Refs validation tests for outputs that include `ref`
	// Validate refs for the mock node output
	const refsSectorWeightings = g2.getRefsForOutput('etf_sector_weightings_mock', 'sector_weightings_snapshot');
	if (refsSectorWeightings.length > 0) {
		const ref = refsSectorWeightings[0];
		const expected = {
			id: '@arrays/data/etf/sector-weightings/getETFSectorWeightings',
			module_name: '@arrays/data/etf/sector-weightings',
			module_display_name: 'ETF Sector Weightings',
			sdk_name: 'getETFSectorWeightings',
			sdk_display_name: 'ETF Sector Weightings',
			source_name: 'Financial Modeling Prep',
			source: 'https://site.financialmodelingprep.com/developer/docs/stable/sector-weighting',
		};

		if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for sector_weightings_snapshot');
		if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for sector_weightings_snapshot');
		if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for sector_weightings_snapshot');
		if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for sector_weightings_snapshot');
		if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for sector_weightings_snapshot');
		if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for sector_weightings_snapshot');
		if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for sector_weightings_snapshot');
		console.log('✓ sector_weightings_snapshot refs validated');
	} else {
		throw new Error('Assertion failed: refsSectorWeightings array is empty.');
	}

	// Run direct get function tests at the end to isolate from graph setup
	testGetETFSectorWeightings();

	return 0;
}

main();
