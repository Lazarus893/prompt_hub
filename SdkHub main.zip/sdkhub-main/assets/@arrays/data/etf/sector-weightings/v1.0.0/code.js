const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

const getETFSectorWeightingsRef = {
    id: '@arrays/data/etf/sector-weightings/getETFSectorWeightings',
    module_name: '@arrays/data/etf/sector-weightings',
    module_display_name: 'ETF Sector Weightings',
    sdk_name: 'getETFSectorWeightings',
    sdk_display_name: 'ETF Sector Weightings',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs/stable/sector-weighting',
};
// Internal base description strings (do not export)
const baseGetETFSectorWeightingsDesc = 'Retrieve ETF sector weightings';

// Internal dynamic call description builders (do not export)
function buildGetETFSectorWeightingsCallDescription(actualParams = {}) {
    const parts = [baseGetETFSectorWeightingsDesc];

    // Add symbol if provided
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getETFSectorWeightings(params) {
	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/etf/sector-weightings';
	const keyValuePairs = Object.keys(params || {}).map((k) => {
		const v = params[k];
		return encodeURIComponent(k) + '=' + encodeURIComponent(v);
	});
	const queryString = keyValuePairs.length > 0 ? `?${keyValuePairs.join('&')}` : '';
	const fullUrl = `${baseUrl}${queryString}`;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	const originalData = r.json();
	return {
		success: originalData.success,
		response: {
			...originalData.response,
			data: originalData?.response?.data || [],
		},
	};
}

function makeETFSectorWeightingsNode(params) {
	return {
		inputs: {
			etf_sector_weightings_raw: () => getETFSectorWeightings(params),
		},
		outputs: {
			sector_weightings_snapshot: {
				name: 'sector_weightings_snapshot',
				description: 'ETF Sector Weightings snapshot (single record with nested weightings array)',
				fields: [
					{ name: 'date', type: 'number', description: 'snapshot time in ms since epoch (UTC)' },
					{ name: 'symbol', type: 'string', description: 'ETF symbol for this snapshot' },
					{
						name: 'weightings',
						type: 'array',
						description: 'array of sector weightings at the snapshot time',
						fields: [
							{ name: 'sector', type: 'string', description: 'sector name' },
							{ name: 'weight_percentage', type: 'number', description: 'percentage weight as number' },
						],
					},
				],
				ref: createReferenceWithTitle(
					getETFSectorWeightingsRef,
					params,
					buildGetETFSectorWeightingsCallDescription
				),
			},
		},
		run: (inputs) => {
			const raw = inputs.etf_sector_weightings_raw;
			if (!raw || !raw.success || !raw.response) {
				throw new Error('ETF sector weightings raw data is invalid');
			}

			const weightingsArray = raw.response.weightings || raw.response.data || [];
			if (!Array.isArray(weightingsArray) || weightingsArray.length === 0) {
				// nothing to append - return undefined to skip this run
				return undefined;
			}

			// Use current time as snapshot time since ETF weightings are typically current snapshots
			const snapshotTime = Date.now();

			const weightings = weightingsArray.map((w) => {
				let pct = w.weight_percentage;
				if (typeof pct === 'string') {
					const parsed = parseFloat(pct);
					pct = Number.isFinite(parsed) ? parsed : 0;
				}
				return {
					sector: w.sector,
					weight_percentage: Number.isFinite(pct) ? pct : 0,
				};
			});

			return {
				sector_weightings_snapshot: [
					{
						date: snapshotTime,
						symbol: params && params.symbol ? String(params.symbol) : '',
						weightings,
					},
				],
			};
		},
	};
}

function getRefs() {
    return [
        getETFSectorWeightingsRef,
    ];
}

module.exports = {
	getETFSectorWeightings,
	makeETFSectorWeightingsNode,
    getRefs,
};