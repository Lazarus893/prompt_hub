function assert(cond, msg) {
  if (!cond) throw new Error(msg || 'Assertion failed');
}

function testGetETFInfoDirect() {
  console.log('\n=== Testing getETFInfo Direct Calls ===');

  const { getETFInfo } = require('@arrays/data/etf/info:v1.0.0'); // manual import for get* function

  let totalTests = 0;
  let passedTests = 0;

  function runTest(name, fn) {
    totalTests++;
    try {
      fn();
      console.log(`✅ ${name}`);
      passedTests++;
    } catch (e) {
      console.log(`❌ ${name}: ${e.message}`);
    }
  }

  function validateETFObject(e, symbolHint) {
    const requiredKeys = [
      'symbol',
      'name',
      'description',
      'expense_ratio',
      'assets_under_management',
      'holdings_count',
      'inception_date',
      'nav',
      'nav_currency',
      'asset_class',
      'avg_volume',
      'domicile',
      'etf_company',
      'isin',
      'sectors_list',
      'security_cusip',
      'website',
      'updated_at',
    ];
    requiredKeys.forEach((k) => assert(k in e, 'missing etf field: ' + k));

    if (symbolHint) assert(e.symbol === symbolHint, `symbol should equal ${symbolHint}`);
    assert(typeof e.symbol === 'string' && e.symbol.length > 0, 'symbol must be non-empty string');
    assert(typeof e.name === 'string' && e.name.length > 0, 'name must be non-empty string');
    assert(typeof e.description === 'string', 'description must be string');

    assert(typeof e.expense_ratio === 'number', 'expense_ratio must be number');
    assert(typeof e.assets_under_management === 'number', 'assets_under_management must be number');
    assert(typeof e.holdings_count === 'number' && Number.isInteger(e.holdings_count), 'holdings_count must be integer number');

    assert(typeof e.inception_date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(e.inception_date), 'inception_date must be YYYY-MM-DD');
    assert(typeof e.nav === 'number', 'nav must be number');
    assert(typeof e.nav_currency === 'string' && /^[A-Z]{3}$/.test(e.nav_currency), 'nav_currency must be 3-letter uppercase');

    assert(typeof e.asset_class === 'string' && e.asset_class.length > 0, 'asset_class must be non-empty string');
    assert(typeof e.avg_volume === 'number', 'avg_volume must be number');
    assert(typeof e.domicile === 'string' && e.domicile.length > 0, 'domicile must be non-empty string');
    assert(typeof e.etf_company === 'string' && e.etf_company.length > 0, 'etf_company must be non-empty string');
    assert(typeof e.isin === 'string' && e.isin.length > 0, 'isin must be non-empty string');
    assert(Array.isArray(e.sectors_list), 'sectors_list must be array');
    if (e.sectors_list.length) {
      const s = e.sectors_list[0];
      assert(s && typeof s === 'object', 'sectors_list[0] must be object');
      assert('exposure' in s && typeof s.exposure === 'number', 'sectors_list[0].exposure must be number');
      assert('industry' in s && typeof s.industry === 'string', 'sectors_list[0].industry must be string');
    }
    assert(typeof e.security_cusip === 'string' && e.security_cusip.length > 0, 'security_cusip must be non-empty string');
    assert(typeof e.website === 'string' && /^https?:\/\//.test(e.website), 'website must be a URL string');
    assert(typeof e.updated_at === 'string' && !isNaN(Date.parse(e.updated_at)), 'updated_at must be ISO date string');
  }

  // --- Happy Path: multiple valid symbols ---
  const VALID_SYMBOLS = ['SPY', 'QQQ', 'IWM'];
  for (const sym of VALID_SYMBOLS) {
    runTest(`getETFInfo happy path with ${sym}`, () => {
      const res = getETFInfo({ symbol: sym });
      assert(res && typeof res === 'object', 'Should return an object');
      assert(res.success === true, 'success should be true');
      assert(res.response && typeof res.response === 'object', 'response should be object');
      assert(Array.isArray(res.response.etfs), 'response.etfs should be array');
      assert(res.response.etfs.length > 0, 'response.etfs should not be empty');
      const e = res.response.etfs[0];
      validateETFObject(e, sym);
      // legacy compatibility: response.data is expected to be array (possibly empty)
      assert(Array.isArray(res.response.data), 'response.data should be an array');
    });
  }

  // --- Boundary & Special Values ---
  runTest('getETFInfo with lowercase symbol should fail', () => {
    try {
      getETFInfo({ symbol: 'spy' });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message && typeof e.message === 'string', 'Should throw error for lowercase symbol');
    }
  });

  runTest('getETFInfo with empty string symbol should fail', () => {
    try {
      getETFInfo({ symbol: '' });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message && typeof e.message === 'string', 'Should throw error for empty symbol');
    }
  });

  runTest('getETFInfo with null symbol should fail', () => {
    try {
      getETFInfo({ symbol: null });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message && typeof e.message === 'string', 'Should throw error for null symbol');
    }
  });

  runTest('getETFInfo with undefined symbol should fail', () => {
    try {
      // @ts-ignore
      getETFInfo({ symbol: undefined });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message && typeof e.message === 'string', 'Should throw error for undefined symbol');
    }
  });

  runTest('getETFInfo with numeric symbol should fail', () => {
    try {
      // @ts-ignore
      getETFInfo({ symbol: 0 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message && typeof e.message === 'string', 'Should throw error for numeric symbol');
    }
  });

  console.log('\n=== getETFInfo Test Summary ===');
  console.log(`Total tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${totalTests - passedTests}`);
  console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

  if (passedTests !== totalTests) {
    throw new Error('Some getETFInfo direct tests failed');
  }
}

function testGraphNodeIntegration() {
  console.log('\n=== Testing Graph Node Integration ===');
  const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
  const { jagentId } = require('env');
  const { makeETFInfoNode, getETFInfo } = require('@arrays/data/etf/info:v1.0.0');

  // quick sanity check via direct call to ensure environment is fine
  const sanity = getETFInfo({ symbol: 'SPY' });
  assert(sanity && sanity.success === true, 'Sanity check getETFInfo should succeed');

  const g = new Graph(jagentId);
  g.addNode('etf_info_spy', makeETFInfoNode({ symbol: 'SPY' }));
  g.run();

  const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'etf_info_spy', 'etf_info_snapshot', { last: '5' }), g.store);
  ts.init();

  if (!ts.data.length) throw new Error('etf_info_snapshot empty');
  const row = ts.data[0];
  ['date', 'symbol', 'etfs'].forEach((k) => {
    if (!(k in row)) throw new Error('missing row field: ' + k);
  });
  if (typeof row.date !== 'number') throw new Error('snapshot date must be number');
  if (!Array.isArray(row.etfs) || !row.etfs.length) throw new Error('etfs empty');

  const e = row.etfs[0];
  [
    'symbol',
    'name',
    'description',
    'expense_ratio',
    'assets_under_management',
    'holdings_count',
    'inception_date',
    'nav',
    'nav_currency',
    'asset_class',
    'avg_volume',
    'domicile',
    'etf_company',
    'isin',
    'sectors_list',
    'security_cusip',
    'website',
    'updated_at',
  ].forEach((k) => {
    if (!(k in e)) throw new Error('missing etf field: ' + k);
  });

  // Validate reference metadata for etf_info_snapshot output
  const refsEtfInfo = g.getRefsForOutput('etf_info_spy', 'etf_info_snapshot');
  if (refsEtfInfo.length > 0) {
    const ref = refsEtfInfo[0];
    const expected = {
      id: '@arrays/data/etf/info/getETFInfo',
      module_name: '@arrays/data/etf/info',
      module_display_name: 'ETF Overview',
      sdk_name: 'getETFInfo',
      sdk_display_name: 'ETF Overview',
      source_name: 'Financial Modeling Prep',
      source: 'https://site.financialmodelingprep.com/developer/docs/stable/information',
    };

    if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for etf_info_snapshot');
    if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for etf_info_snapshot');
    if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for etf_info_snapshot');
    if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for etf_info_snapshot');
    if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for etf_info_snapshot');
    if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for etf_info_snapshot');
    if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for etf_info_snapshot');
  } else {
    throw new Error('Assertion failed: refsEtfInfo array is empty.');
  }
}

function main() {
  // Direct API tests for getETFInfo
  testGetETFInfoDirect();
  // Graph node integration tests
  testGraphNodeIntegration();
}

main();
