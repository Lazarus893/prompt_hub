const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getETFInfo derived from tool.json
// Note: id must be ModuleName + function name to ensure global uniqueness
const getETFInfoRef = {
    id: "@arrays/data/etf/info/getETFInfo",
    module_name: "@arrays/data/etf/info",
    module_display_name: "ETF Overview",
    sdk_name: "getETFInfo",
    sdk_display_name: "ETF Overview",
    source_name: "Financial Modeling Prep",
    source: "https://site.financialmodelingprep.com/developer/docs/stable/information",
};

// Base description (concise) for getETFInfo derived from doc
const baseGetETFInfoDesc = "Get ETF information";

// Dynamic call description builder for getETFInfo based on params in doc
function buildGetETFInfoCallDescription(actualParams = {}) {
    const parts = [baseGetETFInfoDesc];
    if (actualParams.symbol) {
        parts.push(`for ${actualParams.symbol}`);
    }
    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getETFInfo(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/etf/info';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    const originalData = r.json();
    return {
        success: originalData.success,
        response: {
            ...originalData.response,
            data: originalData?.response?.data || [],
        },
    };
}

function makeETFInfoNode(params) {
    return {
        inputs: {
            etf_info_raw: () => getETFInfo(params),
        },
        outputs: {
            etf_info_snapshot: {
                name: 'etf_info_snapshot',
                description: 'ETF info snapshot with details list',
                fields: [
                    { name: 'date', type: 'number', description: 'snapshot time ms (UTC)' },
                    { name: 'symbol', type: 'string', description: 'ETF symbol for this snapshot' },
                    {
                        name: 'etfs',
                        type: 'array',
                        description: 'ETF info list (as returned by API, normalized with key fields)',
                        fields: [
                            { name: 'symbol', type: 'string', description: 'ETF ticker symbol' },
                            { name: 'name', type: 'string', description: 'ETF full name' },
                            { name: 'description', type: 'string', description: 'Investment objective/strategy' },
                            { name: 'expense_ratio', type: 'number', description: 'Annual expense ratio (%)' },
                            { name: 'assets_under_management', type: 'number', description: 'AUM' },
                            { name: 'holdings_count', type: 'number', description: 'Number of holdings' },
                            { name: 'inception_date', type: 'string', description: 'Launch date YYYY-MM-DD' },
                            { name: 'nav', type: 'number', description: 'Net asset value' },
                            { name: 'nav_currency', type: 'string', description: 'NAV currency' },
                            { name: 'asset_class', type: 'string', description: 'Asset class (e.g., Equity)' },
                            { name: 'avg_volume', type: 'number', description: 'Average daily trading volume' },
                            { name: 'domicile', type: 'string', description: 'Country of domicile' },
                            { name: 'etf_company', type: 'string', description: 'ETF issuer/provider company' },
                            { name: 'isin', type: 'string', description: 'ISIN identifier' },
                            {
                                name: 'sectors_list',
                                type: 'array',
                                description: 'Sector exposure breakdown',
                                fields: [
                                    { name: 'exposure', type: 'number', description: 'Sector exposure percentage' },
                                    { name: 'industry', type: 'string', description: 'Industry/sector name' },
                                ],
                            },
                            { name: 'security_cusip', type: 'string', description: 'CUSIP identifier' },
                            { name: 'website', type: 'string', description: 'Fund provider website URL' },
                            { name: 'updated_at', type: 'string', description: 'Last updated timestamp in ISO format' },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getETFInfoRef, params, buildGetETFInfoCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.etf_info_raw;
            if (!raw || !raw.success || !raw.response) {
                throw new Error('ETF info raw data is invalid');
            }
            const list = Array.isArray(raw.response?.etfs) ? raw.response.etfs : Array.isArray(raw.response?.data) ? raw.response.data : [];
            if (!Array.isArray(list) || list.length === 0) {
                throw new Error('ETF info list is empty');
            }

            // Derive snapshot time from upstream if available (max updated_at), else fall back to domain clock
            let snapshotTime = null;
            for (const etf of list) {
                const t = Date.parse(etf?.updated_at);
                if (Number.isFinite(t)) {
                    if (snapshotTime == null || t > snapshotTime) snapshotTime = t;
                }
            }
            if (snapshotTime == null) {
                snapshotTime = Date.now();
            }

            const etfs = list.map((etf) => ({
                symbol: etf.symbol,
                name: etf.name,
                description: etf.description,
                expense_ratio: etf.expense_ratio,
                assets_under_management: etf.assets_under_management,
                holdings_count: etf.holdings_count,
                inception_date: etf.inception_date,
                nav: etf.nav,
                nav_currency: etf.nav_currency,
                asset_class: etf.asset_class,
                avg_volume: etf.avg_volume,
                domicile: etf.domicile,
                etf_company: etf.etf_company,
                isin: etf.isin,
                sectors_list: Array.isArray(etf.sectors_list)
                    ? etf.sectors_list.map((s) => ({
                        exposure: s.exposure,
                        industry: s.industry,
                    }))
                    : [],
                security_cusip: etf.security_cusip,
                website: etf.website,
                updated_at: etf.updated_at,
            }));

            return {
                etf_info_snapshot: [{ date: snapshotTime, symbol: params.symbol || '', etfs }],
            };
        },
    };
}

function getRefs() {
    return [
        getETFInfoRef,
    ];
}

module.exports = {
    getETFInfo,
    makeETFInfoNode,
    getRefs,
};