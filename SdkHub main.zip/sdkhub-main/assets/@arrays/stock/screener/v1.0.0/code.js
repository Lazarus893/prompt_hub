const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');

// Reference metadata for getStockCompanyByScreener (derived from tool.json)
const getStockCompanyByScreenerRef = {
    id: '@arrays/stock/screener/getStockCompanyByScreener',
    module_name: '@arrays/stock/screener',
    module_display_name: 'Stock Screener',
    sdk_name: 'getStockCompanyByScreener',
    sdk_display_name: 'Stock Screener',
    source_name: 'Financial Modeling Prep',
    source: 'https://site.financialmodelingprep.com/developer/docs#search-company-screener',
};

// Base description and dynamic call description builder (from doc)
const getStockCompanyByScreenerBaseFuncDesc = 'Screen stock companies by filters';

function buildGetStockCompanyByScreenerCallDescription(actualParams = {}) {
    const parts = [getStockCompanyByScreenerBaseFuncDesc];

    // High-level scope
    if (actualParams.exchange) parts.push(`on ${actualParams.exchange}`);
    if (actualParams.country) parts.push(`in ${actualParams.country}`);

    const scope = [];
    if (actualParams.sector) scope.push(`Sector: ${actualParams.sector}`);
    if (actualParams.industry) scope.push(`Industry: ${actualParams.industry}`);
    if (scope.length) parts.push(`(${scope.join(', ')})`);

    const filters = [];

    // Interval
    if (actualParams.interval && actualParams.interval !== '1d') {
        filters.push(`Interval: ${actualParams.interval}`);
    }

    // Helper to render ranges
    const addRange = (label, minKey, maxKey, unit = '') => {
        const min = actualParams[minKey];
        const max = actualParams[maxKey];
        const u = unit ? unit : '';
        const hasMin = min !== undefined && min !== null;
        const hasMax = max !== undefined && max !== null;
        if (hasMin && hasMax) filters.push(`${label}: ${min}${u}-${max}${u}`);
        else if (hasMin) filters.push(`${label} >= ${min}${u}`);
        else if (hasMax) filters.push(`${label} <= ${max}${u}`);
    };

    const addDateRange = (label, startKey, endKey) => {
        const s = actualParams[startKey];
        const e = actualParams[endKey];
        if (s && e) filters.push(`${label}: ${s} to ${e}`);
        else if (s) filters.push(`${label} from: ${s}`);
        else if (e) filters.push(`${label} until: ${e}`);
    };

    // Prices / Volume / Market cap
    addRange('Price', 'price_min', 'price_max');
    addRange('Price change', 'price_change_min', 'price_change_max');
    addRange('Volume', 'volume_min', 'volume_max');
    addRange('Market cap', 'market_cap_min', 'market_cap_max');

    // Company attributes
    if (actualParams.is_active_trading === true) filters.push('Active trading only');
    if (actualParams.is_etf === true) filters.push('ETFs only');
    if (actualParams.is_adr === true) filters.push('ADRs only');
    if (actualParams.is_fund === true) filters.push('Funds only');

    addRange('Employees', 'employees_min', 'employees_max');
    addDateRange('IPO date', 'ipo_start', 'ipo_end');

    // Analyst consensus / score
    if (actualParams.consensus) filters.push(`Consensus: ${actualParams.consensus}`);
    addRange('Overall score', 'overall_score_min', 'overall_score_max');

    // Financials and ratios
    addRange('Revenue', 'revenue_min', 'revenue_max');
    addRange('Net income', 'net_income_min', 'net_income_max');
    addRange('EPS', 'eps_min', 'eps_max');
    addRange('Gross profit ratio', 'gross_profit_ratio_min', 'gross_profit_ratio_max');
    addRange('Operating profit ratio', 'operating_profit_ratio_min', 'operating_profit_ratio_max');
    addRange('P/E', 'pe_ratio_min', 'pe_ratio_max');
    addRange('P/S', 'ps_ratio_min', 'ps_ratio_max');
    addRange('P/B', 'pb_ratio_min', 'pb_ratio_max');
    addRange('Dividend yield', 'div_yield_min', 'div_yield_max');
    addRange('EV/EBITDA', 'ev_ebitda_min', 'ev_ebitda_max');
    addRange('Enterprise value', 'ev_min', 'ev_max');
    addRange('ROE', 'roe_min', 'roe_max');
    addRange('Debt/Assets', 'debt_to_assets_min', 'debt_to_assets_max');

    // Institutional ownership
    addRange('Institutional invested change', 'total_invested_change_min', 'total_invested_change_max');
    addRange('Institutional owners', 'investors_holding_min', 'investors_holding_max');
    addRange('Ownership %', 'ownership_percent_min', 'ownership_percent_max');

    // Insider trades
    addRange('Insider buy count', 'insider_buy_count_min', 'insider_buy_count_max');
    addRange('Insider sell count', 'insider_sell_count_min', 'insider_sell_count_max');

    // Corporate events windows
    addDateRange('Recent split', 'recent_split_calendar_start', 'recent_split_calendar_end');
    addDateRange('Upcoming split', 'upcoming_split_calendar_start', 'upcoming_split_calendar_end');
    addDateRange('Recent earnings', 'recent_earnings_date_start', 'recent_earnings_date_end');
    addDateRange('Upcoming earnings', 'upcoming_earnings_date_start', 'upcoming_earnings_date_end');
    addDateRange('Recent equity offerings', 'recent_equity_offerings_date_start', 'recent_equity_offerings_date_end');

    // Congressional trades
    if (actualParams.transaction_type) filters.push(`Congressional trades: ${actualParams.transaction_type}`);
    if (actualParams.transaction_date_start) filters.push(`Trade date from: ${actualParams.transaction_date_start}`);

    // Sorting
    if (actualParams.sort_by && actualParams.sort_by !== 'market_cap') filters.push(`Sort by: ${actualParams.sort_by}`);
    if (actualParams.sort_desc && actualParams.sort_desc !== 'asc') filters.push(`Order: ${actualParams.sort_desc}`);

    // Pagination
    if (typeof actualParams.offset === 'number' && actualParams.offset !== 0) filters.push(`Offset: ${actualParams.offset}`);
    if (typeof actualParams.limit === 'number' && actualParams.limit !== 10) filters.push(`Limit: ${actualParams.limit}`);

    if (filters.length > 0) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getStockCompanyByScreener(params) {
    const { syncFetch: fetch } = require('net/http');
    const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/company/screener';
    const keyValuePairs = Object.keys(params || {}).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = `${baseUrl}?${queryString}`;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'X-API-Key': key,
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    const originalData = r.json();
    const list = originalData?.response?.list || [];
    const transformedList = list.map(c => ({
        ticker: c.ticker,
        name: c.name,
        logo: c.logo,
        sector: c.sector,
        industry: c.industry,
        exchange: c.exchange,
        country: c.country,
        employees: c.employees,
        ipo_date: c.ipo_date,
        is_active_trading: c.is_active_trading,
        is_etf: c.is_etf,
        is_adr: c.is_adr,
        is_fund: c.is_fund,
        revenue: c.revenue,
        net_income: c.net_income,
        eps: c.eps,
        pe_ratio: c.pe_ratio,
        ps_ratio: c.ps_ratio,
        pb_ratio: c.pb_ratio,
        dividend_yield: c.dividend_yield,
        enterprise_value: c.enterprise_value,
        ev_ebitda: c.ev_ebitda,
        roe: c.roe,
        debt_to_assets: c.debt_to_assets,
        price_change: c.price_change,
        market_cap: c.market_cap,

        open: c.open_price,
        close: c.close_price,
        high: c.high_price,
        low: c.low_price,
        volume: c.total_volume,
    }));

    return {
        success: originalData.success,
        response: {
            ...originalData.response,
            list: transformedList,
        },
    };
}

function makeStockCompanyScreenerNode(params) {
    return {
        inputs: {
            stock_company_raw: () => getStockCompanyByScreener(params),
        },
        outputs: {
            companies_screener_list: {
                name: 'companies_screener_list',
                description: 'Snapshot of stock companies list with filters applied',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'snapshot time ms (UTC)',
                    },
                    {
                        name: 'total',
                        type: 'number',
                        description: 'total matched companies',
                    },
                    {
                        name: 'companies',
                        type: 'array',
                        description: 'deduplicated companies (by ticker) in this snapshot',
                        fields: [
                            {
                                name: 'ticker',
                                type: 'string',
                                description: 'Stock ticker',
                            },
                            {
                                name: 'name',
                                type: 'string',
                                description: 'Company name',
                            },
                            {
                                name: 'logo',
                                type: 'string',
                                description: 'Logo URL',
                            },
                            {
                                name: 'sector',
                                type: 'string',
                                description: 'Sector',
                            },
                            {
                                name: 'industry',
                                type: 'string',
                                description: 'Industry',
                            },
                            {
                                name: 'exchange',
                                type: 'string',
                                description: 'Exchange',
                            },
                            {
                                name: 'country',
                                type: 'string',
                                description: 'Country/Region',
                            },
                            {
                                name: 'employees',
                                type: 'number',
                                description: 'Employees',
                            },
                            {
                                name: 'ipo_date',
                                type: 'string',
                                description: 'IPO date YYYY-MM-DD',
                            },
                            {
                                name: 'is_active_trading',
                                type: 'boolean',
                                description: 'Actively traded',
                            },
                            {
                                name: 'is_etf',
                                type: 'boolean',
                                description: 'ETF',
                            },
                            {
                                name: 'is_adr',
                                type: 'boolean',
                                description: 'ADR',
                            },
                            {
                                name: 'is_fund',
                                type: 'boolean',
                                description: 'Fund',
                            },
                            {
                                name: 'open',
                                type: 'number',
                                description: 'Open price (interval)',
                            },
                            {
                                name: 'close',
                                type: 'number',
                                description: 'Close price (interval)',
                            },
                            {
                                name: 'high',
                                type: 'number',
                                description: 'High price (interval)',
                            },
                            {
                                name: 'low',
                                type: 'number',
                                description: 'Low price (interval)',
                            },
                            {
                                name: 'volume',
                                type: 'number',
                                description: 'Total volume (interval)',
                            },
                            {
                                name: 'price_change',
                                type: 'number',
                                description: 'Price change % (interval)',
                            },
                            {
                                name: 'market_cap',
                                type: 'number',
                                description: 'Market cap',
                            },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(
                    getStockCompanyByScreenerRef,
                    params,
                    buildGetStockCompanyByScreenerCallDescription
                ),
            },
        },
        run: (inputs) => {
            const raw = inputs.stock_company_raw;
            const src = raw && raw.response && Array.isArray(raw.response.list) ? raw.response.list : [];
            const mapped = src
                .map((c) => ({
                    ticker: c.ticker,
                    name: c.name,
                    logo: c.logo,
                    sector: c.sector,
                    industry: c.industry,
                    exchange: c.exchange,
                    country: c.country,
                    employees: c.employees,
                    ipo_date: c.ipo_date,
                    is_active_trading: c.is_active_trading,
                    is_etf: c.is_etf,
                    is_adr: c.is_adr,
                    is_fund: c.is_fund,
                    open: c.open,
                    close: c.close,
                    high: c.high,
                    low: c.low,
                    volume: c.volume,
                    price_change: c.price_change,
                    market_cap: c.market_cap,
                }))
                .filter((c) => typeof c.ticker === 'string' && c.ticker.length > 0);
            const dedup = new Map();
            for (const c of mapped) dedup.set(c.ticker, c);
            const companies = Array.from(dedup.values());
            const total = raw && raw.response && typeof raw.response.total === 'number' ? raw.response.total : companies.length;
            return {
                companies_screener_list: [
                    {
                        date: Date.now(),
                        total,
                        companies,
                    },
                ],
            };
        },
    };
}

function getRefs() {
    return [
        getStockCompanyByScreenerRef,
    ];
}

module.exports = {
    getStockCompanyByScreener,
    makeStockCompanyScreenerNode,
    getRefs,
};
