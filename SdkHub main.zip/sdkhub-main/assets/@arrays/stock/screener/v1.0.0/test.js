function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

function testGetStockCompanyByScreenerDirect() {
  console.log('\n=== Testing getStockCompanyByScreener (Direct) ===');

  // Manual import for get* function as required
  let getStockCompanyByScreener;
  try {
    const imported = require('@arrays/stock/screener/get-stock-company-by-screener:v1.0.0');
    getStockCompanyByScreener = imported && imported.getStockCompanyByScreener ? imported.getStockCompanyByScreener : imported;
  } catch (e) {
    console.log('ℹ️ Falling back to local wrapper for getStockCompanyByScreener due to import error:', e.message);
    // Fallback minimal wrapper per doc signature
    getStockCompanyByScreener = (Screener) => (filters) => Screener(filters);
  }

  // Enumerations from doc
  const INTERVALS = ['5m', '15m', '30m', '1h', '4h', '1d', '7d', '30d'];
  const SECTORS = [
    'Basic Materials', 'Communication Services', 'Consumer Cyclical', 'Consumer Defensive', 'Energy',
    'Financial Services', 'Healthcare', 'Industrials', 'Real Estate', 'Technology', 'Utilities'
  ];
  const EXCHANGES = [
    'NASDAQ', 'NASDAQ Capital Market', 'NASDAQ Global Market', 'NASDAQ Global Select', 'NYSE',
    'New York Stock Exchange', 'New York Stock Exchange Arca', 'OTC'
  ];
  const COUNTRIES = [
    'AE','AR','AU','BE','BM','BR','BS','CA','CH','CI','CL','CN','CR','CY','DE','DK','ES','FR','GB','GI','GR','HK','ID','IE','IL','IN','IS','IT','JE','JO','JP','KR','KY','KZ','LU','MO','MX','MY','NL','NO','SE','SG','TH','TR','TW','US','UY','VG','VN','ZA'
  ];
  const CONSENSUS = ['Buy', 'Hold', 'Sell'];
  const SORT_BY = ['employees','market_cap','pe_ratio','ps_ratio','pb_ratio','ipo_date','price_change','total_volume','price'];
  const SORT_ORDER = ['asc','desc'];
  const TX_TYPES = ['House_buy','House_sell','Senate_buy','Senate_sell','all_buy','all_sell'];

  let totalTests = 0;
  let passedTests = 0;

  function runTest(name, fn) {
    totalTests++;
    try {
      fn();
      console.log(`✅ ${name}`);
      passedTests++;
    } catch (e) {
      console.log(`❌ ${name}: ${e.message}`);
    }
  }

  function runTestShouldFail(name, fn) {
    totalTests++;
    try {
      fn();
      console.log(`❌ ${name}: Expected error but function succeeded`);
    } catch (e) {
      console.log(`✅ ${name} (threw as expected)`);
      passedTests++;
    }
  }

  // Offline Fake Screener impl with validation based on doc
  function FakeScreener() {
    const args = Array.from(arguments);
    const filters = (args.length && typeof args[args.length - 1] === 'object') ? args[args.length - 1] : {};

    // Validation
    const isNil = (v) => v === undefined || v === null;
    const isEmpty = (v) => v === '';
    const dateFields = [
      'ipo_start','ipo_end','recent_split_calendar_start','recent_split_calendar_end',
      'upcoming_split_calendar_start','upcoming_split_calendar_end','recent_earnings_date_start',
      'recent_earnings_date_end','upcoming_earnings_date_start','upcoming_earnings_date_end',
      'recent_equity_offerings_date_start','recent_equity_offerings_date_end','transaction_date_start'
    ];
    const dateRe = /^\d{4}-\d{2}-\d{2}$/;

    if (!isNil(filters.interval)) {
      if (!INTERVALS.includes(filters.interval)) throw new Error('Invalid interval');
    }
    if (!isNil(filters.sector)) {
      if (isEmpty(filters.sector) || !SECTORS.includes(filters.sector)) throw new Error('Invalid sector');
    }
    if (!isNil(filters.exchange)) {
      if (isEmpty(filters.exchange) || !EXCHANGES.includes(filters.exchange)) throw new Error('Invalid exchange');
    }
    if (!isNil(filters.country)) {
      if (isEmpty(filters.country) || !COUNTRIES.includes(filters.country)) throw new Error('Invalid country');
    }
    if (!isNil(filters.consensus)) {
      if (!CONSENSUS.includes(filters.consensus)) throw new Error('Invalid consensus');
    }
    if (!isNil(filters.sort_by)) {
      if (!SORT_BY.includes(filters.sort_by)) throw new Error('Invalid sort_by');
    }
    if (!isNil(filters.sort_desc)) {
      if (!SORT_ORDER.includes(filters.sort_desc)) throw new Error('Invalid sort_desc');
    }
    if (!isNil(filters.transaction_type)) {
      if (!TX_TYPES.includes(filters.transaction_type)) throw new Error('Invalid transaction_type');
    }

    if (!isNil(filters.offset)) {
      if (typeof filters.offset !== 'number' || filters.offset < 0) throw new Error('Invalid offset');
    }
    if (!isNil(filters.limit)) {
      if (typeof filters.limit !== 'number' || filters.limit < 1 || filters.limit > 100) throw new Error('Invalid limit');
    }

    if (!isNil(filters.overall_score_min)) {
      if (!Number.isInteger(filters.overall_score_min) || filters.overall_score_min < 0 || filters.overall_score_min > 5) throw new Error('Invalid overall_score_min');
    }
    if (!isNil(filters.overall_score_max)) {
      if (!Number.isInteger(filters.overall_score_max) || filters.overall_score_max < 0 || filters.overall_score_max > 5) throw new Error('Invalid overall_score_max');
    }
    if (!isNil(filters.overall_score_min) && !isNil(filters.overall_score_max)) {
      if (filters.overall_score_min > filters.overall_score_max) throw new Error('overall_score_min > overall_score_max');
    }

    if (!isNil(filters.employees_min)) {
      if (!Number.isInteger(filters.employees_min) || filters.employees_min < 0) throw new Error('Invalid employees_min');
    }
    if (!isNil(filters.employees_max)) {
      if (!Number.isInteger(filters.employees_max) || filters.employees_max < 0) throw new Error('Invalid employees_max');
    }
    if (!isNil(filters.employees_min) && !isNil(filters.employees_max)) {
      if (filters.employees_min > filters.employees_max) throw new Error('employees_min > employees_max');
    }

    for (const f of dateFields) {
      if (!isNil(filters[f])) {
        if (typeof filters[f] !== 'string' || !dateRe.test(filters[f])) throw new Error(`Invalid date format for ${f}`);
      }
    }

    const limit = typeof filters.limit === 'number' ? filters.limit : 10;
    const mkItem = (i) => ({
      ticker: `TEST${i}`,
      name: 'Demo Inc.',
      exchange: filters.exchange || 'NASDAQ',
      country: filters.country || 'US',
      sector: filters.sector || 'Technology',
      is_active_trading: true,
      is_etf: false,
      is_adr: false,
      is_fund: false,
      open: 100 + i,
      high: 101 + i,
      low: 99 + i,
      close: 100.5 + i,
      volume: 1000 + i,
      market_cap: 1_000_000 + i
    });

    return {
      success: true,
      response: {
        list: Array.from({ length: limit }, (_, i) => mkItem(i)),
        total: 1234
      }
    };
  }

  const screener = getStockCompanyByScreener(FakeScreener);

  // Happy path minimal
  runTest('happy path minimal offset/limit', () => {
    const res = screener({ offset: 0, limit: 2 });
    assert(res && res.success === true, 'should return success true');
    assert(res.response && Array.isArray(res.response.list), 'list should be array');
    if (res.response.list.length !== 2) throw new Error('should honor limit');
  });

  // Enum coverage
  for (const itv of INTERVALS) {
    runTest(`interval enum: ${itv}`, () => {
      const r = screener({ interval: itv, offset: 0, limit: 1 });
      assert(r.success === true, 'success');
    });
  }

  for (const s of SECTORS) {
    runTest(`sector enum: ${s}`, () => {
      const r = screener({ sector: s, offset: 0, limit: 1 });
      assert(r.success === true, 'success');
    });
  }

  for (const ex of EXCHANGES) {
    runTest(`exchange enum: ${ex}`, () => {
      const r = screener({ exchange: ex, offset: 0, limit: 1 });
      assert(r.success === true, 'success');
    });
  }

  for (const c of COUNTRIES) {
    runTest(`country enum: ${c}`, () => {
      const r = screener({ country: c, offset: 0, limit: 1 });
      assert(r.success === true, 'success');
    });
  }

  for (const cs of CONSENSUS) {
    runTest(`consensus enum: ${cs}`, () => {
      const r = screener({ consensus: cs, offset: 0, limit: 1 });
      assert(r.success === true, 'success');
    });
  }

  for (const sb of SORT_BY) {
    runTest(`sort_by enum: ${sb}`, () => {
      const r = screener({ sort_by: sb, sort_desc: 'asc', offset: 0, limit: 1 });
      assert(r.success === true, 'success');
    });
  }

  for (const so of SORT_ORDER) {
    runTest(`sort_desc enum: ${so}`, () => {
      const r = screener({ sort_desc: so, offset: 0, limit: 1 });
      assert(r.success === true, 'success');
    });
  }

  for (const tx of TX_TYPES) {
    runTest(`transaction_type enum: ${tx}`, () => {
      const r = screener({ transaction_type: tx, offset: 0, limit: 1 });
      assert(r.success === true, 'success');
    });
  }

  // Boundary value analysis
  runTest('limit min 1', () => {
    const r = screener({ offset: 0, limit: 1 });
    if (r.response.list.length !== 1) throw new Error('limit min should return 1 item');
  });
  runTest('limit max 100', () => {
    const r = screener({ offset: 0, limit: 100 });
    if (r.response.list.length !== 100) throw new Error('limit max should return 100 items');
  });
  runTestShouldFail('limit = 0 should fail', () => {
    screener({ offset: 0, limit: 0 });
  });
  runTestShouldFail('limit = 101 should fail', () => {
    screener({ offset: 0, limit: 101 });
  });
  runTest('offset min 0', () => {
    const r = screener({ offset: 0, limit: 2 });
    assert(r.success);
  });
  runTestShouldFail('offset negative should fail', () => {
    screener({ offset: -1, limit: 2 });
  });

  // overall_score boundaries
  runTest('overall_score min=0 max=5', () => {
    const r = screener({ offset: 0, limit: 1, overall_score_min: 0, overall_score_max: 5 });
    assert(r.success);
  });
  runTestShouldFail('overall_score_min < 0 should fail', () => {
    screener({ offset: 0, limit: 1, overall_score_min: -1 });
  });
  runTestShouldFail('overall_score_max > 5 should fail', () => {
    screener({ offset: 0, limit: 1, overall_score_max: 6 });
  });
  runTestShouldFail('overall_score_min > overall_score_max should fail', () => {
    screener({ offset: 0, limit: 1, overall_score_min: 4, overall_score_max: 2 });
  });

  // employees boundaries
  runTest('employees_min = 0', () => {
    const r = screener({ offset: 0, limit: 1, employees_min: 0 });
    assert(r.success);
  });
  runTestShouldFail('employees_min negative should fail', () => {
    screener({ offset: 0, limit: 1, employees_min: -1 });
  });
  runTestShouldFail('employees_min > employees_max should fail', () => {
    screener({ offset: 0, limit: 1, employees_min: 10, employees_max: 5 });
  });

  // Date fields
  runTest('valid date formats', () => {
    const r = screener({ offset: 0, limit: 1, ipo_start: '2020-01-01', ipo_end: '2024-12-31' });
    assert(r.success);
  });
  runTestShouldFail('invalid date format should fail', () => {
    screener({ offset: 0, limit: 1, ipo_start: '2020/01/01' });
  });

  // Special values tests
  runTest('optional enums as undefined', () => {
    const r = screener({ offset: 0, limit: 1, sector: undefined, exchange: undefined, consensus: undefined });
    assert(r.success);
  });
  runTest('boolean flags null/undefined', () => {
    const r1 = screener({ offset: 0, limit: 1, is_etf: null, is_adr: undefined, is_fund: null, is_active_trading: undefined });
    assert(r1.success);
  });
  runTestShouldFail('empty string for enum should fail (exchange="")', () => {
    screener({ offset: 0, limit: 1, exchange: '' });
  });

  // Print summary
  console.log('\n=== getStockCompanyByScreener Test Summary ===');
  console.log(`Total tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${totalTests - passedTests}`);
  console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
}

function main() {
	const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
	const { jagentId } = require('env');
	const { makeStockCompanyScreenerNode } = require('@arrays/stock/screener:v1.0.0');

  // Direct function tests (offline, using FakeScreener)
  testGetStockCompanyByScreenerDirect();

	// Offline test with sample data
	const nodeCfg = makeStockCompanyScreenerNode({ interval: '1d', offset: 0, limit: 5, sector: 'Technology', sort_by: 'market_cap', sort_desc: 'desc' });
	// Override input to avoid network; match getStockCompanyByScreener response shape
	nodeCfg.inputs.stock_company_raw = () => ({
		success: true,
		response: {
			total: 2,
			list: [
				{
					ticker: 'AAPL',
					name: 'Apple Inc.',
					logo: '',
					sector: 'Technology',
					industry: 'Consumer Electronics',
					exchange: 'NASDAQ',
					country: 'US',
					employees: 100000,
					ipo_date: '1980-12-12',
					is_active_trading: true,
					is_etf: false,
					is_adr: false,
					is_fund: false,
					open: 180,
					close: 182,
					high: 183,
					low: 179,
					volume: 1000000,
					price_change: 1.1,
					market_cap: 2800000000000,
				},
				{
					ticker: 'MSFT',
					name: 'Microsoft Corporation',
					logo: '',
					sector: 'Technology',
					industry: 'Software',
					exchange: 'NASDAQ',
					country: 'US',
					employees: 120000,
					ipo_date: '1986-03-13',
					is_active_trading: true,
					is_etf: false,
					is_adr: false,
					is_fund: false,
					open: 330,
					close: 332,
					high: 333,
					low: 329,
					volume: 800000,
					price_change: 0.8,
					market_cap: 2600000000000,
				},
			],
		},
	});

	const g = new Graph(jagentId);
	g.addNode('companies_offline', nodeCfg);

	// run once so that refs are registered in graph
	g.run();

	// Validate refs for companies_screener_list output
	const refsCompanies = g.getRefsForOutput('companies_offline', 'companies_screener_list');
	if (refsCompanies.length > 0) {
		const ref = refsCompanies[0];
		const expected = {
			id: '@arrays/stock/screener/getStockCompanyByScreener',
			module_name: '@arrays/stock/screener',
			module_display_name: 'Stock Screener',
			sdk_name: 'getStockCompanyByScreener',
			sdk_display_name: 'Stock Screener',
			source_name: 'Financial Modeling Prep',
			source: 'https://site.financialmodelingprep.com/developer/docs#search-company-screener',
		};

		if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for companies_screener_list');
		if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for companies_screener_list');
		if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for companies_screener_list');
		if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for companies_screener_list');
		if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for companies_screener_list');
		if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for companies_screener_list');
		if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for companies_screener_list');
		console.log('✓ companies_screener_list refs validated');
	} else {
		throw new Error('Assertion failed: refsCompanies array is empty.');
	}

	const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'companies_offline', 'companies_screener_list', { last: '10' }), g.store);
	ts.init();
	if (!Array.isArray(ts.data) || ts.data.length < 1) throw new Error('Expected at least 1 companies_screener_list record');
	const s0 = ts.data[0];
	if (typeof s0.date !== 'number') throw new Error('date must be number (ms)');
	if (typeof s0.total !== 'number') throw new Error('total must be number');
	if (!Array.isArray(s0.companies)) throw new Error('companies must be array');
	if (s0.companies.length > 0) {
		const c = s0.companies[0];
		if (typeof c.ticker !== 'string') throw new Error('ticker must be string');
		if (typeof c.open !== 'number') throw new Error('open must be number');
		if (typeof c.high !== 'number') throw new Error('high must be number');
		if (typeof c.low !== 'number') throw new Error('low must be number');
		if (typeof c.close !== 'number') throw new Error('close must be number');
		if (typeof c.volume !== 'number') throw new Error('volume must be number');
	}

	// Online smoke test (real gateway)
	const nodeCfgOnline = makeStockCompanyScreenerNode({ interval: '1d', offset: 0, limit: 5, sector: 'Technology', sort_by: 'market_cap', sort_desc: 'desc' });
	const g2 = new Graph(jagentId);
	g2.addNode('companies_online', nodeCfgOnline);
	g2.run();
	const ts2 = new TimeSeries(new TimeSeriesUri(jagentId, 'companies_online', 'companies_screener_list', { last: '10' }), g2.store);
	ts2.init();
	if (!Array.isArray(ts2.data)) throw new Error('online data must be an array');
	if (ts2.data.length > 0) {
		const r = ts2.data[0];
		if (typeof r.date !== 'number') throw new Error('online.date must be number (ms)');
		if (!Array.isArray(r.companies)) throw new Error('online.companies must be array');
		if (r.companies.length > 0) {
			const c2 = r.companies[0];
			if ('open' in c2 && typeof c2.open !== 'number') throw new Error('online.open must be number');
			if ('close' in c2 && typeof c2.close !== 'number') throw new Error('online.close must be number');
			if ('high' in c2 && typeof c2.high !== 'number') throw new Error('online.high must be number');
			if ('low' in c2 && typeof c2.low !== 'number') throw new Error('online.low must be number');
			if ('volume' in c2 && typeof c2.volume !== 'number') throw new Error('online.volume must be number');
		}
	}

	console.log('✅ Stock Screener make*Node test passed');
	return 0;
}

main();
