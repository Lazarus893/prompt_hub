const { load } = require('@alva/secret');
const key = load('X-ARRAY-KEY');
const getOptionListRef = {
	id: "@arrays/stock/option/screener/getOptionList",
	module_name: "@arrays/stock/option/screener",
	module_display_name: "Options Screener",
	sdk_name: "getOptionList",
	sdk_display_name: "Options Chain & Greeks",
	source_name: "Polygon",
	source: "https://polygon.io/docs/rest/options/contracts/all-contracts",
};

// Base description (concise summary) derived from doc for getOptionList
const getOptionListBaseDesc = "List option contracts for a stock with filters and market data";

// Helper to create ref with dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

// Dynamic call description builder for getOptionList based on actual params
function buildGetOptionListCallDescription(actualParams = {}) {
    const parts = [getOptionListBaseDesc];

    // Context: specific underlying or option ticker
    if (actualParams.stock_ticker) {
        parts.push(`for ${actualParams.stock_ticker}`);
    }
    if (actualParams.option_ticker) {
        parts.push(`(option ${actualParams.option_ticker})`);
    }

    // Filters
    const filters = [];
    if (actualParams.contract_type) {
        filters.push(`Type: ${actualParams.contract_type}`);
    }

    // Expiration window (seconds since epoch per doc)
    if (actualParams.start_expiration_date && actualParams.end_expiration_date) {
        filters.push(`Exp: ${actualParams.start_expiration_date} to ${actualParams.end_expiration_date}`);
    } else if (actualParams.start_expiration_date) {
        filters.push(`Exp from: ${actualParams.start_expiration_date}`);
    } else if (actualParams.end_expiration_date) {
        filters.push(`Exp to: ${actualParams.end_expiration_date}`);
    }

    // Strike price range
    const hasMinStrike = actualParams.min_strike_price !== undefined && actualParams.min_strike_price !== null;
    const hasMaxStrike = actualParams.max_strike_price !== undefined && actualParams.max_strike_price !== null;
    if (hasMinStrike && hasMaxStrike) {
        filters.push(`Strike: ${actualParams.min_strike_price}-${actualParams.max_strike_price}`);
    } else if (hasMinStrike) {
        filters.push(`Min strike: ${actualParams.min_strike_price}`);
    } else if (hasMaxStrike) {
        filters.push(`Max strike: ${actualParams.max_strike_price}`);
    }

    // Pagination & size
    if (actualParams.limit !== undefined && actualParams.limit !== null) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (actualParams.cursor) {
        filters.push(`Cursor: ${actualParams.cursor}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function getOptionList(params) {
	// Parameter validation
	if (!params || typeof params !== 'object') {
		throw new Error('Invalid parameters: params must be an object');
	}

	const stock_ticker = params.stock_ticker;
	if (!stock_ticker || typeof stock_ticker !== 'string' || stock_ticker.trim() === '') {
		throw new Error('Invalid parameters: stock_ticker is required and must be a non-empty string');
	}

	// Validate stock_ticker is uppercase
	if (stock_ticker !== stock_ticker.toUpperCase()) {
		throw new Error('Invalid parameters: stock_ticker must be uppercase');
	}

	// Validate contract_type if provided
	if (params.contract_type !== undefined && params.contract_type !== null) {
		const validTypes = ['call', 'put'];
		if (!validTypes.includes(params.contract_type)) {
			throw new Error(`Invalid contract_type: must be "call" or "put", got "${params.contract_type}"`);
		}
	}

	// Validate strike price range if both provided
	if (params.min_strike_price !== undefined && params.max_strike_price !== undefined) {
		const min = Number(params.min_strike_price);
		const max = Number(params.max_strike_price);
		if (Number.isFinite(min) && Number.isFinite(max) && min > max) {
			throw new Error('Invalid strike price range: min_strike_price must be <= max_strike_price');
		}
	}

	const { syncFetch: fetch } = require('net/http');
	const baseUrl = 'https://data-gateway.prd.space.id/api/v1/stocks/options/list';
	const keyValuePairs = Object.keys(params || {}).map((key) => {
		const value = params[key];
		return encodeURIComponent(key) + '=' + encodeURIComponent(value);
	});
	const queryString = keyValuePairs.join('&');
	const fullUrl = `${baseUrl}?${queryString}`;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'X-API-Key': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

function nsToMs(ns) {
	if (ns == null) return undefined;
	// API provides nanoseconds; convert to milliseconds
	return Math.floor(Number(ns) / 1e6);
}

function makeOptionListNode(params) {
	return {
		inputs: {
			option_list_raw: () => getOptionList(params),
		},
		outputs: {
			option_list: {
				name: 'option_list',
				description: 'Option List snapshot (single record, nested options array)',
				fields: [
					{ name: 'date', type: 'number', description: 'snapshot time ms' },
					{
						name: 'options',
						type: 'array',
						description: 'options list',
						fields: [
							{ name: 'ticker', type: 'string', description: 'Option ticker' },
							{ name: 'contract_type', type: 'string', description: 'Contract type' },
							{ name: 'exercise_style', type: 'string', description: 'Exercise style' },
							{ name: 'expiration_date', type: 'string', description: 'Expiration date' },
							{ name: 'shares_per_contract', type: 'number', description: 'Shares per contract' },
							{ name: 'strike_price', type: 'number', description: 'Strike price' },
							{ name: 'break_even_price', type: 'number', description: 'Break even price' },
							{ name: 'fmv', type: 'number', description: 'Fair market value' },
							{ name: 'implied_volatility', type: 'number', description: 'Implied volatility' },
							{ name: 'open_interest', type: 'number', description: 'Open interest' },
							{ name: 'delta', type: 'number', description: 'Delta' },
							{ name: 'gamma', type: 'number', description: 'Gamma' },
							{ name: 'theta', type: 'number', description: 'Theta' },
							{ name: 'vega', type: 'number', description: 'Vega' },
							{ name: 'change', type: 'number', description: 'Price change' },
							{ name: 'change_percent', type: 'number', description: 'Price change %' },
							{ name: 'close', type: 'number', description: 'Close price' },
							{ name: 'high', type: 'number', description: 'High price' },
							{ name: 'low', type: 'number', description: 'Low price' },
							{ name: 'open', type: 'number', description: 'Open price' },
							{ name: 'previous_close', type: 'number', description: 'Previous close' },
							{ name: 'last_updated', type: 'number', description: 'Last updated time ms' },
							{ name: 'underlying_ticker', type: 'string', description: 'Underlying asset ticker' },
							{ name: 'underlying_price', type: 'number', description: 'Underlying asset price' },
							{ name: 'change_to_break_even', type: 'number', description: 'Change to break even' },
							{ name: 'timeframe', type: 'string', description: 'Timeframe' },
							{ name: 'underlying_last_updated', type: 'number', description: 'Underlying last updated time ms' },
						],
					},
				],
				ref: createReferenceWithTitle(getOptionListRef, params, buildGetOptionListCallDescription),
			},
		},
		run: (inputs) => {
			const raw = inputs.option_list_raw;
			const options = raw?.response?.results;
			const arr = Array.isArray(options)
				? options.map((o) => ({
					ticker: o?.details?.ticker,
					contract_type: o?.details?.contract_type,
					exercise_style: o?.details?.exercise_style,
					expiration_date: o?.details?.expiration_date,
					shares_per_contract: o?.details?.shares_per_contract,
					strike_price: o?.details?.strike_price,
					break_even_price: o?.break_even_price,
					fmv: o?.fmv,
					implied_volatility: o?.implied_volatility,
					open_interest: o?.open_interest,
					delta: o?.greeks?.delta,
					gamma: o?.greeks?.gamma,
					theta: o?.greeks?.theta,
					vega: o?.greeks?.vega,
					change: o?.daily_data?.change,
					change_percent: o?.daily_data?.change_percent,
					close: o?.daily_data?.close,
					high: o?.daily_data?.high,
					low: o?.daily_data?.low,
					open: o?.daily_data?.open,
					previous_close: o?.daily_data?.previous_close,
					last_updated: nsToMs(o?.daily_data?.last_updated),
					underlying_ticker: o?.underlying_asset?.ticker,
					underlying_price: o?.underlying_asset?.price,
					change_to_break_even: o?.underlying_asset?.change_to_break_even,
					timeframe: o?.underlying_asset?.timeframe,
					underlying_last_updated: nsToMs(o?.underlying_asset?.last_updated),
				}))
				: [];
			return {
				option_list: [
					{
						date: Date.now(),
						options: arr,
					},
				],
			};
		},
	};
}

// Unified accessor for all *Ref objects in this module
function getRefs() {
	return [getOptionListRef];
}

module.exports = {
	getOptionList,
	makeOptionListNode,
	getRefs,
};
