function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
}

function testGetOptionList() {
    console.log('\n=== Testing getOptionList (Direct API) ===');

    const { getOptionList } = require('@arrays/stock/option/screener:v1.0.0');

    let totalTests = 0;
    let passedTests = 0;

    function runTest(name, fn) {
        totalTests++;
        try {
            fn();
            console.log(`✅ ${name}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${name}: ${e.message}`);
        }
    }

    function verifyResponseShape(res, allowEmpty = true) {
        assert(res && typeof res === 'object', 'Response should be an object');
        assert(res.response && typeof res.response === 'object', 'Response should have response object');
        assert(Array.isArray(res.response.results), 'response.results should be an array');
        if (!allowEmpty) {
            assert(res.response.results.length > 0, 'Expected non-empty results');
        }
        if (res.pagination) {
            assert(typeof res.pagination === 'object', 'pagination should be an object');
            if (res.pagination.has_more !== undefined) {
                assert(typeof res.pagination.has_more === 'boolean', 'pagination.has_more should be boolean');
            }
            if (res.pagination.next_cursor !== undefined) {
                assert(typeof res.pagination.next_cursor === 'string' || res.pagination.next_cursor === null, 'pagination.next_cursor should be string or null');
            }
        }
    }

    // Parameters helpers
    const nowSec = Math.floor(Date.now() / 1000);
    const in30Days = nowSec + 30 * 24 * 3600;
    const in1Year = nowSec + 365 * 24 * 3600;

    // --- Happy Path ---
    runTest('Basic happy path with AAPL limit=5', () => {
        const res = getOptionList({ stock_ticker: 'AAPL', limit: 5 });
        verifyResponseShape(res);
        assert(res.response.results.length <= 5, 'Should respect limit <= 5');
    });

    runTest('contract_type = call', () => {
        const res = getOptionList({ stock_ticker: 'AAPL', contract_type: 'call', limit: 5 });
        verifyResponseShape(res);
        for (const r of res.response.results) {
            if (r && r.details) {
                assert(r.details.contract_type === 'call', 'Each result should be call');
            }
        }
    });

    runTest('contract_type = put', () => {
        const res = getOptionList({ stock_ticker: 'AAPL', contract_type: 'put', limit: 5 });
        verifyResponseShape(res);
        for (const r of res.response.results) {
            if (r && r.details) {
                assert(r.details.contract_type === 'put', 'Each result should be put');
            }
        }
    });

    // --- Boundary Value Analysis ---
    runTest('limit minimum = 1', () => {
        const res = getOptionList({ stock_ticker: 'AAPL', limit: 1 });
        verifyResponseShape(res);
        assert(res.response.results.length <= 1, 'Should respect limit <= 1');
    });

    runTest('limit maximum = 250', () => {
        const res = getOptionList({ stock_ticker: 'AAPL', limit: 250 });
        verifyResponseShape(res);
        assert(res.response.results.length <= 250, 'Should respect limit <= 250');
    });

    runTest('expiration window near-term (now..+30d)', () => {
        const res = getOptionList({
            stock_ticker: 'AAPL',
            start_expiration_date: nowSec,
            end_expiration_date: in30Days,
            limit: 10,
        });
        verifyResponseShape(res);
        for (const r of res.response.results) {
            if (r && r.details && r.details.expiration_date) {
                const ts = Math.floor(new Date(r.details.expiration_date + 'T00:00:00Z').getTime() / 1000);
                assert(ts >= nowSec && ts <= in30Days, 'expiration_date should be within provided range');
            }
        }
    });

    runTest('expiration window future (now..+1y)', () => {
        const res = getOptionList({
            stock_ticker: 'AAPL',
            start_expiration_date: nowSec,
            end_expiration_date: in1Year,
            limit: 10,
        });
        verifyResponseShape(res);
    });

    runTest('strike price range [100, 500]', () => {
        const res = getOptionList({
            stock_ticker: 'AAPL',
            min_strike_price: 100,
            max_strike_price: 500,
            limit: 10,
        });
        verifyResponseShape(res);
        for (const r of res.response.results) {
            if (r && r.details) {
                const sp = r.details.strike_price;
                assert(typeof sp === 'number', 'strike_price should be number');
                assert(sp >= 100 && sp <= 500, 'strike_price should be within [100, 500]');
            }
        }
    });

    // --- Pagination ---
    runTest('pagination using next_cursor when available', () => {
        const first = getOptionList({ stock_ticker: 'AAPL', limit: 2 });
        verifyResponseShape(first);
        if (first.pagination && first.pagination.has_more && first.pagination.next_cursor) {
            const second = getOptionList({ stock_ticker: 'AAPL', limit: 2, cursor: first.pagination.next_cursor });
            verifyResponseShape(second);
        }
    });

    // --- Special Values & Error Handling ---
    runTest('optional parameters omitted (undefined)', () => {
        const res = getOptionList({ stock_ticker: 'AAPL', limit: 5 });
        verifyResponseShape(res);
    });

    runTest('lowercase stock_ticker normalization or error', () => {
        try {
            const res = getOptionList({ stock_ticker: 'aapl', limit: 5 });
            verifyResponseShape(res);
        } catch (e) {
            // Acceptable: API enforces uppercase only
            assert(e.message.includes('uppercase') || e.message.toLowerCase().includes('invalid') || e.message.toLowerCase().includes('error'), 'Should either work or report validation error');
        }
    });

    runTest('invalid contract_type should error', () => {
        try {
            getOptionList({ stock_ticker: 'AAPL', contract_type: 'invalid', limit: 5 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('call') || e.message.includes('put') || e.message.toLowerCase().includes('invalid'), 'Should handle invalid contract_type');
        }
    });

    runTest('empty stock_ticker should error', () => {
        try {
            getOptionList({ stock_ticker: '', limit: 5 });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.toLowerCase().includes('stock') || e.message.toLowerCase().includes('ticker') || e.message.toLowerCase().includes('invalid'), 'Should handle empty stock_ticker');
        }
    });

    runTest('reversed strike bounds (min > max)', () => {
        try {
            const res = getOptionList({ stock_ticker: 'AAPL', min_strike_price: 400, max_strike_price: 100, limit: 5 });
            // If no error, results should be empty or API may auto-swap; accept empty
            verifyResponseShape(res);
            assert(res.response.results.length === 0 || res.response.results.every(r => r.details.strike_price >= 100 && r.details.strike_price <= 400), 'Should return empty or corrected range');
        } catch (e) {
            // Accept error path as valid behavior
            assert(e.message.toLowerCase().includes('strike') || e.message.toLowerCase().includes('range') || e.message.toLowerCase().includes('invalid'), 'Should handle reversed strike bounds');
        }
    });

    // Print test summary
    console.log('\n=== getOptionList Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    if (passedTests !== totalTests) {
        throw new Error('Some getOptionList direct tests failed');
    }
}

function main() {
    // Run direct API tests focusing on enum coverage and BVA
    testGetOptionList();

    // Existing Graph-based tests for makeOptionListNode
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeOptionListNode } = require('@arrays/stock/option/screener:v1.0.0');

    // Offline test with sample data (format validation)
    const nodeCfg = makeOptionListNode({ stock_ticker: 'AAPL', limit: 10 });
    // Override input to avoid network; match getOptionList response shape
    nodeCfg.inputs.option_list_raw = () => ({
        success: true,
        response: {
            results: [
                {
                    details: {
                        ticker: 'AAPL250117C00180000',
                        contract_type: 'call',
                        exercise_style: 'american',
                        expiration_date: '2025-01-17',
                        shares_per_contract: 100,
                        strike_price: 180,
                    },
                    break_even_price: 5.2,
                    fmv: 5.15,
                    implied_volatility: 0.25,
                    open_interest: 1234,
                    greeks: { delta: 0.55, gamma: 0.02, theta: -0.01, vega: 0.08 },
                    daily_data: {
                        change: 0.1,
                        change_percent: 0.019,
                        close: 5.2,
                        high: 5.3,
                        low: 5.0,
                        open: 5.1,
                        previous_close: 5.1,
                        last_updated: 1723012400000000000,
                    },
                    underlying_asset: {
                        ticker: 'AAPL',
                        price: 182.35,
                        change_to_break_even: -2.35,
                        timeframe: '1d',
                        last_updated: 1723012405000000000,
                    },
                },
                {
                    details: {
                        ticker: 'AAPL250117P00180000',
                        contract_type: 'put',
                        exercise_style: 'american',
                        expiration_date: '2025-01-17',
                        shares_per_contract: 100,
                        strike_price: 180,
                    },
                    break_even_price: 5.7,
                    fmv: 5.6,
                    implied_volatility: 0.27,
                    open_interest: 980,
                    greeks: { delta: -0.45, gamma: 0.018, theta: -0.012, vega: 0.09 },
                    daily_data: {
                        change: -0.05,
                        change_percent: -0.0088,
                        close: 5.6,
                        high: 5.8,
                        low: 5.4,
                        open: 5.65,
                        previous_close: 5.65,
                        last_updated: 1723016000000000000,
                    },
                    underlying_asset: {
                        ticker: 'AAPL',
                        price: 181.85,
                        change_to_break_even: 3.15,
                        timeframe: '1d',
                        last_updated: 1723016005000000000,
                    },
                },
            ],
        },
    });

    const g = new Graph(jagentId);
    g.addNode('options_list_offline', nodeCfg);
    g.run();

    // Validate materialized snapshot
    const ts = new TimeSeries(new TimeSeriesUri(jagentId, 'options_list_offline', 'option_list', { last: '10' }), g.store);
    ts.init();
    if (!Array.isArray(ts.data) || ts.data.length < 1) {
        throw new Error('Expected at least 1 option_list record');
    }
    const latest = ts.data[0];
    if (typeof latest.date !== 'number') throw new Error('date must be number (ms)');
    if (!Array.isArray(latest.options)) throw new Error('options must be array');
    if (latest.options.length > 0) {
        const o = latest.options[0];
        if (typeof o.ticker !== 'string') throw new Error('ticker must be string');
        if (typeof o.last_updated !== 'number') throw new Error('last_updated must be ms number');
    }

    // Validate refs for option_list
    const refsOptionList = g.getRefsForOutput('options_list_offline', 'option_list');
    if (refsOptionList.length > 0) {
        const ref = refsOptionList[0];
        const expected = {
            id: '@arrays/stock/option/screener/getOptionList',
            module_name: '@arrays/stock/option/screener',
            module_display_name: 'Options Screener',
            sdk_name: 'getOptionList',
            sdk_display_name: 'Options Chain & Greeks',
            source_name: 'Polygon',
            source: 'https://polygon.io/docs/rest/options/contracts/all-contracts',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for option_list');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for option_list');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for option_list');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for option_list');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for option_list');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for option_list');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for option_list');
        console.log('✓ option_list refs validated');
    } else {
        throw new Error('Assertion failed: refsOptionList array is empty.');
    }

    // Online smoke test (real gateway)
    const nodeCfgOnline = makeOptionListNode({ stock_ticker: 'AAPL', limit: 10 });
    const g2 = new Graph(jagentId);
    g2.addNode('options_list_online', nodeCfgOnline);
    g2.run();
    const ts2 = new TimeSeries(new TimeSeriesUri(jagentId, 'options_list_online', 'option_list', { last: '10' }), g2.store);
    ts2.init();
    if (!Array.isArray(ts2.data)) throw new Error('online data must be an array');
    if (ts2.data.length > 0) {
        const r = ts2.data[0];
        if (typeof r.date !== 'number') throw new Error('online.date must be number (ms)');
        if (!Array.isArray(r.options)) throw new Error('online.options must be array');
    }

    console.log('✅ Option Screener make*Node test passed');
    return 0;
}

main();
