# @test/suite:v1.0.0

A comprehensive Jest-like test suite library designed for pure V8 environments. Provides familiar testing APIs without Node.js dependencies.

## Features

- **Familiar API**: Similar to Jest with `describe`, `it`, `expect`, and matchers
- **Test Organization**: Nested test suites with `describe` blocks
- **Lifecycle Hooks**: `beforeAll`, `afterAll`, `beforeEach`, `afterEach`
- **Rich Matchers**: 25+ built-in matchers for comprehensive assertions
- **Async Support**: Full support for async/await and promises
- **Test Filtering**: `.only` and `.skip` for focused testing
- **Detailed Reporting**: Clear output with test results and timing
- **Pure V8**: No Node.js dependencies, runs in any V8 environment

## Quick Start

```javascript
const { describe, it, expect, runTests } = require('@test/suite:v1.0.0');

describe('Basic Math', () => {
	it('should add numbers', () => {
		expect(1 + 1).toBe(2);
	});

	it('should multiply numbers', () => {
		expect(2 * 3).toBe(6);
	});
});

// Run all tests
await runTests();
```

## API Reference

### Test Organization

#### `describe(name, fn)`

Creates a test suite. Test suites can be nested.

```javascript
describe('Array', () => {
	describe('push', () => {
		it('should add element', () => {
			const arr = [];
			arr.push(1);
			expect(arr).toHaveLength(1);
		});
	});
});
```

#### `describe.skip(name, fn)`

Skips an entire test suite.

```javascript
describe.skip('Incomplete feature', () => {
	// These tests won't run
});
```

#### `describe.only(name, fn)`

Runs only this test suite and its tests.

```javascript
describe.only('Debug this', () => {
	// Only these tests will run
});
```

### Test Cases

#### `it(name, fn)` or `test(name, fn)`

Defines a test case. Use either `it` or `test` - they're identical.

```javascript
it('should work correctly', () => {
	expect(true).toBeTruthy();
});

test('does the same thing', () => {
	expect(true).toBeTruthy();
});
```

#### `it.skip(name, fn)`

Skips a specific test.

```javascript
it.skip('not ready yet', () => {
	// This test won't run
});
```

#### `it.only(name, fn)`

Runs only this test.

```javascript
it.only('debug this test', () => {
	// Only this test will run
});
```

### Async Tests

Tests automatically handle promises and async functions:

```javascript
it('should handle async operations', async () => {
	const result = await fetchData();
	expect(result).toBeDefined();
});

it('should handle promises', () => {
	return getData().then((data) => {
		expect(data).toHaveProperty('id');
	});
});
```

### Lifecycle Hooks

#### `beforeAll(fn)`

Runs once before all tests in the suite.

```javascript
describe('Database tests', () => {
	beforeAll(async () => {
		await connectDatabase();
	});

	// tests...
});
```

#### `afterAll(fn)`

Runs once after all tests in the suite.

```javascript
describe('Database tests', () => {
	afterAll(async () => {
		await closeDatabase();
	});

	// tests...
});
```

#### `beforeEach(fn)`

Runs before each test in the suite.

```javascript
describe('Array operations', () => {
	let arr;

	beforeEach(() => {
		arr = [1, 2, 3];
	});

	it('should start with 3 elements', () => {
		expect(arr).toHaveLength(3);
	});
});
```

#### `afterEach(fn)`

Runs after each test in the suite.

```javascript
describe('Cleanup tests', () => {
	afterEach(() => {
		// Clean up after each test
	});

	// tests...
});
```

### Expectations

#### `expect(actual)`

Creates an expectation for the actual value.

```javascript
expect(value).toBe(expected);
expect(value).not.toBe(unexpected);
```

### Matchers

#### Equality Matchers

##### `toBe(expected)`

Strict equality using `Object.is()`. Best for primitives.

```javascript
expect(1).toBe(1);
expect('hello').toBe('hello');
expect(true).toBe(true);
```

##### `toEqual(expected)`

Deep equality for objects and arrays.

```javascript
expect({ a: 1, b: 2 }).toEqual({ a: 1, b: 2 });
expect([1, 2, 3]).toEqual([1, 2, 3]);
```

##### `toStrictEqual(expected)`

Strict deep equality (checks prototypes too).

```javascript
expect(new Date('2024-01-01')).toStrictEqual(new Date('2024-01-01'));
```

#### Truthiness Matchers

##### `toBeTruthy()`

Passes if value is truthy.

```javascript
expect(true).toBeTruthy();
expect(1).toBeTruthy();
expect('hello').toBeTruthy();
expect([]).toBeTruthy();
```

##### `toBeFalsy()`

Passes if value is falsy.

```javascript
expect(false).toBeFalsy();
expect(0).toBeFalsy();
expect('').toBeFalsy();
expect(null).toBeFalsy();
```

##### `toBeNull()`

Checks if value is exactly `null`.

```javascript
expect(null).toBeNull();
```

##### `toBeUndefined()`

Checks if value is exactly `undefined`.

```javascript
expect(undefined).toBeUndefined();
expect(obj.missingProp).toBeUndefined();
```

##### `toBeDefined()`

Checks if value is not `undefined`.

```javascript
expect(0).toBeDefined();
expect('').toBeDefined();
expect(null).toBeDefined();
```

##### `toBeNaN()`

Checks if value is `NaN`.

```javascript
expect(NaN).toBeNaN();
expect(0 / 0).toBeNaN();
```

#### Numeric Matchers

##### `toBeGreaterThan(expected)`

```javascript
expect(10).toBeGreaterThan(5);
```

##### `toBeGreaterThanOrEqual(expected)`

```javascript
expect(10).toBeGreaterThanOrEqual(10);
expect(10).toBeGreaterThanOrEqual(5);
```

##### `toBeLessThan(expected)`

```javascript
expect(5).toBeLessThan(10);
```

##### `toBeLessThanOrEqual(expected)`

```javascript
expect(5).toBeLessThanOrEqual(5);
expect(5).toBeLessThanOrEqual(10);
```

##### `toBeCloseTo(expected, precision = 2)`

For floating point comparisons.

```javascript
expect(0.1 + 0.2).toBeCloseTo(0.3);
expect(0.1 + 0.2).toBeCloseTo(0.3, 5); // More precision
```

#### String/Array/Object Matchers

##### `toContain(item)`

Works with strings, arrays, and objects.

```javascript
expect('hello world').toContain('world');
expect([1, 2, 3]).toContain(2);
expect({ a: 1, b: 2 }).toContain('a'); // checks for key
```

##### `toContainEqual(item)`

Deep equality check for array elements.

```javascript
expect([{ id: 1 }, { id: 2 }]).toContainEqual({ id: 1 });
```

##### `toHaveLength(expected)`

Checks the length property.

```javascript
expect([1, 2, 3]).toHaveLength(3);
expect('hello').toHaveLength(5);
```

##### `toHaveProperty(path, value?)`

Checks if object has a property, optionally with a specific value.

```javascript
expect({ a: 1, b: 2 }).toHaveProperty('a');
expect({ a: 1, b: 2 }).toHaveProperty('a', 1);
expect({ a: { b: { c: 3 } } }).toHaveProperty('a.b.c');
expect({ a: { b: { c: 3 } } }).toHaveProperty('a.b.c', 3);
```

##### `toMatch(pattern)`

Tests against a regular expression.

```javascript
expect('hello world').toMatch(/world/);
expect('test@example.com').toMatch(/^\w+@\w+\.\w+$/);
```

##### `toMatchObject(expected)`

Checks if object contains expected properties (partial match).

```javascript
expect({ a: 1, b: 2, c: 3 }).toMatchObject({ a: 1, b: 2 });
```

#### Error Matchers

##### `toThrow(expectedError?)`

Checks if function throws an error.

```javascript
expect(() => {
	throw new Error('oops');
}).toThrow();

expect(() => {
	throw new Error('oops');
}).toThrow('oops');

expect(() => {
	throw new Error('oops');
}).toThrow(/oops/);

expect(() => {
	throw new TypeError('wrong type');
}).toThrow(TypeError);
```

#### Type Matchers

##### `toBeInstanceOf(constructor)`

Checks if value is an instance of a constructor.

```javascript
expect(new Date()).toBeInstanceOf(Date);
expect([]).toBeInstanceOf(Array);
expect({}).toBeInstanceOf(Object);
```

### Negation

Use `.not` to negate any matcher:

```javascript
expect(value).not.toBe(unexpected);
expect(array).not.toContain(item);
expect(() => fn()).not.toThrow();
```

### Running Tests

#### `runTests(options?)`

Runs all defined tests and returns results.

```javascript
const results = await runTests();

// With options
const results = await runTests({
  verbose: true,    // Show detailed output (default: true)
  bail: false,      // Stop on first failure (default: false)
  timeout: 5000     // Timeout in ms (default: 5000)
});

// Results structure
{
  results: [...],           // Array of TestResult objects
  summary: {
    total: 10,
    passed: 9,
    failed: 1,
    skipped: 0,
    duration: 1234
  },
  totalDuration: 1234
}
```

### Configuration

#### `configure(options)`

Configure the test runner.

```javascript
const { configure } = require('@test/suite:v1.0.0');

configure({
	verbose: false, // Disable verbose output
	bail: true, // Stop on first failure
	timeout: 10000, // 10 second timeout
});
```

### Utilities

#### `resetTests()`

Clears all registered tests and suites. Useful for testing the test framework itself.

```javascript
const { resetTests } = require('@test/suite:v1.0.0');

resetTests();
```

## Complete Example

```javascript
const { describe, it, expect, beforeAll, afterAll, beforeEach, afterEach, runTests } = require('@test/suite:v1.0.0');

describe('Array operations', () => {
	let arr;

	beforeAll(() => {
		console.log('Starting array tests');
	});

	afterAll(() => {
		console.log('Finished array tests');
	});

	beforeEach(() => {
		arr = [1, 2, 3];
	});

	afterEach(() => {
		arr = null;
	});

	describe('push', () => {
		it('should add element to end', () => {
			arr.push(4);
			expect(arr).toHaveLength(4);
			expect(arr[3]).toBe(4);
		});

		it('should return new length', () => {
			const length = arr.push(4);
			expect(length).toBe(4);
		});
	});

	describe('pop', () => {
		it('should remove last element', () => {
			const last = arr.pop();
			expect(last).toBe(3);
			expect(arr).toHaveLength(2);
		});

		it('should return undefined for empty array', () => {
			arr = [];
			expect(arr.pop()).toBeUndefined();
		});
	});

	describe('map', () => {
		it('should transform elements', () => {
			const doubled = arr.map((x) => x * 2);
			expect(doubled).toEqual([2, 4, 6]);
		});
	});

	describe('filter', () => {
		it('should keep only matching elements', () => {
			const evens = arr.filter((x) => x % 2 === 0);
			expect(evens).toEqual([2]);
		});
	});

	describe('async operations', () => {
		it('should handle async functions', async () => {
			const result = await Promise.resolve(arr);
			expect(result).toEqual([1, 2, 3]);
		});
	});
});

describe('Object operations', () => {
	it('should check properties', () => {
		const obj = { name: 'John', age: 30 };

		expect(obj).toHaveProperty('name');
		expect(obj).toHaveProperty('name', 'John');
		expect(obj).toMatchObject({ name: 'John' });
	});

	it('should compare objects deeply', () => {
		const obj1 = { a: 1, b: { c: 2 } };
		const obj2 = { a: 1, b: { c: 2 } };

		expect(obj1).toEqual(obj2);
	});
});

describe('Error handling', () => {
	it('should catch errors', () => {
		expect(() => {
			throw new Error('test error');
		}).toThrow('test error');
	});

	it('should not throw', () => {
		expect(() => {
			return 'success';
		}).not.toThrow();
	});
});

// Run all tests
await runTests();
```

## Output Example

```
====================================
TEST RESULTS
====================================

Array operations > push
  ✓ should add element to end (5ms)
  ✓ should return new length (2ms)

Array operations > pop
  ✓ should remove last element (3ms)
  ✓ should return undefined for empty array (1ms)

Array operations > map
  ✓ should transform elements (4ms)

Array operations > filter
  ✓ should keep only matching elements (3ms)

Object operations
  ✓ should check properties (2ms)
  ✓ should compare objects deeply (2ms)

Error handling
  ✓ should catch errors (1ms)
  ✓ should not throw (1ms)

====================================
SUMMARY
====================================
Total:   10
Passed:  10 ✓
Failed:  0 ✗
Skipped: 0 ⊘
Duration: 24ms
====================================

✅ Tests PASSED
```

## Best Practices

1. **Organize tests logically**: Use nested `describe` blocks to group related tests
2. **Use descriptive names**: Test names should clearly describe what they're testing
3. **Test one thing per test**: Keep tests focused and simple
4. **Use appropriate matchers**: Choose the most specific matcher for better error messages
5. **Clean up after tests**: Use `afterEach` and `afterAll` to clean up resources
6. **Avoid test interdependence**: Tests should not depend on each other's state
7. **Use `.only` for debugging**: Focus on specific tests during development
8. **Handle async properly**: Always return promises or use async/await

## Limitations

- No mocking/spying utilities (can be added in future versions)
- No snapshot testing
- No code coverage reporting
- Timeouts are enforced but may not interrupt truly blocking code
- No parallel test execution (tests run sequentially)

## Version

Current version: **v1.0.0**

## License

Internal use only - part of the Alva SDK Hub.
