/**
 * @fileoverview A Jest-like test suite library for pure V8 environments
 * @module @test/suite
 * @version v1.0.0
 *
 * This library provides a familiar testing interface similar to Jest,
 * but designed to run in pure V8 without Node.js dependencies.
 *
 * @example
 * const { describe, it, expect, runTests } = require('@test/suite:v1.0.0');
 *
 * describe('Math operations', () => {
 *   it('should add numbers correctly', () => {
 *     expect(1 + 1).toBe(2);
 *   });
 *
 *   it('should multiply numbers correctly', () => {
 *     expect(2 * 3).toBe(6);
 *   });
 * });
 *
 * runTests();
 */

// ============================================================================
// Core Test State Management
// ============================================================================

const testState = {
	suites: [],
	currentSuite: null,
	results: {
		total: 0,
		passed: 0,
		failed: 0,
		skipped: 0,
		duration: 0,
	},
	config: {
		verbose: true,
		bail: false, // Stop on first failure
		timeout: 5000, // Default timeout for async tests
	},
};

// ============================================================================
// Test Suite and Test Case Classes
// ============================================================================

class TestSuite {
	constructor(name, fn) {
		this.name = name;
		this.fn = fn;
		this.tests = [];
		this.hooks = {
			beforeAll: [],
			afterAll: [],
			beforeEach: [],
			afterEach: [],
		};
		this.parent = null;
		this.children = [];
		this.skipped = false;
		this.only = false;
	}

	addTest(test) {
		this.tests.push(test);
	}

	addHook(type, fn) {
		if (this.hooks[type]) {
			this.hooks[type].push(fn);
		}
	}

	getFullName() {
		const names = [this.name];
		let current = this.parent;
		while (current) {
			names.unshift(current.name);
			current = current.parent;
		}
		return names.join(' > ');
	}
}

class TestCase {
	constructor(name, fn, suite) {
		this.name = name;
		this.fn = fn;
		this.suite = suite;
		this.skipped = false;
		this.only = false;
		this.result = null;
	}

	getFullName() {
		return `${this.suite.getFullName()} > ${this.name}`;
	}
}

class TestResult {
	constructor(test, passed, error = null, duration = 0) {
		this.test = test;
		this.passed = passed;
		this.error = error;
		this.duration = duration;
		this.fullName = test.getFullName();
	}
}

// ============================================================================
// Expectation and Matcher Classes
// ============================================================================

class Expectation {
	constructor(actual) {
		this.actual = actual;
		this.isNot = false;
	}

	get not() {
		const clone = Object.create(Object.getPrototypeOf(this));
		clone.actual = this.actual;
		clone.isNot = !this.isNot;
		return clone;
	}

	_assert(condition, message, negatedMessage) {
		const shouldPass = this.isNot ? !condition : condition;
		if (!shouldPass) {
			const finalMessage = this.isNot ? negatedMessage : message;
			throw new AssertionError(finalMessage);
		}
	}

	toBe(expected) {
		const passed = Object.is(this.actual, expected);
		this._assert(passed, `Expected ${stringify(this.actual)} to be ${stringify(expected)}`, `Expected ${stringify(this.actual)} not to be ${stringify(expected)}`);
	}

	toEqual(expected) {
		const passed = deepEqual(this.actual, expected);
		this._assert(passed, `Expected ${stringify(this.actual)} to equal ${stringify(expected)}`, `Expected ${stringify(this.actual)} not to equal ${stringify(expected)}`);
	}

	toStrictEqual(expected) {
		const passed = strictEqual(this.actual, expected);
		this._assert(passed, `Expected ${stringify(this.actual)} to strictly equal ${stringify(expected)}`, `Expected ${stringify(this.actual)} not to strictly equal ${stringify(expected)}`);
	}

	toBeTruthy() {
		this._assert(!!this.actual, `Expected ${stringify(this.actual)} to be truthy`, `Expected ${stringify(this.actual)} not to be truthy`);
	}

	toBeFalsy() {
		this._assert(!this.actual, `Expected ${stringify(this.actual)} to be falsy`, `Expected ${stringify(this.actual)} not to be falsy`);
	}

	toBeNull() {
		this._assert(this.actual === null, `Expected ${stringify(this.actual)} to be null`, `Expected ${stringify(this.actual)} not to be null`);
	}

	toBeUndefined() {
		this._assert(this.actual === undefined, `Expected ${stringify(this.actual)} to be undefined`, `Expected ${stringify(this.actual)} not to be undefined`);
	}

	toBeDefined() {
		this._assert(this.actual !== undefined, `Expected value to be defined`, `Expected ${stringify(this.actual)} not to be defined`);
	}

	toBeNaN() {
		this._assert(typeof this.actual === 'number' && isNaN(this.actual), `Expected ${stringify(this.actual)} to be NaN`, `Expected ${stringify(this.actual)} not to be NaN`);
	}

	toBeGreaterThan(expected) {
		this._assert(
			this.actual > expected,
			`Expected ${stringify(this.actual)} to be greater than ${stringify(expected)}`,
			`Expected ${stringify(this.actual)} not to be greater than ${stringify(expected)}`
		);
	}

	toBeGreaterThanOrEqual(expected) {
		this._assert(
			this.actual >= expected,
			`Expected ${stringify(this.actual)} to be greater than or equal to ${stringify(expected)}`,
			`Expected ${stringify(this.actual)} not to be greater than or equal to ${stringify(expected)}`
		);
	}

	toBeLessThan(expected) {
		this._assert(
			this.actual < expected,
			`Expected ${stringify(this.actual)} to be less than ${stringify(expected)}`,
			`Expected ${stringify(this.actual)} not to be less than ${stringify(expected)}`
		);
	}

	toBeLessThanOrEqual(expected) {
		this._assert(
			this.actual <= expected,
			`Expected ${stringify(this.actual)} to be less than or equal to ${stringify(expected)}`,
			`Expected ${stringify(this.actual)} not to be less than or equal to ${stringify(expected)}`
		);
	}

	toBeCloseTo(expected, precision = 2) {
		const pow = Math.pow(10, precision);
		const delta = Math.abs(expected - this.actual);
		const maxDelta = Math.pow(10, -precision) / 2;
		this._assert(
			delta < maxDelta,
			`Expected ${stringify(this.actual)} to be close to ${stringify(expected)} (precision: ${precision})`,
			`Expected ${stringify(this.actual)} not to be close to ${stringify(expected)} (precision: ${precision})`
		);
	}

	toContain(item) {
		let contains = false;
		if (typeof this.actual === 'string') {
			contains = this.actual.indexOf(item) !== -1;
		} else if (Array.isArray(this.actual)) {
			contains = this.actual.indexOf(item) !== -1;
		} else if (this.actual && typeof this.actual === 'object') {
			contains = item in this.actual;
		}
		this._assert(contains, `Expected ${stringify(this.actual)} to contain ${stringify(item)}`, `Expected ${stringify(this.actual)} not to contain ${stringify(item)}`);
	}

	toContainEqual(item) {
		let contains = false;
		if (Array.isArray(this.actual)) {
			contains = this.actual.some((element) => deepEqual(element, item));
		}
		this._assert(contains, `Expected ${stringify(this.actual)} to contain equal ${stringify(item)}`, `Expected ${stringify(this.actual)} not to contain equal ${stringify(item)}`);
	}

	toHaveLength(expected) {
		const actualLength = this.actual != null ? this.actual.length : undefined;
		this._assert(actualLength === expected, `Expected length ${actualLength} to be ${expected}`, `Expected length ${actualLength} not to be ${expected}`);
	}

	toHaveProperty(path, value = undefined) {
		const hasProperty = hasPath(this.actual, path);
		const checkValue = arguments.length > 1;

		if (checkValue) {
			const actualValue = getPath(this.actual, path);
			const valueMatches = deepEqual(actualValue, value);
			this._assert(
				hasProperty && valueMatches,
				`Expected ${stringify(this.actual)} to have property "${path}" with value ${stringify(value)}, but got ${stringify(actualValue)}`,
				`Expected ${stringify(this.actual)} not to have property "${path}" with value ${stringify(value)}`
			);
		} else {
			this._assert(hasProperty, `Expected ${stringify(this.actual)} to have property "${path}"`, `Expected ${stringify(this.actual)} not to have property "${path}"`);
		}
	}

	toMatch(pattern) {
		const regex = pattern instanceof RegExp ? pattern : new RegExp(pattern);
		this._assert(regex.test(String(this.actual)), `Expected ${stringify(this.actual)} to match ${regex}`, `Expected ${stringify(this.actual)} not to match ${regex}`);
	}

	toMatchObject(expected) {
		const passed = matchObject(this.actual, expected);
		this._assert(passed, `Expected ${stringify(this.actual)} to match object ${stringify(expected)}`, `Expected ${stringify(this.actual)} not to match object ${stringify(expected)}`);
	}

	toThrow(expectedError) {
		if (typeof this.actual !== 'function') {
			throw new AssertionError('Expected value must be a function');
		}

		let thrown = false;
		let error = null;
		try {
			this.actual();
		} catch (e) {
			thrown = true;
			error = e;
		}

		if (!this.isNot && !thrown) {
			throw new AssertionError('Expected function to throw an error');
		}
		if (this.isNot && thrown) {
			throw new AssertionError(`Expected function not to throw, but it threw: ${error.message}`);
		}

		if (thrown && expectedError !== undefined) {
			let matches = false;
			if (typeof expectedError === 'string') {
				matches = error.message.includes(expectedError);
			} else if (expectedError instanceof RegExp || Object.prototype.toString.call(expectedError) === '[object RegExp]') {
				matches = expectedError.test(error.message);
			} else if (typeof expectedError === 'function') {
				matches = error instanceof expectedError;
			}

			if (!matches) {
				throw new AssertionError(`Expected function to throw ${stringify(expectedError)}, but it threw: ${error.message}`);
			}
		}
	}

	toBeInstanceOf(constructor) {
		this._assert(
			this.actual instanceof constructor,
			`Expected ${stringify(this.actual)} to be instance of ${constructor.name}`,
			`Expected ${stringify(this.actual)} not to be instance of ${constructor.name}`
		);
	}
}

class AssertionError extends Error {
	constructor(message) {
		super(message);
		this.name = 'AssertionError';
	}
}

// ============================================================================
// Utility Functions
// ============================================================================

function stringify(value, depth = 0, maxDepth = 3) {
	if (depth > maxDepth) return '[Circular]';

	if (value === null) return 'null';
	if (value === undefined) return 'undefined';
	if (typeof value === 'string') return `"${value}"`;
	if (typeof value === 'number' || typeof value === 'boolean') return String(value);
	if (typeof value === 'function') return `[Function: ${value.name || 'anonymous'}]`;

	// Better RegExp detection
	if (value instanceof RegExp || Object.prototype.toString.call(value) === '[object RegExp]') {
		return String(value);
	}
	if (value instanceof Date) return value.toISOString();

	if (Array.isArray(value)) {
		if (value.length === 0) return '[]';
		const items = value.slice(0, 10).map((v) => stringify(v, depth + 1, maxDepth));
		const more = value.length > 10 ? `, ... ${value.length - 10} more` : '';
		return `[${items.join(', ')}${more}]`;
	}

	if (typeof value === 'object') {
		const keys = Object.keys(value);
		if (keys.length === 0) return '{}';
		const items = keys.slice(0, 10).map((k) => `${k}: ${stringify(value[k], depth + 1, maxDepth)}`);
		const more = keys.length > 10 ? `, ... ${keys.length - 10} more` : '';
		return `{${items.join(', ')}${more}}`;
	}

	return String(value);
}

function deepEqual(a, b) {
	if (Object.is(a, b)) return true;
	if (a === null || b === null) return false;
	if (typeof a !== typeof b) return false;

	if (a instanceof Date && b instanceof Date) {
		return a.getTime() === b.getTime();
	}

	// Better RegExp detection
	const aIsRegExp = a instanceof RegExp || Object.prototype.toString.call(a) === '[object RegExp]';
	const bIsRegExp = b instanceof RegExp || Object.prototype.toString.call(b) === '[object RegExp]';
	if (aIsRegExp && bIsRegExp) {
		return a.source === b.source && a.flags === b.flags;
	}

	if (typeof a !== 'object') return false;

	if (Array.isArray(a) !== Array.isArray(b)) return false;

	const keysA = Object.keys(a);
	const keysB = Object.keys(b);

	if (keysA.length !== keysB.length) return false;

	for (const key of keysA) {
		if (!keysB.includes(key)) return false;
		if (!deepEqual(a[key], b[key])) return false;
	}

	return true;
}

function strictEqual(a, b) {
	if (!Object.is(a, b)) return false;
	if (typeof a !== 'object' || a === null) return true;

	if (Object.getPrototypeOf(a) !== Object.getPrototypeOf(b)) return false;

	return deepEqual(a, b);
}

function matchObject(actual, expected) {
	if (typeof expected !== 'object' || expected === null) {
		return deepEqual(actual, expected);
	}

	if (typeof actual !== 'object' || actual === null) return false;

	for (const key in expected) {
		if (!matchObject(actual[key], expected[key])) {
			return false;
		}
	}

	return true;
}

function hasPath(obj, path) {
	if (typeof obj !== 'object' || obj === null) return false;

	const keys = typeof path === 'string' ? path.split('.') : [path];
	let current = obj;

	for (const key of keys) {
		if (typeof current !== 'object' || current === null || !(key in current)) {
			return false;
		}
		current = current[key];
	}

	return true;
}

function getPath(obj, path) {
	const keys = typeof path === 'string' ? path.split('.') : [path];
	let current = obj;

	for (const key of keys) {
		if (typeof current !== 'object' || current === null) {
			return undefined;
		}
		current = current[key];
	}

	return current;
}

function isPromise(value) {
	return value && typeof value === 'object' && typeof value.then === 'function';
}

// ============================================================================
// Test Runner
// ============================================================================

async function runTestSuite(suite) {
	const results = [];

	// Run beforeAll hooks
	for (const hook of suite.hooks.beforeAll) {
		await runWithTimeout(hook, testState.config.timeout);
	}

	// Run tests
	for (const test of suite.tests) {
		if (test.skipped) {
			testState.results.skipped++;
			continue;
		}

		if (testState.config.bail && testState.results.failed > 0) {
			break;
		}

		const result = await runTest(test, suite);
		results.push(result);

		if (result.passed) {
			testState.results.passed++;
		} else {
			testState.results.failed++;
		}
		testState.results.total++;
		testState.results.duration += result.duration;
	}

	// Run child suites
	for (const child of suite.children) {
		const childResults = await runTestSuite(child);
		results.push(...childResults);
	}

	// Run afterAll hooks
	for (const hook of suite.hooks.afterAll) {
		await runWithTimeout(hook, testState.config.timeout);
	}

	return results;
}

async function runTest(test, suite) {
	const startTime = Date.now();

	try {
		// Run beforeEach hooks (including parent suites)
		const beforeEachHooks = collectHooks(suite, 'beforeEach');
		for (const hook of beforeEachHooks) {
			await runWithTimeout(hook, testState.config.timeout);
		}

		// Run the test
		await runWithTimeout(test.fn, testState.config.timeout);

		// Run afterEach hooks (including parent suites, in reverse)
		const afterEachHooks = collectHooks(suite, 'afterEach').reverse();
		for (const hook of afterEachHooks) {
			await runWithTimeout(hook, testState.config.timeout);
		}

		const duration = Date.now() - startTime;
		return new TestResult(test, true, null, duration);
	} catch (error) {
		const duration = Date.now() - startTime;
		return new TestResult(test, false, error, duration);
	}
}

function collectHooks(suite, type) {
	const hooks = [];
	let current = suite;
	while (current) {
		hooks.unshift(...current.hooks[type]);
		current = current.parent;
	}
	return hooks;
}

async function runWithTimeout(fn, timeout) {
	const result = fn();

	if (isPromise(result)) {
		// Only use timeout if setTimeout is available (not in all V8 environments)
		if (typeof setTimeout !== 'undefined') {
			return await Promise.race([
				result,
				new Promise((_, reject) => {
					setTimeout(() => reject(new Error(`Test timeout after ${timeout}ms`)), timeout);
				}),
			]);
		} else {
			// No timeout support, just await the result
			return await result;
		}
	}

	return result;
}

// ============================================================================
// Public API
// ============================================================================

function describe(name, fn) {
	const suite = new TestSuite(name, fn);

	if (testState.currentSuite) {
		suite.parent = testState.currentSuite;
		testState.currentSuite.children.push(suite);
	} else {
		testState.suites.push(suite);
	}

	const previousSuite = testState.currentSuite;
	testState.currentSuite = suite;

	try {
		fn();
	} finally {
		testState.currentSuite = previousSuite;
	}

	return suite;
}

describe.skip = function (name, fn) {
	const suite = describe(name, fn);
	suite.skipped = true;
	return suite;
};

describe.only = function (name, fn) {
	const suite = describe(name, fn);
	suite.only = true;
	return suite;
};

function it(name, fn) {
	if (!testState.currentSuite) {
		throw new Error('Tests must be inside a describe block');
	}

	const test = new TestCase(name, fn, testState.currentSuite);
	testState.currentSuite.addTest(test);
	return test;
}

it.skip = function (name, fn) {
	const test = it(name, fn);
	test.skipped = true;
	return test;
};

it.only = function (name, fn) {
	const test = it(name, fn);
	test.only = true;
	return test;
};

const test = it;
test.skip = it.skip;
test.only = it.only;

function expect(actual) {
	return new Expectation(actual);
}

function beforeAll(fn) {
	if (!testState.currentSuite) {
		throw new Error('beforeAll must be inside a describe block');
	}
	testState.currentSuite.addHook('beforeAll', fn);
}

function afterAll(fn) {
	if (!testState.currentSuite) {
		throw new Error('afterAll must be inside a describe block');
	}
	testState.currentSuite.addHook('afterAll', fn);
}

function beforeEach(fn) {
	if (!testState.currentSuite) {
		throw new Error('beforeEach must be inside a describe block');
	}
	testState.currentSuite.addHook('beforeEach', fn);
}

function afterEach(fn) {
	if (!testState.currentSuite) {
		throw new Error('afterEach must be inside a describe block');
	}
	testState.currentSuite.addHook('afterEach', fn);
}

async function runTests(options = {}) {
	// Merge options with config
	Object.assign(testState.config, options);

	// Reset results
	testState.results = {
		total: 0,
		passed: 0,
		failed: 0,
		skipped: 0,
		duration: 0,
	};

	const allResults = [];
	const startTime = Date.now();

	// Check if there are any .only tests/suites
	const hasOnly = checkForOnly(testState.suites);

	// Filter tests if .only is used
	const suitesToRun = hasOnly ? filterOnly(testState.suites) : testState.suites;

	// Run all test suites
	for (const suite of suitesToRun) {
		const results = await runTestSuite(suite);
		allResults.push(...results);
	}

	const totalDuration = Date.now() - startTime;

	// Print results
	printResults(allResults, totalDuration);

	return {
		results: allResults,
		summary: testState.results,
		totalDuration,
	};
}

function checkForOnly(suites) {
	for (const suite of suites) {
		if (suite.only) return true;
		if (suite.tests.some((t) => t.only)) return true;
		if (checkForOnly(suite.children)) return true;
	}
	return false;
}

function filterOnly(suites) {
	return suites
		.map((suite) => {
			const filtered = { ...suite };

			if (suite.only || suite.tests.some((t) => t.only)) {
				filtered.tests = suite.tests.filter((t) => t.only || !suite.tests.some((t) => t.only));
			}

			filtered.children = filterOnly(suite.children);
			return filtered;
		})
		.filter((suite) => {
			return suite.only || suite.tests.some((t) => t.only) || suite.children.length > 0;
		});
}

function printResults(results, totalDuration) {
	if (!testState.config.verbose) {
		printSummary(totalDuration);
		return;
	}

	log('\n====================================');
	log('TEST RESULTS');
	log('====================================\n');

	let currentSuite = null;

	for (const result of results) {
		const suiteName = result.test.suite.getFullName();
		if (suiteName !== currentSuite) {
			log(`\n${suiteName}`);
			currentSuite = suiteName;
		}

		const icon = result.passed ? '✓' : '✗';
		const status = result.passed ? 'PASS' : 'FAIL';
		const duration = result.duration < 1000 ? `${result.duration}ms` : `${(result.duration / 1000).toFixed(2)}s`;

		log(`  ${icon} ${result.test.name} (${duration})`);

		if (!result.passed && result.error) {
			log(`    Error: ${result.error.message}`);
			if (result.error.stack) {
				const stackLines = result.error.stack.split('\n').slice(1, 4);
				stackLines.forEach((line) => log(`      ${line.trim()}`));
			}
		}
	}

	log('\n');
	printSummary(totalDuration);
}

function printSummary(totalDuration) {
	log('====================================');
	log('SUMMARY');
	log('====================================');
	log(`Total:   ${testState.results.total}`);
	log(`Passed:  ${testState.results.passed} ✓`);
	log(`Failed:  ${testState.results.failed} ✗`);
	log(`Skipped: ${testState.results.skipped} ⊘`);

	const duration = totalDuration < 1000 ? `${totalDuration}ms` : `${(totalDuration / 1000).toFixed(2)}s`;
	log(`Duration: ${duration}`);
	log('====================================\n');

	if (testState.results.failed > 0) {
		log('❌ Tests FAILED');
	} else {
		log('✅ Tests PASSED');
	}
}

function configure(options) {
	Object.assign(testState.config, options);
}

function resetTests() {
	testState.suites = [];
	testState.currentSuite = null;
	testState.results = {
		total: 0,
		passed: 0,
		failed: 0,
		skipped: 0,
		duration: 0,
	};
}

// ============================================================================
// Exports
// ============================================================================

module.exports = {
	describe,
	it,
	test,
	expect,
	beforeAll,
	afterAll,
	beforeEach,
	afterEach,
	runTests,
	configure,
	resetTests,
	// Export classes for advanced usage
	TestSuite,
	TestCase,
	TestResult,
	Expectation,
	AssertionError,
};
