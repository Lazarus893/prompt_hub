/**
 * @fileoverview Example tests demonstrating the @test/suite library
 * This file showcases all features and can be used to test the test framework itself
 */

const { describe, it, test, expect, beforeAll, afterAll, beforeEach, afterEach, runTests, configure } = require('@test/suite:v1.0.0');

// Configure test runner
configure({
	verbose: true,
	timeout: 5000,
});

// ============================================================================
// Basic Tests
// ============================================================================

describe('Basic assertions', () => {
	it('should pass a simple test', () => {
		expect(true).toBeTruthy();
	});

	it('should compare numbers with toBe', () => {
		expect(1 + 1).toBe(2);
		expect(5 * 2).toBe(10);
	});

	test('works with test() instead of it()', () => {
		expect('test').toBe('test');
	});
});

// ============================================================================
// Equality Matchers
// ============================================================================

describe('Equality matchers', () => {
	describe('toBe', () => {
		it('should work with primitives', () => {
			expect(1).toBe(1);
			expect('hello').toBe('hello');
			expect(true).toBe(true);
			expect(null).toBe(null);
			expect(undefined).toBe(undefined);
		});

		it('should distinguish between 0 and -0', () => {
			expect(0).toBe(0);
			expect(-0).toBe(-0);
			expect(0).not.toBe(-0);
		});

		it('should distinguish NaN', () => {
			expect(NaN).toBe(NaN);
		});
	});

	describe('toEqual', () => {
		it('should deep compare objects', () => {
			expect({ a: 1, b: 2 }).toEqual({ a: 1, b: 2 });
			expect({ a: 1, b: { c: 3 } }).toEqual({ a: 1, b: { c: 3 } });
		});

		it('should deep compare arrays', () => {
			expect([1, 2, 3]).toEqual([1, 2, 3]);
			expect([{ a: 1 }, { b: 2 }]).toEqual([{ a: 1 }, { b: 2 }]);
		});

		it('should compare dates', () => {
			const date1 = new Date('2024-01-01');
			const date2 = new Date('2024-01-01');
			expect(date1).toEqual(date2);
		});

		it('should compare regexes', () => {
			expect(/test/).toEqual(/test/);
			expect(/test/gi).toEqual(/test/gi);
		});
	});
});

// ============================================================================
// Truthiness Matchers
// ============================================================================

describe('Truthiness matchers', () => {
	it('should test toBeTruthy', () => {
		expect(true).toBeTruthy();
		expect(1).toBeTruthy();
		expect('hello').toBeTruthy();
		expect([]).toBeTruthy();
		expect({}).toBeTruthy();
	});

	it('should test toBeFalsy', () => {
		expect(false).toBeFalsy();
		expect(0).toBeFalsy();
		expect('').toBeFalsy();
		expect(null).toBeFalsy();
		expect(undefined).toBeFalsy();
		expect(NaN).toBeFalsy();
	});

	it('should test toBeNull', () => {
		expect(null).toBeNull();
		expect(undefined).not.toBeNull();
		expect(0).not.toBeNull();
	});

	it('should test toBeUndefined', () => {
		expect(undefined).toBeUndefined();
		let x;
		expect(x).toBeUndefined();
		expect(null).not.toBeUndefined();
	});

	it('should test toBeDefined', () => {
		expect(0).toBeDefined();
		expect('').toBeDefined();
		expect(null).toBeDefined();
		expect(undefined).not.toBeDefined();
	});

	it('should test toBeNaN', () => {
		expect(NaN).toBeNaN();
		expect(0 / 0).toBeNaN();
		expect(parseInt('hello')).toBeNaN();
		expect(0).not.toBeNaN();
	});
});

// ============================================================================
// Numeric Matchers
// ============================================================================

describe('Numeric matchers', () => {
	it('should test toBeGreaterThan', () => {
		expect(10).toBeGreaterThan(5);
		expect(5).not.toBeGreaterThan(10);
	});

	it('should test toBeGreaterThanOrEqual', () => {
		expect(10).toBeGreaterThanOrEqual(10);
		expect(10).toBeGreaterThanOrEqual(5);
		expect(5).not.toBeGreaterThanOrEqual(10);
	});

	it('should test toBeLessThan', () => {
		expect(5).toBeLessThan(10);
		expect(10).not.toBeLessThan(5);
	});

	it('should test toBeLessThanOrEqual', () => {
		expect(5).toBeLessThanOrEqual(5);
		expect(5).toBeLessThanOrEqual(10);
		expect(10).not.toBeLessThanOrEqual(5);
	});

	it('should test toBeCloseTo for floats', () => {
		expect(0.1 + 0.2).toBeCloseTo(0.3);
		expect(0.1 + 0.2).not.toBe(0.3); // Floating point issue
		expect(Math.PI).toBeCloseTo(3.14, 2);
	});
});

// ============================================================================
// String/Array/Object Matchers
// ============================================================================

describe('Collection matchers', () => {
	describe('toContain', () => {
		it('should work with strings', () => {
			expect('hello world').toContain('world');
			expect('hello world').toContain('hello');
			expect('hello world').not.toContain('goodbye');
		});

		it('should work with arrays', () => {
			expect([1, 2, 3]).toContain(2);
			expect([1, 2, 3]).not.toContain(4);
		});

		it('should work with objects (checks keys)', () => {
			expect({ a: 1, b: 2 }).toContain('a');
			expect({ a: 1, b: 2 }).not.toContain('c');
		});
	});

	describe('toContainEqual', () => {
		it('should deep compare array elements', () => {
			expect([{ id: 1 }, { id: 2 }]).toContainEqual({ id: 1 });
			expect([{ id: 1 }, { id: 2 }]).not.toContainEqual({ id: 3 });
		});
	});

	describe('toHaveLength', () => {
		it('should check array length', () => {
			expect([1, 2, 3]).toHaveLength(3);
			expect([]).toHaveLength(0);
		});

		it('should check string length', () => {
			expect('hello').toHaveLength(5);
			expect('').toHaveLength(0);
		});
	});

	describe('toHaveProperty', () => {
		it('should check for property existence', () => {
			const obj = { a: 1, b: 2 };
			expect(obj).toHaveProperty('a');
			expect(obj).toHaveProperty('b');
			expect(obj).not.toHaveProperty('c');
		});

		it('should check property value', () => {
			const obj = { a: 1, b: 2 };
			expect(obj).toHaveProperty('a', 1);
			expect(obj).toHaveProperty('b', 2);
		});

		it('should handle nested properties', () => {
			const obj = { a: { b: { c: 3 } } };
			expect(obj).toHaveProperty('a.b.c');
			expect(obj).toHaveProperty('a.b.c', 3);
		});
	});

	describe('toMatch', () => {
		it('should match with regex', () => {
			expect('hello world').toMatch(/world/);
			expect('test@example.com').toMatch(/^\w+@\w+\.\w+$/);
		});

		it('should match with string pattern', () => {
			expect('hello').toMatch('ell');
		});
	});

	describe('toMatchObject', () => {
		it('should partially match objects', () => {
			const obj = { a: 1, b: 2, c: 3 };
			expect(obj).toMatchObject({ a: 1 });
			expect(obj).toMatchObject({ a: 1, b: 2 });
			expect(obj).toMatchObject({ a: 1, b: 2, c: 3 });
		});

		it('should handle nested objects', () => {
			const obj = { a: { b: { c: 3 } }, d: 4 };
			expect(obj).toMatchObject({ a: { b: { c: 3 } } });
		});
	});
});

// ============================================================================
// Error Matchers
// ============================================================================

describe('Error matchers', () => {
	it('should test toThrow without message', () => {
		expect(() => {
			throw new Error('oops');
		}).toThrow();
	});

	it('should test toThrow with string message', () => {
		expect(() => {
			throw new Error('something went wrong');
		}).toThrow('went wrong');
	});

	it('should test toThrow with regex', () => {
		expect(() => {
			throw new Error('Error: 404 not found');
		}).toThrow(/404/);
	});

	it('should test toThrow with error type', () => {
		expect(() => {
			throw new TypeError('wrong type');
		}).toThrow(TypeError);
	});

	it('should test not.toThrow', () => {
		expect(() => {
			return 'success';
		}).not.toThrow();
	});
});

// ============================================================================
// Type Matchers
// ============================================================================

describe('Type matchers', () => {
	it('should test toBeInstanceOf', () => {
		expect(new Date()).toBeInstanceOf(Date);
		expect([]).toBeInstanceOf(Array);
		expect({}).toBeInstanceOf(Object);
		expect(/regex/).toBeInstanceOf(RegExp);
	});
});

// ============================================================================
// Negation Tests
// ============================================================================

describe('Negation with .not', () => {
	it('should negate toBe', () => {
		expect(1).not.toBe(2);
		expect('hello').not.toBe('world');
	});

	it('should negate toEqual', () => {
		expect({ a: 1 }).not.toEqual({ a: 2 });
		expect([1, 2]).not.toEqual([1, 3]);
	});

	it('should negate truthiness', () => {
		expect(false).not.toBeTruthy();
		expect(true).not.toBeFalsy();
	});

	it('should negate comparisons', () => {
		expect(5).not.toBeGreaterThan(10);
		expect(10).not.toBeLessThan(5);
	});
});

// ============================================================================
// Lifecycle Hooks
// ============================================================================

describe('Lifecycle hooks', () => {
	const state = { setup: false, values: [] };

	beforeAll(() => {
		state.setup = true;
	});

	afterAll(() => {
		state.setup = false;
	});

	beforeEach(() => {
		state.values.push('before');
	});

	afterEach(() => {
		state.values.push('after');
	});

	it('should run beforeAll', () => {
		expect(state.setup).toBe(true);
	});

	it('should run beforeEach', () => {
		expect(state.values).toContain('before');
	});

	it('should maintain state between tests', () => {
		// By now we've run beforeEach and afterEach multiple times
		expect(state.values.length).toBeGreaterThan(0);
	});
});

// ============================================================================
// Nested Describes
// ============================================================================

describe('Nested test suites', () => {
	describe('Level 1', () => {
		describe('Level 2', () => {
			describe('Level 3', () => {
				it('should work with deep nesting', () => {
					expect(true).toBeTruthy();
				});
			});
		});
	});

	describe('Sibling suite', () => {
		it('should be independent', () => {
			expect(1 + 1).toBe(2);
		});
	});
});

// ============================================================================
// Async Tests
// ============================================================================

describe('Async tests', () => {
	it('should handle async/await', async () => {
		const result = await Promise.resolve(42);
		expect(result).toBe(42);
	});

	it('should handle promise chains', () => {
		return Promise.resolve(10)
			.then((value) => value * 2)
			.then((value) => {
				expect(value).toBe(20);
			});
	});

	it('should handle async errors', async () => {
		try {
			await Promise.reject(new Error('async error'));
		} catch (error) {
			expect(error.message).toBe('async error');
		}
	});

	it('should handle multiple promises', async () => {
		const results = await Promise.all([Promise.resolve(1), Promise.resolve(2), Promise.resolve(3)]);
		expect(results).toEqual([1, 2, 3]);
	});
});

// ============================================================================
// Array Operations Example
// ============================================================================

describe('Array operations', () => {
	let arr;

	beforeEach(() => {
		arr = [1, 2, 3];
	});

	describe('push', () => {
		it('should add element to end', () => {
			arr.push(4);
			expect(arr).toHaveLength(4);
			expect(arr[3]).toBe(4);
		});

		it('should return new length', () => {
			const length = arr.push(4);
			expect(length).toBe(4);
		});
	});

	describe('pop', () => {
		it('should remove last element', () => {
			const last = arr.pop();
			expect(last).toBe(3);
			expect(arr).toHaveLength(2);
		});

		it('should return undefined for empty array', () => {
			arr = [];
			expect(arr.pop()).toBeUndefined();
		});
	});

	describe('map', () => {
		it('should transform elements', () => {
			const doubled = arr.map((x) => x * 2);
			expect(doubled).toEqual([2, 4, 6]);
		});

		it('should not modify original', () => {
			arr.map((x) => x * 2);
			expect(arr).toEqual([1, 2, 3]);
		});
	});

	describe('filter', () => {
		it('should keep only matching elements', () => {
			const evens = arr.filter((x) => x % 2 === 0);
			expect(evens).toEqual([2]);
		});
	});

	describe('reduce', () => {
		it('should sum all elements', () => {
			const sum = arr.reduce((acc, val) => acc + val, 0);
			expect(sum).toBe(6);
		});
	});
});

// ============================================================================
// Object Operations Example
// ============================================================================

describe('Object operations', () => {
	it('should create objects', () => {
		const obj = { name: 'John', age: 30 };
		expect(obj).toHaveProperty('name');
		expect(obj).toHaveProperty('age');
	});

	it('should update properties', () => {
		const obj = { count: 0 };
		obj.count++;
		expect(obj.count).toBe(1);
	});

	it('should delete properties', () => {
		const obj = { a: 1, b: 2 };
		delete obj.b;
		expect(obj).toHaveProperty('a');
		expect(obj).not.toHaveProperty('b');
	});

	it('should use Object.keys', () => {
		const obj = { a: 1, b: 2, c: 3 };
		expect(Object.keys(obj)).toEqual(['a', 'b', 'c']);
	});
});

// ============================================================================
// String Operations Example
// ============================================================================

describe('String operations', () => {
	it('should concatenate strings', () => {
		expect('hello' + ' ' + 'world').toBe('hello world');
	});

	it('should use template literals', () => {
		const name = 'Alice';
		expect(`Hello, ${name}!`).toBe('Hello, Alice!');
	});

	it('should split strings', () => {
		expect('a,b,c'.split(',')).toEqual(['a', 'b', 'c']);
	});

	it('should use string methods', () => {
		expect('HELLO'.toLowerCase()).toBe('hello');
		expect('hello'.toUpperCase()).toBe('HELLO');
		expect('  trim  '.trim()).toBe('trim');
	});
});

// ============================================================================
// Math Operations Example
// ============================================================================

describe('Math operations', () => {
	it('should perform basic arithmetic', () => {
		expect(1 + 1).toBe(2);
		expect(5 - 3).toBe(2);
		expect(4 * 5).toBe(20);
		expect(10 / 2).toBe(5);
		expect(10 % 3).toBe(1);
	});

	it('should use Math functions', () => {
		expect(Math.round(3.7)).toBe(4);
		expect(Math.floor(3.7)).toBe(3);
		expect(Math.ceil(3.1)).toBe(4);
		expect(Math.abs(-5)).toBe(5);
	});

	it('should handle Math constants', () => {
		expect(Math.PI).toBeCloseTo(3.14159, 5);
		expect(Math.E).toBeCloseTo(2.71828, 5);
	});
});

// ============================================================================
// Complex Example: Simple Calculator
// ============================================================================

describe('Simple Calculator', () => {
	class Calculator {
		constructor() {
			this.result = 0;
		}

		add(n) {
			this.result += n;
			return this;
		}

		subtract(n) {
			this.result -= n;
			return this;
		}

		multiply(n) {
			this.result *= n;
			return this;
		}

		divide(n) {
			if (n === 0) throw new Error('Division by zero');
			this.result /= n;
			return this;
		}

		clear() {
			this.result = 0;
			return this;
		}

		getResult() {
			return this.result;
		}
	}

	let calc;

	beforeEach(() => {
		calc = new Calculator();
	});

	it('should start with 0', () => {
		expect(calc.getResult()).toBe(0);
	});

	it('should add numbers', () => {
		calc.add(5).add(3);
		expect(calc.getResult()).toBe(8);
	});

	it('should subtract numbers', () => {
		calc.add(10).subtract(3);
		expect(calc.getResult()).toBe(7);
	});

	it('should multiply numbers', () => {
		calc.add(5).multiply(3);
		expect(calc.getResult()).toBe(15);
	});

	it('should divide numbers', () => {
		calc.add(20).divide(4);
		expect(calc.getResult()).toBe(5);
	});

	it('should throw on division by zero', () => {
		expect(() => calc.divide(0)).toThrow('Division by zero');
	});

	it('should chain operations', () => {
		calc.add(10).multiply(2).subtract(5).divide(3);
		expect(calc.getResult()).toBeCloseTo(5, 0);
	});

	it('should clear result', () => {
		calc.add(100).clear();
		expect(calc.getResult()).toBe(0);
	});
});

// ============================================================================
// Run Tests
// ============================================================================

// This would normally be called at the end

log('Test suite loaded successfully!');

log('Now running tests...');

runTests().then((results) => {
	log('All tests completed!');
	log(JSON.stringify(results.summary, null, 2));
});
