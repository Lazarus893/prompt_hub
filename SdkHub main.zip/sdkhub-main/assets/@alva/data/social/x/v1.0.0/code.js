const { sdkRelay } = require('sdkrelay');
const { useCredit } = require('internal');

// Refs injected from tool.json metadata
const getXUserRef = {
  id: '@alva/data/social/x/getXUser',
  module_name: '@alva/data/social/x',
  module_display_name: 'Real-time X Search',
  sdk_name: 'getXUser',
  sdk_display_name: 'X Profile Details',
  source_name: 'X',
  source: 'https://docs.x.com/x-api/introduction',
};

const getXPostsRef = {
  id: '@alva/data/social/x/getXPosts',
  module_name: '@alva/data/social/x',
  module_display_name: 'Real-time X Search',
  sdk_name: 'getXPosts',
  sdk_display_name: 'X User Posts',
  source_name: 'X',
  source: 'https://docs.x.com/x-api/introduction',
};

const getXFollowersRef = {
  id: '@alva/data/social/x/getXFollowers',
  module_name: '@alva/data/social/x',
  module_display_name: 'Real-time X Search',
  sdk_name: 'getXFollowers',
  sdk_display_name: 'X Follower Tracker',
  source_name: 'X',
  source: 'https://docs.x.com/x-api/introduction',
};

const getXFollowingsRef = {
  id: '@alva/data/social/x/getXFollowings',
  module_name: '@alva/data/social/x',
  module_display_name: 'Real-time X Search',
  sdk_name: 'getXFollowings',
  sdk_display_name: 'X Following Activity',
  source_name: 'X',
  source: 'https://docs.x.com/x-api/introduction',
};

// Base descriptions (internal only, do not export)
const getXUserBaseFuncDesc = 'Get X/Twitter user info';
const getXPostsBaseFuncDesc = 'Get user posts';
const getXFollowersBaseFuncDesc = 'Get followers list';
const getXFollowingsBaseFuncDesc = 'Get following accounts';
const searchXBaseFuncDesc = 'Search X/Twitter posts';

// Dynamic call description builders (internal only, do not export)
function buildGetXUserCallDescription(actualParams = {}) {
  const parts = [getXUserBaseFuncDesc];
  if (actualParams.username) {
    parts.push(`for @${actualParams.username}`);
  }
  return parts.join(' ').trim();
}

function buildGetXPostsCallDescription(actualParams = {}) {
  const parts = [getXPostsBaseFuncDesc];
  if (actualParams.username) {
    parts.push(`by @${actualParams.username}`);
  }
  const filters = [];
  if (actualParams.start_time && actualParams.end_time) {
    filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
  } else if (actualParams.start_time) {
    filters.push(`Time from: ${actualParams.start_time}`);
  } else if (actualParams.end_time) {
    filters.push(`Time until: ${actualParams.end_time}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetXFollowersCallDescription(actualParams = {}) {
  const parts = [getXFollowersBaseFuncDesc];
  if (actualParams.username) {
    parts.push(`of @${actualParams.username}`);
  }
  const filters = [];
  if (actualParams.start_time && actualParams.end_time) {
    filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
  } else if (actualParams.start_time) {
    filters.push(`Time from: ${actualParams.start_time}`);
  } else if (actualParams.end_time) {
    filters.push(`Time until: ${actualParams.end_time}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetXFollowingsCallDescription(actualParams = {}) {
  const parts = [getXFollowingsBaseFuncDesc];
  if (actualParams.username) {
    parts.push(`for @${actualParams.username}`);
  }
  const filters = [];
  if (actualParams.start_time && actualParams.end_time) {
    filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
  } else if (actualParams.start_time) {
    filters.push(`Time from: ${actualParams.start_time}`);
  } else if (actualParams.end_time) {
    filters.push(`Time until: ${actualParams.end_time}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildSearchXCallDescription(actualParams = {}) {
  const parts = [searchXBaseFuncDesc];
  if (actualParams.query) {
    parts.push(`for "${actualParams.query}"`);
  }
  return parts.join(' ').trim();
}

// Helper to create ref with dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
  // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
  const title = titleBuilder(params);

  // 2. 组合 refObject 和新 title
  const newObject = {
    ...refObject,
    title: title,
  };

  // 3. 返回新对象
  return newObject;
}

function getXUser(params) {
  useCredit('getXUser', 1500);
  return sdkRelay('GetXUser', params);
}

function getXPosts(params) {
  useCredit('getXPosts', 1500);
  return sdkRelay('GetXPosts', params);
}

function getXFollowers(params) {
  useCredit('getXFollowers', 1500);
  return sdkRelay('GetXFollowers', params);
}

function getXFollowings(params) {
  useCredit('getXFollowings', 1500);
  return sdkRelay('GetXFollowings', params);
}

function searchX(params) {
  useCredit('searchX', 1500);
  return sdkRelay('SearchX', params);
}

function toMs(value) {
  if (value == null) return null;
  if (typeof value === 'number') return value > 1e12 ? value : value * 1000;
  if (typeof value === 'string') {
    const parsed = Date.parse(value);
    if (!Number.isNaN(parsed)) return parsed;
  }
  return null;
}

function ensureUniqueDates(records) {
  const used = new Set();
  return records.map((record) => {
    if (record == null || record.date == null) {
      throw new Error('record.date is required');
    }
    let date = record.date;
    while (used.has(date)) date += 1;
    used.add(date);
    return { ...record, date };
  });
}

function pickSnapshotDate(params) {
  const candidates = [params?.end_time, params?.endTime, params?.start_time, params?.startTime];
  for (const candidate of candidates) {
    const ms = toMs(candidate);
    if (ms != null) return ms;
  }
  return Date.now();
}

/**
 * Nodified node: X User
 */
function makeXUserNode(params) {
  return {
    inputs: {
      user_raw: () => getXUser(params),
    },
    outputs: {
      user_profile: {
        name: 'x_user_profile',
        description: 'Twitter user profile',
        fields: [
          { name: 'date', type: 'number', description: 'snapshot time ms' },
          { name: 'id', type: 'string', description: 'user id' },
          { name: 'username', type: 'string', description: 'username' },
          { name: 'name', type: 'string', description: 'display name' },
          { name: 'description', type: 'string', description: 'bio' },
          { name: 'created_at', type: 'number', description: 'account creation time ms' },
          { name: 'followers_count', type: 'number', description: 'followers count' },
          { name: 'followings_count', type: 'number', description: 'following count' },
          { name: 'verified', type: 'boolean', description: 'verified' },
          { name: 'avatar', type: 'string', description: 'avatar URL' },
          { name: 'banner', type: 'string', description: 'banner URL' },
        ],
        ref: createReferenceWithTitle(getXUserRef, params, buildGetXUserCallDescription),
      },
    },
    run: (inputs) => {
      const user = inputs.user_raw || {};
      const snapshotDate = pickSnapshotDate(params);
      const createdMs = toMs(user.created_at);
      return {
        user_profile: ensureUniqueDates([
          {
            date: snapshotDate,
            id: user.id,
            username: user.username,
            name: user.name,
            description: user.description,
            created_at: createdMs != null ? createdMs : undefined,
            followers_count: user.followers_count,
            followings_count: user.followings_count,
            verified: user.verified,
            avatar: user.avatar,
            banner: user.banner,
          },
        ]),
      };
    },
  };
}

/**
 * Nodified node: X Posts
 */
function makeXPostsNode(params) {
  return {
    inputs: {
      posts_raw: () => getXPosts(params),
    },
    outputs: {
      posts: {
        name: 'x_posts',
        description: 'User posts',
        fields: [
          { name: 'date', type: 'number', description: 'post time ms' },
          { name: 'id', type: 'string', description: 'post id' },
          { name: 'content', type: 'string', description: 'post content' },
          {
            name: 'author',
            type: 'object',
            description: 'author information',
            fields: [
              { name: 'id', type: 'string', description: 'user id' },
              { name: 'username', type: 'string', description: 'username' },
              { name: 'name', type: 'string', description: 'display name' },
              { name: 'description', type: 'string', description: 'bio' },
              { name: 'followers_count', type: 'number', description: 'followers count' },
              { name: 'followings_count', type: 'number', description: 'following count' },
              { name: 'verified', type: 'boolean', description: 'verified' },
              { name: 'avatar', type: 'string', description: 'avatar URL' },
              { name: 'banner', type: 'string', description: 'banner URL' },
            ],
          },
          {
            name: 'metrics',
            type: 'object',
            description: 'engagement metrics',
            fields: [
              { name: 'retweet_count', type: 'number', description: 'retweets' },
              { name: 'reply_count', type: 'number', description: 'replies' },
              { name: 'like_count', type: 'number', description: 'likes' },
              { name: 'quote_count', type: 'number', description: 'quotes' },
            ],
          },
        ],
        ref: createReferenceWithTitle(getXPostsRef, params, buildGetXPostsCallDescription),
      },
    },
    run: (inputs) => {
      const postsArr = Array.isArray(inputs.posts_raw) ? inputs.posts_raw : [];
      const posts = postsArr
        .map((item) => {
          const ts = toMs(item.created_at);
          const metrics = item.metrics || {};
          return {
            date: ts,
            id: item.id,
            content: item.content,
            author: item.author,
            metrics: {
              retweet_count: metrics.retweet_count,
              reply_count: metrics.reply_count,
              like_count: metrics.like_count,
              quote_count: metrics.quote_count,
            },
          };
        })
        .filter(Boolean);
      return { posts: ensureUniqueDates(posts) };
    },
  };
}

function mapUsersList(list) {
  return Array.isArray(list)
    ? list
        .map((item) => {
          const ts = toMs(item.followed_at || item.created_at);
          if (ts == null) return null;
          return {
            date: ts,
            id: item.id,
            username: item.username,
            name: item.name,
            description: item.description,
            followers_count: item.followers_count,
            followings_count: item.followings_count,
            verified: item.verified,
            avatar: item.avatar,
            banner: item.banner,
          };
        })
        .filter(Boolean)
    : [];
}

/**
 * Nodified node: X Followers
 */
function makeXFollowersNode(params) {
  return {
    inputs: {
      followers_raw: () => getXFollowers(params),
    },
    outputs: {
      followers: {
        name: 'x_followers',
        description: 'Followers information',
        fields: [
          { name: 'date', type: 'number', description: 'follow time ms' },
          { name: 'id', type: 'string', description: 'user id' },
          { name: 'username', type: 'string', description: 'username' },
          { name: 'name', type: 'string', description: 'display name' },
          { name: 'description', type: 'string', description: 'bio' },
          { name: 'followers_count', type: 'number', description: 'followers count' },
          { name: 'followings_count', type: 'number', description: 'following count' },
          { name: 'verified', type: 'boolean', description: 'verified' },
          { name: 'avatar', type: 'string', description: 'avatar URL' },
          { name: 'banner', type: 'string', description: 'banner URL' },
        ],
        ref: createReferenceWithTitle(getXFollowersRef, params, buildGetXFollowersCallDescription),
      },
    },
    run: (inputs) => {
      const followers = mapUsersList(inputs.followers_raw || []);
      return { followers: ensureUniqueDates(followers) };
    },
  };
}

/**
 * Nodified node: X Followings
 */
function makeXFollowingsNode(params) {
  return {
    inputs: {
      followings_raw: () => getXFollowings(params),
    },
    outputs: {
      followings: {
        name: 'x_followings',
        description: 'Accounts the user follows',
        fields: [
          { name: 'date', type: 'number', description: 'follow time ms' },
          { name: 'id', type: 'string', description: 'user id' },
          { name: 'username', type: 'string', description: 'username' },
          { name: 'name', type: 'string', description: 'display name' },
          { name: 'description', type: 'string', description: 'bio' },
          { name: 'followers_count', type: 'number', description: 'followers count' },
          { name: 'followings_count', type: 'number', description: 'following count' },
          { name: 'verified', type: 'boolean', description: 'verified' },
          { name: 'avatar', type: 'string', description: 'avatar URL' },
          { name: 'banner', type: 'string', description: 'banner URL' },
        ],
        ref: createReferenceWithTitle(getXFollowingsRef, params, buildGetXFollowingsCallDescription),
      },
    },
    run: (inputs) => {
      const followings = mapUsersList(inputs.followings_raw || []);
      return { followings: ensureUniqueDates(followings) };
    },
  };
}

/**
 * Nodified node: X Search
 */
function makeSearchXNode(params) {
  return {
    inputs: {
      search_raw: () => searchX(params),
    },
    outputs: {
      search_results: {
        name: 'x_search_results',
        description: 'Search results for posts',
        fields: [
          { name: 'date', type: 'number', description: 'snapshot time ms' },
          { name: 'query', type: 'string', description: 'search query' },
          {
            name: 'results',
            type: 'array',
            description: 'matching posts',
            fields: [
              { name: 'title', type: 'string', description: 'post title' },
              { name: 'url', type: 'string', description: 'post URL' },
              { name: 'content', type: 'string', description: 'post content' },
              { name: 'author_username', type: 'string', description: 'author username' },
            ],
          },
        ],
      },
    },
    run: (inputs) => {
      const arr = Array.isArray(inputs.search_raw) ? inputs.search_raw : [];
      const snapshotDate = pickSnapshotDate(params);
      const results = arr.map((r) => ({
        title: r.title,
        url: r.url,
        content: r.content,
        author_username: r.author_username || r.authorUsername,
      }));
      return {
        search_results: ensureUniqueDates([
          {
            date: snapshotDate,
            query: params.query,
            results,
          },
        ]),
      };
    },
  };
}

function getRefs() {
  return [
    getXUserRef,
    getXPostsRef,
    getXFollowersRef,
    getXFollowingsRef,
  ];
}

module.exports = {
  getXUser,
  getXPosts,
  getXFollowers,
  getXFollowings,
  searchX,
  makeXUserNode,
  makeXPostsNode,
  makeXFollowersNode,
  makeXFollowingsNode,
  makeSearchXNode,
  getRefs,
};
