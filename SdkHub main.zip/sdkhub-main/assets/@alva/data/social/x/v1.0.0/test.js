function main() {
	const { Graph } = require('@alva/graph:v1.0.0');
	const { jagentId } = require('env');
	const { makeXUserNode, makeXPostsNode, makeXFollowersNode, makeXFollowingsNode, makeSearchXNode } = require('@alva/data/social/x');

	const nowSeconds = Math.floor(Date.now() / 1000);
	const graph = new Graph(jagentId);

	graph.addNode('x_user', makeXUserNode({ username: 'elonmusk' }));

	graph.addNode(
		'x_posts',
		makeXPostsNode({
			username: 'elonmusk',
			start_time: nowSeconds - 7 * 24 * 60 * 60,
			end_time: nowSeconds,
		})
	);

	graph.addNode(
		'x_followers',
		makeXFollowersNode({
			username: 'elonmusk',
			start_time: nowSeconds - 3 * 24 * 60 * 60,
			end_time: nowSeconds,
		})
	);

	graph.addNode(
		'x_followings',
		makeXFollowingsNode({
			username: 'elonmusk',
			start_time: nowSeconds - 3 * 24 * 60 * 60,
			end_time: nowSeconds,
		})
	);

	graph.addNode('x_search', makeSearchXNode({ query: 'bitcoin price analysis' }));

	// Corner case tests
	// Test 1: Query with multiple keywords (edge case for query complexity)
	graph.addNode('x_search_multi_keyword', makeSearchXNode({ query: 'bitcoin ethereum solana web3' }));

	// Test 2: Query with hashtag (special character test)
	graph.addNode('x_search_hashtag', makeSearchXNode({ query: '#cryptocurrency #blockchain' }));

	// Test 3: Query with UTF-8 encoded characters (Chinese + emoji)
	graph.addNode('x_search_utf8', makeSearchXNode({ query: '比特币 🚀' }));

	// Test 4: Short time range for posts
	graph.addNode(
		'x_posts_short_time',
		makeXPostsNode({
			username: 'elonmusk',
			start_time: nowSeconds - 1 * 24 * 60 * 60, // Only 1 day
			end_time: nowSeconds,
		})
	);

	// Test 5: Different user for followers (edge case)
	graph.addNode(
		'x_followers_alt',
		makeXFollowersNode({
			username: 'elonmusk',
			start_time: nowSeconds - 1 * 24 * 60 * 60,
			end_time: nowSeconds,
		})
	);

	graph.run();

	const { TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');

	const xUserUri = new TimeSeriesUri(jagentId, 'x_user', 'user_profile', { last: '10' });
	const xUserSeries = new TimeSeries(xUserUri, graph.store);
	xUserSeries.init();
	const xUserData = xUserSeries.data;

	if (xUserData.length > 0) {
		const record = xUserData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('x_user: date must be a positive number (ms)');
		}
		if (typeof record.id !== 'string') {
			throw new Error('x_user: id must be a string');
		}
		if (typeof record.username !== 'string') {
			throw new Error('x_user: username must be a string');
		}
		if (typeof record.name !== 'string') {
			throw new Error('x_user: name must be a string');
		}
		if (record.description != null && typeof record.description !== 'string') {
			throw new Error('x_user: description must be a string or null/undefined');
		}
		if (typeof record.followers_count !== 'number') {
			throw new Error('x_user: followers_count must be a number');
		}
		if (typeof record.followings_count !== 'number') {
			throw new Error('x_user: followings_count must be a number');
		}
		if (typeof record.verified !== 'boolean') {
			throw new Error('x_user: verified must be a boolean');
		}
		log('✓ x_user node output validated');
	}

	const xPostsUri = new TimeSeriesUri(jagentId, 'x_posts', 'posts', { last: '10' });
	const xPostsSeries = new TimeSeries(xPostsUri, graph.store);
	xPostsSeries.init();
	const xPostsData = xPostsSeries.data;

	if (xPostsData.length > 0) {
		const record = xPostsData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('x_posts: date must be a positive number (ms)');
		}
		if (typeof record.id !== 'string') {
			throw new Error('x_posts: id must be a string');
		}
		if (typeof record.content !== 'string') {
			throw new Error('x_posts: content must be a string');
		}
		if (typeof record.author !== 'object') {
			throw new Error('x_posts: author must be an object');
		}
		if (typeof record.metrics !== 'object') {
			throw new Error('x_posts: metrics must be an object');
		}
		log('✓ x_posts node output validated');
	}

	const xFollowersUri = new TimeSeriesUri(jagentId, 'x_followers', 'followers', { last: '10' });
	const xFollowersSeries = new TimeSeries(xFollowersUri, graph.store);
	xFollowersSeries.init();
	const xFollowersData = xFollowersSeries.data;

	if (xFollowersData.length > 0) {
		const record = xFollowersData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('x_followers: date must be a positive number (ms)');
		}
		if (typeof record.id !== 'string') {
			throw new Error('x_followers: id must be a string');
		}
		if (typeof record.username !== 'string') {
			throw new Error('x_followers: username must be a string');
		}
		if (typeof record.name !== 'string') {
			throw new Error('x_followers: name must be a string');
		}
		if (record.description != null && typeof record.description !== 'string') {
			throw new Error('x_followers: description must be a string or null/undefined');
		}
		if (typeof record.followers_count !== 'number') {
			throw new Error('x_followers: followers_count must be a number');
		}
		if (typeof record.followings_count !== 'number') {
			throw new Error('x_followers: followings_count must be a number');
		}
		if (typeof record.verified !== 'boolean') {
			throw new Error('x_followers: verified must be a boolean');
		}
		log('✓ x_followers node output validated');
	}

	const xFollowingsUri = new TimeSeriesUri(jagentId, 'x_followings', 'followings', { last: '10' });
	const xFollowingsSeries = new TimeSeries(xFollowingsUri, graph.store);
	xFollowingsSeries.init();
	const xFollowingsData = xFollowingsSeries.data;

	if (xFollowingsData.length > 0) {
		const record = xFollowingsData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('x_followings: date must be a positive number (ms)');
		}
		if (typeof record.id !== 'string') {
			throw new Error('x_followings: id must be a string');
		}
		if (typeof record.username !== 'string') {
			throw new Error('x_followings: username must be a string');
		}
		if (typeof record.name !== 'string') {
			throw new Error('x_followings: name must be a string');
		}
		if (record.description != null && typeof record.description !== 'string') {
			throw new Error('x_followings: description must be a string or null/undefined');
		}
		if (typeof record.followers_count !== 'number') {
			throw new Error('x_followings: followers_count must be a number');
		}
		if (typeof record.followings_count !== 'number') {
			throw new Error('x_followings: followings_count must be a number');
		}
		if (typeof record.verified !== 'boolean') {
			throw new Error('x_followings: verified must be a boolean');
		}
		log('✓ x_followings node output validated');
	}

	const xSearchUri = new TimeSeriesUri(jagentId, 'x_search', 'search_results', { last: '10' });
	const xSearchSeries = new TimeSeries(xSearchUri, graph.store);
	xSearchSeries.init();
	const xSearchData = xSearchSeries.data;

	if (xSearchData.length > 0) {
		const record = xSearchData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('x_search: date must be a positive number (ms)');
		}
		if (typeof record.query !== 'string') {
			throw new Error('x_search: query must be a string');
		}
		if (!Array.isArray(record.results)) {
			throw new Error('x_search: results must be an array');
		}
		log('✓ x_search node output validated');
	}

	// Validate refs metadata are injected correctly for each get* function outputs
	// x_user -> user_profile
	{
		const refs = graph.getRefsForOutput('x_user', 'user_profile');
		if (refs.length > 0) {
			const ref = refs[0];
			const expected = {
				id: '@alva/data/social/x/getXUser',
				module_name: '@alva/data/social/x',
				module_display_name: 'Real-time X Search',
				sdk_name: 'getXUser',
				sdk_display_name: 'X Profile Details',
				source_name: 'X',
				source: 'https://docs.x.com/x-api/introduction',
			};

			if (ref.id !== expected.id) throw new Error('x_user ref.id mismatch');
			if (ref.module_name !== expected.module_name) throw new Error('x_user ref.module_name mismatch');
			if (ref.module_display_name !== expected.module_display_name) throw new Error('x_user ref.module_display_name mismatch');
			if (ref.sdk_name !== expected.sdk_name) throw new Error('x_user ref.sdk_name mismatch');
			if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('x_user ref.sdk_display_name mismatch');
			if (ref.source_name !== expected.source_name) throw new Error('x_user ref.source_name mismatch');
			if (ref.source !== expected.source) throw new Error('x_user ref.source mismatch');
			log('✓ x_user refs validated');
		} else {
			throw new Error('Assertion failed: x_user refs array is empty.');
		}
	}

	// x_posts -> posts
	{
		const refs = graph.getRefsForOutput('x_posts', 'posts');
		if (refs.length > 0) {
			const ref = refs[0];
			const expected = {
				id: '@alva/data/social/x/getXPosts',
				module_name: '@alva/data/social/x',
				module_display_name: 'Real-time X Search',
				sdk_name: 'getXPosts',
				sdk_display_name: 'X User Posts',
				source_name: 'X',
				source: 'https://docs.x.com/x-api/introduction',
			};
			if (ref.id !== expected.id) throw new Error('x_posts ref.id mismatch');
			if (ref.module_name !== expected.module_name) throw new Error('x_posts ref.module_name mismatch');
			if (ref.module_display_name !== expected.module_display_name) throw new Error('x_posts ref.module_display_name mismatch');
			if (ref.sdk_name !== expected.sdk_name) throw new Error('x_posts ref.sdk_name mismatch');
			if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('x_posts ref.sdk_display_name mismatch');
			if (ref.source_name !== expected.source_name) throw new Error('x_posts ref.source_name mismatch');
			if (ref.source !== expected.source) throw new Error('x_posts ref.source mismatch');
			log('✓ x_posts refs validated');
		} else {
			throw new Error('Assertion failed: x_posts refs array is empty.');
		}
	}

	// x_followers -> followers
	{
		const refs = graph.getRefsForOutput('x_followers', 'followers');
		if (refs.length > 0) {
			const ref = refs[0];
			const expected = {
				id: '@alva/data/social/x/getXFollowers',
				module_name: '@alva/data/social/x',
				module_display_name: 'Real-time X Search',
				sdk_name: 'getXFollowers',
				sdk_display_name: 'X Follower Tracker',
				source_name: 'X',
				source: 'https://docs.x.com/x-api/introduction',
			};
			if (ref.id !== expected.id) throw new Error('x_followers ref.id mismatch');
			if (ref.module_name !== expected.module_name) throw new Error('x_followers ref.module_name mismatch');
			if (ref.module_display_name !== expected.module_display_name) throw new Error('x_followers ref.module_display_name mismatch');
			if (ref.sdk_name !== expected.sdk_name) throw new Error('x_followers ref.sdk_name mismatch');
			if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('x_followers ref.sdk_display_name mismatch');
			if (ref.source_name !== expected.source_name) throw new Error('x_followers ref.source_name mismatch');
			if (ref.source !== expected.source) throw new Error('x_followers ref.source mismatch');
			log('✓ x_followers refs validated');
		} else {
			throw new Error('Assertion failed: x_followers refs array is empty.');
		}
	}

	// x_followings -> followings
	{
		const refs = graph.getRefsForOutput('x_followings', 'followings');
		if (refs.length > 0) {
			const ref = refs[0];
			const expected = {
				id: '@alva/data/social/x/getXFollowings',
				module_name: '@alva/data/social/x',
				module_display_name: 'Real-time X Search',
				sdk_name: 'getXFollowings',
				sdk_display_name: 'X Following Activity',
				source_name: 'X',
				source: 'https://docs.x.com/x-api/introduction',
			};
			if (ref.id !== expected.id) throw new Error('x_followings ref.id mismatch');
			if (ref.module_name !== expected.module_name) throw new Error('x_followings ref.module_name mismatch');
			if (ref.module_display_name !== expected.module_display_name) throw new Error('x_followings ref.module_display_name mismatch');
			if (ref.sdk_name !== expected.sdk_name) throw new Error('x_followings ref.sdk_name mismatch');
			if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('x_followings ref.sdk_display_name mismatch');
			if (ref.source_name !== expected.source_name) throw new Error('x_followings ref.source_name mismatch');
			if (ref.source !== expected.source) throw new Error('x_followings ref.source mismatch');
			log('✓ x_followings refs validated');
		} else {
			throw new Error('Assertion failed: x_followings refs array is empty.');
		}
	}

	// Validate corner case: multi-keyword query
	{
		const uri = new TimeSeriesUri(jagentId, 'x_search_multi_keyword', 'search_results', { last: '1' });
		const series = new TimeSeries(uri, graph.store);
		series.init();
		if (series.data.length >= 0) {
			log('✓ x_search_multi_keyword (corner case: multiple keywords) validated');
		}
	}

	// Validate corner case: hashtag query
	{
		const uri = new TimeSeriesUri(jagentId, 'x_search_hashtag', 'search_results', { last: '1' });
		const series = new TimeSeries(uri, graph.store);
		series.init();
		if (series.data.length >= 0) {
			log('✓ x_search_hashtag (corner case: hashtag #) validated');
		}
	}

	// Validate corner case: UTF-8 encoding (Chinese + emoji)
	{
		const uri = new TimeSeriesUri(jagentId, 'x_search_utf8', 'search_results', { last: '1' });
		const series = new TimeSeries(uri, graph.store);
		series.init();
		if (series.data.length >= 0) {
			log('✓ x_search_utf8 (corner case: UTF-8 比特币 🚀) validated');
		}
	}

	// Validate corner case: short time range posts
	{
		const uri = new TimeSeriesUri(jagentId, 'x_posts_short_time', 'posts', { last: '1' });
		const series = new TimeSeries(uri, graph.store);
		series.init();
		if (series.data.length >= 0) {
			log('✓ x_posts_short_time (corner case: 1 day time range) validated');
		}
	}

	// Validate corner case: alternative followers
	{
		const uri = new TimeSeriesUri(jagentId, 'x_followers_alt', 'followers', { last: '1' });
		const series = new TimeSeries(uri, graph.store);
		series.init();
		if (series.data.length >= 0) {
			log('✓ x_followers_alt (corner case: short time range followers) validated');
		}
	}

	log('✅ X social make*Node tests passed');
	return 0;
}

main();
