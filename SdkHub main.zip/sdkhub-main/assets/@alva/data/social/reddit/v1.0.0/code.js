const { sdkRelay } = require('sdkrelay');
const { useCredit } = require('internal');

// Refs derived from tool.json
const getRedditUserPostsRef = {
    id: '@alva/data/social/reddit/getRedditUserPosts',
    module_name: '@alva/data/social/reddit',
    module_display_name: 'Real-time Reddit Search',
    sdk_name: 'getRedditUserPosts',
    sdk_display_name: 'Reddit User Post',
    source_name: 'Reddit',
    source: 'https://www.reddit.com/dev/api/',
};

const getSubRedditHotPostsRef = {
    id: '@alva/data/social/reddit/getSubRedditHotPosts',
    module_name: '@alva/data/social/reddit',
    module_display_name: 'Real-time Reddit Search',
    sdk_name: 'getSubRedditHotPosts',
    sdk_display_name: 'Reddit Trending Post',
    source_name: 'Reddit',
    source: 'https://www.reddit.com/dev/api/',
};

const getSubRedditNewPostsRef = {
    id: '@alva/data/social/reddit/getSubRedditNewPosts',
    module_name: '@alva/data/social/reddit',
    module_display_name: 'Real-time Reddit Search',
    sdk_name: 'getSubRedditNewPosts',
    sdk_display_name: 'Reddit New Post',
    source_name: 'Reddit',
    source: 'https://www.reddit.com/dev/api/',
};

// ---- Base descriptions derived from doc ----
const baseGetRedditUserPostsDescription = 'Search Reddit user posts';
const baseGetSubRedditHotPostsDescription = 'Get Reddit hot posts';
const baseGetSubRedditNewPostsDescription = 'Get Reddit new posts';

// ---- Dynamic description builders (internal use only, not exported) ----
function buildGetRedditUserPostsCallDescription(actualParams = {}) {
    const parts = [baseGetRedditUserPostsDescription];

    if (actualParams.username) {
        parts.push(`by ${actualParams.username}`);
    }

    const filters = [];
    if (actualParams.start_time && actualParams.end_time) {
        filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
    } else if (actualParams.start_time) {
        filters.push(`Time from: ${actualParams.start_time}`);
    } else if (actualParams.end_time) {
        filters.push(`Time to: ${actualParams.end_time}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function buildGetSubRedditHotPostsCallDescription(actualParams = {}) {
    const parts = [baseGetSubRedditHotPostsDescription];

    if (actualParams.subreddit) {
        parts.push(`from r/${actualParams.subreddit}`);
    }

    const filters = [];
    if (actualParams.geo && actualParams.geo !== 'GLOBAL') {
        filters.push(`Geo: ${actualParams.geo}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function buildGetSubRedditNewPostsCallDescription(actualParams = {}) {
    const parts = [baseGetSubRedditNewPostsDescription];

    if (actualParams.subreddit) {
        parts.push(`from r/${actualParams.subreddit}`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getRedditUserPosts(params) {
    useCredit('getRedditUserPosts', 1500);
    return sdkRelay('GetRedditUserPosts', params);
}

function getSubRedditHotPosts(params) {
    useCredit('getSubRedditHotPosts', 1500);
    return sdkRelay('GetSubRedditHotPosts', params);
}

function getSubRedditNewPosts(params) {
    useCredit('getSubRedditNewPosts', 1500);
    return sdkRelay('GetSubRedditNewPosts', params);
}

function toMs(value) {
    if (value == null) return null;
    if (typeof value === 'number') return value > 1e12 ? value : value * 1000;
    if (typeof value === 'string') {
        const parsed = Date.parse(value);
        if (!Number.isNaN(parsed)) return parsed;
    }
    return null;
}

// Ensure strictly increasing unique dates by sorting ascending and bumping ties by +1ms
function ensureUniqueDateAscending(records) {
    if (!Array.isArray(records)) return [];
    const arr = records.slice().sort((a, b) => a.date - b.date);
    for (let i = 1; i < arr.length; i++) {
        if (arr[i].date <= arr[i - 1].date) {
            arr[i].date = arr[i - 1].date + 1;
        }
    }
    return arr;
}

function mapPosts(posts) {
    const src = Array.isArray(posts) ? posts : [];
    return src
        .map((item) => {
            const ts = toMs(item.created_at);
            if (ts == null) return null;
            return {
                date: ts,
                post_id: item.post_id || item.id,
                title: item.title,
                selftext: item.selftext,
                author: item.author,
                subreddit: item.subreddit,
                score: item.score,
                num_comments: item.num_comments,
                url: item.url,
            };
        })
        .filter(Boolean);
}

function makeRedditUserPostsNode(params) {
    return {
        inputs: {
            posts_raw: () => getRedditUserPosts(params),
        },
        outputs: {
            user_posts: {
                name: 'reddit_user_posts',
                description: 'Reddit user posts',
                fields: [
                    { name: 'date', type: 'number', description: 'post time ms' },
                    { name: 'post_id', type: 'string', description: 'post id' },
                    { name: 'title', type: 'string', description: 'post title' },
                    { name: 'selftext', type: 'string', description: 'post content' },
                    { name: 'author', type: 'string', description: 'author username' },
                    { name: 'subreddit', type: 'string', description: 'subreddit name' },
                    { name: 'score', type: 'number', description: 'score' },
                    { name: 'num_comments', type: 'number', description: 'number of comments' },
                    { name: 'url', type: 'string', description: 'post URL' },
                ],
                ref: createReferenceWithTitle(getRedditUserPostsRef, params, buildGetRedditUserPostsCallDescription),
            },
        },
        run: (inputs) => {
            const arr = mapPosts(inputs.posts_raw);
            return { user_posts: ensureUniqueDateAscending(arr) };
        },
    };
}

function makeSubRedditHotPostsNode(params) {
    return {
        inputs: {
            hot_posts_raw: () => getSubRedditHotPosts(params),
        },
        outputs: {
            hot_posts: {
                name: 'reddit_hot_posts',
                description: 'Hot posts for subreddit',
                fields: [
                    { name: 'date', type: 'number', description: 'post time ms' },
                    { name: 'post_id', type: 'string', description: 'post id' },
                    { name: 'title', type: 'string', description: 'post title' },
                    { name: 'selftext', type: 'string', description: 'post content' },
                    { name: 'author', type: 'string', description: 'author username' },
                    { name: 'subreddit', type: 'string', description: 'subreddit name' },
                    { name: 'score', type: 'number', description: 'score' },
                    { name: 'num_comments', type: 'number', description: 'number of comments' },
                    { name: 'url', type: 'string', description: 'post URL' },
                ],
                ref: createReferenceWithTitle(getSubRedditHotPostsRef, params, buildGetSubRedditHotPostsCallDescription),
            },
        },
        run: (inputs) => {
            const arr = mapPosts(inputs.hot_posts_raw);
            return { hot_posts: ensureUniqueDateAscending(arr) };
        },
    };
}

function makeSubRedditNewPostsNode(params) {
    return {
        inputs: {
            new_posts_raw: () => getSubRedditNewPosts(params),
        },
        outputs: {
            new_posts: {
                name: 'reddit_new_posts',
                description: 'New posts for subreddit',
                fields: [
                    { name: 'date', type: 'number', description: 'post time ms' },
                    { name: 'post_id', type: 'string', description: 'post id' },
                    { name: 'title', type: 'string', description: 'post title' },
                    { name: 'selftext', type: 'string', description: 'post content' },
                    { name: 'author', type: 'string', description: 'author username' },
                    { name: 'subreddit', type: 'string', description: 'subreddit name' },
                    { name: 'score', type: 'number', description: 'score' },
                    { name: 'num_comments', type: 'number', description: 'number of comments' },
                    { name: 'url', type: 'string', description: 'post URL' },
                ],
                ref: createReferenceWithTitle(getSubRedditNewPostsRef, params, buildGetSubRedditNewPostsCallDescription),
            },
        },
        run: (inputs) => {
            const arr = mapPosts(inputs.new_posts_raw);
            return { new_posts: ensureUniqueDateAscending(arr) };
        },
    };
}
function getRefs() {
    return [
        getRedditUserPostsRef,
        getSubRedditHotPostsRef,
        getSubRedditNewPostsRef,
    ];
}

module.exports = {
    getRedditUserPosts,
    getSubRedditHotPosts,
    getSubRedditNewPosts,
    makeRedditUserPostsNode,
    makeSubRedditHotPostsNode,
    makeSubRedditNewPostsNode,
    getRefs,
};
