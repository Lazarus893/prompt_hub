function main() {
	const { Graph } = require('@alva/graph:v1.0.0');
	const { jagentId } = require('env');
	const { makeRedditUserPostsNode, makeSubRedditHotPostsNode, makeSubRedditNewPostsNode } = require('@alva/data/social/reddit:v1.0.0');

	const g = new Graph(jagentId);

	g.addNode(
		'reddit_user_posts',
		makeRedditUserPostsNode({
			username: 'Significant_Pin_920',
			start_time: 1737639784, // seconds
			end_time: 1737639784 + 30 * 24 * 60 * 60, // +30d in seconds
		})
	);

	g.addNode('reddit_hot_posts', makeSubRedditHotPostsNode({ subreddit: 'technology', geo: 'GLOBAL' }));

	g.addNode('reddit_new_posts', makeSubRedditNewPostsNode({ subreddit: 'ethereum' }));

	// Corner case tests
	// Test 1: Short time range (edge case for time range)
	g.addNode(
		'reddit_user_posts_short_time',
		makeRedditUserPostsNode({
			username: 'Significant_Pin_920',
			start_time: 1737639784,
			end_time: 1737639784 + 1 * 24 * 60 * 60, // Only 1 day
		})
	);

	// Test 2: Same subreddit different geo (parameter variation)
	g.addNode('reddit_hot_posts_diff_geo', makeSubRedditHotPostsNode({ subreddit: 'technology', geo: 'US' }));

	// Test 3: Long time range (edge case)
	g.addNode(
		'reddit_user_posts_long_time',
		makeRedditUserPostsNode({
			username: 'Significant_Pin_920',
			start_time: 1737639784,
			end_time: 1737639784 + 90 * 24 * 60 * 60, // 90 days
		})
	);

	g.run();
	const { TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');

	const userPostsUri = new TimeSeriesUri(jagentId, 'reddit_user_posts', 'user_posts', { last: '10' });
	const userPostsSeries = new TimeSeries(userPostsUri, g.store);
	userPostsSeries.init();
	const userPostsData = userPostsSeries.data;

	if (userPostsData.length > 0) {
		const record = userPostsData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('reddit_user_posts: date must be a positive number (ms)');
		}
		if (typeof record.post_id !== 'string') {
			throw new Error('reddit_user_posts: post_id must be a string');
		}
		if (typeof record.title !== 'string') {
			throw new Error('reddit_user_posts: title must be a string');
		}
		if (typeof record.selftext !== 'string') {
			throw new Error('reddit_user_posts: selftext must be a string');
		}
		if (typeof record.author !== 'string') {
			throw new Error('reddit_user_posts: author must be a string');
		}
		if (typeof record.subreddit !== 'string') {
			throw new Error('reddit_user_posts: subreddit must be a string');
		}
		if (typeof record.score !== 'number') {
			throw new Error('reddit_user_posts: score must be a number');
		}
		if (typeof record.num_comments !== 'number') {
			throw new Error('reddit_user_posts: num_comments must be a number');
		}
		if (typeof record.url !== 'string') {
			throw new Error('reddit_user_posts: url must be a string');
		}
		log('✓ reddit_user_posts node output validated');
	}

	const hotPostsUri = new TimeSeriesUri(jagentId, 'reddit_hot_posts', 'hot_posts', { last: '10' });
	const hotPostsSeries = new TimeSeries(hotPostsUri, g.store);
	hotPostsSeries.init();
	const hotPostsData = hotPostsSeries.data;

	if (hotPostsData.length > 0) {
		const record = hotPostsData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('reddit_hot_posts: date must be a positive number (ms)');
		}
		if (typeof record.post_id !== 'string') {
			throw new Error('reddit_hot_posts: post_id must be a string');
		}
		if (typeof record.title !== 'string') {
			throw new Error('reddit_hot_posts: title must be a string');
		}
		if (typeof record.author !== 'string') {
			throw new Error('reddit_hot_posts: author must be a string');
		}
		if (typeof record.subreddit !== 'string') {
			throw new Error('reddit_hot_posts: subreddit must be a string');
		}
		if (typeof record.score !== 'number') {
			throw new Error('reddit_hot_posts: score must be a number');
		}
		if (typeof record.num_comments !== 'number') {
			throw new Error('reddit_hot_posts: num_comments must be a number');
		}
		if (typeof record.url !== 'string') {
			throw new Error('reddit_hot_posts: url must be a string');
		}
		log('✓ reddit_hot_posts node output validated');
	}

	const newPostsUri = new TimeSeriesUri(jagentId, 'reddit_new_posts', 'new_posts', { last: '10' });
	const newPostsSeries = new TimeSeries(newPostsUri, g.store);
	newPostsSeries.init();
	const newPostsData = newPostsSeries.data;

	if (newPostsData.length > 0) {
		const record = newPostsData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('reddit_new_posts: date must be a positive number (ms)');
		}
		if (typeof record.post_id !== 'string') {
			throw new Error('reddit_new_posts: post_id must be a string');
		}
		if (typeof record.title !== 'string') {
			throw new Error('reddit_new_posts: title must be a string');
		}
		if (typeof record.author !== 'string') {
			throw new Error('reddit_new_posts: author must be a string');
		}
		if (typeof record.subreddit !== 'string') {
			throw new Error('reddit_new_posts: subreddit must be a string');
		}
		if (typeof record.score !== 'number') {
			throw new Error('reddit_new_posts: score must be a number');
		}
		if (typeof record.num_comments !== 'number') {
			throw new Error('reddit_new_posts: num_comments must be a number');
		}
		if (typeof record.url !== 'string') {
			throw new Error('reddit_new_posts: url must be a string');
		}
		log('✓ reddit_new_posts node output validated');
	}

	// Validate refs for outputs using Graph.getRefsForOutput
	{
		const refs = g.getRefsForOutput('reddit_user_posts', 'user_posts');
		if (refs.length > 0) {
			const ref = refs[0];
			const expected = {
				id: '@alva/data/social/reddit/getRedditUserPosts',
				module_name: '@alva/data/social/reddit',
				module_display_name: 'Real-time Reddit Search',
				sdk_name: 'getRedditUserPosts',
				sdk_display_name: 'Reddit User Post',
				source_name: 'Reddit',
				source: 'https://www.reddit.com/dev/api/',
			};

			if (ref.id !== expected.id) {
				throw new Error(`Assertion failed (user_posts.ref.id): expected ${expected.id}, got ${ref.id}`);
			}
			if (ref.module_name !== expected.module_name) {
				throw new Error(`Assertion failed (user_posts.ref.module_name): expected ${expected.module_name}, got ${ref.module_name}`);
			}
			if (ref.module_display_name !== expected.module_display_name) {
				throw new Error(`Assertion failed (user_posts.ref.module_display_name): expected ${expected.module_display_name}, got ${ref.module_display_name}`);
			}
			if (ref.sdk_name !== expected.sdk_name) {
				throw new Error(`Assertion failed (user_posts.ref.sdk_name): expected ${expected.sdk_name}, got ${ref.sdk_name}`);
			}
			if (ref.sdk_display_name !== expected.sdk_display_name) {
				throw new Error(`Assertion failed (user_posts.ref.sdk_display_name): expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
			}
			if (ref.source_name !== expected.source_name) {
				throw new Error(`Assertion failed (user_posts.ref.source_name): expected ${expected.source_name}, got ${ref.source_name}`);
			}
			if (ref.source !== expected.source) {
				throw new Error(`Assertion failed (user_posts.ref.source): expected ${expected.source}, got ${ref.source}`);
			}
			log('✓ reddit_user_posts refs validated');
		} else {
			throw new Error('Assertion failed: refs array for reddit_user_posts.user_posts is empty.');
		}
	}

	{
		const refs = g.getRefsForOutput('reddit_hot_posts', 'hot_posts');
		if (refs.length > 0) {
			const ref = refs[0];
			const expected = {
				id: '@alva/data/social/reddit/getSubRedditHotPosts',
				module_name: '@alva/data/social/reddit',
				module_display_name: 'Real-time Reddit Search',
				sdk_name: 'getSubRedditHotPosts',
				sdk_display_name: 'Reddit Trending Post',
				source_name: 'Reddit',
				source: 'https://www.reddit.com/dev/api/',
			};

			if (ref.id !== expected.id) {
				throw new Error(`Assertion failed (hot_posts.ref.id): expected ${expected.id}, got ${ref.id}`);
			}
			if (ref.module_name !== expected.module_name) {
				throw new Error(`Assertion failed (hot_posts.ref.module_name): expected ${expected.module_name}, got ${ref.module_name}`);
			}
			if (ref.module_display_name !== expected.module_display_name) {
				throw new Error(`Assertion failed (hot_posts.ref.module_display_name): expected ${expected.module_display_name}, got ${ref.module_display_name}`);
			}
			if (ref.sdk_name !== expected.sdk_name) {
				throw new Error(`Assertion failed (hot_posts.ref.sdk_name): expected ${expected.sdk_name}, got ${ref.sdk_name}`);
			}
			if (ref.sdk_display_name !== expected.sdk_display_name) {
				throw new Error(`Assertion failed (hot_posts.ref.sdk_display_name): expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
			}
			if (ref.source_name !== expected.source_name) {
				throw new Error(`Assertion failed (hot_posts.ref.source_name): expected ${expected.source_name}, got ${ref.source_name}`);
			}
			if (ref.source !== expected.source) {
				throw new Error(`Assertion failed (hot_posts.ref.source): expected ${expected.source}, got ${ref.source}`);
			}
			log('✓ reddit_hot_posts refs validated');
		} else {
			throw new Error('Assertion failed: refs array for reddit_hot_posts.hot_posts is empty.');
		}
	}

	{
		const refs = g.getRefsForOutput('reddit_new_posts', 'new_posts');
		if (refs.length > 0) {
			const ref = refs[0];
			const expected = {
				id: '@alva/data/social/reddit/getSubRedditNewPosts',
				module_name: '@alva/data/social/reddit',
				module_display_name: 'Real-time Reddit Search',
				sdk_name: 'getSubRedditNewPosts',
				sdk_display_name: 'Reddit New Post',
				source_name: 'Reddit',
				source: 'https://www.reddit.com/dev/api/',
			};

			if (ref.id !== expected.id) {
				throw new Error(`Assertion failed (new_posts.ref.id): expected ${expected.id}, got ${ref.id}`);
			}
			if (ref.module_name !== expected.module_name) {
				throw new Error(`Assertion failed (new_posts.ref.module_name): expected ${expected.module_name}, got ${ref.module_name}`);
			}
			if (ref.module_display_name !== expected.module_display_name) {
				throw new Error(`Assertion failed (new_posts.ref.module_display_name): expected ${expected.module_display_name}, got ${ref.module_display_name}`);
			}
			if (ref.sdk_name !== expected.sdk_name) {
				throw new Error(`Assertion failed (new_posts.ref.sdk_name): expected ${expected.sdk_name}, got ${ref.sdk_name}`);
			}
			if (ref.sdk_display_name !== expected.sdk_display_name) {
				throw new Error(`Assertion failed (new_posts.ref.sdk_display_name): expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
			}
			if (ref.source_name !== expected.source_name) {
				throw new Error(`Assertion failed (new_posts.ref.source_name): expected ${expected.source_name}, got ${ref.source_name}`);
			}
			if (ref.source !== expected.source) {
				throw new Error(`Assertion failed (new_posts.ref.source): expected ${expected.source}, got ${ref.source}`);
			}
			log('✓ reddit_new_posts refs validated');
		} else {
			throw new Error('Assertion failed: refs array for reddit_new_posts.new_posts is empty.');
		}
	}

	// Validate corner case: short time range
	{
		const uri = new TimeSeriesUri(jagentId, 'reddit_user_posts_short_time', 'user_posts', { last: '1' });
		const series = new TimeSeries(uri, g.store);
		series.init();
		if (series.data.length >= 0) {
			log('✓ reddit_user_posts_short_time (corner case: 1 day time range) validated');
		}
	}

	// Validate corner case: different geo parameter
	{
		const uri = new TimeSeriesUri(jagentId, 'reddit_hot_posts_diff_geo', 'hot_posts', { last: '1' });
		const series = new TimeSeries(uri, g.store);
		series.init();
		if (series.data.length >= 0) {
			log('✓ reddit_hot_posts_diff_geo (corner case: geo=US parameter) validated');
		}
	}

	// Validate corner case: long time range (90 days)
	{
		const uri = new TimeSeriesUri(jagentId, 'reddit_user_posts_long_time', 'user_posts', { last: '1' });
		const series = new TimeSeries(uri, g.store);
		series.init();
		if (series.data.length >= 0) {
			log('✓ reddit_user_posts_long_time (corner case: 90 day time range) validated');
		}
	}

	log('✅ Reddit make*Node tests passed');
	return 0;
}

main();
