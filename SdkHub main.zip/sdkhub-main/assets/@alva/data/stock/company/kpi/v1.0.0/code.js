const { sdkRelay } = require('sdkrelay');
const { useCredit } = require('internal');

/**
 * Original SDK call: search for company financial KPIs
 */
function getKpis(params) {
  useCredit('getKpis', 350);
  return sdkRelay('GetKpis', params);
}

/**
 * Reference metadata for getKpis, derived from tool.json
 */
const getKpisRef = {
  id: '@alva/data/stock/company/kpi/getKpis',
  module_name: '@alva/data/stock/company/kpi',
  module_display_name: 'Company KPI & Operating Metrics',
  sdk_name: 'getKpis',
  sdk_display_name: 'Company KPI & Operating Metrics',
  source_name: 'Fiscal.ai',
  source: 'https://docs.fiscal.ai/docs/api-reference#segments-and-kpis',
};

// -------------------------------------------------------------------------------------
// Internal dynamic call description builders (derived from doc). Not exported.
// -------------------------------------------------------------------------------------

/**
 * getKpis summary (from doc): Search for company financial KPIs by ticker/exchange/period_type with keyword and optional time range.
 */
const getKpisBaseFuncDesc = 'Search company financial KPIs';

function buildGetKpisCallDescription(actualParams = {}) {
  const parts = [getKpisBaseFuncDesc];

  // Key identifiers
  if (actualParams.ticker) {
    parts.push(`for ${actualParams.ticker}`);
  }
  if (actualParams.exchange) {
    parts.push(`on ${actualParams.exchange}`);
  }
  if (actualParams.period_type) {
    parts.push(`(${actualParams.period_type})`);
  }

  // Optional filters
  const filters = [];
  if (actualParams.keyword) {
    filters.push(`Keyword: ${actualParams.keyword}`);
  }

  if (actualParams.start_time && actualParams.end_time) {
    filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
  } else if (actualParams.start_time) {
    filters.push(`Time from: ${actualParams.start_time}`);
  } else if (actualParams.end_time) {
    filters.push(`Time until: ${actualParams.end_time}`);
  }

  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }

  return parts.join(' ').trim();
}

/**
 * makeKpisNode summary (from doc): Create a KPI graph node that aggregates KPI search results as grouped time-series records.
 */
const makeKpisNodeBaseFuncDesc = 'Create KPI aggregation node';

function buildMakeKpisNodeCallDescription(actualParams = {}) {
  const parts = [makeKpisNodeBaseFuncDesc];

  // Key identifiers (same shape as getKpis params based on doc/example)
  if (actualParams.ticker) {
    parts.push(`for ${actualParams.ticker}`);
  }
  if (actualParams.exchange) {
    parts.push(`on ${actualParams.exchange}`);
  }
  if (actualParams.period_type) {
    parts.push(`(${actualParams.period_type})`);
  }

  // Optional filters
  const filters = [];
  if (actualParams.keyword) {
    filters.push(`Keyword: ${actualParams.keyword}`);
  }

  if (actualParams.start_time && actualParams.end_time) {
    filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
  } else if (actualParams.start_time) {
    filters.push(`Time from: ${actualParams.start_time}`);
  } else if (actualParams.end_time) {
    filters.push(`Time until: ${actualParams.end_time}`);
  }

  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }

  return parts.join(' ').trim();
}

/**
 * Create a reference object with a computed title based on params and builder
 */
function createReferenceWithTitle(refObject, params, titleBuilder) {
  // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
  const title = titleBuilder(params);

  // 2. 组合 refObject 和新 title
  const newObject = {
    ...refObject,
    title: title,
  };

  // 3. 返回新对象
  return newObject;
}

/**
 * Parse report_date string into ms epoch
 */
function parseReportDate(value) {
  if (value == null) return null;
  const parsed = Date.parse(value);
  if (Number.isNaN(parsed)) return null;
  return parsed;
}

/**
 * Nodified SDK node factory: groups KPIs by report date and aggregates per-company metrics
 */
function makeKpisNode(params) {
  return {
    inputs: {
      // Fetch raw KPIs from the SDK; no transformation here.
      kpis_raw: () => getKpis(params),
    },
    outputs: {
      kpis: {
        name: 'company_kpis',
        description:
          'Financial KPIs grouped by report date; one record per report date with per-company metrics',
        fields: [
          { name: 'date', type: 'number', description: 'report date in ms (UTC)' },
          {
            name: 'companies',
            type: 'array',
            description: 'companies with KPIs on this report date',
            fields: [
              { name: 'ticker', type: 'string', description: 'instrument ticker' },
              { name: 'exchange', type: 'string', description: 'trading venue' },
              { name: 'period_type', type: 'string', description: 'reporting period type' },
              {
                name: 'metrics',
                type: 'array',
                description: 'metrics for this company at this report date',
                fields: [
                  { name: 'metric_name', type: 'string', description: 'metric identifier' },
                  { name: 'value', type: 'number', description: 'metric value' },
                ],
              },
            ],
          },
        ],
        ref: createReferenceWithTitle(getKpisRef, params, buildMakeKpisNodeCallDescription),
      },
    },
    run: (inputs) => {
      const raw = Array.isArray(inputs.kpis_raw) ? inputs.kpis_raw : [];

      // Group by report date (ms) -> per-company -> metrics
      const byDate = new Map(); // dateMs -> Map(companyKey -> { ticker, exchange, period_type, metrics: Map(name->value) })

      for (const item of raw) {
        const dateMs = parseReportDate(item.report_date);
        if (dateMs == null) continue;

        let companies = byDate.get(dateMs);
        if (!companies) {
          companies = new Map();
          byDate.set(dateMs, companies);
        }

        const ticker = item.ticker;
        const exchange = item.exchange;
        const period_type = item.period_type;
        const companyKey = `${ticker}::${exchange}::${period_type}`;

        let company = companies.get(companyKey);
        if (!company) {
          company = {
            ticker,
            exchange,
            period_type,
            metrics: new Map(),
          };
          companies.set(companyKey, company);
        }

        // Last-write-wins for duplicate metric_name within same company/date
        company.metrics.set(item.metric_name, item.value);
      }

      const dates = Array.from(byDate.keys()).sort((a, b) => a - b);

      const out = dates.map((date) => {
        const companiesMap = byDate.get(date);
        const companies = Array.from(companiesMap.values())
          .sort((a, b) => {
            // deterministic ordering
            if (a.ticker !== b.ticker) return String(a.ticker).localeCompare(String(b.ticker));
            if (a.exchange !== b.exchange) return String(a.exchange).localeCompare(String(b.exchange));
            return String(a.period_type).localeCompare(String(b.period_type));
          })
          .map((c) => ({
            ticker: c.ticker,
            exchange: c.exchange,
            period_type: c.period_type,
            metrics: Array.from(c.metrics.entries())
              .sort((x, y) => String(x[0]).localeCompare(String(y[0])))
              .map(([metric_name, value]) => ({ metric_name, value })),
          }));

        return { date, companies };
      });

      return { kpis: out };
    },
  };
}

/**
 * Get all reference metadata objects defined in this module.
 */
function getRefs() {
  return [getKpisRef];
}

module.exports = {
  getKpis,
  makeKpisNode,
  getRefs,
};
