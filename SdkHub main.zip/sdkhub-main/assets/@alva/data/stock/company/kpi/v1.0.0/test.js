// Assertion helpers
function assert(cond, msg) {
  if (!cond) throw new Error(msg || 'assertion failed');
}
function isInteger(n) { return Number.isInteger(n); }
function isMsEpoch(n) { return typeof n === 'number' && isInteger(n) && n > 0 && n > 10_000_000_000; }
function hasUniqueDates(rows) {
  const s = new Set();
  for (const r of rows) {
    if (s.has(r.date)) return false;
    s.add(r.date);
  }
  return true;
}
function expectFieldsMatch(rows, fieldNames) {
  for (const r of rows) {
    const got = Object.keys(r);
	assert(got.includes('date'), 'missing required field: "date"');
    for (const f of fieldNames) assert(got.includes(f), `missing field: ${f}`);
  }
}

// Node output checker
const { TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');

async function checkNodeOutput(graph, jagentId, nodeId, outputName, {
  expectFields = [],
  preloadLast = '200',
  extra = null
} = {}) {
  const uri = new TimeSeriesUri(jagentId, nodeId, outputName, { last: preloadLast });
  const view = new TimeSeries(uri, graph.store);
  view.init();
  const rows = view.data.slice();

  if (rows.length === 0) {
	throw new Error(`no rows returned for node ${nodeId} output ${outputName}`);
  }

  console.log(rows);

  // Basic invariants
  for (const r of rows) {
    assert(typeof r === 'object' && r != null, 'row must be object');
    assert(isMsEpoch(r.date), `date must be ms epoch, got: ${r.date}`);
  }
  assert(hasUniqueDates(rows), 'duplicate "date" values within one output');

  // Schema check
  expectFieldsMatch(rows, expectFields);

  // Optional additional checks
  if (typeof extra === 'function') extra(rows, view);
  return rows;
}

// Schema validation
const EXPECT_KPIS_KEYS = ['date', 'companies'];
function expectKeysOrdered(row, expected) {
  const keys = Object.keys(row);
  for (let i = 0; i < expected.length; i++) {
    if (keys[i] !== expected[i]) throw new Error(`schema mismatch at ${i}: expected ${expected[i]}, got ${keys[i]}`);
  }
}

async function main() {
  const { Graph } = require('@alva/graph:v1.0.0');
  const { jagentId } = require('env');
  const { makeKpisNode } = require('@alva/data/stock/company/kpi:v1.0.0');

  const params = {
    ticker: 'MSFT',
    exchange: 'NASDAQ',
    period_type: 'annual',
    keyword: 'revenue',
    start_time: Math.floor(Date.UTC(2024, 0, 1) / 1000),
    end_time: Math.floor(Date.UTC(2024, 11, 1) / 1000),
  };

  const g = new Graph(jagentId);
  g.addNode('company_kpis', makeKpisNode(params));
  g.run();

  // Assert ref metadata exists and matches expected for output 'kpis'
  const refs = g.getRefsForOutput('company_kpis', 'kpis');
  if (refs.length > 0) {
    const ref = refs[0];
    const expected = {
      id: '@alva/data/stock/company/kpi/getKpis',
      module_name: '@alva/data/stock/company/kpi',
      module_display_name: 'Company KPI & Operating Metrics',
      sdk_name: 'getKpis',
      sdk_display_name: 'Company KPI & Operating Metrics',
      source_name: 'Fiscal.ai',
      source: 'https://docs.fiscal.ai/docs/api-reference#segments-and-kpis',
    };

    if (ref.id !== expected.id) {
      throw new Error(`ref.id mismatch: expected ${expected.id}, got ${ref.id}`);
    }
    if (ref.module_name !== expected.module_name) {
      throw new Error(`ref.module_name mismatch: expected ${expected.module_name}, got ${ref.module_name}`);
    }
    if (ref.module_display_name !== expected.module_display_name) {
      throw new Error(`ref.module_display_name mismatch: expected ${expected.module_display_name}, got ${ref.module_display_name}`);
    }
    if (ref.sdk_name !== expected.sdk_name) {
      throw new Error(`ref.sdk_name mismatch: expected ${expected.sdk_name}, got ${ref.sdk_name}`);
    }
    if (ref.sdk_display_name !== expected.sdk_display_name) {
      throw new Error(`ref.sdk_display_name mismatch: expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
    }
    if (ref.source_name !== expected.source_name) {
      throw new Error(`ref.source_name mismatch: expected ${expected.source_name}, got ${ref.source_name}`);
    }
    if (ref.source !== expected.source) {
      throw new Error(`ref.source mismatch: expected ${expected.source}, got ${ref.source}`);
    }
    console.log('✓ kpis refs validated');
  } else {
    throw new Error('Assertion failed: refs array is empty.');
  }

  // Comprehensive output validation
  const rows = await checkNodeOutput(g, jagentId, 'company_kpis', 'kpis', {
    expectFields: ['companies'],
    preloadLast: '50',
    extra: (rows) => {
      // Schema validation
      if (rows.length > 0) {
        expectKeysOrdered(rows[rows.length - 1], EXPECT_KPIS_KEYS);
      }

      // Content validation
      for (const r of rows) {
        assert(Array.isArray(r.companies), 'companies must be array');
        for (const c of r.companies) {
          ['ticker', 'exchange', 'period_type'].forEach(k =>
            assert(typeof c[k] === 'string', `company ${k} must be string`)
          );
          assert(Array.isArray(c.metrics), 'metrics must be array');
          for (const m of c.metrics) {
            assert(typeof m.metric_name === 'string', 'metric_name must be string');
            assert(typeof m.value === 'number', 'value must be number');
          }
        }
      }
    }
  });

  console.log('✅ makeKpisNode comprehensive test passed');
  return 0;
}

main();
