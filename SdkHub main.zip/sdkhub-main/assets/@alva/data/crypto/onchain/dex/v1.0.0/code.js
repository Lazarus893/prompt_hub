const { useCredit } = require('internal');
const cryptoQuantSDK = require('@alva/external/cryptoquant:v1.0.0');
const coinGlassSDK = require('@alva/external/coinglass:v1.0.0');

// Data source reference metadata (from tool.json)
const getVolumeRef = {
  id: '@alva/data/crypto/onchain/dex/getVolume',
  module_name: '@alva/data/crypto/onchain/dex',
  module_display_name: 'On-chain DEX Activity',
  sdk_name: 'getVolume',
  sdk_display_name: 'XRP DEX Volume',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/XRP-Dex-Data/operation/getDexVolume',
};

const getTransactionsCountRef = {
  id: '@alva/data/crypto/onchain/dex/getTransactionsCount',
  module_name: '@alva/data/crypto/onchain/dex',
  module_display_name: 'On-chain DEX Activity',
  sdk_name: 'getTransactionsCount',
  sdk_display_name: 'XRP DEX Transaction',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/XRP-Network-Data/operation/getTransactionsCount',
};

const getLiquidityRef = {
  id: '@alva/data/crypto/onchain/dex/getLiquidity',
  module_name: '@alva/data/crypto/onchain/dex',
  module_display_name: 'On-chain DEX Activity',
  sdk_name: 'getLiquidity',
  sdk_display_name: 'XRP DEX Liquidity',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/XRP-Dex-Data/operation/getDexLiquidity',
};

const getPriceRef = {
  id: '@alva/data/crypto/onchain/dex/getPrice',
  module_name: '@alva/data/crypto/onchain/dex',
  module_display_name: 'On-chain DEX Activity',
  sdk_name: 'getPrice',
  sdk_display_name: 'XRP DEX Price',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/XRP-Dex-Data/operation/getDexPrice',
};

const getHyperliquidWhaleAlertsRef = {
  id: '@alva/data/crypto/onchain/dex/getHyperliquidWhaleAlerts',
  module_name: '@alva/data/crypto/onchain/dex',
  module_display_name: 'On-chain DEX Activity',
  sdk_name: 'getHyperliquidWhaleAlerts',
  sdk_display_name: 'Hyperliquid Whales Alert',
  source_name: 'Coinglass',
  source: 'https://docs.coinglass.com/reference/hyperliquid-whale-alert',
};

const getHyperliquidWhalePositionsRef = {
  id: '@alva/data/crypto/onchain/dex/getHyperliquidWhalePositions',
  module_name: '@alva/data/crypto/onchain/dex',
  module_display_name: 'On-chain DEX Activity',
  sdk_name: 'getHyperliquidWhalePositions',
  sdk_display_name: 'Hyperliquid Whales Positions',
  source_name: 'Coinglass',
  source: 'https://docs.coinglass.com/reference/hyperliquid-whale-position',
};

// Auto-generated base descriptions and dynamic description builders (internal use only)
const getVolumeBaseDesc = 'Get DEX trading volume history';
const getTransactionsCountBaseDesc = 'Get DEX transaction counts history';
const getLiquidityBaseDesc = 'Get DEX USD liquidity history';
const getPriceBaseDesc = 'Get DEX USD price history';
const getHyperliquidWhaleAlertsBaseDesc = 'Get Hyperliquid whale alerts (> $1M)';
const getHyperliquidWhalePositionsBaseDesc = 'Get open Hyperliquid whale positions (> $1M)';

function formatTimeForDesc(v) {
  if (v == null) return '';
  if (typeof v === 'number') {
    const ms = v > 1e12 ? v : v * 1000;
    try {
      return new Date(ms).toISOString();
    } catch {
      return String(v);
    }
  }
  return String(v);
}

function buildGetVolumeCallDescription(actualParams = {}) {
  const parts = [getVolumeBaseDesc];
  if (actualParams.symbol) {
    parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.limit && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${formatTimeForDesc(actualParams.from)} to ${formatTimeForDesc(actualParams.to)}`);
  } else if (actualParams.from) {
    filters.push(`Time from: ${formatTimeForDesc(actualParams.from)}`);
  } else if (actualParams.to) {
    filters.push(`Time to: ${formatTimeForDesc(actualParams.to)}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetTransactionsCountCallDescription(actualParams = {}) {
  const parts = [getTransactionsCountBaseDesc];
  if (actualParams.symbol) {
    parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.limit && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${formatTimeForDesc(actualParams.from)} to ${formatTimeForDesc(actualParams.to)}`);
  } else if (actualParams.from) {
    filters.push(`Time from: ${formatTimeForDesc(actualParams.from)}`);
  } else if (actualParams.to) {
    filters.push(`Time to: ${formatTimeForDesc(actualParams.to)}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetLiquidityCallDescription(actualParams = {}) {
  const parts = [getLiquidityBaseDesc];
  if (actualParams.symbol) {
    parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.limit && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${formatTimeForDesc(actualParams.from)} to ${formatTimeForDesc(actualParams.to)}`);
  } else if (actualParams.from) {
    filters.push(`Time from: ${formatTimeForDesc(actualParams.from)}`);
  } else if (actualParams.to) {
    filters.push(`Time to: ${formatTimeForDesc(actualParams.to)}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetPriceCallDescription(actualParams = {}) {
  const parts = [getPriceBaseDesc];
  if (actualParams.symbol) {
    parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.limit && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${formatTimeForDesc(actualParams.from)} to ${formatTimeForDesc(actualParams.to)}`);
  } else if (actualParams.from) {
    filters.push(`Time from: ${formatTimeForDesc(actualParams.from)}`);
  } else if (actualParams.to) {
    filters.push(`Time to: ${formatTimeForDesc(actualParams.to)}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetHyperliquidWhaleAlertsCallDescription() {
  return getHyperliquidWhaleAlertsBaseDesc;
}

function buildGetHyperliquidWhalePositionsCallDescription() {
  return getHyperliquidWhalePositionsBaseDesc;
}

// Helper to add dynamic title to ref metadata
function createReferenceWithTitle(refObject, params, titleBuilder) {
  // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
  const title = titleBuilder(params);

  // 2. 组合 refObject 和新 title
  const newObject = {
    ...refObject,
    title: title,
  };

  // 3. 返回新对象
  return newObject;
}

function getVolume(params) {
  useCredit('getVolume', 350);
  return cryptoQuantSDK.getCQDexVolume(params);
}

function getTransactionsCount(params) {
  useCredit('getTransactionsCount', 350);
  return cryptoQuantSDK.getCQDexTransactionsCount(params);
}

function getLiquidity(params) {
  useCredit('getLiquidity', 350);
  return cryptoQuantSDK.getCQDexLiquidity(params);
}

function getPrice(params) {
  useCredit('getPrice', 350);
  return cryptoQuantSDK.getCQDexDexPrice(params);
}

function getHyperliquidWhaleAlerts() {
  useCredit('getHyperliquidWhaleAlerts', 350);
  return coinGlassSDK.getHyperliquidWhaleAlerts();
}

function getHyperliquidWhalePositions() {
  useCredit('getHyperliquidWhalePositions', 350);
  return coinGlassSDK.getHyperliquidWhalePositions();
}

function toMs(value) {
  if (value == null) {
    return null;
  }
  if (typeof value === 'number') {
    return value > 1e12 ? value : value * 1000;
  }
  if (typeof value === 'string') {
    const parsed = Date.parse(value);
    if (!Number.isNaN(parsed)) {
      return parsed;
    }
  }
  return null;
}

function extractCqSeries(response) {
  const data = response?.result?.data;
  return Array.isArray(data) ? data : [];
}

// Avoid micro-shifting time keys: collapse duplicates by keeping the last record per date (deterministic)
function dedupeByDate(records) {
  const byDate = new Map();
  for (const r of records) {
    byDate.set(r.date, r);
  }
  const out = Array.from(byDate.values());
  out.sort((a, b) => a.date - b.date);
  return out;
}

function makeVolumeNode(params) {
  return {
    inputs: {
      volume_raw: () => getVolume(params),
    },
    outputs: {
      volume: {
        name: 'dex_volume',
        description: 'DEX trading volume',
        fields: [
          { name: 'date', type: 'number', description: 'timestamp ms' },
          { name: 'dex_volume', type: 'number', description: 'trading volume in native asset' },
        ],
        ref: createReferenceWithTitle(getVolumeRef, params, buildGetVolumeCallDescription),
      },
    },
    run: (inputs) => {
      const series = extractCqSeries(inputs.volume_raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) return null;
          return { date: ts, dex_volume: Number(item.dex_volume) };
        })
        .filter(Boolean);
      return { volume: dedupeByDate(series) };
    },
  };
}

function makeTransactionsCountNode(params) {
  return {
    inputs: {
      transactions_raw: () => getTransactionsCount(params),
    },
    outputs: {
      transactions: {
        name: 'dex_transactions_count',
        description: 'DEX transaction counts',
        fields: [
          { name: 'date', type: 'number', description: 'timestamp ms' },
          { name: 'transactions_count', type: 'number', description: 'transactions count' },
        ],
        ref: createReferenceWithTitle(
          getTransactionsCountRef,
          params,
          buildGetTransactionsCountCallDescription
        ),
      },
    },
    run: (inputs) => {
      const series = extractCqSeries(inputs.transactions_raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) return null;
          return { date: ts, transactions_count: Number(item.transactions_count) };
        })
        .filter(Boolean);
      return { transactions: dedupeByDate(series) };
    },
  };
}

function makeLiquidityNode(params) {
  return {
    inputs: {
      liquidity_raw: () => getLiquidity(params),
    },
    outputs: {
      liquidity: {
        name: 'dex_liquidity',
        description: 'DEX USD liquidity',
        fields: [
          { name: 'date', type: 'number', description: 'timestamp ms' },
          { name: 'liquidity_usd', type: 'number', description: 'liquidity in USD' },
        ],
        ref: createReferenceWithTitle(getLiquidityRef, params, buildGetLiquidityCallDescription),
      },
    },
    run: (inputs) => {
      const series = extractCqSeries(inputs.liquidity_raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) return null;
          return { date: ts, liquidity_usd: Number(item.liquidity_usd) };
        })
        .filter(Boolean);
      return { liquidity: dedupeByDate(series) };
    },
  };
}

function makeDexPriceNode(params) {
  return {
    inputs: {
      dex_price_raw: () => getPrice(params),
    },
    outputs: {
      price: {
        name: 'dex_price',
        description: 'DEX price in USD',
        fields: [
          { name: 'date', type: 'number', description: 'timestamp ms' },
          { name: 'dex_price', type: 'number', description: 'price in USD' },
        ],
        ref: createReferenceWithTitle(getPriceRef, params, buildGetPriceCallDescription),
      },
    },
    run: (inputs) => {
      const series = extractCqSeries(inputs.dex_price_raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) return null;
          return { date: ts, dex_price: Number(item.dex_price) };
        })
        .filter(Boolean);
      return { price: dedupeByDate(series) };
    },
  };
}

function makeHyperliquidWhaleAlertsNode() {
  return {
    inputs: {
      alerts_raw: () => getHyperliquidWhaleAlerts(),
    },
    outputs: {
      alerts: {
        name: 'hyperliquid_whale_alerts',
        description: 'Hyperliquid whale alerts',
        fields: [
          { name: 'date', type: 'number', description: 'alert time ms' },
          { name: 'user', type: 'string', description: 'wallet address' },
          { name: 'symbol', type: 'string', description: 'asset symbol' },
          { name: 'position_size', type: 'number', description: 'position size' },
          { name: 'entry_price', type: 'number', description: 'entry price' },
          { name: 'liq_price', type: 'number', description: 'liquidation price' },
          { name: 'position_value_usd', type: 'number', description: 'position value USD' },
          { name: 'position_action', type: 'number', description: 'action code' },
        ],
        ref: createReferenceWithTitle(
          getHyperliquidWhaleAlertsRef,
          {},
          buildGetHyperliquidWhaleAlertsCallDescription
        ),
      },
    },
    run: (inputs) => {
      const alerts = Array.isArray(inputs.alerts_raw)
        ? inputs.alerts_raw
            .map((item) => {
              const ts = toMs(item.create_time);
              if (ts == null) return null;
              return {
                date: ts,
                user: item.user,
                symbol: item.symbol,
                position_size: item.position_size,
                entry_price: item.entry_price,
                liq_price: item.liq_price,
                position_value_usd: item.position_value_usd,
                position_action: item.position_action,
              };
            })
            .filter(Boolean)
        : [];
      return { alerts: dedupeByDate(alerts) };
    },
  };
}

function makeHyperliquidWhalePositionsNode() {
  return {
    inputs: {
      positions_raw: () => getHyperliquidWhalePositions(),
    },
    outputs: {
      positions: {
        name: 'hyperliquid_whale_positions',
        description: 'Open Hyperliquid whale positions',
        fields: [
          { name: 'date', type: 'number', description: 'last update ms' },
          { name: 'user', type: 'string', description: 'wallet address' },
          { name: 'symbol', type: 'string', description: 'asset symbol' },
          { name: 'position_size', type: 'number', description: 'position size' },
          { name: 'entry_price', type: 'number', description: 'entry price' },
          { name: 'mark_price', type: 'number', description: 'current mark price' },
          { name: 'liq_price', type: 'number', description: 'liquidation price' },
          { name: 'leverage', type: 'number', description: 'leverage' },
          { name: 'margin_balance', type: 'number', description: 'margin balance' },
          { name: 'position_value_usd', type: 'number', description: 'position value USD' },
          { name: 'unrealized_pnl', type: 'number', description: 'unrealized PnL' },
          { name: 'funding_fee', type: 'number', description: 'funding fees' },
          { name: 'margin_mode', type: 'string', description: 'margin mode' },
        ],
        ref: createReferenceWithTitle(
          getHyperliquidWhalePositionsRef,
          {},
          buildGetHyperliquidWhalePositionsCallDescription
        ),
      },
    },
    run: (inputs) => {
      const positions = Array.isArray(inputs.positions_raw)
        ? inputs.positions_raw
            .map((item) => {
              const ts = toMs(item.update_time);
              if (ts == null) return null;
              return {
                date: ts,
                user: item.user,
                symbol: item.symbol,
                position_size: item.position_size,
                entry_price: item.entry_price,
                mark_price: item.mark_price,
                liq_price: item.liq_price,
                leverage: item.leverage,
                margin_balance: item.margin_balance,
                position_value_usd: item.position_value_usd,
                unrealized_pnl: item.unrealized_pnl,
                funding_fee: item.funding_fee,
                margin_mode: item.margin_mode,
              };
            })
            .filter(Boolean)
        : [];
      return { positions: dedupeByDate(positions) };
    },
  };
}

function makePriceNode(params) {
  return makeDexPriceNode(params);
}

function getRefs() {
  return [
    getVolumeRef,
    getTransactionsCountRef,
    getLiquidityRef,
    getPriceRef,
    getHyperliquidWhaleAlertsRef,
    getHyperliquidWhalePositionsRef,
  ];
}

module.exports = {
  getVolume,
  getTransactionsCount,
  getLiquidity,
  getPrice,
  getHyperliquidWhaleAlerts,
  getHyperliquidWhalePositions,
  makeVolumeNode,
  makeTransactionsCountNode,
  makeLiquidityNode,
  makeDexPriceNode,
  makePriceNode,
  makeHyperliquidWhaleAlertsNode,
  makeHyperliquidWhalePositionsNode,
  getRefs,
};
