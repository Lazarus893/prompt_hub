// Assertion helper functions
function assert(cond, msg) {
	if (!cond) throw new Error(msg || 'assertion failed');
}
function isInteger(n) {
	return Number.isInteger(n);
}
function isMsEpoch(n) {
	return typeof n === 'number' && isInteger(n) && n > 0 && n > 10_000_000_000;
} // > ~1970s in ms
function hasUniqueDates(rows) {
	const s = new Set();
	for (const r of rows) {
		if (s.has(r.date)) return false;
		s.add(r.date);
	}
	return true;
}
function expectFieldsMatch(rows, fieldNames) {
	for (const r of rows) {
		const got = Object.keys(r);
		// date MUST be first field
		assert(got.includes('date'), 'missing required field: "date"');
		for (const f of fieldNames) assert(got.includes(f), `missing field: ${f}`);
	}
}

// Generic graph-output checker
function checkNodeOutput(
	graph,
	jagentId,
	nodeId,
	outputName,
	{
		expectFields = [], // fields AFTER 'date'
		preloadLast = '200', // how many to read back
		extra = null, // (rows, view) => void for custom assertions
	} = {}
) {
	const { TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
	const uri = new TimeSeriesUri(jagentId, nodeId, outputName, { last: preloadLast });
	const view = new TimeSeries(uri, graph.store);
	view.init(); // preload
	// NOTE: TimeSeries.data is newest-first (descending)
	const rows = view.data.slice(); // array of records

	if (rows.length === 0) {
		throw new Error(`no rows returned for node ${nodeId} output ${outputName}`);
	}

	// Basic invariants
	for (const r of rows) {
		assert(typeof r === 'object' && r != null, 'row must be object');
		assert(isMsEpoch(r.date), `date must be ms epoch, got: ${r.date}`);
	}
	assert(hasUniqueDates(rows), 'duplicate "date" values within one output');

	// Schema check (date-first + declared fields)
	expectFieldsMatch(rows, expectFields);

	// Optional additional checks
	if (typeof extra === 'function') extra(rows, view);
	return rows;
}

function main() {
	const { Graph } = require('@alva/graph:v1.0.0');
	const { jagentId } = require('env');
	const {
		makeVolumeNode,
		makeTransactionsCountNode,
		makeLiquidityNode,
		makeDexPriceNode,
		makeHyperliquidWhaleAlertsNode,
		makeHyperliquidWhalePositionsNode,
		makePriceNode,
	} = require('@alva/data/crypto/onchain/dex:v1.0.0');

	const nowSec = Math.floor(Date.now() / 1000);
	const oneWeekAgoSec = nowSec - 7 * 24 * 60 * 60;
	const fromMs = oneWeekAgoSec * 1000;
	const toMs = nowSec * 1000;

	const graph = new Graph(jagentId);

	// Test volume node
	graph.addNode('dex_volume', makeVolumeNode({ symbol: 'xrp', from: oneWeekAgoSec, to: nowSec, limit: 5 }));

	// Test transactions count node
	graph.addNode('dex_transactions', makeTransactionsCountNode({ symbol: 'xrp', from: oneWeekAgoSec, to: nowSec, limit: 5 }));

	// Test liquidity node
	graph.addNode('dex_liquidity', makeLiquidityNode({ symbol: 'xrp', from: oneWeekAgoSec, to: nowSec, limit: 5 }));

	// Test DEX price node
	graph.addNode('dex_price', makeDexPriceNode({ symbol: 'xrp', from: oneWeekAgoSec, to: nowSec, limit: 5 }));

	// Test price node (alias)
	graph.addNode('price', makePriceNode({ symbol: 'xrp', from: oneWeekAgoSec, to: nowSec, limit: 5 }));

	// Test hyperliquid whale alerts node
	graph.addNode('hyperliquid_alerts', makeHyperliquidWhaleAlertsNode());

	// Test hyperliquid whale positions node
	graph.addNode('hyperliquid_positions', makeHyperliquidWhalePositionsNode());

	graph.run();

	// Helper: check refs for a given output
	function checkRefs(graph, nodeId, outputName, expected) {
		const refs = graph.getRefsForOutput(nodeId, outputName);
		if (!refs || refs.length === 0) {
			throw new Error(`Assertion failed: refs array is empty for ${nodeId}:${outputName}.`);
		}
		const ref = refs[0];
		if (ref.id !== expected.id) {
			throw new Error(`ref.id mismatch for ${nodeId}:${outputName}. expected ${expected.id}, got ${ref.id}`);
		}
		if (ref.module_name !== expected.module_name) {
			throw new Error(`ref.module_name mismatch for ${nodeId}:${outputName}. expected ${expected.module_name}, got ${ref.module_name}`);
		}
		if (ref.module_display_name !== expected.module_display_name) {
			throw new Error(
				`ref.module_display_name mismatch for ${nodeId}:${outputName}. expected ${expected.module_display_name}, got ${ref.module_display_name}`
			);
		}
		if (ref.sdk_name !== expected.sdk_name) {
			throw new Error(`ref.sdk_name mismatch for ${nodeId}:${outputName}. expected ${expected.sdk_name}, got ${ref.sdk_name}`);
		}
		if (ref.sdk_display_name !== expected.sdk_display_name) {
			throw new Error(
				`ref.sdk_display_name mismatch for ${nodeId}:${outputName}. expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`
			);
		}
		if (ref.source_name !== expected.source_name) {
			throw new Error(`ref.source_name mismatch for ${nodeId}:${outputName}. expected ${expected.source_name}, got ${ref.source_name}`);
		}
		if (ref.source !== expected.source) {
			throw new Error(`ref.source mismatch for ${nodeId}:${outputName}. expected ${expected.source}, got ${ref.source}`);
		}
	}

	// Test volume node output
	const volumeRows = checkNodeOutput(graph, jagentId, 'dex_volume', 'volume', {
		expectFields: ['dex_volume'],
		preloadLast: '50',
		extra: (rows) => {
			for (const r of rows) {
				assert(typeof r.dex_volume === 'number', 'dex_volume must be number');
				assert(r.date >= fromMs && r.date <= toMs, 'date should be within [from, to]');
			}
		},
	});

	// Test transactions count node output
	const txCountRows = checkNodeOutput(graph, jagentId, 'dex_transactions', 'transactions', {
		expectFields: ['transactions_count'],
		preloadLast: '50',
		extra: (rows) => {
			for (const r of rows) {
				assert(typeof r.transactions_count === 'number', 'transactions_count must be number');
				assert(r.date >= fromMs && r.date <= toMs, 'date should be within [from, to]');
			}
		},
	});

	// Test liquidity node output
	const liquidityRows = checkNodeOutput(graph, jagentId, 'dex_liquidity', 'liquidity', {
		expectFields: ['liquidity_usd'],
		preloadLast: '50',
		extra: (rows) => {
			for (const r of rows) {
				assert(typeof r.liquidity_usd === 'number', 'liquidity must be number');
				assert(r.date >= fromMs && r.date <= toMs, 'date should be within [from, to]');
			}
		},
	});

	// Test DEX price node output
	const dexPriceRows = checkNodeOutput(graph, jagentId, 'dex_price', 'price', {
		expectFields: ['dex_price'],
		preloadLast: '50',
		extra: (rows) => {
			for (const r of rows) {
				assert(typeof r.dex_price === 'number', 'dex_price_usd must be number');
				assert(r.date >= fromMs && r.date <= toMs, 'date should be within [from, to]');
			}
		},
	});

	// Test price node output (alias)
	const priceRows = checkNodeOutput(graph, jagentId, 'price', 'price', {
		expectFields: ['dex_price'],
		preloadLast: '50',
		extra: (rows) => {
			for (const r of rows) {
				assert(typeof r.dex_price === 'number', 'dex_price_usd must be number');
				assert(r.date >= fromMs && r.date <= toMs, 'date should be within [from, to]');
			}
		},
	});

	// Test hyperliquid whale alerts node output
	const alertsRows = checkNodeOutput(graph, jagentId, 'hyperliquid_alerts', 'alerts', {
		expectFields: ['user', 'symbol', 'position_size', 'entry_price', 'position_value_usd', 'position_action'],
		preloadLast: '50',
		extra: (rows) => {
			for (const r of rows) {
				['user', 'symbol'].forEach((k) => assert(typeof r[k] === 'string', `alert ${k} must be string`));
				['position_size', 'entry_price', 'position_value_usd', 'position_action'].forEach((k) => assert(typeof r[k] === 'number', `alert ${k} must be number`));
			}
		},
	});

	// Test hyperliquid whale positions node output
	const positionsRows = checkNodeOutput(graph, jagentId, 'hyperliquid_positions', 'positions', {
		expectFields: ['user', 'symbol', 'position_size', 'entry_price', 'mark_price', 'liq_price', 'leverage', 'margin_balance', 'position_value_usd', 'unrealized_pnl', 'funding_fee', 'margin_mode'],
		preloadLast: '50',
		extra: (rows) => {
			for (const r of rows) {
				['user', 'symbol', 'margin_mode'].forEach((k) => assert(typeof r[k] === 'string', `position ${k} must be string`));
				['position_size', 'entry_price', 'mark_price', 'liq_price', 'leverage', 'margin_balance', 'position_value_usd', 'unrealized_pnl', 'funding_fee'].forEach((k) =>
					assert(typeof r[k] === 'number', `position ${k} must be number`)
				);
			}
		},
	});

	// =========================
	// Ref metadata assertions
	// =========================
	checkRefs(graph, 'dex_volume', 'volume', {
		id: '@alva/data/crypto/onchain/dex/getVolume',
		module_name: '@alva/data/crypto/onchain/dex',
		module_display_name: 'On-chain DEX Activity',
		sdk_name: 'getVolume',
		sdk_display_name: 'XRP DEX Volume',
		source_name: 'CryptoQuant',
		source: 'https://cryptoquant.com/en/docs#tag/XRP-Dex-Data/operation/getDexVolume',
	});

	checkRefs(graph, 'dex_transactions', 'transactions', {
		id: '@alva/data/crypto/onchain/dex/getTransactionsCount',
		module_name: '@alva/data/crypto/onchain/dex',
		module_display_name: 'On-chain DEX Activity',
		sdk_name: 'getTransactionsCount',
		sdk_display_name: 'XRP DEX Transaction',
		source_name: 'CryptoQuant',
		source: 'https://cryptoquant.com/en/docs#tag/XRP-Network-Data/operation/getTransactionsCount',
	});

	checkRefs(graph, 'dex_liquidity', 'liquidity', {
		id: '@alva/data/crypto/onchain/dex/getLiquidity',
		module_name: '@alva/data/crypto/onchain/dex',
		module_display_name: 'On-chain DEX Activity',
		sdk_name: 'getLiquidity',
		sdk_display_name: 'XRP DEX Liquidity',
		source_name: 'CryptoQuant',
		source: 'https://cryptoquant.com/en/docs#tag/XRP-Dex-Data/operation/getDexLiquidity',
	});

	checkRefs(graph, 'dex_price', 'price', {
		id: '@alva/data/crypto/onchain/dex/getPrice',
		module_name: '@alva/data/crypto/onchain/dex',
		module_display_name: 'On-chain DEX Activity',
		sdk_name: 'getPrice',
		sdk_display_name: 'XRP DEX Price',
		source_name: 'CryptoQuant',
		source: 'https://cryptoquant.com/en/docs#tag/XRP-Dex-Data/operation/getDexPrice',
	});

	// Also verify ref metadata for the alias price node
	checkRefs(graph, 'price', 'price', {
		id: '@alva/data/crypto/onchain/dex/getPrice',
		module_name: '@alva/data/crypto/onchain/dex',
		module_display_name: 'On-chain DEX Activity',
		sdk_name: 'getPrice',
		sdk_display_name: 'XRP DEX Price',
		source_name: 'CryptoQuant',
		source: 'https://cryptoquant.com/en/docs#tag/XRP-Dex-Data/operation/getDexPrice',
	});

	checkRefs(graph, 'hyperliquid_alerts', 'alerts', {
		id: '@alva/data/crypto/onchain/dex/getHyperliquidWhaleAlerts',
		module_name: '@alva/data/crypto/onchain/dex',
		module_display_name: 'On-chain DEX Activity',
		sdk_name: 'getHyperliquidWhaleAlerts',
		sdk_display_name: 'Hyperliquid Whales Alert',
		source_name: 'Coinglass',
		source: 'https://docs.coinglass.com/reference/hyperliquid-whale-alert',
	});

	checkRefs(graph, 'hyperliquid_positions', 'positions', {
		id: '@alva/data/crypto/onchain/dex/getHyperliquidWhalePositions',
		module_name: '@alva/data/crypto/onchain/dex',
		module_display_name: 'On-chain DEX Activity',
		sdk_name: 'getHyperliquidWhalePositions',
		sdk_display_name: 'Hyperliquid Whales Positions',
		source_name: 'Coinglass',
		source: 'https://docs.coinglass.com/reference/hyperliquid-whale-position',
	});

	// as long as no throw, it is considered passed
	log('✅ Dex make*Node tests passed');
	log('✅ Ref metadata tests passed');
	testDirectFunctions(oneWeekAgoSec, nowSec);
	return 0;
}

function testDirectFunctions(defaultFromSec, defaultToSec) {
	console.log('\n=== Testing Direct Function Calls ===');

	const {
		getVolume,
		getTransactionsCount,
		getLiquidity,
		getPrice,
		getHyperliquidWhaleAlerts,
		getHyperliquidWhalePositions,
	} = require('@alva/data/crypto/onchain/dex:v1.0.0');

	// Define supported parameters
	const SUPPORTED_SYMBOLS = ['xrp'];
	const TIME_WINDOWS = ['day', 'hour'];

	let totalTests = 0;
	let passedTests = 0;

	// Helper function to run test and track results
	function runTest(testName, testFunc) {
		totalTests++;
		try {
			testFunc();
			console.log(`✅ ${testName}`);
			passedTests++;
		} catch (e) {
			console.log(`❌ ${testName}: ${e.message}`);
		}
	}

	// ============ getVolume Tests ============
	console.log('\n--- Testing getVolume ---');

	// Happy path tests
	for (const symbol of SUPPORTED_SYMBOLS) {
		for (const window of TIME_WINDOWS) {
			runTest(`getVolume with ${symbol} - ${window} window`, () => {
				const volume = getVolume({
					symbol: symbol,
					window: window,
					from: defaultFromSec,
					to: defaultToSec,
					limit: 5
				});
				assert(volume && typeof volume === 'object', `Should return object for ${symbol}-${window}`);
				assert(volume.result && Array.isArray(volume.result.data), `Should have data array for ${symbol}-${window}`);
				assert(volume.result.data.length <= 5, `Should respect limit parameter for ${symbol}-${window}`);
				for (const dp of volume.result.data) {
					assert(typeof dp.timestamp === 'number', 'data point should have timestamp');
					assert(dp.timestamp >= defaultFromSec && dp.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
				}
			});
		}
	}

	// Boundary value tests for limit parameter
	runTest('getVolume boundary values - minimum limit', () => {
		const volumeMin = getVolume({
			symbol: 'xrp',
			from: defaultFromSec,
			to: defaultToSec,
			limit: 2
		});
		assert(volumeMin && typeof volumeMin === 'object', 'Should work with minimum limit (2)');
		assert(volumeMin.result && Array.isArray(volumeMin.result.data), 'Should have data array with minimum limit');
		for (const dp of volumeMin.result.data) {
			assert(typeof dp.timestamp === 'number', 'data point should have timestamp');
			assert(dp.timestamp >= defaultFromSec && dp.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
		}
	});

	runTest('getVolume boundary values - maximum limit', () => {
		const volumeMax = getVolume({
			symbol: 'xrp',
			from: defaultFromSec,
			to: defaultToSec,
			limit: 100000
		});
		assert(volumeMax && typeof volumeMax === 'object', 'Should work with maximum limit (100000)');
		for (const dp of volumeMax.result.data) {
			assert(typeof dp.timestamp === 'number', 'data point should have timestamp');
			assert(dp.timestamp >= defaultFromSec && dp.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
		}
	});

	// Test with time range parameters
	runTest('getVolume with time range', () => {
		const volumeWithTime = getVolume({
			symbol: 'xrp',
			from: defaultFromSec,
			to: defaultToSec,
			limit: 10
		});
		assert(volumeWithTime && typeof volumeWithTime === 'object', 'Should work with time range parameters');
		assert(volumeWithTime.result && Array.isArray(volumeWithTime.result.data), 'Should have data array with time range');
		for (const dp of volumeWithTime.result.data) {
			assert(typeof dp.timestamp === 'number', 'data point should have timestamp');
			assert(dp.timestamp >= defaultFromSec && dp.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
		}
	});

	// Test default values
	runTest('getVolume with default parameters (window default only)', () => {
		const volumeDefault = getVolume({
			symbol: 'xrp',
			from: defaultFromSec,
			to: defaultToSec
		});
		assert(volumeDefault && typeof volumeDefault === 'object', 'Should work with default parameters');
		assert(volumeDefault.result && Array.isArray(volumeDefault.result.data), 'Should have data array with defaults');
		for (const dp of volumeDefault.result.data) {
			assert(typeof dp.timestamp === 'number', 'data point should have timestamp');
			assert(dp.timestamp >= defaultFromSec && dp.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
		}
	});

	// Data validation
	runTest('getVolume data structure validation', () => {
		const volume = getVolume({
			symbol: 'xrp',
			from: defaultFromSec,
			to: defaultToSec,
			limit: 3
		});
		assert(volume.result && Array.isArray(volume.result.data), 'Should have data array');

		for (const dataPoint of volume.result.data) {
			assert(typeof dataPoint === 'object', 'Each data point should be an object');
			assert('dex_volume' in dataPoint, 'Each data point should have dex_volume field');
			assert(dataPoint.dex_volume === null || typeof dataPoint.dex_volume === 'string', 'dex_volume should be null or number');
			assert(typeof dataPoint.timestamp === 'number', 'timestamp should exist');
			assert(dataPoint.timestamp >= defaultFromSec && dataPoint.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
		}
	});

	// ============ getTransactionsCount Tests ============
	console.log('\n--- Testing getTransactionsCount ---');

	for (const symbol of SUPPORTED_SYMBOLS) {
		for (const window of TIME_WINDOWS) {
			runTest(`getTransactionsCount with ${symbol} - ${window} window`, () => {
				const txCount = getTransactionsCount({
					symbol: symbol,
					window: window,
					from: defaultFromSec,
					to: defaultToSec,
					limit: 5
				});
				assert(txCount && typeof txCount === 'object', `Should return object for ${symbol}-${window}`);
				assert(txCount.result && Array.isArray(txCount.result.data), `Should have data array for ${symbol}-${window}`);
				for (const dp of txCount.result.data) {
					assert(typeof dp.timestamp === 'number', 'data point should have timestamp');
					assert(dp.timestamp >= defaultFromSec && dp.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
				}
			});
		}
	}

	// Boundary tests
	runTest('getTransactionsCount boundary values', () => {
		const txCountMin = getTransactionsCount({
			symbol: 'xrp',
			from: defaultFromSec,
			to: defaultToSec,
			limit: 2
		});
		assert(txCountMin && typeof txCountMin === 'object', 'Should work with minimum limit');

		const txCountMax = getTransactionsCount({
			symbol: 'xrp',
			from: defaultFromSec,
			to: defaultToSec,
			limit: 100000
		});
		assert(txCountMax && typeof txCountMax === 'object', 'Should work with maximum limit');
		for (const dp of txCountMax.result.data) {
			assert(typeof dp.timestamp === 'number', 'data point should have timestamp');
			assert(dp.timestamp >= defaultFromSec && dp.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
		}
	});

	// Data validation
	runTest('getTransactionsCount data structure validation', () => {
		const txCount = getTransactionsCount({
			symbol: 'xrp',
			from: defaultFromSec,
			to: defaultToSec,
			limit: 3
		});

		for (const dataPoint of txCount.result.data) {
			console.log(typeof dataPoint.transactions_count);
			assert(typeof dataPoint === 'object', 'Each data point should be an object');
			assert('transactions_count' in dataPoint, 'Each data point should have transactions_count field');
			assert(dataPoint.transactions_count === null || typeof dataPoint.transactions_count === 'string', 'transactions_count should be null or number');
			assert(typeof dataPoint.timestamp === 'number', 'timestamp should exist');
			assert(dataPoint.timestamp >= defaultFromSec && dataPoint.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
		}
	});

	// ============ getLiquidity Tests ============
	console.log('\n--- Testing getLiquidity ---');

	for (const symbol of SUPPORTED_SYMBOLS) {
		for (const window of TIME_WINDOWS) {
			runTest(`getLiquidity with ${symbol} - ${window} window`, () => {
				const liquidity = getLiquidity({
					symbol: symbol,
					window: window,
					from: defaultFromSec,
					to: defaultToSec,
					limit: 5
				});
				assert(liquidity && typeof liquidity === 'object', `Should return object for ${symbol}-${window}`);
				assert(liquidity.result && Array.isArray(liquidity.result.data), `Should have data array for ${symbol}-${window}`);
				for (const dp of liquidity.result.data) {
					assert(typeof dp.timestamp === 'number', 'data point should have timestamp');
					assert(dp.timestamp >= defaultFromSec && dp.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
				}
			});
		}
	}

	// Boundary tests
	runTest('getLiquidity boundary values', () => {
		const liquidityMin = getLiquidity({
			symbol: 'xrp',
			from: defaultFromSec,
			to: defaultToSec,
			limit: 2
		});
		assert(liquidityMin && typeof liquidityMin === 'object', 'Should work with minimum limit');

		const liquidityMax = getLiquidity({
			symbol: 'xrp',
			from: defaultFromSec,
			to: defaultToSec,
			limit: 100000
		});
		assert(liquidityMax && typeof liquidityMax === 'object', 'Should work with maximum limit');
		for (const dp of liquidityMax.result.data) {
			assert(typeof dp.timestamp === 'number', 'data point should have timestamp');
			assert(dp.timestamp >= defaultFromSec && dp.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
		}
	});

	// Data validation
	runTest('getLiquidity data structure validation', () => {
		const liquidity = getLiquidity({
			symbol: 'xrp',
			from: defaultFromSec,
			to: defaultToSec,
			limit: 3
		});

		for (const dataPoint of liquidity.result.data) {
			assert(typeof dataPoint === 'object', 'Each data point should be an object');
			assert('liquidity_usd' in dataPoint, 'Each data point should have liquidity_usd field');
			assert(dataPoint.liquidity_usd === null || typeof dataPoint.liquidity_usd === 'string', 'liquidity_usd should be null or number');
			assert(typeof dataPoint.timestamp === 'number', 'timestamp should exist');
			assert(dataPoint.timestamp >= defaultFromSec && dataPoint.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
		}
	});

	// ============ getPrice Tests ============
	console.log('\n--- Testing getPrice ---');

	for (const symbol of SUPPORTED_SYMBOLS) {
		for (const window of TIME_WINDOWS) {
			runTest(`getPrice with ${symbol} - ${window} window`, () => {
				const price = getPrice({
					symbol: symbol,
					window: window,
					from: defaultFromSec,
					to: defaultToSec,
					limit: 5
				});
				assert(price && typeof price === 'object', `Should return object for ${symbol}-${window}`);
				assert(price.result && Array.isArray(price.result.data), `Should have data array for ${symbol}-${window}`);
				for (const dp of price.result.data) {
					assert(typeof dp.timestamp === 'number', 'data point should have timestamp');
					assert(dp.timestamp >= defaultFromSec && dp.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
				}
			});
		}
	}

	// Boundary tests
	runTest('getPrice boundary values', () => {
		const priceMin = getPrice({
			symbol: 'xrp',
			from: defaultFromSec,
			to: defaultToSec,
			limit: 2
		});
		assert(priceMin && typeof priceMin === 'object', 'Should work with minimum limit');

		const priceMax = getPrice({
			symbol: 'xrp',
			from: defaultFromSec,
			to: defaultToSec,
			limit: 100000
		});
		assert(priceMax && typeof priceMax === 'object', 'Should work with maximum limit');
		for (const dp of priceMax.result.data) {
			assert(typeof dp.timestamp === 'number', 'data point should have timestamp');
			assert(dp.timestamp >= defaultFromSec && dp.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
		}
	});

	// Data validation
	runTest('getPrice data structure validation', () => {
		const price = getPrice({
			symbol: 'xrp',
			from: defaultFromSec,
			to: defaultToSec,
			limit: 3
		});

		for (const dataPoint of price.result.data) {
			assert(typeof dataPoint === 'object', 'Each data point should be an object');
			assert('dex_price' in dataPoint, 'Each data point should have dex_price field');
			assert(dataPoint.dex_price === null || typeof dataPoint.dex_price === 'string', 'dex_price should be null or number');
			assert(typeof dataPoint.timestamp === 'number', 'timestamp should exist');
			assert(dataPoint.timestamp >= defaultFromSec && dataPoint.timestamp <= defaultToSec, 'timestamp should be within [from, to]');
		}
	});

	// ============ getHyperliquidWhaleAlerts Tests ============
	console.log('\n--- Testing getHyperliquidWhaleAlerts ---');

	runTest('getHyperliquidWhaleAlerts basic test', () => {
		const alerts = getHyperliquidWhaleAlerts();
		assert(Array.isArray(alerts), 'Should return an array of alerts');

		// Validate structure of each alert if array is not empty
		for (const alert of alerts.slice(0, 3)) { // Check first 3 alerts to avoid too much processing
			assert(typeof alert === 'object', 'Each alert should be an object');
			assert('user' in alert, 'Alert should have user field');
			assert('symbol' in alert, 'Alert should have symbol field');
			assert('position_size' in alert, 'Alert should have position_size field');
			assert('entry_price' in alert, 'Alert should have entry_price field');
			assert('position_value_usd' in alert, 'Alert should have position_value_usd field');
			assert('position_action' in alert, 'Alert should have position_action field');
			assert('create_time' in alert, 'Alert should have create_time field');

			// Validate field types
			assert(typeof alert.user === 'string', 'user should be string');
			assert(typeof alert.symbol === 'string', 'symbol should be string');
			assert(typeof alert.position_size === 'number', 'position_size should be number');
			assert(typeof alert.entry_price === 'number', 'entry_price should be number');
			assert(typeof alert.position_value_usd === 'number', 'position_value_usd should be number');
			assert(typeof alert.position_action === 'number', 'position_action should be number');
			assert(typeof alert.create_time === 'number', 'create_time should be number (Unix milliseconds)');

			// Validate position_action values (1 = open, 2 = close)
			assert(alert.position_action === 1 || alert.position_action === 2, 'position_action should be 1 or 2');

			// Validate create_time is milliseconds timestamp
			assert(alert.create_time > 1000000000000, 'create_time should be milliseconds timestamp');
		}
	});

	// ============ getHyperliquidWhalePositions Tests ============
	console.log('\n--- Testing getHyperliquidWhalePositions ---');

	runTest('getHyperliquidWhalePositions basic test', () => {
		const positions = getHyperliquidWhalePositions();
		assert(Array.isArray(positions), 'Should return an array of positions');

		// Validate structure of each position if array is not empty
		for (const position of positions.slice(0, 3)) { // Check first 3 positions
			assert(typeof position === 'object', 'Each position should be an object');
			assert('user' in position, 'Position should have user field');
			assert('symbol' in position, 'Position should have symbol field');
			assert('position_size' in position, 'Position should have position_size field');
			assert('entry_price' in position, 'Position should have entry_price field');
			assert('mark_price' in position, 'Position should have mark_price field');
			assert('liq_price' in position, 'Position should have liq_price field');
			assert('leverage' in position, 'Position should have leverage field');
			assert('margin_balance' in position, 'Position should have margin_balance field');
			assert('position_value_usd' in position, 'Position should have position_value_usd field');
			assert('unrealized_pnl' in position, 'Position should have unrealized_pnl field');
			assert('funding_fee' in position, 'Position should have funding_fee field');
			assert('margin_mode' in position, 'Position should have margin_mode field');
			assert('create_time' in position, 'Position should have create_time field');
			assert('update_time' in position, 'Position should have update_time field');

			// Validate field types
			assert(typeof position.user === 'string', 'user should be string');
			assert(typeof position.symbol === 'string', 'symbol should be string');
			assert(typeof position.position_size === 'number', 'position_size should be number');
			assert(typeof position.entry_price === 'number', 'entry_price should be number');
			assert(typeof position.mark_price === 'number', 'mark_price should be number');
			assert(typeof position.liq_price === 'number', 'liq_price should be number');
			assert(typeof position.leverage === 'number', 'leverage should be number');
			assert(typeof position.margin_balance === 'number', 'margin_balance should be number');
			assert(typeof position.position_value_usd === 'number', 'position_value_usd should be number');
			assert(typeof position.unrealized_pnl === 'number', 'unrealized_pnl should be number');
			assert(typeof position.funding_fee === 'number', 'funding_fee should be number');
			assert(typeof position.margin_mode === 'string', 'margin_mode should be string');
			assert(typeof position.create_time === 'number', 'create_time should be number (Unix milliseconds)');
			assert(typeof position.update_time === 'number', 'update_time should be number (Unix milliseconds)');

			// Validate margin_mode values
			assert(position.margin_mode === 'cross' || position.margin_mode === 'isolated', 'margin_mode should be cross or isolated');

			// Validate timestamps are milliseconds
			assert(position.create_time > 1000000000000, 'create_time should be milliseconds timestamp');
			assert(position.update_time > 1000000000000, 'update_time should be milliseconds timestamp');
		}
	});

	// ============ Error Handling Tests ============
	console.log('\n--- Testing Error Handling ---');

	// ============ getVolume Error Handling Tests ============

	// Test missing symbol
	runTest('getVolume missing symbol', () => {
		try {
			getVolume({
				from: defaultFromSec,
				to: defaultToSec,
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('symbol') && e.message.includes('required'), 'Should handle missing symbol');
		}
	});

	// Test invalid symbol values
	runTest('getVolume invalid symbol - lowercase', () => {
		try {
			getVolume({
				symbol: 'btc',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Unsupported symbol'), 'Should handle unsupported symbol');
		}
	});

	runTest('getVolume invalid symbol - empty string', () => {
		try {
			getVolume({
				symbol: '',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Unsupported symbol') || e.message.includes('required'), 'Should handle empty symbol');
		}
	});

	// Test invalid window values
	runTest('getVolume invalid window - minute', () => {
		try {
			getVolume({
				symbol: 'xrp',
				window: 'minute',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid window'), 'Should handle invalid window');
		}
	});

	runTest('getVolume invalid window - week', () => {
		try {
			getVolume({
				symbol: 'xrp',
				window: 'week',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid window'), 'Should handle invalid window');
		}
	});

	// Test limit boundary cases
	runTest('getVolume limit too small - zero', () => {
		try {
			getVolume({
				symbol: 'xrp',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 0
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid limit'), 'Should handle limit = 0');
		}
	});

	runTest('getVolume limit too small - negative', () => {
		try {
			getVolume({
				symbol: 'xrp',
				from: defaultFromSec,
				to: defaultToSec,
				limit: -5
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid limit'), 'Should handle negative limit');
		}
	});

	runTest('getVolume limit too small - boundary', () => {
		try {
			getVolume({
				symbol: 'xrp',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 1
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid limit'), 'Should handle limit = 1');
		}
	});

	runTest('getVolume limit too large - boundary', () => {
		try {
			getVolume({
				symbol: 'xrp',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 100001
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid limit'), 'Should handle limit > 100000');
		}
	});

	runTest('getVolume limit too large - huge', () => {
		try {
			getVolume({
				symbol: 'xrp',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 999999
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid limit'), 'Should handle huge limit');
		}
	});

	// Test invalid limit types
	runTest('getVolume invalid limit type - string', () => {
		try {
			getVolume({
				symbol: 'xrp',
				from: defaultFromSec,
				to: defaultToSec,
				limit: '10'
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid limit'), 'Should handle string limit');
		}
	});

	runTest('getVolume invalid limit type - float', () => {
		try {
			getVolume({
				symbol: 'xrp',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 10.5
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid limit'), 'Should handle float limit');
		}
	});

	// Test invalid time range values
	runTest('getVolume invalid time range - equal timestamps', () => {
		try {
			const now = Math.floor(Date.now() / 1000);
			getVolume({
				symbol: 'xrp',
				from: now,
				to: now, // equal to from
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid time range'), 'Should handle equal timestamps');
		}
	});

	runTest('getVolume invalid time range - from after to', () => {
		try {
			const now = Math.floor(Date.now() / 1000);
			getVolume({
				symbol: 'xrp',
				from: now,
				to: now - 3600, // 1 hour before from
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid time range'), 'Should handle from > to');
		}
	});

	// Test invalid timestamp types
	runTest('getVolume invalid timestamp type - string from', () => {
		try {
			getVolume({
				symbol: 'xrp',
				from: '2023-01-01',
				to: Math.floor(Date.now() / 1000),
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid time range'), 'Should handle string from timestamp');
		}
	});

	runTest('getVolume invalid timestamp type - string to', () => {
		try {
			const oneWeekAgo = Math.floor(Date.now() / 1000) - (7 * 24 * 60 * 60);
			getVolume({
				symbol: 'xrp',
				from: oneWeekAgo,
				to: '2023-12-31',
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid time range'), 'Should handle string to timestamp');
		}
	});

	// ============ getTransactionsCount Error Handling Tests ============

	// Test missing symbol
	runTest('getTransactionsCount missing symbol', () => {
		try {
			getTransactionsCount({
				from: defaultFromSec,
				to: defaultToSec,
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('symbol') && e.message.includes('required'), 'Should handle missing symbol');
		}
	});

	// Test invalid symbol
	runTest('getTransactionsCount invalid symbol', () => {
		try {
			getTransactionsCount({
				symbol: 'btc',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Unsupported symbol'), 'Should handle invalid symbol');
		}
	});

	// Test invalid window
	runTest('getTransactionsCount invalid window', () => {
		try {
			getTransactionsCount({
				symbol: 'xrp',
				window: 'minute',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid window'), 'Should handle invalid window');
		}
	});

	// Test limit boundaries
	runTest('getTransactionsCount limit too small', () => {
		try {
			getTransactionsCount({
				symbol: 'xrp',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 1
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid limit'), 'Should handle limit too small');
		}
	});

	runTest('getTransactionsCount limit too large', () => {
		try {
			getTransactionsCount({
				symbol: 'xrp',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 200000
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid limit'), 'Should handle limit too large');
		}
	});

	// ============ getLiquidity Error Handling Tests ============

	// Test missing symbol
	runTest('getLiquidity missing symbol', () => {
		try {
			getLiquidity({
				from: defaultFromSec,
				to: defaultToSec,
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('symbol') && e.message.includes('required'), 'Should handle missing symbol');
		}
	});

	// Test invalid symbol
	runTest('getLiquidity invalid symbol', () => {
		try {
			getLiquidity({
				symbol: 'eth',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Unsupported symbol'), 'Should handle invalid symbol');
		}
	});

	// Test invalid window
	runTest('getLiquidity invalid window', () => {
		try {
			getLiquidity({
				symbol: 'xrp',
				window: 'minute',
				from: defaultFromSec,
				to: defaultToSec
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid window'), 'Should handle invalid window');
		}
	});

	// Test invalid limit type
	runTest('getLiquidity invalid limit type', () => {
		try {
			getLiquidity({
				symbol: 'xrp',
				from: defaultFromSec,
				to: defaultToSec,
				limit: '50'
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid limit'), 'Should handle string limit');
		}
	});

	// ============ getPrice Error Handling Tests ============

	// Test missing symbol
	runTest('getPrice missing symbol', () => {
		try {
			getPrice({
				window: 'day',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('symbol') && e.message.includes('required'), 'Should handle missing symbol');
		}
	});

	// Test invalid symbol
	runTest('getPrice invalid symbol', () => {
		try {
			getPrice({
				symbol: 'invalid_symbol',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Unsupported symbol'), 'Should handle invalid symbol');
		}
	});

	// Test invalid window
	runTest('getPrice invalid window', () => {
		try {
			getPrice({
				symbol: 'xrp',
				window: 'week',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid window'), 'Should handle invalid window');
		}
	});

	// Test invalid limit values
	runTest('getPrice limit negative', () => {
		try {
			getPrice({
				symbol: 'xrp',
				from: defaultFromSec,
				to: defaultToSec,
				limit: -10
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid limit'), 'Should handle negative limit');
		}
	});

	runTest('getPrice limit float', () => {
		try {
			getPrice({
				symbol: 'xrp',
				from: defaultFromSec,
				to: defaultToSec,
				limit: 25.7
			});
			throw new Error('Expected error but function succeeded');
		} catch (e) {
			assert(e.message.includes('Invalid limit'), 'Should handle float limit');
		}
	});

	// Print test summary
	console.log('\n=== Test Summary ===');
	console.log(`Total tests: ${totalTests}`);
	console.log(`Passed: ${passedTests}`);
	console.log(`Failed: ${totalTests - passedTests}`);
	console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

	if (passedTests === totalTests) {
		console.log('🎉 All tests passed!');
	} else {
		console.log('⚠️  Some tests failed. Please review the output above.');
	}
}

main();
