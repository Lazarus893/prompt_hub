const { Graph } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');
const { makeTradingTransactionsNode, makeMemeCreationNode } = require('@alva/data/crypto/onchain/activity:v1.0.0');

function main() {
  // Build a graph and add nodes so refs can be retrieved via graph API without executing network calls
  const g = new Graph(jagentId);
  g.addNode('meme_creation', makeMemeCreationNode({ network: 'solana', start_time: 0, end_time: 0 }));
  g.run();

  // Validate refs for meme_creation using graph API
  const memeRefs = g.getRefsForOutput('meme_creation', 'meme_creation');
  if (memeRefs.length > 0) {
    const ref = memeRefs[0];
    const expected = {
      id: '@alva/data/crypto/onchain/activity/getMemeCreation',
      module_name: '@alva/data/crypto/onchain/activity ',
      module_display_name: 'On-chain Activity Tracker',
      sdk_name: 'getMemeCreation',
      sdk_display_name: 'New Solana Token',
      source_name: 'Bitquery',
      source: 'https://docs.bitquery.io/docs/category/bsc/\n\nhttps://docs.bitquery.io/docs/examples/Solana/',
    };

    if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for meme_creation');
    if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for meme_creation');
    if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for meme_creation');
    if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for meme_creation');
    if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for meme_creation');
    if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for meme_creation');
    if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for meme_creation');
    console.log('✓ meme_creation refs validated');
  } else {
    throw new Error('Assertion failed: refs array is empty for meme_creation.');
  }

  // Validate refs for trading_transactions directly from node metadata (no graph run required)
  const tradingNode = makeTradingTransactionsNode({});
  const ref = tradingNode.outputs && tradingNode.outputs.trading_transactions && tradingNode.outputs.trading_transactions.ref;
  if (!ref) throw new Error('Assertion failed: trading_transactions ref not found on node outputs');

  const expected = {
    id: '@alva/data/crypto/onchain/activity/getTradingTransactions',
    module_name: '@alva/data/crypto/onchain/activity ',
    module_display_name: 'On-chain Activity Tracker',
    sdk_name: 'getTradingTransactions',
    sdk_display_name: 'Crypto Wallet Activity',
    source_name: 'Bitquery',
    source: 'https://docs.bitquery.io/docs/streams/kafka-streaming-concepts/',
  };

  if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for trading_transactions');
  if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for trading_transactions');
  if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for trading_transactions');
  if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for trading_transactions');
  if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for trading_transactions');
  if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for trading_transactions');
  if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for trading_transactions');
  console.log('✓ trading_transactions refs validated');

  console.log('✓ All ref validations passed');
}

main();
