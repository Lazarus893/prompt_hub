const { sdkRelay } = require('sdkrelay');
const { useCredit } = require('internal');

// Refs from tool.json
const getTradingTransactionsRef = {
  id: '@alva/data/crypto/onchain/activity/getTradingTransactions',
  module_name: '@alva/data/crypto/onchain/activity ',
  module_display_name: 'On-chain Activity Tracker',
  sdk_name: 'getTradingTransactions',
  sdk_display_name: 'Crypto Wallet Activity',
  source_name: 'Bitquery',
  source: 'https://docs.bitquery.io/docs/streams/kafka-streaming-concepts/',
};

const getMemeCreationRef = {
  id: '@alva/data/crypto/onchain/activity/getMemeCreation',
  module_name: '@alva/data/crypto/onchain/activity ',
  module_display_name: 'On-chain Activity Tracker',
  sdk_name: 'getMemeCreation',
  sdk_display_name: 'New Solana Token',
  source_name: 'Bitquery',
  source: 'https://docs.bitquery.io/docs/category/bsc/\n\nhttps://docs.bitquery.io/docs/examples/Solana/',
};

function getRefs() {
    return [
        getTradingTransactionsRef,
        getMemeCreationRef,
    ];
}

function getTradingTransactions(params) {
    useCredit('getTradingTransactions', 350);
    return sdkRelay('GetTransactions', params);
}

function getMemeCreation(params) {
    useCredit('getMemeCreation', 350);
    return sdkRelay('GetMemeCreation', params);
}

function toMs(value) {
    if (value == null) {
        return null;
    }
    if (typeof value === 'number') {
        return value > 1e12 ? value : value * 1000;
    }
    if (typeof value === 'string') {
        const parsed = Date.parse(value);
        if (!Number.isNaN(parsed)) {
            return parsed;
        }
    }
    return null;
}

function ensureUniqueDates(records) {
    const used = new Set();
    return records.map((record) => {
        let { date } = record;
        while (used.has(date)) {
            date += 1;
        }
        used.add(date);
        return { ...record, date };
    });
}

// Base descriptions (summarized from doc)
const getTradingTransactionsBaseFuncDesc = 'Get on-chain trading transactions';
const getMemeCreationBaseFuncDesc = 'Get newly created meme tokens';

// Dynamic description builders
function buildGetTradingTransactionsCallDescription(actualParams = {}) {
    const parts = [getTradingTransactionsBaseFuncDesc];

    // Wallets summary
    if (Array.isArray(actualParams.wallet_list) && actualParams.wallet_list.length > 0) {
        const count = actualParams.wallet_list.length;
        parts.push(`for ${count} wallet${count > 1 ? 's' : ''}`);
        const networks = Array.from(new Set(
            actualParams.wallet_list
                .map(w => (w && w.network) || null)
                .filter(Boolean)
        ));
        if (networks.length > 0) {
            parts.push(`on ${networks.join(', ')}`);
        }
    }

    // Include official smart money list
    if (actualParams.enable_official_address_list === true) {
        parts.push('including official smart money addresses');
    }

    // Additional filters
    const filters = [];
    const { start_time, end_time } = actualParams;
    if (start_time && end_time) {
        filters.push(`Time: ${start_time} to ${end_time}`);
    } else if (start_time) {
        filters.push(`Time from: ${start_time}`);
    } else if (end_time) {
        filters.push(`Time until: ${end_time}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function buildGetMemeCreationCallDescription(actualParams = {}) {
    const parts = [getMemeCreationBaseFuncDesc];

    // Network (omit if not provided)
    if (actualParams.network) {
        parts.push(`on ${actualParams.network}`);
    }

    // Filters
    const filters = [];
    const { start_time, end_time } = actualParams;
    if (start_time && end_time) {
        filters.push(`Time: ${start_time} to ${end_time}`);
    } else if (start_time) {
        filters.push(`Time from: ${start_time}`);
    } else if (end_time) {
        filters.push(`Time until: ${end_time}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function makeTradingTransactionsNode(params) {
    return {
        inputs: {
            transactions_raw: () => getTradingTransactions(params),
        },
        outputs: {
            trading_transactions: {
                name: 'trading_transactions',
                description: 'On-chain trading transactions',
                fields: [
                    { name: 'date', type: 'number', description: 'transaction time ms' },
                    { name: 'dir', type: 'string', description: 'transaction direction' },
                    { name: 'wallet_addr', type: 'string', description: 'wallet address' },
                    { name: 'asset', type: 'string', description: 'asset symbol' },
                    { name: 'asset_addr', type: 'string', description: 'asset contract address' },
                    { name: 'side_asset', type: 'string', description: 'side asset' },
                    { name: 'side_asset_addr', type: 'string', description: 'side asset contract' },
                    { name: 'amount', type: 'number', description: 'amount transacted' },
                    { name: 'amount_usd', type: 'number', description: 'amount in USD' },
                    { name: 'source', type: 'string', description: 'transaction source' },
                    { name: 'wallet_kind', type: 'string', description: 'wallet type' },
                    { name: 'label', type: 'string', description: 'wallet label' },
                    { name: 'twitter_handle', type: 'string', description: 'wallet twitter handle' },
                ],
                ref: createReferenceWithTitle(getTradingTransactionsRef, params, buildGetTradingTransactionsCallDescription),
            },
        },
        run: (inputs) => {
            const transactions = Array.isArray(inputs.transactions_raw)
                ? inputs.transactions_raw
                        .map((item) => {
                            const ts = toMs(item.time);
                            if (ts == null) return null;
                            return {
                                date: ts,
                                dir: item.dir,
                                wallet_addr: item.wallet_addr,
                                asset: item.asset,
                                asset_addr: item.asset_addr,
                                side_asset: item.side_asset,
                                side_asset_addr: item.side_asset_addr,
                                amount: item.amount,
                                amount_usd: item.amount_usd,
                                source: item.source,
                                wallet_kind: item.wallet_kind,
                                label: item.label,
                                twitter_handle: item.twitter_handle,
                            };
                        })
                        .filter(Boolean)
                : [];
            return { trading_transactions: ensureUniqueDates(transactions) };
        },
    };
}

function makeMemeCreationNode(params) {
    return {
        inputs: {
            meme_creation_raw: () => getMemeCreation(params),
        },
        outputs: {
            meme_creation: {
                name: 'meme_creation',
                description: 'Newly created meme tokens',
                fields: [
                    { name: 'date', type: 'number', description: 'creation time ms' },
                    { name: 'name', type: 'string', description: 'token name' },
                    { name: 'symbol', type: 'string', description: 'token symbol' },
                    { name: 'contract_address', type: 'string', description: 'token contract address' },
                    { name: 'network', type: 'string', description: 'network' },
                    { name: 'creator_address', type: 'string', description: 'creator address' },
                    { name: 'description', type: 'string', description: 'token description' },
                ],
                ref: createReferenceWithTitle(getMemeCreationRef, params, buildGetMemeCreationCallDescription),
            },
        },
        run: (inputs) => {
            const records = Array.isArray(inputs.meme_creation_raw)
                ? inputs.meme_creation_raw
                        .map((item) => {
                            const ts = toMs(item.created_at);
                            if (ts == null) return null;
                            return {
                                date: ts,
                                name: item.name,
                                symbol: item.symbol,
                                contract_address: item.contract_address,
                                network: item.network,
                                creator_address: item.creator_address,
                                description: item.description || '',
                            };
                        })
                        .filter(Boolean)
                : [];
            return { meme_creation: ensureUniqueDates(records) };
        },
    };
}

module.exports = {
    getTradingTransactions,
    getMemeCreation,
    makeTradingTransactionsNode,
    makeMemeCreationNode,
    getRefs,
};
