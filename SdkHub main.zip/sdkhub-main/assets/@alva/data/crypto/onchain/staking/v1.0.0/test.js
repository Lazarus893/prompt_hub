const { Graph } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');
const { makeTotalValueStakedNode, makeStakingInflowTotalNode, makeStakingTransactionCountNode, makeStakingValidatorTotalNode } = require('@alva/data/crypto/onchain/staking:v1.0.0');

// Shared test time range (from/to are REQUIRED by cryptoQuantSDK)
const TEST_TO = Math.floor(Date.now() / 1000);
const TEST_FROM = TEST_TO - 7 * 24 * 60 * 60; // 1 week ago
const FROM_MS = TEST_FROM * 1000;
const TO_MS = TEST_TO * 1000;

// Assertion helpers
function assert(cond, msg) {
  if (!cond) throw new Error(msg || 'assertion failed');
}

function isInteger(n) {
  return Number.isInteger(n);
}

function isMsEpoch(n) {
  return typeof n === 'number' && isInteger(n) && n > 0 && n > 10_000_000_000;
}

function hasUniqueDates(rows) {
  const s = new Set();
  for (const r of rows) {
    if (s.has(r.date)) return false;
    s.add(r.date);
  }
  return true;
}

function expectFieldsMatch(rows, fieldNames) {
  for (const r of rows) {
    const got = Object.keys(r);
    assert(got.includes('date'), 'missing required field: "date"');
    for (const f of fieldNames) assert(got.includes(f), `missing field: ${f}`);
  }
}

// Output checker
async function checkNodeOutput(graph, jagentId, nodeId, outputName, { expectFields = [], preloadLast = '200', extra = null, range = null } = {}) {
  const { TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
  const uri = new TimeSeriesUri(jagentId, nodeId, outputName, { last: preloadLast });
  const view = new TimeSeries(uri, graph.store);
  view.init();
  const rows = view.data.slice();

  if (rows.length === 0) {
    throw new Error(`no rows returned for node ${nodeId} output ${outputName}`);
  }

  for (const r of rows) {
    assert(typeof r === 'object' && r != null, 'row must be object');
    assert(isMsEpoch(r.date), `date must be ms epoch, got: ${r.date}`);
    if (range) {
      assert(r.date >= range.from * 1000 && r.date <= range.to * 1000, `date out of range: ${r.date}`);
    }
  }
  assert(hasUniqueDates(rows), 'duplicate "date" values within one output');
  expectFieldsMatch(rows, expectFields);

  if (typeof extra === 'function') extra(rows, view);
  return rows;
}

function runOriginalTests() {
  console.log('\n=== Running Original Graph Tests (with required from/to) ===');
  const params = { symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: 5 };

  const g = new Graph(jagentId);
  g.addNode('staking_total_value', makeTotalValueStakedNode(params));
  g.addNode('staking_inflow', makeStakingInflowTotalNode(params));
  g.addNode('staking_transactions', makeStakingTransactionCountNode(params));
  g.addNode('staking_validators', makeStakingValidatorTotalNode(params));

  g.run();

  // ---- Ref assertions ----
  // staking_total_value -> total_value_staked
  {
    const refs = g.getRefsForOutput('staking_total_value', 'total_value_staked');
    if (refs.length > 0) {
      const ref = refs[0];
      const expected = {
        id: '@alva/data/crypto/onchain/staking/getTotalValueStaked',
        module_name: '@alva/data/crypto/onchain/staking',
        module_display_name: 'On-Chain Staking Activity',
        sdk_name: 'getTotalValueStaked',
        sdk_display_name: 'ETH Total Value Staked',
        source_name: 'CryptoQuant',
        source: 'https://cryptoquant.com/en/docs#tag/ETH-2.0/operation/ETHgetTotalValueStaked',
      };
      if (ref.id !== expected.id) throw new Error(`ref.id mismatch: got ${ref.id}`);
      if (ref.module_name !== expected.module_name) throw new Error(`ref.module_name mismatch: got ${ref.module_name}`);
      if (ref.module_display_name !== expected.module_display_name) throw new Error(`ref.module_display_name mismatch: got ${ref.module_display_name}`);
      if (ref.sdk_name !== expected.sdk_name) throw new Error(`ref.sdk_name mismatch: got ${ref.sdk_name}`);
      if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error(`ref.sdk_display_name mismatch: got ${ref.sdk_display_name}`);
      if (ref.source_name !== expected.source_name) throw new Error(`ref.source_name mismatch: got ${ref.source_name}`);
      if (ref.source !== expected.source) throw new Error(`ref.source mismatch: got ${ref.source}`);
    } else {
      throw new Error('Assertion failed: refs array is empty for total_value_staked.');
    }
  }

  // staking_inflow -> staking_inflow_total
  {
    const refs = g.getRefsForOutput('staking_inflow', 'staking_inflow_total');
    if (refs.length > 0) {
      const ref = refs[0];
      const expected = {
        id: '@alva/data/crypto/onchain/staking/getStakingInflowTotal',
        module_name: '@alva/data/crypto/onchain/staking',
        module_display_name: 'On-Chain Staking Activity',
        sdk_name: 'getStakingInflowTotal',
        sdk_display_name: 'ETH Total Staking Inflow',
        source_name: 'CryptoQuant',
        source: 'https://cryptoquant.com/en/docs#tag/ETH-2.0/operation/ETHgetStakingInflowTotal',
      };
      if (ref.id !== expected.id) throw new Error(`ref.id mismatch: got ${ref.id}`);
      if (ref.module_name !== expected.module_name) throw new Error(`ref.module_name mismatch: got ${ref.module_name}`);
      if (ref.module_display_name !== expected.module_display_name) throw new Error(`ref.module_display_name mismatch: got ${ref.module_display_name}`);
      if (ref.sdk_name !== expected.sdk_name) throw new Error(`ref.sdk_name mismatch: got ${ref.sdk_name}`);
      if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error(`ref.sdk_display_name mismatch: got ${ref.sdk_display_name}`);
      if (ref.source_name !== expected.source_name) throw new Error(`ref.source_name mismatch: got ${ref.source_name}`);
      if (ref.source !== expected.source) throw new Error(`ref.source mismatch: got ${ref.source}`);
    } else {
      throw new Error('Assertion failed: refs array is empty for staking_inflow_total.');
    }
  }

  // staking_transactions -> staking_transaction_count
  {
    const refs = g.getRefsForOutput('staking_transactions', 'staking_transaction_count');
    if (refs.length > 0) {
      const ref = refs[0];
      const expected = {
        id: '@alva/data/crypto/onchain/staking/getStakingTransactionCount',
        module_name: '@alva/data/crypto/onchain/staking',
        module_display_name: 'On-Chain Staking Activity',
        sdk_name: 'getStakingTransactionCount',
        sdk_display_name: 'ETH Staking Transaction Count',
        source_name: 'CryptoQuant',
        source: 'https://cryptoquant.com/en/docs#tag/ETH-2.0/operation/ETHgetStakingTransactionCount',
      };
      if (ref.id !== expected.id) throw new Error(`ref.id mismatch: got ${ref.id}`);
      if (ref.module_name !== expected.module_name) throw new Error(`ref.module_name mismatch: got ${ref.module_name}`);
      if (ref.module_display_name !== expected.module_display_name) throw new Error(`ref.module_display_name mismatch: got ${ref.module_display_name}`);
      if (ref.sdk_name !== expected.sdk_name) throw new Error(`ref.sdk_name mismatch: got ${ref.sdk_name}`);
      if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error(`ref.sdk_display_name mismatch: got ${ref.sdk_display_name}`);
      if (ref.source_name !== expected.source_name) throw new Error(`ref.source_name mismatch: got ${ref.source_name}`);
      if (ref.source !== expected.source) throw new Error(`ref.source mismatch: got ${ref.source}`);
    } else {
      throw new Error('Assertion failed: refs array is empty for staking_transaction_count.');
    }
  }

  // staking_validators -> staking_validator_total
  {
    const refs = g.getRefsForOutput('staking_validators', 'staking_validator_total');
    if (refs.length > 0) {
      const ref = refs[0];
      const expected = {
        id: '@alva/data/crypto/onchain/staking/getStakingValidatorTotal',
        module_name: '@alva/data/crypto/onchain/staking',
        module_display_name: 'On-Chain Staking Activity',
        sdk_name: 'getStakingValidatorTotal',
        sdk_display_name: 'ETH Total Staking Validator',
        source_name: 'CryptoQuant',
        source: 'https://cryptoquant.com/en/docs#tag/ETH-2.0/operation/ETHgetStakingValidatorTotal',
      };
      if (ref.id !== expected.id) throw new Error(`ref.id mismatch: got ${ref.id}`);
      if (ref.module_name !== expected.module_name) throw new Error(`ref.module_name mismatch: got ${ref.module_name}`);
      if (ref.module_display_name !== expected.module_display_name) throw new Error(`ref.module_display_name mismatch: got ${ref.module_display_name}`);
      if (ref.sdk_name !== expected.sdk_name) throw new Error(`ref.sdk_name mismatch: got ${ref.sdk_name}`);
      if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error(`ref.sdk_display_name mismatch: got ${ref.sdk_display_name}`);
      if (ref.source_name !== expected.source_name) throw new Error(`ref.source_name mismatch: got ${ref.source_name}`);
      if (ref.source !== expected.source) throw new Error(`ref.source mismatch: got ${ref.source}`);
    } else {
      throw new Error('Assertion failed: refs array is empty for staking_validator_total.');
    }
  }

  // Test total value staked node output
  const totalValueRows = checkNodeOutput(g, jagentId, 'staking_total_value', 'total_value_staked', {
    expectFields: ['total_value_staked'],
    preloadLast: '50',
    range: { from: TEST_FROM, to: TEST_TO },
    extra: (rows) => {
      for (const r of rows) {
        assert(typeof r.total_value_staked === 'number', 'total_value_staked must be number');
      }
    },
  });

  // Test staking inflow total node output
  const inflowRows = checkNodeOutput(g, jagentId, 'staking_inflow', 'staking_inflow_total', {
    expectFields: ['staking_inflow_total'],
    preloadLast: '50',
    range: { from: TEST_FROM, to: TEST_TO },
    extra: (rows) => {
      for (const r of rows) {
        assert(typeof r.staking_inflow_total === 'number', 'staking_inflow_total must be number');
      }
    },
  });

  // Test staking transaction count node output
  const txCountRows = checkNodeOutput(g, jagentId, 'staking_transactions', 'staking_transaction_count', {
    expectFields: ['staking_transaction_count'],
    preloadLast: '50',
    range: { from: TEST_FROM, to: TEST_TO },
    extra: (rows) => {
      for (const r of rows) {
        assert(typeof r.staking_transaction_count === 'number', 'staking_transaction_count must be number');
      }
    },
  });

  // Test staking validator total node output
  const validatorRows = checkNodeOutput(g, jagentId, 'staking_validators', 'staking_validator_total', {
    expectFields: ['staking_validator_total'],
    preloadLast: '50',
    range: { from: TEST_FROM, to: TEST_TO },
    extra: (rows) => {
      for (const r of rows) {
        assert(typeof r.staking_validator_total === 'number', 'staking_validator_total must be number');
      }
    },
  });

  return 0;
}

function testStakingFunctions() {
  console.log('\n=== Testing Staking Functions (with required from/to) ===');

  const {
    getTotalValueStaked,
    getStakingInflowTotal,
    getStakingTransactionCount,
    getStakingValidatorTotal
  } = require('@alva/data/crypto/onchain/staking:v1.0.0');

  let totalTests = 0;
  let passedTests = 0;

  // Helper function to run test and track results
  function runTest(testName, testFunc) {
    totalTests++;
    try {
      testFunc();
      console.log(`✅ ${testName}`);
      passedTests++;
    } catch (e) {
      console.log(`❌ ${testName}: ${e.message}`);
    }
  }

  function assertTimeRange(result, from, to) {
    assert(result && result.result && Array.isArray(result.result.data), 'Invalid result');
    for (const item of result.result.data) {
      if (item && typeof item.timestamp === 'number') {
        assert(item.timestamp >= from && item.timestamp <= to, `timestamp out of range: ${item.timestamp}`);
      }
    }
  }

  // ============ getTotalValueStaked Tests ============
  console.log('\n--- Testing getTotalValueStaked ---');

  // Test with required symbol and time range
  runTest('getTotalValueStaked with required params', () => {
    const result = getTotalValueStaked({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO });
    assert(result && typeof result === 'object', 'Should return object');
    assert(result.status && typeof result.status === 'object', 'Should have status object');
    assert(result.result && typeof result.result === 'object', 'Should have result object');
    assert(Array.isArray(result.result.data), 'Should have data array');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  // Test all window enum values
  runTest('getTotalValueStaked with window=day', () => {
    const result = getTotalValueStaked({ symbol: 'eth2', window: 'day', from: TEST_FROM, to: TEST_TO, limit: 5 });
    assert(result && result.result && Array.isArray(result.result.data), 'Should work with day window');
    assert(result.result.data.length <= 5, 'Should respect limit parameter');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  runTest('getTotalValueStaked with window=hour', () => {
    const result = getTotalValueStaked({ symbol: 'eth2', window: 'hour', from: TEST_FROM, to: TEST_TO, limit: 5 });
    assert(result && result.result && Array.isArray(result.result.data), 'Should work with hour window');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  runTest('getTotalValueStaked with window=block', () => {
    const result = getTotalValueStaked({ symbol: 'eth2', window: 'block', from: TEST_FROM, to: TEST_TO, limit: 5 });
    assert(result && result.result && Array.isArray(result.result.data), 'Should work with block window');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  // Test boundary values for limit parameter
  runTest('getTotalValueStaked with minimum limit', () => {
    const result = getTotalValueStaked({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: 2 });
    assert(result && result.result && Array.isArray(result.result.data), 'Should work with minimum limit');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  runTest('getTotalValueStaked with maximum limit', () => {
    const result = getTotalValueStaked({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: 100000 });
    assert(result && result.result && Array.isArray(result.result.data), 'Should work with maximum limit');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  // Test with time range parameters (different small range)
  runTest('getTotalValueStaked with from/to timestamps', () => {
    const now = TEST_TO;
    const oneWeekAgo = TEST_FROM;
    const result = getTotalValueStaked({ symbol: 'eth2', from: oneWeekAgo, to: now, limit: 10 });
    assert(result && result.result && Array.isArray(result.result.data), 'Should work with time range');
    assertTimeRange(result, oneWeekAgo, now);
  });

  // Test data structure
  runTest('getTotalValueStaked data structure validation', () => {
    const result = getTotalValueStaked({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: 3 });
    if (result.result.data.length > 0) {
      const dataPoint = result.result.data[0];
      assert(typeof dataPoint.total_value_staked === 'number', 'total_value_staked should be number');
      assert(typeof dataPoint.timestamp === 'number', 'date should be timestamp number');
      assertTimeRange(result, TEST_FROM, TEST_TO);
    }
  });

  // ============ getStakingInflowTotal Tests ============
  console.log('\n--- Testing getStakingInflowTotal ---');

  // Test with required params
  runTest('getStakingInflowTotal with required params', () => {
    const result = getStakingInflowTotal({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO });
    assert(result && typeof result === 'object', 'Should return object');
    assert(result.status && typeof result.status === 'object', 'Should have status object');
    assert(result.result && typeof result.result === 'object', 'Should have result object');
    assert(Array.isArray(result.result.data), 'Should have data array');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  // Test all window enum values (day, hour only)
  runTest('getStakingInflowTotal with window=day', () => {
    const result = getStakingInflowTotal({ symbol: 'eth2', window: 'day', from: TEST_FROM, to: TEST_TO, limit: 5 });
    assert(result && result.result && Array.isArray(result.result.data), 'Should work with day window');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  runTest('getStakingInflowTotal with window=hour', () => {
    const result = getStakingInflowTotal({ symbol: 'eth2', window: 'hour', from: TEST_FROM, to: TEST_TO, limit: 5 });
    assert(result && result.result && Array.isArray(result.result.data), 'Should work with hour window');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  // Test boundary values for limit parameter
  runTest('getStakingInflowTotal boundary values', () => {
    const resultMin = getStakingInflowTotal({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: 2 });
    assert(resultMin && resultMin.result && Array.isArray(resultMin.result.data), 'Should work with minimum limit');

    const resultMax = getStakingInflowTotal({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: 100000 });
    assert(resultMax && resultMax.result && Array.isArray(resultMax.result.data), 'Should work with maximum limit');
    assertTimeRange(resultMin, TEST_FROM, TEST_TO);
    assertTimeRange(resultMax, TEST_FROM, TEST_TO);
  });

  // Test data structure
  runTest('getStakingInflowTotal data structure validation', () => {
    const result = getStakingInflowTotal({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: 3 });
    if (result.result.data.length > 0) {
      const dataPoint = result.result.data[0];
      assert(typeof dataPoint.staking_inflow_total === 'number', 'staking_inflow_total should be number');
      assert(typeof dataPoint.timestamp === 'number', 'date should be timestamp number');
      assertTimeRange(result, TEST_FROM, TEST_TO);
    }
  });

  // ============ getStakingTransactionCount Tests ============
  console.log('\n--- Testing getStakingTransactionCount ---');

  // Test with required params
  runTest('getStakingTransactionCount with required params', () => {
    const result = getStakingTransactionCount({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO });
    assert(result && typeof result === 'object', 'Should return object');
    assert(result.status && typeof result.status === 'object', 'Should have status object');
    assert(result.result && typeof result.result === 'object', 'Should have result object');
    assert(Array.isArray(result.result.data), 'Should have data array');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  // Test all window enum values (day, hour only)
  runTest('getStakingTransactionCount with window=day', () => {
    const result = getStakingTransactionCount({ symbol: 'eth2', window: 'day', from: TEST_FROM, to: TEST_TO, limit: 5 });
    assert(result && result.result && Array.isArray(result.result.data), 'Should work with day window');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  runTest('getStakingTransactionCount with window=hour', () => {
    const result = getStakingTransactionCount({ symbol: 'eth2', window: 'hour', from: TEST_FROM, to: TEST_TO, limit: 5 });
    assert(result && result.result && Array.isArray(result.result.data), 'Should work with hour window');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  // Test with time range parameters
  runTest('getStakingTransactionCount with time range', () => {
    const now = TEST_TO;
    const threeDaysAgo = now - 3 * 24 * 60 * 60;
    const result = getStakingTransactionCount({ symbol: 'eth2', from: threeDaysAgo, to: now, limit: 10 });
    assert(result && result.result && Array.isArray(result.result.data), 'Should work with time range');
    assertTimeRange(result, threeDaysAgo, now);
  });

  // Test data structure
  runTest('getStakingTransactionCount data structure validation', () => {
    const result = getStakingTransactionCount({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: 3 });
    if (result.result.data.length > 0) {
      const dataPoint = result.result.data[0];
      assert(typeof dataPoint.staking_transaction_count === 'number', 'staking_transaction_count should be number');
      assert(typeof dataPoint.timestamp === 'number', 'date should be timestamp number');
      assertTimeRange(result, TEST_FROM, TEST_TO);
    }
  });

  // ============ getStakingValidatorTotal Tests ============
  console.log('\n--- Testing getStakingValidatorTotal ---');

  // Test with required params
  runTest('getStakingValidatorTotal with required params', () => {
    const result = getStakingValidatorTotal({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO });
    assert(result && typeof result === 'object', 'Should return object');
    assert(result.status && typeof result.status === 'object', 'Should have status object');
    assert(result.result && typeof result.result === 'object', 'Should have result object');
    assert(Array.isArray(result.result.data), 'Should have data array');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  // Test all window enum values (day, hour only)
  runTest('getStakingValidatorTotal with window=day', () => {
    const result = getStakingValidatorTotal({ symbol: 'eth2', window: 'day', from: TEST_FROM, to: TEST_TO, limit: 5 });
    assert(result && result.result && Array.isArray(result.result.data), 'Should work with day window');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  runTest('getStakingValidatorTotal with window=hour', () => {
    const result = getStakingValidatorTotal({ symbol: 'eth2', window: 'hour', from: TEST_FROM, to: TEST_TO, limit: 5 });
    assert(result && result.result && Array.isArray(result.result.data), 'Should work with hour window');
    assertTimeRange(result, TEST_FROM, TEST_TO);
  });

  // Test boundary values for limit parameter
  runTest('getStakingValidatorTotal boundary values', () => {
    const resultMin = getStakingValidatorTotal({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: 2 });
    assert(resultMin && resultMin.result && Array.isArray(resultMin.result.data), 'Should work with minimum limit');

    const resultMax = getStakingValidatorTotal({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: 100000 });
    assert(resultMax && resultMax.result && Array.isArray(resultMax.result.data), 'Should work with maximum limit');
    assertTimeRange(resultMin, TEST_FROM, TEST_TO);
    assertTimeRange(resultMax, TEST_FROM, TEST_TO);
  });

  // Test data structure
  runTest('getStakingValidatorTotal data structure validation', () => {
    const result = getStakingValidatorTotal({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: 3 });
    if (result.result.data.length > 0) {
      const dataPoint = result.result.data[0];
      assert(typeof dataPoint.staking_validator_total === 'number', 'staking_validator_total should be number');
      assert(typeof dataPoint.timestamp === 'number', 'date should be timestamp number');
      assertTimeRange(result, TEST_FROM, TEST_TO);
    }
  });

  // ============ Error Handling Tests ============
  console.log('\n--- Testing Error Handling ---');

  // Test invalid symbol (with required from/to)
  runTest('All functions with invalid symbol', () => {
    try {
      getTotalValueStaked({ symbol: 'invalid', from: TEST_FROM, to: TEST_TO });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.includes('Error') || e.message.includes('invalid') || e.message.includes('Unsupported'), 'Should handle invalid symbol');
    }
  });


  // Test invalid window for getTotalValueStaked
  runTest('getTotalValueStaked with invalid window', () => {
    try {
      getTotalValueStaked({ symbol: 'eth2', window: 'invalid', from: TEST_FROM, to: TEST_TO });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.includes('Error') || e.message.includes('Invalid'), 'Should handle invalid window');
    }
  });

  // Test invalid window for other functions
  runTest('getStakingInflowTotal with invalid window', () => {
    try {
      getStakingInflowTotal({ symbol: 'eth2', window: 'block', from: TEST_FROM, to: TEST_TO }); // Not supported for this function
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.includes('Error') || e.message.includes('Invalid'), 'Should handle invalid window');
    }
  });

  // Test limit out of range
  runTest('All functions with limit below range', () => {
    try {
      getTotalValueStaked({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: 1 }); // Below minimum of 2
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.includes('Error') || e.message.includes('Invalid'), 'Should handle limit below range');
    }
  });

  runTest('All functions with limit above range', () => {
    try {
      getTotalValueStaked({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: 100001 }); // Above maximum of 100000
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.includes('Error') || e.message.includes('Invalid'), 'Should handle limit above range');
    }
  });

  // Test missing required parameter symbol (with from/to present)
  runTest('All functions missing required symbol', () => {
    try {
      getTotalValueStaked({ from: TEST_FROM, to: TEST_TO }); // Missing required symbol
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.includes('Error') || e.message.includes('required') || e.message.includes('symbol'), 'Should handle missing required parameter');
    }
  });

  // Test invalid timestamp format
  runTest('Functions with invalid timestamps', () => {
    try {
      getTotalValueStaked({ symbol: 'eth2', from: 'invalid_timestamp', to: 'invalid_timestamp' });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.includes('Error') || e.message.includes('timestamp'), 'Should handle invalid timestamps');
    }
  });

  // ============ Special Value Tests ============
  console.log('\n--- Testing Special Values ---');

  // Test with zero limit (should fail)
  runTest('Functions with zero limit', () => {
    try {
      getStakingInflowTotal({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: 0 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.includes('Error') || e.message.includes('Invalid'), 'Should handle zero limit');
    }
  });

  // Test with negative limit (should fail)
  runTest('Functions with negative limit', () => {
    try {
      getStakingTransactionCount({ symbol: 'eth2', from: TEST_FROM, to: TEST_TO, limit: -5 });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.includes('Error') || e.message.includes('Invalid'), 'Should handle negative limit');
    }
  });

  // Test with very old timestamp
  runTest('Functions with very old timestamp', () => {
    const ancientTime = 0;
    try {
      const result = getStakingValidatorTotal({ symbol: 'eth2', from: ancientTime, to: ancientTime + 3600, limit: 5 });
      assert(result && result.result, 'Should handle very old timestamp gracefully');
    } catch (e) {
      // Expected to possibly fail, but should fail gracefully
      assert(e.message.includes('Error') || e.message.includes('timestamp') || e.message.length > 0, 'Should handle very old timestamp');
    }
  });

  // Print test summary
  console.log('\n=== Staking Functions Test Summary ===');
  console.log(`Total tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${totalTests - passedTests}`);
  console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

  if (passedTests === totalTests) {
    console.log('🎉 All staking function tests passed!');
  } else {
    console.log('⚠️  Some staking function tests failed. Please review the output above.');
  }
}

function main(){
  // Run graph node tests (with from/to)
  runOriginalTests();

  // Run direct function tests (with from/to and time range assertions)
  testStakingFunctions();

  return 0;
}

main();
