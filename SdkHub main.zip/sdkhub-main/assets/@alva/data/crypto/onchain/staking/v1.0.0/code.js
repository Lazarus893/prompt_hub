const { useCredit } = require('internal');
const cryptoQuantSDK = require('@alva/external/cryptoquant:v1.0.0');

// Refs sourced from tool.json
const getTotalValueStakedRef = {
  id: '@alva/data/crypto/onchain/staking/getTotalValueStaked',
  module_name: '@alva/data/crypto/onchain/staking',
  module_display_name: 'On-Chain Staking Activity',
  sdk_name: 'getTotalValueStaked',
  sdk_display_name: 'ETH Total Value Staked',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/ETH-2.0/operation/ETHgetTotalValueStaked',
};

const getStakingInflowTotalRef = {
  id: '@alva/data/crypto/onchain/staking/getStakingInflowTotal',
  module_name: '@alva/data/crypto/onchain/staking',
  module_display_name: 'On-Chain Staking Activity',
  sdk_name: 'getStakingInflowTotal',
  sdk_display_name: 'ETH Total Staking Inflow',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/ETH-2.0/operation/ETHgetStakingInflowTotal',
};

const getStakingTransactionCountRef = {
  id: '@alva/data/crypto/onchain/staking/getStakingTransactionCount',
  module_name: '@alva/data/crypto/onchain/staking',
  module_display_name: 'On-Chain Staking Activity',
  sdk_name: 'getStakingTransactionCount',
  sdk_display_name: 'ETH Staking Transaction Count',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/ETH-2.0/operation/ETHgetStakingTransactionCount',
};

const getStakingValidatorTotalRef = {
  id: '@alva/data/crypto/onchain/staking/getStakingValidatorTotal',
  module_name: '@alva/data/crypto/onchain/staking',
  module_display_name: 'On-Chain Staking Activity',
  sdk_name: 'getStakingValidatorTotal',
  sdk_display_name: 'ETH Total Staking Validator',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/ETH-2.0/operation/ETHgetStakingValidatorTotal',
};

function getTotalValueStaked(params) {
  useCredit('getTotalValueStaked', 350);
  return cryptoQuantSDK.getCQTotalValueStaked(params);
}

function getStakingInflowTotal(params) {
  useCredit('getStakingInflowTotal', 350);
  return cryptoQuantSDK.getCQStakingInflowTotal(params);
}

function getStakingTransactionCount(params) {
  useCredit('getStakingTransactionCount', 350);
  return cryptoQuantSDK.getCQStakingTransactionCount(params);
}

function getStakingValidatorTotal(params) {
  useCredit('getStakingValidatorTotal', 350);
  return cryptoQuantSDK.getCQStakingValidatorTotal(params);
}

function toMs(value) {
  if (value == null) {
    return null;
  }
  if (typeof value === 'number') {
    return value > 1e12 ? value : value * 1000;
  }
  if (typeof value === 'string') {
    const parsed = Date.parse(value);
    if (!Number.isNaN(parsed)) {
      return parsed;
    }
  }
  return null;
}

function extractSeries(response) {
  const data = response?.result?.data;
  return Array.isArray(data) ? data : [];
}

// Deduplicate by timestamp (ms) without micro-shifting.
// For duplicates at the same timestamp, keep the last occurrence deterministically.
function coalesceByDate(records) {
  const sorted = records.slice().sort((a, b) => a.date - b.date);
  const out = [];
  for (const r of sorted) {
    const last = out[out.length - 1];
    if (last && last.date === r.date) {
      out[out.length - 1] = r; // keep the latest for that timestamp
    } else {
      out.push(r);
    }
  }
  return out;
}

function createStakingNode(fetchFn, params, config) {
  const { outputKey, outputName, description, fields, ref } = config;
  return {
    inputs: {
      raw: () => fetchFn(params),
    },
    outputs: {
      [outputKey]: {
        name: outputName,
        description,
        fields: [
          { name: 'date', type: 'number', description: 'timestamp ms' },
          ...fields.map((field) => ({
            name: field.name,
            type: field.type || 'number',
            description: field.description,
          })),
        ],
        ref,
      },
    },
    run: (inputs) => {
      const series = extractSeries(inputs.raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) return null;
          const record = { date: ts };
          for (const field of fields) {
            record[field.name] = item[field.source || field.name];
          }
          return record;
        })
        .filter(Boolean);
      return { [outputKey]: coalesceByDate(series) };
    },
  };
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
  // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
  const title = titleBuilder(params);

  // 2. 组合 refObject 和新 title
  const newObject = {
    ...refObject,
    title: title
  };

  // 3. 返回新对象
  return newObject;
}

function makeTotalValueStakedNode(params) {
  return createStakingNode(getTotalValueStaked, params, {
    outputKey: 'total_value_staked',
    outputName: 'staking_total_value_staked',
    description: 'Total value staked',
    fields: [{ name: 'total_value_staked', description: 'total staked balance' }],
    ref: createReferenceWithTitle(getTotalValueStakedRef, params, buildGetTotalValueStakedCallDescription),
  });
}

function makeStakingInflowTotalNode(params) {
  return createStakingNode(getStakingInflowTotal, params, {
    outputKey: 'staking_inflow_total',
    outputName: 'staking_inflow_total',
    description: 'Staking inflow totals',
    fields: [{ name: 'staking_inflow_total', description: 'total inflow' }],
    ref: createReferenceWithTitle(getStakingInflowTotalRef, params, buildGetStakingInflowTotalCallDescription),
  });
}

function makeStakingTransactionCountNode(params) {
  return createStakingNode(getStakingTransactionCount, params, {
    outputKey: 'staking_transaction_count',
    outputName: 'staking_transaction_count',
    description: 'Staking transaction count',
    fields: [{ name: 'staking_transaction_count', description: 'transaction count' }],
    ref: createReferenceWithTitle(getStakingTransactionCountRef, params, buildGetStakingTransactionCountCallDescription),
  });
}

function makeStakingValidatorTotalNode(params) {
  return createStakingNode(getStakingValidatorTotal, params, {
    outputKey: 'staking_validator_total',
    outputName: 'staking_validator_total',
    description: 'Total staking validators',
    fields: [{ name: 'staking_validator_total', description: 'validator count' }],
    ref: createReferenceWithTitle(getStakingValidatorTotalRef, params, buildGetStakingValidatorTotalCallDescription),
  });
}

// ===== Internal description builders (do not export) =====
// Base descriptions (concise summaries derived from doc)
const baseGetTotalValueStakedDesc = 'Get historical total value staked';
const baseGetStakingInflowTotalDesc = 'Get historical total staking inflow';
const baseGetStakingTransactionCountDesc = 'Get historical staking transaction count';
const baseGetStakingValidatorTotalDesc = 'Get historical total validators';

function buildGetTotalValueStakedCallDescription(actualParams = {}) {
  const parts = [baseGetTotalValueStakedDesc];
  if (actualParams.symbol) {
    parts.push(`for ${actualParams.symbol}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  } else if (actualParams.from) {
    filters.push(`Time from: ${actualParams.from}`);
  } else if (actualParams.to) {
    filters.push(`Time to: ${actualParams.to}`);
  }
  if (actualParams.limit && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetStakingInflowTotalCallDescription(actualParams = {}) {
  const parts = [baseGetStakingInflowTotalDesc];
  if (actualParams.symbol) {
    parts.push(`for ${actualParams.symbol}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  } else if (actualParams.from) {
    filters.push(`Time from: ${actualParams.from}`);
  } else if (actualParams.to) {
    filters.push(`Time to: ${actualParams.to}`);
  }
  if (actualParams.limit && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetStakingTransactionCountCallDescription(actualParams = {}) {
  const parts = [baseGetStakingTransactionCountDesc];
  if (actualParams.symbol) {
    parts.push(`for ${actualParams.symbol}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  } else if (actualParams.from) {
    filters.push(`Time from: ${actualParams.from}`);
  } else if (actualParams.to) {
    filters.push(`Time to: ${actualParams.to}`);
  }
  if (actualParams.limit && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetStakingValidatorTotalCallDescription(actualParams = {}) {
  const parts = [baseGetStakingValidatorTotalDesc];
  if (actualParams.symbol) {
    parts.push(`for ${actualParams.symbol}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  } else if (actualParams.from) {
    filters.push(`Time from: ${actualParams.from}`);
  } else if (actualParams.to) {
    filters.push(`Time to: ${actualParams.to}`);
  }
  if (actualParams.limit && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function getRefs() {
  return [
    getTotalValueStakedRef,
    getStakingInflowTotalRef,
    getStakingTransactionCountRef,
    getStakingValidatorTotalRef,
  ];
}

module.exports = {
  getTotalValueStaked,
  getStakingInflowTotal,
  getStakingTransactionCount,
  getStakingValidatorTotal,
  makeTotalValueStakedNode,
  makeStakingInflowTotalNode,
  makeStakingTransactionCountNode,
  makeStakingValidatorTotalNode,
  getRefs,
};
