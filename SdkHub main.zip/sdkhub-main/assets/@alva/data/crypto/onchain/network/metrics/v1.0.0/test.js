// Test assertion helpers
function assert(cond, msg) {
    if (!cond) throw new Error(msg || 'assertion failed');
}

function isInteger(n) {
    return Number.isInteger(n);
}

function isMsEpoch(n) {
    return typeof n === 'number' && isInteger(n) && n > 0 && n > 10_000_000_000;
}

function hasUniqueDates(rows) {
    const s = new Set();
    for (const r of rows) {
        if (s.has(r.date)) return false;
        s.add(r.date);
    }
    return true;
}

function expectFieldsMatch(rows, fieldNames) {
    for (const r of rows) {
        const got = Object.keys(r);
        assert(got.includes('date'), 'missing required field: "date"');
        for (const f of fieldNames) assert(got.includes(f), `missing field: ${f}`);
    }
}

// Common time range for all tests (REQUIRED by SDK)
const NOW_S = Math.floor(Date.now() / 1000);
const FROM_S = NOW_S - 7 * 24 * 60 * 60; // last 7 days
const TO_S = NOW_S;

// Generic graph output checker
function checkNodeOutput(graph, jagentId, nodeId, outputName, { expectFields = [], preloadLast = '50', extra = null, timeBounds = null } = {}) {
    const { TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const uri = new TimeSeriesUri(jagentId, nodeId, outputName, { last: preloadLast });
    const view = new TimeSeries(uri, graph.store);
    view.init();
    const rows = view.data.slice();

    if (rows.length === 0) {
        throw new Error(`no rows returned for node ${nodeId} output ${outputName}`);
    }

    for (const r of rows) {
        assert(typeof r === 'object' && r != null, 'row must be object');
        assert(isMsEpoch(r.date), `date must be ms epoch, got: ${r.date}`);
        if (timeBounds) {
            const fromMs = timeBounds.from * 1000;
            const toMs = timeBounds.to * 1000;
            assert(r.date >= fromMs, `date ${r.date} should be >= from ${fromMs}`);
            assert(r.date <= toMs, `date ${r.date} should be <= to ${toMs}`);
        }
    }
    assert(hasUniqueDates(rows), 'duplicate "date" values within one output');
    expectFieldsMatch(rows, expectFields);

    if (typeof extra === 'function') extra(rows, view);
    return rows;
}

function assertRefEquals(ref, expected) {
    const keys = ['id', 'module_name', 'module_display_name', 'sdk_name', 'sdk_display_name', 'source_name', 'source'];
    for (const k of keys) {
        if (ref[k] !== expected[k]) {
            throw new Error(`Assertion failed for ref.${k}: expected ${JSON.stringify(expected[k])}, got ${JSON.stringify(ref[k])}`);
        }
    }
}

function main() {
    const { Graph } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const {
        makeAddressesCountNode,
        makeTransactionsCountNode,
        makeFeesNode,
        makeContractsCountNode,
        makeBlockCountNode,
        makeGasNode,
        makeBlockRewardNode,
        makeTokensTransferredNode,
        makeFlowIndicatorMpiNode,
        makeWhaleRatioNode,
        makeInflowAgeDistributionNode,
    } = require('@alva/data/crypto/onchain/network/metrics:v1.0.0');

    const graph = new Graph(jagentId);

    // Test all make*Node functions with comprehensive output validation (include required from/to)
    graph.addNode('btc_addresses', makeAddressesCountNode({ symbol: 'btc', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('btc_transactions', makeTransactionsCountNode({ symbol: 'btc', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('btc_fees', makeFeesNode({ symbol: 'btc', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('btc_block_reward', makeBlockRewardNode({ symbol: 'btc', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('network_addresses', makeAddressesCountNode({ symbol: 'xrp', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('network_transactions', makeTransactionsCountNode({ symbol: 'xrp', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('network_tokens_transferred', makeTokensTransferredNode({ symbol: 'xrp', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('network_fees', makeFeesNode({ symbol: 'eth', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('network_contracts', makeContractsCountNode({ symbol: 'eth', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('network_block_count', makeBlockCountNode({ symbol: 'eth', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('network_gas', makeGasNode({ symbol: 'eth', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('network_block_reward_eth', makeBlockRewardNode({ symbol: 'eth', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('network_block_reward_btc', makeBlockRewardNode({ symbol: 'btc', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('flow_indicator_mpi', makeFlowIndicatorMpiNode({ symbol: 'btc', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('exchange_whale_ratio', makeWhaleRatioNode({ symbol: 'btc', exchange: 'Binance', from: FROM_S, to: TO_S, limit: 5 }));
    graph.addNode('inflow_age_distribution', makeInflowAgeDistributionNode({ symbol: 'btc', exchange: 'binance', from: FROM_S, to: TO_S, limit: 5 }));

    graph.run();

    // Test BTC Network Data APIs (5 core APIs)
    console.log('🔍 Testing BTC Network Data APIs...');

    const btcAddrRows = checkNodeOutput(graph, jagentId, 'btc_addresses', 'addresses', {
        expectFields: ['addresses_count_active', 'addresses_count_sender', 'addresses_count_receiver'],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                ['addresses_count_active', 'addresses_count_sender', 'addresses_count_receiver'].forEach((k) => assert(typeof r[k] === 'number', `${k} must be number`));
            }
        },
    });

    const btcTxRows = checkNodeOutput(graph, jagentId, 'btc_transactions', 'transactions', {
        expectFields: ['transactions_count_total'],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.transactions_count_total === 'number', 'transactions_count_total must be number');
            }
        },
    });

    const btcFeesRows = checkNodeOutput(graph, jagentId, 'btc_fees', 'fees', {
        expectFields: ['total_fees'],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.total_fees === 'number', 'total_fees must be number');
            }
        },
    });

    const btcBlockRewardRows = checkNodeOutput(graph, jagentId, 'network_block_reward_btc', 'block_reward', {
        expectFields: ['blockreward_usd'],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.blockreward_usd === 'number', 'blockreward_usd must be number');
            }
        },
    });

    const ethBlockRewardRows = checkNodeOutput(graph, jagentId, 'network_block_reward_eth', 'block_reward', {
        expectFields: ['blockreward_usd'],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.blockreward_usd === 'number', 'blockreward_usd must be number');
            }
        },
    });

    console.log('✅ BTC Active Addresses Count (BTC) API tested');
    console.log('✅ BTC Transactions Count (BTC) API tested');
    console.log('✅ BTC Fees (BTC) API tested');
    console.log('✅ BTC Block Reward (BTC) API tested');
    console.log('✅ ETH Block Reward (ETH) API tested');
    console.log(`✅ Tested ${btcAddrRows.length} BTC addresses records`);
    console.log(`✅ Tested ${btcTxRows.length} BTC transactions records`);
    console.log(`✅ Tested ${btcFeesRows.length} BTC fees records`);
    console.log(`✅ Tested ${btcBlockRewardRows.length} BTC block reward records`);

    // Test addresses count node output
    const addrRows = checkNodeOutput(graph, jagentId, 'network_addresses', 'addresses', {
        expectFields: ['addresses_count_active', 'addresses_count_sender', 'addresses_count_receiver'],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                ['addresses_count_active', 'addresses_count_sender', 'addresses_count_receiver'].forEach((k) => assert(typeof r[k] === 'number', `${k} must be number`));
            }
        },
    });

    // Test transactions count node output
    const txRows = checkNodeOutput(graph, jagentId, 'network_transactions', 'transactions', {
        expectFields: ['transactions_count_total'],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.transactions_count_total === 'number', 'transactions_count_total must be number');
            }
        },
    });

    // Test fees node output
    const feesRows = checkNodeOutput(graph, jagentId, 'network_fees', 'fees', {
        expectFields: ['total_fees'],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.total_fees === 'number', 'total_fees must be number');
            }
        },
    });

    // Test contracts count node output
    const contractsRows = checkNodeOutput(graph, jagentId, 'network_contracts', 'contracts', {
        expectFields: ['contracts_created_new', 'contracts_destroyed_new', 'contracts_count_total'],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                ['contracts_created_new', 'contracts_destroyed_new', 'contracts_count_total'].forEach((k) => assert(typeof r[k] === 'number', `${k} must be number`));
            }
        },
    });

    // Test block count node output
    const blockRows = checkNodeOutput(graph, jagentId, 'network_block_count', 'block_count', {
        expectFields: ['block_count'],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.block_count === 'number', 'block_count must be number');
            }
        },
    });

    // Test gas node output
    const gasRows = checkNodeOutput(graph, jagentId, 'network_gas', 'gas', {
        expectFields: ['gas_used_total', 'gas_used_mean', 'gas_price_mean', 'gas_limit_mean'],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                ['gas_used_total', 'gas_used_mean', 'gas_price_mean', 'gas_limit_mean'].forEach((k) => assert(typeof r[k] === 'number', `${k} must be number`));
            }
        },
    });

    // Test tokens transferred node output
    const tokensRows = checkNodeOutput(graph, jagentId, 'network_tokens_transferred', 'tokens_transferred', {
        expectFields: ['tokens_transferred_total'],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.tokens_transferred_total === 'number', 'tokens_transferred_total must be number');
            }
        },
    });

    console.log('✅ All network metrics make*Node tests passed');
    console.log(`✅ Tested ${addrRows.length} addresses records`);
    console.log(`✅ Tested ${txRows.length} transactions records`);
    console.log(`✅ Tested ${feesRows.length} fees records`);
    console.log(`✅ Tested ${contractsRows.length} contracts records`);
    console.log(`✅ Tested ${blockRows.length} block count records`);
    console.log(`✅ Tested ${gasRows.length} gas records`);
    console.log(`✅ Tested ${tokensRows.length} tokens transferred records`);
    // Test flow indicator MPI node output
    const mpiRows = checkNodeOutput(graph, jagentId, 'flow_indicator_mpi', 'flow_indicator_mpi', {
        expectFields: ['mpi'],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.mpi === 'number', 'mpi must be number');
            }
        },
    });

    // Test flow indicator exchange whale ratio node output
    const whaleRatioRows = checkNodeOutput(graph, jagentId, 'exchange_whale_ratio', 'flow_exchange_whale_ratio', {
        expectFields: ['exchange_whale_ratio'],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.exchange_whale_ratio === 'number', 'exchange_whale_ratio must be number');
            }
        },
    });

    // Test flow indicator exchange inflow age distribution node output
    const ageDistributionRows = checkNodeOutput(graph, jagentId, 'inflow_age_distribution', 'inflow_age_distribution', {
        expectFields: [
            'range_0d_1d', 'range_1d_1w', 'range_1w_1m', 'range_1m_3m', 'range_3m_6m',
            'range_6m_12m', 'range_12m_18m', 'range_18m_2y', 'range_2y_3y',
            'range_3y_5y', 'range_5y_7y', 'range_7y_10y', 'range_10y_inf',
            'range_0d_1d_percent', 'range_1d_1w_percent', 'range_1w_1m_percent', 'range_1m_3m_percent',
            'range_3m_6m_percent', 'range_6m_12m_percent', 'range_12m_18m_percent', 'range_18m_2y_percent',
            'range_2y_3y_percent', 'range_3y_5y_percent', 'range_5y_7y_percent', 'range_7y_10y_percent',
            'range_10y_inf_percent'
        ],
        preloadLast: '50',
        timeBounds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                [
                    'range_0d_1d', 'range_1d_1w', 'range_1w_1m', 'range_1m_3m', 'range_3m_6m',
                    'range_6m_12m', 'range_12m_18m', 'range_18m_2y', 'range_2y_3y',
                    'range_3y_5y', 'range_5y_7y', 'range_7y_10y', 'range_10y_inf',
                    'range_0d_1d_percent', 'range_1d_1w_percent', 'range_1w_1m_percent', 'range_1m_3m_percent',
                    'range_3m_6m_percent', 'range_6m_12m_percent', 'range_12m_18m_percent', 'range_18m_2y_percent',
                    'range_2y_3y_percent', 'range_3y_5y_percent', 'range_5y_7y_percent', 'range_7y_10y_percent',
                    'range_10y_inf_percent'
                ].forEach((k) => assert(typeof r[k] === 'number', `${k} must be number`));
            }
        },
    });

    console.log(`✅ Tested ${mpiRows.length} MPI records`);
    console.log(`✅ Tested ${whaleRatioRows.length} exchange whale ratio records`);
    console.log(`✅ Tested ${ageDistributionRows.length} exchange inflow age distribution records`);

    // Additional tests: verify refs metadata against tool.json entries (via ref constants in code.js)
    console.log('🔍 Verifying refs for selected outputs...');

    // network_gas -> getGas
    {
        const refs = graph.getRefsForOutput('network_gas', 'gas');
        if (refs.length > 0) {
            const expected = {
                id: '@alva/data/crypto/onchain/network/metrics/getGas',
                module_name: '@alva/data/crypto/onchain/network/metrics',
                module_display_name: 'On-Chain Network Metrics',
                sdk_name: 'getGas',
                sdk_display_name: 'ETH Gas',
                source_name: 'CryptoQuant',
                source: 'https://cryptoquant.com/en/docs#tag/ETH-Network-Data/operation/getGasETH',
            };
            assertRefEquals(refs[0], expected);
            console.log('✅ Ref verified for network_gas/gas');
        } else {
            throw new Error('Assertion failed: refs array is empty for network_gas/gas.');
        }
    }

    // btc_addresses -> getAddressesCount
    {
        const refs = graph.getRefsForOutput('btc_addresses', 'addresses');
        if (refs.length > 0) {
            const expected = {
                id: '@alva/data/crypto/onchain/network/metrics/getAddressesCount',
                module_name: '@alva/data/crypto/onchain/network/metrics',
                module_display_name: 'On-Chain Network Metrics',
                sdk_name: 'getAddressesCount',
                sdk_display_name: 'Token Active Addresses Count',
                source_name: 'CryptoQuant',
                source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Data/operation/getAddressesCount',
            };
            assertRefEquals(refs[0], expected);
            console.log('✅ Ref verified for btc_addresses/addresses');
        } else {
            throw new Error('Assertion failed: refs array is empty for btc_addresses/addresses.');
        }
    }

    // network_contracts -> getContractsCount
    {
        const refs = graph.getRefsForOutput('network_contracts', 'contracts');
        if (refs.length > 0) {
            const expected = {
                id: '@alva/data/crypto/onchain/network/metrics/getContractsCount',
                module_name: '@alva/data/crypto/onchain/network/metrics',
                module_display_name: 'On-Chain Network Metrics',
                sdk_name: 'getContractsCount',
                sdk_display_name: 'ETH Contracts Count',
                source_name: 'CryptoQuant',
                source: 'https://cryptoquant.com/en/docs#tag/ETH-Network-Data/operation/getContractsCountETH',
            };
            assertRefEquals(refs[0], expected);
            console.log('✅ Ref verified for network_contracts/contracts');
        } else {
            throw new Error('Assertion failed: refs array is empty for network_contracts/contracts.');
        }
    }

    // network_tokens_transferred -> getTokensTransferred
    {
        const refs = graph.getRefsForOutput('network_tokens_transferred', 'tokens_transferred');
        if (refs.length > 0) {
            const expected = {
                id: '@alva/data/crypto/onchain/network/metrics/getTokensTransferred',
                module_name: '@alva/data/crypto/onchain/network/metrics',
                module_display_name: 'On-Chain Network Metrics',
                sdk_name: 'getTokensTransferred',
                sdk_display_name: 'Token Transferred Count',
                source_name: 'CryptoQuant',
                source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Data/operation/getTokensTransferred',
            };
            assertRefEquals(refs[0], expected);
            console.log('✅ Ref verified for network_tokens_transferred/tokens_transferred');
        } else {
            throw new Error('Assertion failed: refs array is empty for network_tokens_transferred/tokens_transferred.');
        }
    }

    // flow_indicator_mpi -> getFlowIndicatorMpi
    {
        const refs = graph.getRefsForOutput('flow_indicator_mpi', 'flow_indicator_mpi');
        if (refs.length > 0) {
            const expected = {
                id: '@alva/data/crypto/onchain/network/metrics/getFlowIndicatorMpi',
                module_name: '@alva/data/crypto/onchain/network/metrics',
                module_display_name: 'On-Chain Network Metrics',
                sdk_name: 'getFlowIndicatorMpi',
                sdk_display_name: "BTC Miners' Position Index",
                source_name: 'CryptoQuant',
                source: 'https://cryptoquant.com/en/docs#tag/BTC-Flow-Indicator/operation/getMPI',
            };
            assertRefEquals(refs[0], expected);
            console.log('✅ Ref verified for flow_indicator_mpi/flow_indicator_mpi');
        } else {
            throw new Error('Assertion failed: refs array is empty for flow_indicator_mpi/flow_indicator_mpi.');
        }
    }

    // exchange_whale_ratio -> getFlowIndicatorExchangeWhaleRatio
    {
        const refs = graph.getRefsForOutput('exchange_whale_ratio', 'flow_exchange_whale_ratio');
        if (refs.length > 0) {
            const expected = {
                id: '@alva/data/crypto/onchain/network/metrics/getFlowIndicatorExchangeWhaleRatio',
                module_name: '@alva/data/crypto/onchain/network/metrics',
                module_display_name: 'On-Chain Network Metrics',
                sdk_name: 'getFlowIndicatorExchangeWhaleRatio',
                sdk_display_name: 'BTC Exchange Whale Ratio',
                source_name: 'CryptoQuant',
                source: 'https://cryptoquant.com/en/docs#tag/BTC-Flow-Indicator/operation/getExchangeWhaleRatio',
            };
            assertRefEquals(refs[0], expected);
            console.log('✅ Ref verified for exchange_whale_ratio/flow_exchange_whale_ratio');
        } else {
            throw new Error('Assertion failed: refs array is empty for exchange_whale_ratio/flow_exchange_whale_ratio.');
        }
    }

    // inflow_age_distribution -> getFlowIndicatorExchangeInflowAgeDistribution
    {
        const refs = graph.getRefsForOutput('inflow_age_distribution', 'inflow_age_distribution');
        if (refs.length > 0) {
            const expected = {
                id: '@alva/data/crypto/onchain/network/metrics/getFlowIndicatorExchangeInflowAgeDistribution',
                module_name: '@alva/data/crypto/onchain/network/metrics',
                module_display_name: 'On-Chain Network Metrics',
                sdk_name: 'getFlowIndicatorExchangeInflowAgeDistribution',
                sdk_display_name: 'BTC Exchange Inflow Age Distribution',
                source_name: 'CryptoQuant',
                source: 'https://cryptoquant.com/en/docs#tag/BTC-Flow-Indicator/operation/getExchangeInflowAgeDistribution',
            };
            assertRefEquals(refs[0], expected);
            console.log('✅ Ref verified for inflow_age_distribution/inflow_age_distribution');
        } else {
            throw new Error('Assertion failed: refs array is empty for inflow_age_distribution/inflow_age_distribution.');
        }
    }

    // btc_transactions -> getTransactionsCount
    {
        const refs = graph.getRefsForOutput('btc_transactions', 'transactions');
        if (refs.length > 0) {
            const expected = {
                id: '@alva/data/crypto/onchain/network/metrics/getTransactionsCount',
                module_name: '@alva/data/crypto/onchain/network/metrics',
                module_display_name: 'On-Chain Network Metrics',
                sdk_name: 'getTransactionsCount',
                sdk_display_name: 'Token Transaction Count',
                source_name: 'CryptoQuant',
                source: `https://cryptoquant.com/en/docs#tag/BTC-Network-Data/operation/getVelocity

https://cryptoquant.com/en/docs#tag/ETH-Network-Data/operation/getTransactionsCountETH

https://cryptoquant.com/en/docs#tag/XRP-Network-Data/operation/getTransactionsCount`,
            };
            assertRefEquals(refs[0], expected);
            console.log('✅ Ref verified for btc_transactions/transactions');
        } else {
            throw new Error('Assertion failed: refs array is empty for btc_transactions/transactions.');
        }
    }

    // network_fees -> getFees
    {
        const refs = graph.getRefsForOutput('network_fees', 'fees');
        if (refs.length > 0) {
            const expected = {
                id: '@alva/data/crypto/onchain/network/metrics/getFees',
                module_name: '@alva/data/crypto/onchain/network/metrics',
                module_display_name: 'On-Chain Network Metrics',
                sdk_name: 'getFees',
                sdk_display_name: 'Token Fees',
                source_name: 'CryptoQuant',
                source: `https://cryptoquant.com/en/docs#tag/ETH-Network-Data/operation/getFeesETH

https://cryptoquant.com/en/docs#tag/XRP-Network-Data/operation/getFees`,
            };
            assertRefEquals(refs[0], expected);
            console.log('✅ Ref verified for network_fees/fees');
        } else {
            throw new Error('Assertion failed: refs array is empty for network_fees/fees.');
        }
    }

    // network_block_count -> getBlockCount
    {
        const refs = graph.getRefsForOutput('network_block_count', 'block_count');
        if (refs.length > 0) {
            const expected = {
                id: '@alva/data/crypto/onchain/network/metrics/getBlockCount',
                module_name: '@alva/data/crypto/onchain/network/metrics',
                module_display_name: 'On-Chain Network Metrics',
                sdk_name: 'getBlockCount',
                sdk_display_name: 'Token Block Count',
                source_name: 'CryptoQuant',
                source: `https://cryptoquant.com/en/docs#tag/BTC-Network-Data/operation/getBlockCount
https://cryptoquant.com/en/docs#tag/ETH-Network-Data/operation/getBlockCountETH
`,
            };
            assertRefEquals(refs[0], expected);
            console.log('✅ Ref verified for network_block_count/block_count');
        } else {
            throw new Error('Assertion failed: refs array is empty for network_block_count/block_count.');
        }
    }

    // network_block_reward_eth -> getBlockReward
    {
        const refs = graph.getRefsForOutput('network_block_reward_eth', 'block_reward');
        if (refs.length > 0) {
            const expected = {
                id: '@alva/data/crypto/onchain/network/metrics/getBlockReward',
                module_name: '@alva/data/crypto/onchain/network/metrics',
                module_display_name: 'On-Chain Network Metrics',
                sdk_name: 'getBlockReward',
                sdk_display_name: 'Token Block Reward',
                source_name: 'CryptoQuant',
                source: `https://cryptoquant.com/en/docs#tag/BTC-Network-Data/operation/getBlockReward
https://cryptoquant.com/en/docs#tag/ETH-Network-Data/operation/getBlockrewardETH`,
            };
            assertRefEquals(refs[0], expected);
            console.log('✅ Ref verified for network_block_reward_eth/block_reward');
        } else {
            throw new Error('Assertion failed: refs array is empty for network_block_reward_eth/block_reward.');
        }
    }

    testDirectGetFunctions();

    return 0;
}

function testDirectGetFunctions() {
    console.log('\n=== Testing Direct Get Function Calls ===');

    // Manual imports for get functions
    const {
        getAddressesCount,
        getTransactionsCount,
        getFees,
        getContractsCount,
        getBlockCount,
        getGas,
        getBlockReward,
        getTokensTransferred,
        getFlowIndicatorMpi,
        getFlowIndicatorExchangeWhaleRatio,
        getFlowIndicatorExchangeInflowAgeDistribution,
    } = require('@alva/data/crypto/onchain/network/metrics:v1.0.0');

    // Define constants for testing
    const SUPPORTED_SYMBOLS = {
        getAddressesCount: ['btc', 'xrp'],
        getTransactionsCount: ['eth', 'xrp', 'btc'],
        getFees: ['eth', 'xrp', 'btc'],
        getContractsCount: ['eth'],
        getBlockCount: ['eth'],
        getGas: ['eth'],
        getBlockReward: ['eth', 'btc'],
        getTokensTransferred: ['eth', 'xrp', 'btc'],
        getFlowIndicatorMpi: ['btc'],
        getFlowIndicatorExchangeWhaleRatio: ['btc'],
        getFlowIndicatorExchangeInflowAgeDistribution: ['btc']
    };

    const SUPPORTED_EXCHANGES = [
        'binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
        'bybit', 'kucoin', 'okx', 'upbit'
    ];

    const SUPPORTED_WINDOWS = ['day', 'hour'];

    let totalTests = 0;
    let passedTests = 0;

    // Helper function to run test and track results
    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    // Helper function to validate API response structure
    function validateApiResponse(response, expectedFields = [], timeBounds = null) {
        assert(response && typeof response === 'object', 'Response should be an object');
        assert(response.status && typeof response.status === 'object', 'Response should have status object');
        assert(typeof response.status.code === 'number', 'Status code should be a number');
        assert(typeof response.status.message === 'string', 'Status message should be a string');
        assert(response.result && typeof response.result === 'object', 'Response should have result object');
        assert(Array.isArray(response.result.data), 'Result data should be an array');

        if (expectedFields.length > 0 && response.result.data.length > 0) {
            const firstRecord = response.result.data[0];
            expectedFields.forEach(field => {
                assert(field in firstRecord, `Expected field '${field}' not found in response data`);
            });
        }

        if (timeBounds && Array.isArray(response.result.data)) {
            for (const item of response.result.data) {
                if (item && typeof item.timestamp === 'number') {
                    assert(item.timestamp >= timeBounds.from, `timestamp ${item.timestamp} should be >= from ${timeBounds.from}`);
                    assert(item.timestamp <= timeBounds.to, `timestamp ${item.timestamp} should be <= to ${timeBounds.to}`);
                }
            }
        }
    }

    // ============ getAddressesCount Tests ============
    console.log('\n--- Testing getAddressesCount ---');

    // Test happy path with all supported symbols and windows
    for (const symbol of SUPPORTED_SYMBOLS.getAddressesCount) {
        for (const window of SUPPORTED_WINDOWS) {
            runTest(`getAddressesCount with ${symbol} - ${window} window`, () => {
                const response = getAddressesCount({
                    symbol: symbol,
                    window: window,
                    from: FROM_S,
                    to: TO_S,
                    limit: 5
                });
                validateApiResponse(response, ['addresses_count_active', 'addresses_count_sender', 'addresses_count_receiver'], { from: FROM_S, to: TO_S });
            });
        }
    }

    // Test boundary values
    runTest('getAddressesCount boundary values', () => {
        const responseMin = getAddressesCount({
            symbol: 'btc',
            from: FROM_S,
            to: TO_S,
            limit: 2
        });
        validateApiResponse(responseMin, [], { from: FROM_S, to: TO_S });

        const responseMax = getAddressesCount({
            symbol: 'btc',
            from: FROM_S,
            to: TO_S,
            limit: 100000
        });
        validateApiResponse(responseMax, [], { from: FROM_S, to: TO_S });
    });

    // Test time range parameters
    runTest('getAddressesCount with time range', () => {
        const now = Math.floor(Date.now() / 1000);
        const oneDayAgo = now - 86400;

        const response = getAddressesCount({
            symbol: 'btc',
            from: oneDayAgo,
            to: now,
            limit: 10
        });
        validateApiResponse(response, [], { from: oneDayAgo, to: now });
    });

    // ============ getTransactionsCount Tests ============
    console.log('\n--- Testing getTransactionsCount ---');

    for (const symbol of SUPPORTED_SYMBOLS.getTransactionsCount) {
        for (const window of SUPPORTED_WINDOWS) {
            runTest(`getTransactionsCount with ${symbol} - ${window} window`, () => {
                const response = getTransactionsCount({
                    symbol: symbol,
                    window: window,
                    from: FROM_S,
                    to: TO_S,
                    limit: 5
                });
                validateApiResponse(response, ['transactions_count_total'], { from: FROM_S, to: TO_S });
            });
        }
    }

    // ============ getFees Tests ============
    console.log('\n--- Testing getFees ---');

    for (const symbol of SUPPORTED_SYMBOLS.getFees) {
        for (const window of SUPPORTED_WINDOWS) {
            runTest(`getFees with ${symbol} - ${window} window`, () => {
                const response = getFees({
                    symbol: symbol,
                    window: window,
                    from: FROM_S,
                    to: TO_S,
                    limit: 5
                });
                validateApiResponse(response, ['total_fees'], { from: FROM_S, to: TO_S });
            });
        }
    }

    // ============ getContractsCount Tests ============
    console.log('\n--- Testing getContractsCount ---');

    for (const window of SUPPORTED_WINDOWS) {
        runTest(`getContractsCount with eth - ${window} window`, () => {
            const response = getContractsCount({
                symbol: 'eth',
                window: window,
                from: FROM_S,
                to: TO_S,
                limit: 5
            });
            validateApiResponse(response, ['contracts_created_new', 'contracts_destroyed_new', 'contracts_count_total'], { from: FROM_S, to: TO_S });
        });
    }

    // ============ getBlockCount Tests ============
    console.log('\n--- Testing getBlockCount ---');

    for (const window of SUPPORTED_WINDOWS) {
        runTest(`getBlockCount with eth - ${window} window`, () => {
            const response = getBlockCount({
                symbol: 'eth',
                window: window,
                from: FROM_S,
                to: TO_S,
                limit: 5
            });
            validateApiResponse(response, ['block_count'], { from: FROM_S, to: TO_S });
        });
    }

    // ============ getGas Tests ============
    console.log('\n--- Testing getGas ---');

    for (const window of SUPPORTED_WINDOWS) {
        runTest(`getGas with eth - ${window} window`, () => {
            const response = getGas({
                symbol: 'eth',
                window: window,
                from: FROM_S,
                to: TO_S,
                limit: 5
            });
            validateApiResponse(response, ['gas_used_total', 'gas_used_mean', 'gas_price_mean', 'gas_limit_mean'], { from: FROM_S, to: TO_S });
        });
    }

    // ============ getBlockReward Tests ============
    console.log('\n--- Testing getBlockReward ---');

    for (const symbol of SUPPORTED_SYMBOLS.getBlockReward) {
        for (const window of SUPPORTED_WINDOWS) {
            runTest(`getBlockReward with ${symbol} - ${window} window`, () => {
                const response = getBlockReward({
                    symbol: symbol,
                    window: window,
                    from: FROM_S,
                    to: TO_S,
                    limit: 5
                });
                validateApiResponse(response, ['blockreward_usd'], { from: FROM_S, to: TO_S });
            });
        }
    }

    // ============ getTokensTransferred Tests ============
    console.log('\n--- Testing getTokensTransferred ---');

    for (const symbol of SUPPORTED_SYMBOLS.getTokensTransferred) {
        for (const window of SUPPORTED_WINDOWS) {
            runTest(`getTokensTransferred with ${symbol} - ${window} window`, () => {
                const response = getTokensTransferred({
                    symbol: symbol,
                    window: window,
                    from: FROM_S,
                    to: TO_S,
                    limit: 5
                });
                validateApiResponse(response, ['tokens_transferred_total'], { from: FROM_S, to: TO_S });
            });
        }
    }

    // ============ getFlowIndicatorMpi Tests ============
    console.log('\n--- Testing getFlowIndicatorMpi ---');

    runTest('getFlowIndicatorMpi happy path', () => {
        const response = getFlowIndicatorMpi({
            symbol: 'btc',
            from: FROM_S,
            to: TO_S,
            limit: 5
        });
        validateApiResponse(response, ['mpi'], { from: FROM_S, to: TO_S });
    });

    runTest('getFlowIndicatorMpi with time range', () => {
        const now = Math.floor(Date.now() / 1000);
        const sevenDaysAgo = now - (7 * 24 * 60 * 60);

        const response = getFlowIndicatorMpi({
            symbol: 'btc',
            from: sevenDaysAgo,
            to: now,
            limit: 10
        });
        validateApiResponse(response, [], { from: sevenDaysAgo, to: now });
    });

    // ============ getFlowIndicatorExchangeWhaleRatio Tests ============
    console.log('\n--- Testing getFlowIndicatorExchangeWhaleRatio ---');

    // Test with major exchanges
    const majorExchanges = ['binance', 'coinbase', 'kraken'];
    for (const exchange of SUPPORTED_EXCHANGES) {
        runTest(`getFlowIndicatorExchangeWhaleRatio with ${exchange}`, () => {
            const response = getFlowIndicatorExchangeWhaleRatio({
                symbol: 'btc',
                exchange: exchange,
                from: FROM_S,
                to: TO_S,
                limit: 5
            });
            validateApiResponse(response, ['exchange_whale_ratio'], { from: FROM_S, to: TO_S });
        });
    }

    for (const window of SUPPORTED_WINDOWS) {
        runTest(`getFlowIndicatorExchangeWhaleRatio with ${window} window`, () => {
            const response = getFlowIndicatorExchangeWhaleRatio({
                symbol: 'btc',
                exchange: 'binance',
                window: window,
                from: FROM_S,
                to: TO_S,
                limit: 5
            });
            validateApiResponse(response, [], { from: FROM_S, to: TO_S });
        });
    }

    // ============ getFlowIndicatorExchangeInflowAgeDistribution Tests ============
    console.log('\n--- Testing getFlowIndicatorExchangeInflowAgeDistribution ---');

    for (const exchange of SUPPORTED_EXCHANGES) {
        runTest(`getFlowIndicatorExchangeInflowAgeDistribution with ${exchange}`, () => {
            const response = getFlowIndicatorExchangeInflowAgeDistribution({
                symbol: 'btc',
                exchange: exchange,
                from: FROM_S,
                to: TO_S,
                limit: 5
            });
            const expectedFields = [
                'range_0d_1d', 'range_1d_1w', 'range_1w_1m', 'range_1m_3m', 'range_3m_6m',
                'range_6m_12m', 'range_12m_18m', 'range_18m_2y', 'range_2y_3y',
                'range_3y_5y', 'range_5y_7y', 'range_7y_10y', 'range_10y_inf',
                'range_0d_1d_percent', 'range_1d_1w_percent', 'range_1w_1m_percent', 'range_1m_3m_percent',
                'range_3m_6m_percent', 'range_6m_12m_percent', 'range_12m_18m_percent', 'range_18m_2y_percent',
                'range_2y_3y_percent', 'range_3y_5y_percent', 'range_5y_7y_percent', 'range_7y_10y_percent',
                'range_10y_inf_percent'
            ];
            validateApiResponse(response, expectedFields, { from: FROM_S, to: TO_S });
        });
    }

    // ============ Comprehensive Error Handling Tests ============
    console.log('\n--- Testing Comprehensive Error Handling ---');

    // Test Missing Required Parameters
    runTest('getAddressesCount missing symbol', () => {
        try {
            getAddressesCount({
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('symbol') && e.message.includes('required'),
                   `Should require symbol parameter. Got: ${e.message}`);
        }
    });

    // Test Invalid Symbols
    runTest('getAddressesCount invalid symbol', () => {
        try {
            getAddressesCount({
                symbol: 'invalid',
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Unsupported symbol') || e.message.includes('invalid'),
                   `Should handle invalid symbol. Got: ${e.message}`);
        }
    });

    runTest('getTransactionsCount invalid symbol', () => {
        try {
            getTransactionsCount({
                symbol: 'doge', // Not in [btc, eth, xrp]
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Unsupported symbol'),
                   `Should handle unsupported symbol. Got: ${e.message}`);
        }
    });

    runTest('getFees invalid symbol', () => {
        try {
            getFees({
                symbol: 'ltc', // Not in [btc, eth, xrp]
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Unsupported symbol'),
                   `Should handle unsupported symbol. Got: ${e.message}`);
        }
    });

    runTest('getContractsCount invalid symbol', () => {
        try {
            getContractsCount({
                symbol: 'btc', // Only eth supported
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Unsupported symbol'),
                   `Should handle unsupported symbol. Got: ${e.message}`);
        }
    });

    runTest('getBlockCount invalid symbol', () => {
        try {
            getBlockCount({
                symbol: 'btc', // Only eth supported
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Unsupported symbol'),
                   `Should handle unsupported symbol. Got: ${e.message}`);
        }
    });

    runTest('getGas invalid symbol', () => {
        try {
            getGas({
                symbol: 'btc', // Only eth supported
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Unsupported symbol'),
                   `Should handle unsupported symbol. Got: ${e.message}`);
        }
    });

    runTest('getBlockReward invalid symbol', () => {
        try {
            getBlockReward({
                symbol: 'xrp', // Not in [btc, eth]
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Unsupported symbol'),
                   `Should handle unsupported symbol. Got: ${e.message}`);
        }
    });

    runTest('getTokensTransferred invalid symbol', () => {
        try {
            getTokensTransferred({
                symbol: 'doge', // Not in [btc, eth, xrp]
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Unsupported symbol'),
                   `Should handle unsupported symbol. Got: ${e.message}`);
        }
    });

    runTest('getFlowIndicatorMpi invalid symbol', () => {
        try {
            getFlowIndicatorMpi({
                symbol: 'eth', // Only btc supported
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Unsupported symbol'),
                   `Should handle unsupported symbol. Got: ${e.message}`);
        }
    });

    // Test Invalid Exchanges
    runTest('getFlowIndicatorExchangeWhaleRatio missing exchange', () => {
        try {
            getFlowIndicatorExchangeWhaleRatio({
                symbol: 'btc',
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('exchange') && e.message.includes('required'),
                   `Should require exchange parameter. Got: ${e.message}`);
        }
    });

    runTest('getFlowIndicatorExchangeWhaleRatio invalid exchange', () => {
        try {
            getFlowIndicatorExchangeWhaleRatio({
                symbol: 'btc',
                exchange: 'InvalidExchange123',
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Unsupported exchange'),
                   `Should handle invalid exchange. Got: ${e.message}`);
        }
    });

    runTest('getFlowIndicatorExchangeInflowAgeDistribution missing exchange', () => {
        try {
            getFlowIndicatorExchangeInflowAgeDistribution({
                symbol: 'btc',
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('exchange') && e.message.includes('required'),
                   `Should require exchange parameter. Got: ${e.message}`);
        }
    });

    runTest('getFlowIndicatorExchangeInflowAgeDistribution invalid exchange', () => {
        try {
            getFlowIndicatorExchangeInflowAgeDistribution({
                symbol: 'btc',
                exchange: 'FakeExchange',
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Unsupported exchange'),
                   `Should handle invalid exchange. Got: ${e.message}`);
        }
    });

    // Test Invalid Window Parameters
    runTest('getAddressesCount invalid window', () => {
        try {
            getAddressesCount({
                symbol: 'btc',
                window: 'week', // Not 'day' or 'hour'
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Invalid window'),
                   `Should handle invalid window. Got: ${e.message}`);
        }
    });

    runTest('getTransactionsCount invalid window', () => {
        try {
            getTransactionsCount({
                symbol: 'btc',
                window: 'minute', // Not 'day' or 'hour'
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Invalid window'),
                   `Should handle invalid window. Got: ${e.message}`);
        }
    });

    // Test Invalid Limit Parameters
    runTest('Invalid limit - too small', () => {
        try {
            getTransactionsCount({
                symbol: 'btc',
                from: FROM_S,
                to: TO_S,
                limit: 1 // Below minimum of 2
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Invalid limit') || e.message.includes('at least 2'),
                   `Should handle limit too small. Got: ${e.message}`);
        }
    });

    runTest('Invalid limit - too large', () => {
        try {
            getFees({
                symbol: 'btc',
                from: FROM_S,
                to: TO_S,
                limit: 100001 // Above maximum of 100000
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Invalid limit') || e.message.includes('cannot exceed'),
                   `Should handle limit too large. Got: ${e.message}`);
        }
    });

    // Test Invalid Time Range Parameters
    runTest('Invalid time range - from >= to', () => {
        try {
            const now = Math.floor(Date.now() / 1000);
            getAddressesCount({
                symbol: 'btc',
                from: now,
                to: now - 3600, // from is after to
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Invalid time range') || e.message.includes('must be less than'),
                   `Should handle invalid time range. Got: ${e.message}`);
        }
    });

    runTest('Invalid time range - non-numeric from', () => {
        try {
            getTransactionsCount({
                symbol: 'btc',
                from: 'not-a-number',
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Invalid time range') || e.message.includes('Unix timestamp'),
                   `Should handle non-numeric from. Got: ${e.message}`);
        }
    });

    runTest('Invalid time range - non-numeric to', () => {
        try {
            getFees({
                symbol: 'btc',
                from: FROM_S,
                to: 'invalid-timestamp',
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Invalid time range') || e.message.includes('Unix timestamp'),
                   `Should handle non-numeric to. Got: ${e.message}`);
        }
    });

    // Test Invalid Parameter Types
    runTest('Invalid parameter types - null symbol', () => {
        try {
            getBlockReward({
                symbol: null,
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('symbol') && e.message.includes('required'),
                   `Should handle null symbol. Got: ${e.message}`);
        }
    });

    runTest('Invalid parameter types - empty string symbol', () => {
        try {
            getTokensTransferred({
                symbol: '',
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Unsupported symbol') || e.message.includes('symbol'),
                   `Should handle empty string symbol. Got: ${e.message}`);
        }
    });

    // Test Case Sensitivity and Exchange Variations
    runTest('Exchange validation - case insensitive', () => {
        try {
            getFlowIndicatorExchangeWhaleRatio({
                symbol: 'btc',
                exchange: 'BINANCE', // Should work with case insensitive
                from: FROM_S,
                to: TO_S,
                limit: 5
            });
            // Should succeed or at least not throw validation error
        } catch (e) {
            if (e.message.includes('Unsupported exchange')) {
                throw new Error('Should accept uppercase exchanges');
            }
        }
    });

    runTest('Exchange validation - spaced names', () => {
        try {
            getFlowIndicatorExchangeInflowAgeDistribution({
                symbol: 'btc',
                exchange: 'htx global', // Should work with spaced names
                from: FROM_S,
                to: TO_S,
                limit: 5
            });
            // Should succeed or at least not throw validation error
        } catch (e) {
            if (e.message.includes('Unsupported exchange')) {
                throw new Error('Should accept exchanges with spaces');
            }
        }
    });

    // ============ Boundary and Special Value Tests ============
    console.log('\n--- Testing Boundary and Special Values ---');

    runTest('Null parameters handling', () => {
        try {
            getTransactionsCount({
                symbol: 'btc',
                window: null,
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            // Should either work or throw meaningful error
        } catch (e) {
            assert(e.message.includes('Error'), 'Should handle null window gracefully');
        }
    });

    runTest('Very large limit', () => {
        try {
            getBlockReward({
                symbol: 'btc',
                from: FROM_S,
                to: TO_S,
                limit: 100000
            });
            // Should handle large limit gracefully
        } catch (e) {
            assert(e.message.includes('Error'), 'Should handle large limit gracefully');
        }
    });

    // ============ Data Validation Tests ============
    console.log('\n--- Testing Data Validation ---');

    runTest('Response data types validation', () => {
        const response = getGas({
            symbol: 'eth',
            from: FROM_S,
            to: TO_S,
            limit: 1
        });

        if (response.result.data.length > 0) {
            const data = response.result.data[0];
            assert(typeof data.gas_used_total === 'number', 'gas_used_total should be number');
            assert(typeof data.gas_used_mean === 'number', 'gas_used_mean should be number');
            assert(typeof data.gas_price_mean === 'number', 'gas_price_mean should be number');
            assert(typeof data.gas_limit_mean === 'number', 'gas_limit_mean should be number');
        }
    });

    runTest('Timestamp validation', () => {
        const response = getTokensTransferred({
            symbol: 'btc',
            from: FROM_S,
            to: TO_S,
            limit: 1
        });

        if (response.result.data.length > 0) {
            const data = response.result.data[0];
            assert(typeof data.timestamp === 'number', 'timestamp should be number');
            assert(data.timestamp > 1000000000, 'timestamp should be valid Unix timestamp');
            assert(data.timestamp >= FROM_S && data.timestamp <= TO_S, 'timestamp should be within requested range');
        }
    });

    // Print test summary
    console.log('\n=== Direct Function Tests Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    if (passedTests === totalTests) {
        console.log('🎉 All direct function tests passed!');
    } else {
        console.log('⚠️  Some tests failed. Please review the output above.');
    }
}

main();
