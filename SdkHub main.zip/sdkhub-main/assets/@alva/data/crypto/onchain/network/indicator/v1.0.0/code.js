const { useCredit } = require('internal');
const cryptoQuantSDK = require('@alva/external/cryptoquant:v1.0.0');

// Reference metadata from tool.json for each SDK get* function
const getIndicatorStockToFlowRef = {
  id: '@alva/data/crypto/onchain/network/indicator/getIndicatorStockToFlow',
  module_name: '@alva/data/crypto/onchain/network/indicator',
  module_display_name: 'On-Chain Network Indicator',
  sdk_name: 'getIndicatorStockToFlow',
  sdk_display_name: 'BTC Stock to Flow',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getStockToFlow',
};

const getIndicatorNvtRef = {
  id: '@alva/data/crypto/onchain/network/indicator/getIndicatorNvt',
  module_name: '@alva/data/crypto/onchain/network/indicator',
  module_display_name: 'On-Chain Network Indicator',
  sdk_name: 'getIndicatorNvt',
  sdk_display_name: 'BTC Network Value to Transaction',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getNetworkIndicatorNVT',
};

const getIndicatorPuellMultipleRef = {
  id: '@alva/data/crypto/onchain/network/indicator/getIndicatorPuellMultiple',
  module_name: '@alva/data/crypto/onchain/network/indicator',
  module_display_name: 'On-Chain Network Indicator',
  sdk_name: 'getIndicatorPuellMultiple',
  sdk_display_name: 'BTC Puell Multiple',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getPuellMultiple',
};

const getIndicatorCddRef = {
  id: '@alva/data/crypto/onchain/network/indicator/getIndicatorCdd',
  module_name: '@alva/data/crypto/onchain/network/indicator',
  module_display_name: 'On-Chain Network Indicator',
  sdk_name: 'getIndicatorCdd',
  sdk_display_name: 'BTC Coin Days Destroyed',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getCDD',
};

const getIndicatorMcaRef = {
  id: '@alva/data/crypto/onchain/network/indicator/getIndicatorMca',
  module_name: '@alva/data/crypto/onchain/network/indicator',
  module_display_name: 'On-Chain Network Indicator',
  sdk_name: 'getIndicatorMca',
  sdk_display_name: 'BTC Mean Coin Age',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getMCA',
};

const getIndicatorScaRef = {
  id: '@alva/data/crypto/onchain/network/indicator/getIndicatorSca',
  module_name: '@alva/data/crypto/onchain/network/indicator',
  module_display_name: 'On-Chain Network Indicator',
  sdk_name: 'getIndicatorSca',
  sdk_display_name: 'BTC Sum Coin Age',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getSCA',
};

const getIndicatorScaDistributionRef = {
  id: '@alva/data/crypto/onchain/network/indicator/getIndicatorScaDistribution',
  module_name: '@alva/data/crypto/onchain/network/indicator',
  module_display_name: 'On-Chain Network Indicator',
  sdk_name: 'getIndicatorScaDistribution',
  sdk_display_name: 'BTC Sum Coin Age Distribution',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getSCADistribution',
};

const getIndicatorNuplRef = {
  id: '@alva/data/crypto/onchain/network/indicator/getIndicatorNupl',
  module_name: '@alva/data/crypto/onchain/network/indicator',
  module_display_name: 'On-Chain Network Indicator',
  sdk_name: 'getIndicatorNupl',
  sdk_display_name: 'BTC Net Unrealized Profit/Loss',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/docs#tag/BTC-Network-Indicator/operation/getNUPL',
};

const getIndicatorNrplRef = {
  id: '@alva/data/crypto/onchain/network/indicator/getIndicatorNrpl',
  module_name: '@alva/data/crypto/onchain/network/indicator',
  module_display_name: 'On-Chain Network Indicator',
  sdk_name: 'getIndicatorNrpl',
  sdk_display_name: 'BTC Net Realized Profit and Loss',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getNRPL',
};

// -------------------------------------------------------------------------------------------------
// Helper to create ref object with dynamic title
// -------------------------------------------------------------------------------------------------
function createReferenceWithTitle(refObject, params, titleBuilder) {
  // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
  const title = titleBuilder(params);

  // 2. 组合 refObject 和新 title
  const newObject = {
    ...refObject,
    title: title,
  };

  // 3. 返回新对象
  return newObject;
}

function getIndicatorStockToFlow(params) {
  useCredit('getIndicatorStockToFlow', 350);
  return cryptoQuantSDK.getCQNetworkIndicatorStockToFlow(params);
}

function getIndicatorNvt(params) {
  useCredit('getIndicatorNvt', 350);
  return cryptoQuantSDK.getCQNetworkIndicatorNvt(params);
}

function getIndicatorPuellMultiple(params) {
  useCredit('getIndicatorPuellMultiple', 350);
  return cryptoQuantSDK.getCQNetworkIndicatorPuellMultiple(params);
}

function getIndicatorCdd(params) {
  useCredit('getIndicatorCdd', 350);
  return cryptoQuantSDK.getCQNetworkIndicatorCdd(params);
}

function getIndicatorMca(params) {
  useCredit('getIndicatorMca', 350);
  return cryptoQuantSDK.getCQNetworkIndicatorMca(params);
}

function getIndicatorSca(params) {
  useCredit('getIndicatorSca', 350);
  return cryptoQuantSDK.getCQNetworkIndicatorSca(params);
}

function getIndicatorScaDistribution(params) {
  useCredit('getIndicatorScaDistribution', 350);
  return cryptoQuantSDK.getCQNetworkIndicatorScaDistribution(params);
}

function getIndicatorNupl(params) {
  useCredit('getIndicatorNupl', 350);
  return cryptoQuantSDK.getCQNetworkIndicatorNupl(params);
}

function getIndicatorNrpl(params) {
  useCredit('getIndicatorNrpl', 350);
  return cryptoQuantSDK.getCQNetworkIndicatorNrpl(params);
}

function toMs(value) {
  if (value == null) return null;
  if (typeof value === 'number') return value > 1e12 ? value : value * 1000;
  if (typeof value === 'string') {
    const parsed = Date.parse(value);
    if (!Number.isNaN(parsed)) return parsed;
  }
  return null;
}

function extractSeries(response) {
  const data = response?.result?.data;
  return Array.isArray(data) ? data : [];
}

// Deduplicate by date (ms), keeping the last occurrence for each date.
// Return records sorted by date ascending (store sorts anyway, but we keep it clean).
function dedupeByDateKeepLast(records) {
  const byDate = new Map();
  for (const rec of records) {
    byDate.set(rec.date, rec);
  }
  return Array.from(byDate.keys())
    .sort((a, b) => a - b)
    .map((k) => byDate.get(k));
}

function buildIndicatorNode(fetchFn, params, config) {
  const { outputKey, outputName, description, fields, ref } = config;
  return {
    inputs: {
      raw: () => fetchFn(params),
    },
    outputs: {
      [outputKey]: {
        name: outputName,
        description,
        fields: [
          { name: 'date', type: 'number', description: 'timestamp ms' },
          ...fields.map((field) => ({
            name: field.name,
            type: field.type || 'number',
            description: field.description,
          })),
        ],
        ...(ref ? { ref } : {}),
      },
    },
    run: (inputs) => {
      const series = extractSeries(inputs.raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) return null;
          const record = { date: ts };
          for (const field of fields) {
            record[field.name] = item[field.source || field.name];
          }
          return record;
        })
        .filter(Boolean);
      return { [outputKey]: dedupeByDateKeepLast(series) };
    },
  };
}

function makeIndicatorStockToFlowNode(params) {
  return buildIndicatorNode(getIndicatorStockToFlow, params, {
    outputKey: 'stock_to_flow',
    outputName: 'network_stock_to_flow',
    description: 'Stock to Flow ratio and reversion',
    fields: [
      { name: 'stock_to_flow', description: 'Stock to Flow ratio' },
      { name: 'stock_to_flow_reversion', description: 'Price divided by Stock to Flow' },
    ],
    ref: createReferenceWithTitle(
      getIndicatorStockToFlowRef,
      params,
      buildGetIndicatorStockToFlowCallDescription
    ),
  });
}

function makeIndicatorNvtNode(params) {
  return buildIndicatorNode(getIndicatorNvt, params, {
    outputKey: 'nvt',
    outputName: 'network_nvt',
    description: 'Network Value to Transaction ratio',
    fields: [{ name: 'nvt', description: 'NVT ratio' }],
    ref: createReferenceWithTitle(
      getIndicatorNvtRef,
      params,
      buildGetIndicatorNvtCallDescription
    ),
  });
}

function makeIndicatorPuellMultipleNode(params) {
  return buildIndicatorNode(getIndicatorPuellMultiple, params, {
    outputKey: 'puell_multiple',
    outputName: 'network_puell_multiple',
    description: 'Puell Multiple',
    fields: [{ name: 'puell_multiple', description: 'Puell Multiple value' }],
    ref: createReferenceWithTitle(
      getIndicatorPuellMultipleRef,
      params,
      buildGetIndicatorPuellMultipleCallDescription
    ),
  });
}

function makeIndicatorCddNode(params) {
  return buildIndicatorNode(getIndicatorCdd, params, {
    outputKey: 'cdd',
    outputName: 'network_cdd',
    description: 'Coin Days Destroyed',
    fields: [{ name: 'cdd', description: 'Coin Days Destroyed' }],
    ref: createReferenceWithTitle(
      getIndicatorCddRef,
      params,
      buildGetIndicatorCddCallDescription
    ),
  });
}

function makeIndicatorMcaNode(params) {
  return buildIndicatorNode(getIndicatorMca, params, {
    outputKey: 'mca',
    outputName: 'network_mca',
    description: 'Mean Coin Age',
    fields: [{ name: 'mca', description: 'Mean Coin Age' }],
    ref: createReferenceWithTitle(
      getIndicatorMcaRef,
      params,
      buildGetIndicatorMcaCallDescription
    ),
  });
}

function makeIndicatorScaNode(params) {
  return buildIndicatorNode(getIndicatorSca, params, {
    outputKey: 'sca',
    outputName: 'network_sca',
    description: 'Sum Coin Age and dollar age',
    fields: [
      { name: 'sca', description: 'Sum Coin Age' },
      { name: 'scda', description: 'Sum Coin Dollar Age' },
    ],
    ref: createReferenceWithTitle(
      getIndicatorScaRef,
      params,
      buildGetIndicatorScaCallDescription
    ),
  });
}

function makeIndicatorScaDistributionNode(params) {
  const ranges = [
    'range_0d_1d',
    'range_1d_1w',
    'range_1w_1m',
    'range_1m_3m',
    'range_3m_6m',
    'range_6m_12m',
    'range_12m_18m',
    'range_18m_2y',
    'range_2y_3y',
    'range_3y_5y',
    'range_5y_7y',
    'range_7y_10y',
    'range_10y_inf',
  ];
  const percentRanges = ranges.map((name) => `${name}_percent`);
  return buildIndicatorNode(getIndicatorScaDistribution, params, {
    outputKey: 'sca_distribution',
    outputName: 'network_sca_distribution',
    description: 'Sum Coin Age distribution',
    fields: [
      ...ranges.map((name) => ({ name, description: `${name.replace(/_/g, ' ')} SCA` })),
      ...percentRanges.map((name) => ({ name, description: `${name.replace(/_/g, ' ')} share` })),
    ],
    ref: createReferenceWithTitle(
      getIndicatorScaDistributionRef,
      params,
      buildGetIndicatorScaDistributionCallDescription
    ),
  });
}

function makeIndicatorNuplNode(params) {
  return buildIndicatorNode(getIndicatorNupl, params, {
    outputKey: 'nupl',
    outputName: 'network_nupl',
    description: 'Net unrealized profit and loss components',
    fields: [
      { name: 'nupl', description: 'Net unrealized profit and loss' },
      { name: 'nup', description: 'Net unrealized profit' },
      { name: 'nul', description: 'Net unrealized loss' },
    ],
    ref: createReferenceWithTitle(
      getIndicatorNuplRef,
      params,
      buildGetIndicatorNuplCallDescription
    ),
  });
}

function makeIndicatorNrplNode(params) {
  return buildIndicatorNode(getIndicatorNrpl, params, {
    outputKey: 'nrpl',
    outputName: 'network_nrpl',
    description: 'Net realized profit and loss',
    fields: [{ name: 'nrpl', description: 'Net realized profit and loss' }],
    ref: createReferenceWithTitle(
      getIndicatorNrplRef,
      params,
      buildGetIndicatorNrplCallDescription
    ),
  });
}

// -------------------------------------------------------------------------------------------------
// Auto-generated base descriptions and dynamic description builders (from doc)
// Note: these helpers are INTERNAL (no export)
// -------------------------------------------------------------------------------------------------

// Base descriptions (concise summaries per function)
const getIndicatorStockToFlowBaseDesc = 'Get BTC Stock-to-Flow';
const getIndicatorNvtBaseDesc = 'Get BTC NVT ratio';
const getIndicatorPuellMultipleBaseDesc = 'Get BTC Puell Multiple';
const getIndicatorCddBaseDesc = 'Get BTC Coin Days Destroyed';
const getIndicatorMcaBaseDesc = 'Get BTC Mean Coin Age';
const getIndicatorScaBaseDesc = 'Get BTC Sum Coin Age';
const getIndicatorScaDistributionBaseDesc = 'Get BTC Sum Coin Age distribution';
const getIndicatorNuplBaseDesc = 'Get BTC Net Unrealized Profit/Loss';
const getIndicatorNrplBaseDesc = 'Get BTC Net Realized Profit/Loss';

function buildGetIndicatorStockToFlowCallDescription(actualParams = {}) {
  const parts = [getIndicatorStockToFlowBaseDesc];
  if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') filters.push(`Window: ${actualParams.window}`);
  if (actualParams.from && actualParams.to) filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  else if (actualParams.from) filters.push(`Time from: ${actualParams.from}`);
  else if (actualParams.to) filters.push(`Time to: ${actualParams.to}`);
  if (actualParams.limit != null && actualParams.limit !== 100) filters.push(`Limit: ${actualParams.limit}`);
  if (filters.length) parts.push(`(${filters.join(', ')})`);
  return parts.join(' ').trim();
}

function buildGetIndicatorNvtCallDescription(actualParams = {}) {
  const parts = [getIndicatorNvtBaseDesc];
  if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') filters.push(`Window: ${actualParams.window}`);
  if (actualParams.from && actualParams.to) filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  else if (actualParams.from) filters.push(`Time from: ${actualParams.from}`);
  else if (actualParams.to) filters.push(`Time to: ${actualParams.to}`);
  if (actualParams.limit != null && actualParams.limit !== 100) filters.push(`Limit: ${actualParams.limit}`);
  if (filters.length) parts.push(`(${filters.join(', ')})`);
  return parts.join(' ').trim();
}

function buildGetIndicatorPuellMultipleCallDescription(actualParams = {}) {
  const parts = [getIndicatorPuellMultipleBaseDesc];
  if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') filters.push(`Window: ${actualParams.window}`);
  if (actualParams.from && actualParams.to) filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  else if (actualParams.from) filters.push(`Time from: ${actualParams.from}`);
  else if (actualParams.to) filters.push(`Time to: ${actualParams.to}`);
  if (actualParams.limit != null && actualParams.limit !== 100) filters.push(`Limit: ${actualParams.limit}`);
  if (filters.length) parts.push(`(${filters.join(', ')})`);
  return parts.join(' ').trim();
}

function buildGetIndicatorCddCallDescription(actualParams = {}) {
  const parts = [getIndicatorCddBaseDesc];
  if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') filters.push(`Window: ${actualParams.window}`);
  if (actualParams.from && actualParams.to) filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  else if (actualParams.from) filters.push(`Time from: ${actualParams.from}`);
  else if (actualParams.to) filters.push(`Time to: ${actualParams.to}`);
  if (actualParams.limit != null && actualParams.limit !== 100) filters.push(`Limit: ${actualParams.limit}`);
  if (filters.length) parts.push(`(${filters.join(', ')})`);
  return parts.join(' ').trim();
}

function buildGetIndicatorMcaCallDescription(actualParams = {}) {
  const parts = [getIndicatorMcaBaseDesc];
  if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') filters.push(`Window: ${actualParams.window}`);
  if (actualParams.from && actualParams.to) filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  else if (actualParams.from) filters.push(`Time from: ${actualParams.from}`);
  else if (actualParams.to) filters.push(`Time to: ${actualParams.to}`);
  if (actualParams.limit != null && actualParams.limit !== 100) filters.push(`Limit: ${actualParams.limit}`);
  if (filters.length) parts.push(`(${filters.join(', ')})`);
  return parts.join(' ').trim();
}

function buildGetIndicatorScaCallDescription(actualParams = {}) {
  const parts = [getIndicatorScaBaseDesc];
  if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') filters.push(`Window: ${actualParams.window}`);
  if (actualParams.from && actualParams.to) filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  else if (actualParams.from) filters.push(`Time from: ${actualParams.from}`);
  else if (actualParams.to) filters.push(`Time to: ${actualParams.to}`);
  if (actualParams.limit != null && actualParams.limit !== 100) filters.push(`Limit: ${actualParams.limit}`);
  if (filters.length) parts.push(`(${filters.join(', ')})`);
  return parts.join(' ').trim();
}

function buildGetIndicatorScaDistributionCallDescription(actualParams = {}) {
  const parts = [getIndicatorScaDistributionBaseDesc];
  if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') filters.push(`Window: ${actualParams.window}`);
  if (actualParams.from && actualParams.to) filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  else if (actualParams.from) filters.push(`Time from: ${actualParams.from}`);
  else if (actualParams.to) filters.push(`Time to: ${actualParams.to}`);
  if (actualParams.limit != null && actualParams.limit !== 100) filters.push(`Limit: ${actualParams.limit}`);
  if (filters.length) parts.push(`(${filters.join(', ')})`);
  return parts.join(' ').trim();
}

function buildGetIndicatorNuplCallDescription(actualParams = {}) {
  const parts = [getIndicatorNuplBaseDesc];
  if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') filters.push(`Window: ${actualParams.window}`);
  if (actualParams.from && actualParams.to) filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  else if (actualParams.from) filters.push(`Time from: ${actualParams.from}`);
  else if (actualParams.to) filters.push(`Time to: ${actualParams.to}`);
  if (actualParams.limit != null && actualParams.limit !== 100) filters.push(`Limit: ${actualParams.limit}`);
  if (filters.length) parts.push(`(${filters.join(', ')})`);
  return parts.join(' ').trim();
}

function buildGetIndicatorNrplCallDescription(actualParams = {}) {
  const parts = [getIndicatorNrplBaseDesc];
  if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') filters.push(`Window: ${actualParams.window}`);
  if (actualParams.from && actualParams.to) filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  else if (actualParams.from) filters.push(`Time from: ${actualParams.from}`);
  else if (actualParams.to) filters.push(`Time to: ${actualParams.to}`);
  if (actualParams.limit != null && actualParams.limit !== 100) filters.push(`Limit: ${actualParams.limit}`);
  if (filters.length) parts.push(`(${filters.join(', ')})`);
  return parts.join(' ').trim();
}

// Collect and expose all Ref metadata objects
function getRefs() {
  return [
    getIndicatorStockToFlowRef,
    getIndicatorNvtRef,
    getIndicatorPuellMultipleRef,
    getIndicatorCddRef,
    getIndicatorMcaRef,
    getIndicatorScaRef,
    getIndicatorScaDistributionRef,
    getIndicatorNuplRef,
    getIndicatorNrplRef,
  ];
}

module.exports = {
  getIndicatorStockToFlow,
  getIndicatorNvt,
  getIndicatorPuellMultiple,
  getIndicatorCdd,
  getIndicatorMca,
  getIndicatorSca,
  getIndicatorScaDistribution,
  getIndicatorNupl,
  getIndicatorNrpl,
  makeIndicatorStockToFlowNode,
  makeIndicatorNvtNode,
  makeIndicatorPuellMultipleNode,
  makeIndicatorCddNode,
  makeIndicatorMcaNode,
  makeIndicatorScaNode,
  makeIndicatorScaDistributionNode,
  makeIndicatorNuplNode,
  makeIndicatorNrplNode,
  getRefs,
};