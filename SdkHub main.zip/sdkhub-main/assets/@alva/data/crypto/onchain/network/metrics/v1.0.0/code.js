const { useCredit } = require('internal');
const cryptoQuantSDK = require('@alva/external/cryptoquant:v1.0.0');

// Auto-generated references from tool.json for SDK functions
const getAddressesCountRef = {
    id: '@alva/data/crypto/onchain/network/metrics/getAddressesCount',
    module_name: '@alva/data/crypto/onchain/network/metrics',
    module_display_name: 'On-Chain Network Metrics',
    sdk_name: 'getAddressesCount',
    sdk_display_name: 'Token Active Addresses Count',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Data/operation/getAddressesCount',
};
const getTransactionsCountRef = {
    id: '@alva/data/crypto/onchain/network/metrics/getTransactionsCount',
    module_name: '@alva/data/crypto/onchain/network/metrics',
    module_display_name: 'On-Chain Network Metrics',
    sdk_name: 'getTransactionsCount',
    sdk_display_name: 'Token Transaction Count',
    source_name: 'CryptoQuant',
    source: `https://cryptoquant.com/en/docs#tag/BTC-Network-Data/operation/getVelocity

https://cryptoquant.com/en/docs#tag/ETH-Network-Data/operation/getTransactionsCountETH

https://cryptoquant.com/en/docs#tag/XRP-Network-Data/operation/getTransactionsCount`,
};
const getFeesRef = {
    id: '@alva/data/crypto/onchain/network/metrics/getFees',
    module_name: '@alva/data/crypto/onchain/network/metrics',
    module_display_name: 'On-Chain Network Metrics',
    sdk_name: 'getFees',
    sdk_display_name: 'Token Fees',
    source_name: 'CryptoQuant',
    source: `https://cryptoquant.com/en/docs#tag/ETH-Network-Data/operation/getFeesETH

https://cryptoquant.com/en/docs#tag/XRP-Network-Data/operation/getFees`,
};
const getContractsCountRef = {
    id: '@alva/data/crypto/onchain/network/metrics/getContractsCount',
    module_name: '@alva/data/crypto/onchain/network/metrics',
    module_display_name: 'On-Chain Network Metrics',
    sdk_name: 'getContractsCount',
    sdk_display_name: 'ETH Contracts Count',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/ETH-Network-Data/operation/getContractsCountETH',
};
const getBlockCountRef = {
    id: '@alva/data/crypto/onchain/network/metrics/getBlockCount',
    module_name: '@alva/data/crypto/onchain/network/metrics',
    module_display_name: 'On-Chain Network Metrics',
    sdk_name: 'getBlockCount',
    sdk_display_name: 'Token Block Count',
    source_name: 'CryptoQuant',
    source: `https://cryptoquant.com/en/docs#tag/BTC-Network-Data/operation/getBlockCount
https://cryptoquant.com/en/docs#tag/ETH-Network-Data/operation/getBlockCountETH
`,
};
const getGasRef = {
    id: '@alva/data/crypto/onchain/network/metrics/getGas',
    module_name: '@alva/data/crypto/onchain/network/metrics',
    module_display_name: 'On-Chain Network Metrics',
    sdk_name: 'getGas',
    sdk_display_name: 'ETH Gas',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/ETH-Network-Data/operation/getGasETH',
};
const getBlockRewardRef = {
    id: '@alva/data/crypto/onchain/network/metrics/getBlockReward',
    module_name: '@alva/data/crypto/onchain/network/metrics',
    module_display_name: 'On-Chain Network Metrics',
    sdk_name: 'getBlockReward',
    sdk_display_name: 'Token Block Reward',
    source_name: 'CryptoQuant',
    source: `https://cryptoquant.com/en/docs#tag/BTC-Network-Data/operation/getBlockReward
https://cryptoquant.com/en/docs#tag/ETH-Network-Data/operation/getBlockrewardETH`,
};
const getTokensTransferredRef = {
    id: '@alva/data/crypto/onchain/network/metrics/getTokensTransferred',
    module_name: '@alva/data/crypto/onchain/network/metrics',
    module_display_name: 'On-Chain Network Metrics',
    sdk_name: 'getTokensTransferred',
    sdk_display_name: 'Token Transferred Count',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Data/operation/getTokensTransferred',
};
const getFlowIndicatorMpiRef = {
    id: '@alva/data/crypto/onchain/network/metrics/getFlowIndicatorMpi',
    module_name: '@alva/data/crypto/onchain/network/metrics',
    module_display_name: 'On-Chain Network Metrics',
    sdk_name: 'getFlowIndicatorMpi',
    sdk_display_name: "BTC Miners' Position Index",
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/BTC-Flow-Indicator/operation/getMPI',
};
const getFlowIndicatorExchangeWhaleRatioRef = {
    id: '@alva/data/crypto/onchain/network/metrics/getFlowIndicatorExchangeWhaleRatio',
    module_name: '@alva/data/crypto/onchain/network/metrics',
    module_display_name: 'On-Chain Network Metrics',
    sdk_name: 'getFlowIndicatorExchangeWhaleRatio',
    sdk_display_name: 'BTC Exchange Whale Ratio',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/BTC-Flow-Indicator/operation/getExchangeWhaleRatio',
};
const getFlowIndicatorExchangeInflowAgeDistributionRef = {
    id: '@alva/data/crypto/onchain/network/metrics/getFlowIndicatorExchangeInflowAgeDistribution',
    module_name: '@alva/data/crypto/onchain/network/metrics',
    module_display_name: 'On-Chain Network Metrics',
    sdk_name: 'getFlowIndicatorExchangeInflowAgeDistribution',
    sdk_display_name: 'BTC Exchange Inflow Age Distribution',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/BTC-Flow-Indicator/operation/getExchangeInflowAgeDistribution',
};

// Helper: create reference with dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title,
    };

    // 3. 返回新对象
    return newObject;
}

function getAddressesCount(params) {
    useCredit('getAddressesCount', 350);
    return cryptoQuantSDK.getCQNetworkAddressesCount(params);
}

function getTransactionsCount(params) {
    useCredit('getTransactionsCount', 350);
    return cryptoQuantSDK.getCQNetworkTransactionsCount(params);
}

function getFees(params) {
    useCredit('getFees', 350);
    return cryptoQuantSDK.getCQNetworkFees(params);
}

function getContractsCount(params) {
    useCredit('getContractsCount', 350);
    return cryptoQuantSDK.getCQNetworkContractsCount(params);
}

function getBlockCount(params) {
    useCredit('getBlockCount', 350);
    return cryptoQuantSDK.getCQNetworkBlockCount(params);
}

function getGas(params) {
    useCredit('getGas', 350);
    return cryptoQuantSDK.getCQNetworkGas(params);
}

function getBlockReward(params) {
    useCredit('getBlockReward', 350);
    return cryptoQuantSDK.getCQNetworkBlockReward(params);
}

function getTokensTransferred(params) {
    useCredit('getTokensTransferred', 350);
    return cryptoQuantSDK.getCQNetworkTokensTransferred(params);
}

function getFlowIndicatorMpi(params){
    useCredit('getFlowIndicatorMpi',350);
    return cryptoQuantSDK.getCQFlowIndicatorMpi(params);
}

function getFlowIndicatorExchangeWhaleRatio(params){
    useCredit('getFlowIndicatorExchangeWhaleRatio',350);
    return cryptoQuantSDK.getCQFlowIndicatorExchangeWhaleRatio(params);
}

function getFlowIndicatorExchangeInflowAgeDistribution(params){
    useCredit('getFlowIndicatorExchangeInflowAgeDistribution',350);
    return cryptoQuantSDK.getCQFlowIndicatorExchangeInflowAgeDistribution(params);
}

function toMs(value) {
    if (value == null) {
        return null;
    }
    if (typeof value === 'number') {
        return value > 1e12 ? value : value * 1000;
    }
    if (typeof value === 'string') {
        const parsed = Date.parse(value);
        if (!Number.isNaN(parsed)) {
            return parsed;
        }
    }
    return null;
}

function extractSeries(response) {
    const data = response?.result?.data;
    return Array.isArray(data) ? data : [];
}

function ensureUniqueDates(records) {
    const used = new Set();
    return records.map((record) => {
        let { date } = record;
        while (used.has(date)) {
            date += 1;
        }
        used.add(date);
        return { ...record, date };
    });
}

function buildMetricNode(fetchFn, params, config) {
    const { outputKey, outputName, description, fields, ref } = config;
    return {
        inputs: {
            raw: () => fetchFn(params),
        },
        outputs: {
            [outputKey]: {
                name: outputName,
                description,
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'timestamp ms',
                    },
                    ...fields.map((field) => ({
                        name: field.name,
                        type: field.type || 'number',
                        description: field.description,
                    })),
                ],
                ref,
            },
        },
        run: (inputs) => {
            const series = extractSeries(inputs.raw)
                .map((item) => {
                    const ts = toMs(item.timestamp);
                    if (ts == null) {
                        return null;
                    }
                    const record = { date: ts };
                    for (const field of fields) {
                        record[field.name] = item[field.source || field.name];
                    }
                    return record;
                })
                .filter(Boolean);
            return { [outputKey]: ensureUniqueDates(series) };
        },
    };
}

function makeAddressesCountNode(params) {
    return buildMetricNode(getAddressesCount, params, {
        outputKey: 'addresses',
        outputName: 'network_addresses_count',
        description: 'Active, sending, and receiving addresses',
        ref: createReferenceWithTitle(getAddressesCountRef, params, buildGetAddressesCountCallDescription),
        fields: [
            {
                name: 'addresses_count_active',
                description: 'active addresses',
                source: 'addresses_count_active',
            },
            {
                name: 'addresses_count_sender',
                description: 'sending addresses',
                source: 'addresses_count_sender',
            },
            {
                name: 'addresses_count_receiver',
                description: 'receiving addresses',
                source: 'addresses_count_receiver',
            },
        ],
    });
}

function makeTransactionsCountNode(params) {
    return buildMetricNode(getTransactionsCount, params, {
        outputKey: 'transactions',
        outputName: 'network_transactions_count',
        description: 'Network transactions count',
        ref: createReferenceWithTitle(getTransactionsCountRef, params, buildGetTransactionsCountCallDescription),
        fields: [
            {
                name: 'transactions_count_total',
                description: 'transactions count total',
            },
        ],
    });
}

function makeFeesNode(params) {
    return buildMetricNode(getFees, params, {
        outputKey: 'fees',
        outputName: 'network_fees',
        description: 'Total transaction fees',
        ref: createReferenceWithTitle(getFeesRef, params, buildGetFeesCallDescription),
        fields: [{ name: 'total_fees', description: 'total fees in native unit' }],
    });
}

function makeContractsCountNode(params) {
    return buildMetricNode(getContractsCount, params, {
        outputKey: 'contracts',
        outputName: 'network_contracts_count',
        description: 'Smart contract counts',
        ref: createReferenceWithTitle(getContractsCountRef, params, buildGetContractsCountCallDescription),
        fields: [
            {
                name: 'contracts_created_new',
                description: 'new contracts created',
            },
            {
                name: 'contracts_destroyed_new',
                description: 'contracts destroyed',
            },
            { name: 'contracts_count_total', description: 'total contracts' },
        ],
    });
}

function makeBlockCountNode(params) {
    return buildMetricNode(getBlockCount, params, {
        outputKey: 'block_count',
        outputName: 'network_block_count',
        description: 'Blocks generated',
        ref: createReferenceWithTitle(getBlockCountRef, params, buildGetBlockCountCallDescription),
        fields: [{ name: 'block_count', description: 'block count per window' }],
    });
}

function makeGasNode(params) {
    return buildMetricNode(getGas, params, {
        outputKey: 'gas',
        outputName: 'network_gas',
        description: 'Gas usage statistics',
        ref: createReferenceWithTitle(getGasRef, params, buildGetGasCallDescription),
        fields: [
            { name: 'gas_used_total', description: 'total gas used' },
            { name: 'gas_used_mean', description: 'average gas used' },
            { name: 'gas_price_mean', description: 'average gas price' },
            { name: 'gas_limit_mean', description: 'average gas limit' },
        ],
    });
}

function makeBlockRewardNode(params) {
    return buildMetricNode(getBlockReward, params, {
        outputKey: 'block_reward',
        outputName: 'network_block_reward',
        description: 'Block reward totals',
        ref: createReferenceWithTitle(getBlockRewardRef, params, buildGetBlockRewardCallDescription),
        fields: [{ name: 'blockreward_usd', description: 'block reward USD' }],
    });
}

function makeTokensTransferredNode(params) {
    return buildMetricNode(getTokensTransferred, params, {
        outputKey: 'tokens_transferred',
        outputName: 'network_tokens_transferred',
        description: 'Tokens transferred on-chain',
        ref: createReferenceWithTitle(getTokensTransferredRef, params, buildGetTokensTransferredCallDescription),
        fields: [
            {
                name: 'tokens_transferred_total',
                description: 'tokens transferred total',
            },
        ],
    });
}

function makeFlowIndicatorMpiNode(params) {
    return buildMetricNode(getFlowIndicatorMpi, params, {
        outputKey: 'flow_indicator_mpi',
        outputName: 'flow_indicator_mpi',
        description: 'Bitcoin Miners\' Position Index (MPI)',
        ref: createReferenceWithTitle(getFlowIndicatorMpiRef, params, buildGetFlowIndicatorMpiCallDescription),
        fields: [
            {
                name: 'mpi',
                description: 'Miners\' Position Index value',
            },
        ],
    });
}

function makeWhaleRatioNode(params) {
    return buildMetricNode(getFlowIndicatorExchangeWhaleRatio, params, {
        outputKey: 'flow_exchange_whale_ratio',
        outputName: 'flow_exchange_whale_ratio',
        description: 'Exchange Whale Ratio',
        ref: createReferenceWithTitle(getFlowIndicatorExchangeWhaleRatioRef, params, buildGetFlowIndicatorExchangeWhaleRatioCallDescription),
        fields: [
            {
                name: 'exchange_whale_ratio',
                description: 'ratio of the top 10 inflows to total inflows',
            },
        ],
    });
}

function makeInflowAgeDistributionNode(params) {
    return buildMetricNode(getFlowIndicatorExchangeInflowAgeDistribution, params, {
        outputKey: 'inflow_age_distribution',
        outputName: 'inflow_age_distribution',
        description: 'Exchange Inflow Age Distribution',
        ref: createReferenceWithTitle(getFlowIndicatorExchangeInflowAgeDistributionRef, params, buildGetFlowIndicatorExchangeInflowAgeDistributionCallDescription),
        fields: [
            {
                name: 'range_0d_1d',
                description: 'Inflow from UTXOs aged 0-1 day',
            },
            {
                name: 'range_1d_1w',
                description: 'Inflow from UTXOs aged 1 day - 1 week',
            },
            {
                name: 'range_1w_1m',
                description: 'Inflow from UTXOs aged 1 week - 1 month',
            },
            {
                name: 'range_1m_3m',
                description: 'Inflow from UTXOs aged 1-3 months',
            },
            {
                name: 'range_3m_6m',
                description: 'Inflow from UTXOs aged 3-6 months',
            },
            {
                name: 'range_6m_12m',
                description: 'Inflow from UTXOs aged 6-12 months',
            },
            {
                name: 'range_12m_18m',
                description: 'Inflow from UTXOs aged 12-18 months',
            },
            {
                name: 'range_18m_2y',
                description: 'Inflow from UTXOs aged 18 months - 2 years',
            },
            {
                name: 'range_2y_3y',
                description: 'Inflow from UTXOs aged 2-3 years',
            },
            {
                name: 'range_3y_5y',
                description: 'Inflow from UTXOs aged 3-5 years',
            },
            {
                name: 'range_5y_7y',
                description: 'Inflow from UTXOs aged 5-7 years',
            },
            {
                name: 'range_7y_10y',
                description: 'Inflow from UTXOs aged 7-10 years',
            },
            {
                name: 'range_10y_inf',
                description: 'Inflow from UTXOs aged > 10 years',
            },
            {
                name: 'range_0d_1d_percent',
                description: 'Percentage of inflow from UTXOs aged 0-1 day',
            },
            {
                name: 'range_1d_1w_percent',
                description: 'Percentage of inflow from UTXOs aged 1 day - 1 week',
            },
            {
                name: 'range_1w_1m_percent',
                description: 'Percentage of inflow from UTXOs aged 1 week - 1 month',
            },
            {
                name: 'range_1m_3m_percent',
                description: 'Percentage of inflow from UTXOs aged 1-3 months',
            },
            {
                name: 'range_3m_6m_percent',
                description: 'Percentage of inflow from UTXOs aged 3-6 months',
            },
            {
                name: 'range_6m_12m_percent',
                description: 'Percentage of inflow from UTXOs aged 6-12 months',
            },
            {
                name: 'range_12m_18m_percent',
                description: 'Percentage of inflow from UTXOs aged 12-18 months',
            },
            {
                name: 'range_18m_2y_percent',
                description: 'Percentage of inflow from UTXOs aged 18 months - 2 years',
            },
            {
                name: 'range_2y_3y_percent',
                description: 'Percentage of inflow from UTXOs aged 2-3 years',
            },
            {
                name: 'range_3y_5y_percent',
                description: 'Percentage of inflow from UTXOs aged 3-5 years',
            },
            {
                name: 'range_5y_7y_percent',
                description: 'Percentage of inflow from UTXOs aged 5-7 years',
            },
            {
                name: 'range_7y_10y_percent',
                description: 'Percentage of inflow from UTXOs aged 7-10 years',
            },
            {
                name: 'range_10y_inf_percent',
                description: 'Percentage of inflow from UTXOs aged > 10 years',
            },
        ],
    });
}

// -------------------- Internal base descriptions (from doc) --------------------
// Note: These are internal helpers and MUST NOT be exported.
const baseGetAddressesCountDescription = 'Get network addresses count';
const baseGetTransactionsCountDescription = 'Get network transaction counts';
const baseGetFeesDescription = 'Get total transaction fees';
const baseGetContractsCountDescription = 'Get smart contract counts';
const baseGetBlockCountDescription = 'Get block counts';
const baseGetGasDescription = 'Get gas usage and price metrics';
const baseGetBlockRewardDescription = 'Get block reward totals';
const baseGetTokensTransferredDescription = 'Get tokens transferred';
const baseGetFlowIndicatorMpiDescription = "Get Bitcoin Miners' Position Index";
const baseGetFlowIndicatorExchangeWhaleRatioDescription = 'Get Exchange Whale Ratio';
const baseGetFlowIndicatorExchangeInflowAgeDistributionDescription = 'Get exchange inflow age distribution';

// -------------------- Dynamic call description builders (from doc params) --------------------
// Note: These are internal helpers and MUST NOT be exported.
function buildGetAddressesCountCallDescription(actualParams = {}) {
    const parts = [baseGetAddressesCountDescription];
    if (actualParams.symbol) {
        parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
    }
    const filters = [];
    if (actualParams.window && actualParams.window !== 'day') {
        filters.push(`Window: ${actualParams.window}`);
    }
    if (actualParams.from && actualParams.to) {
        filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
    } else if (actualParams.from) {
        filters.push(`From: ${actualParams.from}`);
    } else if (actualParams.to) {
        filters.push(`To: ${actualParams.to}`);
    }
    if (typeof actualParams.limit === 'number' && actualParams.limit !== 100) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

function buildGetTransactionsCountCallDescription(actualParams = {}) {
    const parts = [baseGetTransactionsCountDescription];
    if (actualParams.symbol) {
        parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
    }
    const filters = [];
    if (actualParams.window && actualParams.window !== 'day') {
        filters.push(`Window: ${actualParams.window}`);
    }
    if (actualParams.from && actualParams.to) {
        filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
    } else if (actualParams.from) {
        filters.push(`From: ${actualParams.from}`);
    } else if (actualParams.to) {
        filters.push(`To: ${actualParams.to}`);
    }
    if (typeof actualParams.limit === 'number' && actualParams.limit !== 100) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

function buildGetFeesCallDescription(actualParams = {}) {
    const parts = [baseGetFeesDescription];
    if (actualParams.symbol) {
        parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
    }
    const filters = [];
    if (actualParams.window && actualParams.window !== 'day') {
        filters.push(`Window: ${actualParams.window}`);
    }
    if (actualParams.from && actualParams.to) {
        filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
    } else if (actualParams.from) {
        filters.push(`From: ${actualParams.from}`);
    } else if (actualParams.to) {
        filters.push(`To: ${actualParams.to}`);
    }
    if (typeof actualParams.limit === 'number' && actualParams.limit !== 100) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

function buildGetContractsCountCallDescription(actualParams = {}) {
    const parts = [baseGetContractsCountDescription];
    if (actualParams.symbol) {
        parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
    }
    const filters = [];
    if (actualParams.window && actualParams.window !== 'day') {
        filters.push(`Window: ${actualParams.window}`);
    }
    if (actualParams.from && actualParams.to) {
        filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
    } else if (actualParams.from) {
        filters.push(`From: ${actualParams.from}`);
    } else if (actualParams.to) {
        filters.push(`To: ${actualParams.to}`);
    }
    if (typeof actualParams.limit === 'number' && actualParams.limit !== 100) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

function buildGetBlockCountCallDescription(actualParams = {}) {
    const parts = [baseGetBlockCountDescription];
    if (actualParams.symbol) {
        parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
    }
    const filters = [];
    if (actualParams.window && actualParams.window !== 'day') {
        filters.push(`Window: ${actualParams.window}`);
    }
    if (actualParams.from && actualParams.to) {
        filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
    } else if (actualParams.from) {
        filters.push(`From: ${actualParams.from}`);
    } else if (actualParams.to) {
        filters.push(`To: ${actualParams.to}`);
    }
    if (typeof actualParams.limit === 'number' && actualParams.limit !== 100) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

function buildGetGasCallDescription(actualParams = {}) {
    const parts = [baseGetGasDescription];
    if (actualParams.symbol) {
        parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
    }
    const filters = [];
    if (actualParams.window && actualParams.window !== 'day') {
        filters.push(`Window: ${actualParams.window}`);
    }
    if (actualParams.from && actualParams.to) {
        filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
    } else if (actualParams.from) {
        filters.push(`From: ${actualParams.from}`);
    } else if (actualParams.to) {
        filters.push(`To: ${actualParams.to}`);
    }
    if (typeof actualParams.limit === 'number' && actualParams.limit !== 100) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

function buildGetBlockRewardCallDescription(actualParams = {}) {
    const parts = [baseGetBlockRewardDescription];
    if (actualParams.symbol) {
        parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
    }
    const filters = [];
    if (actualParams.window && actualParams.window !== 'day') {
        filters.push(`Window: ${actualParams.window}`);
    }
    if (actualParams.from && actualParams.to) {
        filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
    } else if (actualParams.from) {
        filters.push(`From: ${actualParams.from}`);
    } else if (actualParams.to) {
        filters.push(`To: ${actualParams.to}`);
    }
    if (typeof actualParams.limit === 'number' && actualParams.limit !== 100) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

function buildGetTokensTransferredCallDescription(actualParams = {}) {
    const parts = [baseGetTokensTransferredDescription];
    if (actualParams.symbol) {
        parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
    }
    const filters = [];
    if (actualParams.window && actualParams.window !== 'day') {
        filters.push(`Window: ${actualParams.window}`);
    }
    if (actualParams.from && actualParams.to) {
        filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
    } else if (actualParams.from) {
        filters.push(`From: ${actualParams.from}`);
    } else if (actualParams.to) {
        filters.push(`To: ${actualParams.to}`);
    }
    if (typeof actualParams.limit === 'number' && actualParams.limit !== 100) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

function buildGetFlowIndicatorMpiCallDescription(actualParams = {}) {
    const parts = [baseGetFlowIndicatorMpiDescription];
    if (actualParams.symbol) {
        parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
    }
    const filters = [];
    if (actualParams.window && actualParams.window !== 'day') {
        filters.push(`Window: ${actualParams.window}`);
    }
    if (actualParams.from && actualParams.to) {
        filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
    } else if (actualParams.from) {
        filters.push(`From: ${actualParams.from}`);
    } else if (actualParams.to) {
        filters.push(`To: ${actualParams.to}`);
    }
    if (typeof actualParams.limit === 'number' && actualParams.limit !== 100) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

function buildGetFlowIndicatorExchangeWhaleRatioCallDescription(actualParams = {}) {
    const parts = [baseGetFlowIndicatorExchangeWhaleRatioDescription];
    if (actualParams.symbol) {
        parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
    }
    if (actualParams.exchange) {
        parts.push(`from ${actualParams.exchange}`);
    }
    const filters = [];
    if (actualParams.window && actualParams.window !== 'day') {
        filters.push(`Window: ${actualParams.window}`);
    }
    if (actualParams.from && actualParams.to) {
        filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
    } else if (actualParams.from) {
        filters.push(`From: ${actualParams.from}`);
    } else if (actualParams.to) {
        filters.push(`To: ${actualParams.to}`);
    }
    if (typeof actualParams.limit === 'number' && actualParams.limit !== 100) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

function buildGetFlowIndicatorExchangeInflowAgeDistributionCallDescription(actualParams = {}) {
    const parts = [baseGetFlowIndicatorExchangeInflowAgeDistributionDescription];
    if (actualParams.symbol) {
        parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
    }
    if (actualParams.exchange) {
        parts.push(`from ${actualParams.exchange}`);
    }
    const filters = [];
    if (actualParams.window && actualParams.window !== 'day') {
        filters.push(`Window: ${actualParams.window}`);
    }
    if (actualParams.from && actualParams.to) {
        filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
    } else if (actualParams.from) {
        filters.push(`From: ${actualParams.from}`);
    } else if (actualParams.to) {
        filters.push(`To: ${actualParams.to}`);
    }
    if (typeof actualParams.limit === 'number' && actualParams.limit !== 100) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

// -------------------- Refs collector --------------------
function getRefs() {
    return [
        getAddressesCountRef,
        getTransactionsCountRef,
        getFeesRef,
        getContractsCountRef,
        getBlockCountRef,
        getGasRef,
        getBlockRewardRef,
        getTokensTransferredRef,
        getFlowIndicatorMpiRef,
        getFlowIndicatorExchangeWhaleRatioRef,
        getFlowIndicatorExchangeInflowAgeDistributionRef,
    ];
}

module.exports = {
    getAddressesCount,
    getTransactionsCount,
    getFees,
    getContractsCount,
    getBlockCount,
    getGas,
    getBlockReward,
    getTokensTransferred,
    getFlowIndicatorMpi,
    getFlowIndicatorExchangeWhaleRatio,
    getFlowIndicatorExchangeInflowAgeDistribution,
    makeAddressesCountNode,
    makeTransactionsCountNode,
    makeFeesNode,
    makeContractsCountNode,
    makeBlockCountNode,
    makeGasNode,
    makeBlockRewardNode,
    makeTokensTransferredNode,
    makeFlowIndicatorMpiNode,
    makeWhaleRatioNode,
    makeInflowAgeDistributionNode,
    getRefs,
};