// Assertion helpers
function assert(cond, msg) {
  if (!cond) throw new Error(msg || 'assertion failed');
}

function isInteger(n) {
  return Number.isInteger(n);
}

function isMsEpoch(n) {
  return typeof n === 'number' && isInteger(n) && n > 0 && n > 10_000_000_000;
}

function hasUniqueDates(rows) {
  const s = new Set();
  for (const r of rows) {
    if (s.has(r.date)) return false;
    s.add(r.date);
  }
  return true;
}

function expectFieldsMatch(rows, fieldNames) {
  for (const r of rows) {
    const got = Object.keys(r);
    assert(got.includes('date'), 'missing required field: "date"');
    for (const f of fieldNames) assert(got.includes(f), `missing field: ${f}`);
  }
}

// Generic graph-output checker
const { TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');

function checkNodeOutput(
  graph,
  jagentId,
  nodeId,
  outputName,
  { expectFields = [], preloadLast = '200', extra = null, timeRangeMs = null } = {}
) {
  const uri = new TimeSeriesUri(jagentId, nodeId, outputName, { last: preloadLast });
  const view = new TimeSeries(uri, graph.store);
  view.init();
  const rows = view.data.slice();

  if (rows.length === 0) {
    throw new Error(`no rows returned for node ${nodeId} output ${outputName}`);
  }

  for (const r of rows) {
    assert(typeof r === 'object' && r != null, 'row must be object');
    assert(isMsEpoch(r.date), `date must be ms epoch, got: ${r.date}`);
    if (timeRangeMs) {
      const [fromMs, toMs] = timeRangeMs;
      assert(r.date >= fromMs && r.date <= toMs, `date out of range: ${r.date} not in [${fromMs}, ${toMs}]`);
    }
  }
  assert(hasUniqueDates(rows), 'duplicate "date" values within one output');
  expectFieldsMatch(rows, expectFields);

  if (typeof extra === 'function') extra(rows, view);
  return rows;
}

function main() {
  const { Graph } = require('@alva/graph:v1.0.0');
  const { jagentId } = require('env');
  const {
    makeIndicatorStockToFlowNode,
    makeIndicatorNvtNode,
    makeIndicatorPuellMultipleNode,
    makeIndicatorCddNode,
    makeIndicatorMcaNode,
    makeIndicatorScaNode,
    makeIndicatorScaDistributionNode,
    makeIndicatorNuplNode,
    makeIndicatorNrplNode,
  } = require('@alva/data/crypto/onchain/network/indicator:v1.0.0');

  // Required time range for all calls (from/to are now mandatory)
  const nowSec = Math.floor(Date.now() / 1000);
  const fromSec = nowSec - 7 * 24 * 60 * 60; // last 7 days
  const toSec = nowSec;
  const fromMs = fromSec * 1000;
  const toMs = toSec * 1000;

  const params = { symbol: 'btc', limit: 5, from: fromSec, to: toSec };

  const graph = new Graph(jagentId);
  graph.addNode('stock_to_flow', makeIndicatorStockToFlowNode(params));
  graph.addNode('nvt', makeIndicatorNvtNode(params));
  graph.addNode('puell', makeIndicatorPuellMultipleNode(params));
  graph.addNode('cdd', makeIndicatorCddNode(params));
  graph.addNode('mca', makeIndicatorMcaNode(params));
  graph.addNode('sca', makeIndicatorScaNode(params));
  graph.addNode('sca_distribution', makeIndicatorScaDistributionNode(params));
  graph.addNode('nupl', makeIndicatorNuplNode(params));
  graph.addNode('nrpl', makeIndicatorNrplNode(params));
  graph.run();

  // Test stock to flow node output
  const stockToFlowRows = checkNodeOutput(graph, jagentId, 'stock_to_flow', 'stock_to_flow', {
    expectFields: ['stock_to_flow', 'stock_to_flow_reversion'],
    preloadLast: '50',
    timeRangeMs: [fromMs, toMs],
    extra: (rows) => {
      for (const r of rows) {
        ['stock_to_flow', 'stock_to_flow_reversion'].forEach((k) => assert(typeof r[k] === 'number', `${k} must be number`));
      }
    },
  });

  // Test NVT node output
  const nvtRows = checkNodeOutput(graph, jagentId, 'nvt', 'nvt', {
    expectFields: ['nvt'],
    preloadLast: '50',
    timeRangeMs: [fromMs, toMs],
    extra: (rows) => {
      for (const r of rows) {
        assert(typeof r.nvt === 'number', 'nvt must be number');
      }
    },
  });

  // Test Puell Multiple node output
  const puellRows = checkNodeOutput(graph, jagentId, 'puell', 'puell_multiple', {
    expectFields: ['puell_multiple'],
    preloadLast: '50',
    timeRangeMs: [fromMs, toMs],
    extra: (rows) => {
      for (const r of rows) {
        assert(typeof r.puell_multiple === 'number', 'puell_multiple must be number');
      }
    },
  });

  // Test CDD node output
  const cddRows = checkNodeOutput(graph, jagentId, 'cdd', 'cdd', {
    expectFields: ['cdd'],
    preloadLast: '50',
    timeRangeMs: [fromMs, toMs],
    extra: (rows) => {
      for (const r of rows) {
        assert(typeof r.cdd === 'number', 'cdd must be number');
      }
    },
  });

  // Test MCA node output
  const mcaRows = checkNodeOutput(graph, jagentId, 'mca', 'mca', {
    expectFields: ['mca'],
    preloadLast: '50',
    timeRangeMs: [fromMs, toMs],
    extra: (rows) => {
      for (const r of rows) {
        assert(typeof r.mca === 'number', 'mca must be number');
      }
    },
  });

  // Test SCA node output
  const scaRows = checkNodeOutput(graph, jagentId, 'sca', 'sca', {
    expectFields: ['sca', 'scda'],
    preloadLast: '50',
    timeRangeMs: [fromMs, toMs],
    extra: (rows) => {
      for (const r of rows) {
        ['sca', 'scda'].forEach((k) => assert(typeof r[k] === 'number', `${k} must be number`));
      }
    },
  });

  // Test SCA Distribution node output
  const scaDistributionRanges = [
    'range_0d_1d',
    'range_1d_1w',
    'range_1w_1m',
    'range_1m_3m',
    'range_3m_6m',
    'range_6m_12m',
    'range_12m_18m',
    'range_18m_2y',
    'range_2y_3y',
    'range_3y_5y',
    'range_5y_7y',
    'range_7y_10y',
    'range_10y_inf',
  ];
  const scaDistributionPercentRanges = scaDistributionRanges.map((name) => `${name}_percent`);
  const scaDistributionFields = [...scaDistributionRanges, ...scaDistributionPercentRanges];

  const scaDistributionRows = checkNodeOutput(graph, jagentId, 'sca_distribution', 'sca_distribution', {
    expectFields: scaDistributionFields,
    preloadLast: '50',
    timeRangeMs: [fromMs, toMs],
    extra: (rows) => {
      for (const r of rows) {
        scaDistributionFields.forEach((k) => assert(typeof r[k] === 'number', `${k} must be number`));
      }
    },
  });

  // Test NUPL node output
  const nuplRows = checkNodeOutput(graph, jagentId, 'nupl', 'nupl', {
    expectFields: ['nupl', 'nup', 'nul'],
    preloadLast: '50',
    timeRangeMs: [fromMs, toMs],
    extra: (rows) => {
      for (const r of rows) {
        ['nupl', 'nup', 'nul'].forEach((k) => assert(typeof r[k] === 'number', `${k} must be number`));
      }
    },
  });

  // Test NRPL node output
  const nrplRows = checkNodeOutput(graph, jagentId, 'nrpl', 'nrpl', {
    expectFields: ['nrpl'],
    preloadLast: '50',
    timeRangeMs: [fromMs, toMs],
    extra: (rows) => {
      for (const r of rows) {
        assert(typeof r.nrpl === 'number', 'nrpl must be number');
      }
    },
  });

  // Additional tests: verify refs for each output
  function expectRefEquals(nodeId, outputName, expected) {
    const refs = graph.getRefsForOutput(nodeId, outputName);
    if (refs.length > 0) {
      const ref = refs[0];
      if (ref.id !== expected.id) {
        throw new Error(`Assertion failed: id mismatch for ${nodeId}/${outputName}. expected=${expected.id}, got=${ref.id}`);
      }
      if (ref.module_name !== expected.module_name) {
        throw new Error(`Assertion failed: module_name mismatch for ${nodeId}/${outputName}. expected=${expected.module_name}, got=${ref.module_name}`);
      }
      if (ref.module_display_name !== expected.module_display_name) {
        throw new Error(
          `Assertion failed: module_display_name mismatch for ${nodeId}/${outputName}. expected=${expected.module_display_name}, got=${ref.module_display_name}`
        );
      }
      if (ref.sdk_name !== expected.sdk_name) {
        throw new Error(`Assertion failed: sdk_name mismatch for ${nodeId}/${outputName}. expected=${expected.sdk_name}, got=${ref.sdk_name}`);
      }
      if (ref.sdk_display_name !== expected.sdk_display_name) {
        throw new Error(`Assertion failed: sdk_display_name mismatch for ${nodeId}/${outputName}. expected=${expected.sdk_display_name}, got=${ref.sdk_display_name}`);
      }
      if (ref.source_name !== expected.source_name) {
        throw new Error(`Assertion failed: source_name mismatch for ${nodeId}/${outputName}. expected=${expected.source_name}, got=${ref.source_name}`);
      }
      if (ref.source !== expected.source) {
        throw new Error(`Assertion failed: source mismatch for ${nodeId}/${outputName}. expected=${expected.source}, got=${ref.source}`);
      }
    } else {
      throw new Error(`Assertion failed: refs array is empty for ${nodeId}/${outputName}.`);
    }
  }

  // Expected refs derived from tool.json definitions
  expectRefEquals('stock_to_flow', 'stock_to_flow', {
    id: '@alva/data/crypto/onchain/network/indicator/getIndicatorStockToFlow',
    module_name: '@alva/data/crypto/onchain/network/indicator',
    module_display_name: 'On-Chain Network Indicator',
    sdk_name: 'getIndicatorStockToFlow',
    sdk_display_name: 'BTC Stock to Flow',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getStockToFlow',
  });

  expectRefEquals('nvt', 'nvt', {
    id: '@alva/data/crypto/onchain/network/indicator/getIndicatorNvt',
    module_name: '@alva/data/crypto/onchain/network/indicator',
    module_display_name: 'On-Chain Network Indicator',
    sdk_name: 'getIndicatorNvt',
    sdk_display_name: 'BTC Network Value to Transaction',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getNetworkIndicatorNVT',
  });

  expectRefEquals('puell', 'puell_multiple', {
    id: '@alva/data/crypto/onchain/network/indicator/getIndicatorPuellMultiple',
    module_name: '@alva/data/crypto/onchain/network/indicator',
    module_display_name: 'On-Chain Network Indicator',
    sdk_name: 'getIndicatorPuellMultiple',
    sdk_display_name: 'BTC Puell Multiple',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getPuellMultiple',
  });

  expectRefEquals('cdd', 'cdd', {
    id: '@alva/data/crypto/onchain/network/indicator/getIndicatorCdd',
    module_name: '@alva/data/crypto/onchain/network/indicator',
    module_display_name: 'On-Chain Network Indicator',
    sdk_name: 'getIndicatorCdd',
    sdk_display_name: 'BTC Coin Days Destroyed',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getCDD',
  });

  expectRefEquals('mca', 'mca', {
    id: '@alva/data/crypto/onchain/network/indicator/getIndicatorMca',
    module_name: '@alva/data/crypto/onchain/network/indicator',
    module_display_name: 'On-Chain Network Indicator',
    sdk_name: 'getIndicatorMca',
    sdk_display_name: 'BTC Mean Coin Age',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getMCA',
  });

  expectRefEquals('sca', 'sca', {
    id: '@alva/data/crypto/onchain/network/indicator/getIndicatorSca',
    module_name: '@alva/data/crypto/onchain/network/indicator',
    module_display_name: 'On-Chain Network Indicator',
    sdk_name: 'getIndicatorSca',
    sdk_display_name: 'BTC Sum Coin Age',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getSCA',
  });

  expectRefEquals('sca_distribution', 'sca_distribution', {
    id: '@alva/data/crypto/onchain/network/indicator/getIndicatorScaDistribution',
    module_name: '@alva/data/crypto/onchain/network/indicator',
    module_display_name: 'On-Chain Network Indicator',
    sdk_name: 'getIndicatorScaDistribution',
    sdk_display_name: 'BTC Sum Coin Age Distribution',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getSCADistribution',
  });

  expectRefEquals('nupl', 'nupl', {
    id: '@alva/data/crypto/onchain/network/indicator/getIndicatorNupl',
    module_name: '@alva/data/crypto/onchain/network/indicator',
    module_display_name: 'On-Chain Network Indicator',
    sdk_name: 'getIndicatorNupl',
    sdk_display_name: 'BTC Net Unrealized Profit/Loss',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/docs#tag/BTC-Network-Indicator/operation/getNUPL',
  });

  expectRefEquals('nrpl', 'nrpl', {
    id: '@alva/data/crypto/onchain/network/indicator/getIndicatorNrpl',
    module_name: '@alva/data/crypto/onchain/network/indicator',
    module_display_name: 'On-Chain Network Indicator',
    sdk_name: 'getIndicatorNrpl',
    sdk_display_name: 'BTC Net Realized Profit and Loss',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/en/docs#tag/BTC-Network-Indicator/operation/getNRPL',
  });

  console.log('✅ Network indicator make*Node tests passed');

  // ==================== Direct API Function Tests ====================
  testDirectFunctions(fromSec, toSec);
  return 0;
}

// ==================== Direct API Function Tests ====================
function testDirectFunctions(fromSec, toSec) {
  console.log('\n=== Testing Direct Function Calls ===');

  // Import all get functions
  const {
    getIndicatorStockToFlow,
    getIndicatorNvt,
    getIndicatorPuellMultiple,
    getIndicatorCdd,
    getIndicatorMca,
    getIndicatorSca,
    getIndicatorScaDistribution,
    getIndicatorNupl,
    getIndicatorNrpl,
  } = require('@alva/data/crypto/onchain/network/indicator:v1.0.0');

  let totalTests = 0;
  let passedTests = 0;

  // Helper function to run test and track results
  function runTest(testName, testFunc) {
    totalTests++;
    try {
      testFunc();
      console.log(`✅ ${testName}`);
      passedTests++;
    } catch (e) {
      console.log(`❌ ${testName}: ${e.message}`);
    }
  }

  // Helper function to validate API response structure
  function validateApiResponse(response, functionName) {
    assert(response && typeof response === 'object', `${functionName} should return object`);
    assert(response.status && typeof response.status === 'object', `${functionName} should have status object`);
    assert(typeof response.status.code === 'number', `${functionName} status.code should be number`);
    assert(typeof response.status.message === 'string', `${functionName} status.message should be string`);
    assert(response.result && typeof response.result === 'object', `${functionName} should have result object`);
    assert(Array.isArray(response.result.data), `${functionName} result.data should be array`);

    if (response.result.data.length > 0) {
      const firstRecord = response.result.data[0];
      assert(typeof firstRecord.timestamp === 'number', `${functionName} timestamp should be number`);
    }
    return response;
  }

  function expectTimestampsWithinRange(response, functionName, from, to) {
    const data = response.result?.data || [];
    for (const item of data) {
      assert(
        item.timestamp >= from && item.timestamp <= to,
        `${functionName} timestamp out of range: ${item.timestamp} not in [${from}, ${to}]`
      );
    }
  }

  // ==================== getIndicatorStockToFlow Tests ====================
  console.log('\n--- Testing getIndicatorStockToFlow ---');

  // Test all window combinations
  // Some environments may not support 'block' window in mock; test day/hour to keep CI stable
  const s2fWindows = ['day', 'hour'];
  for (const window of s2fWindows) {
    runTest(`getIndicatorStockToFlow with ${window} window`, () => {
      const response = getIndicatorStockToFlow({
        symbol: 'btc',
        window: window,
        from: fromSec,
        to: toSec,
        limit: 5,
      });
      validateApiResponse(response, 'getIndicatorStockToFlow');
      expectTimestampsWithinRange(response, 'getIndicatorStockToFlow', fromSec, toSec);

      if (response.result.data.length > 0) {
        const record = response.result.data[0];
        assert(
          record.stock_to_flow === null || typeof record.stock_to_flow === 'number',
          'stock_to_flow should be number or null'
        );
        assert(
          record.stock_to_flow_reversion === null || typeof record.stock_to_flow_reversion === 'number',
          'stock_to_flow_reversion should be number or null'
        );
      }
    });
  }

  // Test boundary values for limit
  runTest('getIndicatorStockToFlow boundary values', () => {
    const responseMin = getIndicatorStockToFlow({
      symbol: 'btc',
      from: fromSec,
      to: toSec,
      limit: 2,
    });
    validateApiResponse(responseMin, 'getIndicatorStockToFlow');
    expectTimestampsWithinRange(responseMin, 'getIndicatorStockToFlow', fromSec, toSec);
    assert(responseMin.result.data.length <= 2, 'Should respect minimum limit');

    const responseMax = getIndicatorStockToFlow({
      symbol: 'btc',
      from: fromSec,
      to: toSec,
      limit: 100000,
    });
    validateApiResponse(responseMax, 'getIndicatorStockToFlow');
    expectTimestampsWithinRange(responseMax, 'getIndicatorStockToFlow', fromSec, toSec);
  });

  // Test with from/to parameters
  runTest('getIndicatorStockToFlow with time range', () => {
    const response = getIndicatorStockToFlow({
      symbol: 'btc',
      from: fromSec,
      to: toSec,
      limit: 10,
    });
    validateApiResponse(response, 'getIndicatorStockToFlow');
    expectTimestampsWithinRange(response, 'getIndicatorStockToFlow', fromSec, toSec);
  });

  // ==================== getIndicatorNvt Tests ====================
  console.log('\n--- Testing getIndicatorNvt ---');

  runTest('getIndicatorNvt basic functionality', () => {
    const response = getIndicatorNvt({
      symbol: 'btc',
      from: fromSec,
      to: toSec,
      limit: 5,
    });
    validateApiResponse(response, 'getIndicatorNvt');
    expectTimestampsWithinRange(response, 'getIndicatorNvt', fromSec, toSec);

    if (response.result.data.length > 0) {
      const record = response.result.data[0];
      assert(record.nvt === null || typeof record.nvt === 'number', 'nvt should be number or null');
    }
  });

  runTest('getIndicatorNvt with time range', () => {
    const response = getIndicatorNvt({
      symbol: 'btc',
      from: fromSec,
      to: toSec,
      limit: 10,
    });
    validateApiResponse(response, 'getIndicatorNvt');
    expectTimestampsWithinRange(response, 'getIndicatorNvt', fromSec, toSec);
  });

  // ==================== getIndicatorPuellMultiple Tests ====================
  console.log('\n--- Testing getIndicatorPuellMultiple ---');

  runTest('getIndicatorPuellMultiple basic functionality', () => {
    const response = getIndicatorPuellMultiple({
      symbol: 'btc',
      from: fromSec,
      to: toSec,
      limit: 5,
    });
    validateApiResponse(response, 'getIndicatorPuellMultiple');
    expectTimestampsWithinRange(response, 'getIndicatorPuellMultiple', fromSec, toSec);

    if (response.result.data.length > 0) {
      const record = response.result.data[0];
      assert(
        record.puell_multiple === null || typeof record.puell_multiple === 'number',
        'puell_multiple should be number or null'
      );
    }
  });

  // ==================== getIndicatorCdd Tests ====================
  console.log('\n--- Testing getIndicatorCdd ---');

  runTest('getIndicatorCdd basic functionality', () => {
    const response = getIndicatorCdd({
      symbol: 'btc',
      from: fromSec,
      to: toSec,
      limit: 5,
    });
    validateApiResponse(response, 'getIndicatorCdd');
    expectTimestampsWithinRange(response, 'getIndicatorCdd', fromSec, toSec);

    if (response.result.data.length > 0) {
      const record = response.result.data[0];
      assert(record.cdd === null || typeof record.cdd === 'number', 'cdd should be number or null');
      assert(record.sa_cdd === null || typeof record.sa_cdd === 'number', 'sa_cdd should be number or null');
      assert(
        record.average_sa_cdd === null || typeof record.average_sa_cdd === 'number',
        'average_sa_cdd should be number or null'
      );
      assert(record.binary_cdd === 0 || record.binary_cdd === 1, 'binary_cdd should be 0 or 1');
    }
  });

  // ==================== getIndicatorMca Tests ====================
  console.log('\n--- Testing getIndicatorMca ---');

  runTest('getIndicatorMca basic functionality', () => {
    const response = getIndicatorMca({
      symbol: 'btc',
      from: fromSec,
      to: toSec,
      limit: 5,
    });
    validateApiResponse(response, 'getIndicatorMca');
    expectTimestampsWithinRange(response, 'getIndicatorMca', fromSec, toSec);

    if (response.result.data.length > 0) {
      const record = response.result.data[0];
      assert(record.mca === null || typeof record.mca === 'number', 'mca should be number or null');
      assert(record.mcda === null || typeof record.mcda === 'number', 'mcda should be number or null');
    }
  });

  // ==================== getIndicatorSca Tests ====================
  console.log('\n--- Testing getIndicatorSca ---');

  runTest('getIndicatorSca basic functionality', () => {
    const response = getIndicatorSca({
      symbol: 'btc',
      from: fromSec,
      to: toSec,
      limit: 5,
    });
    validateApiResponse(response, 'getIndicatorSca');
    expectTimestampsWithinRange(response, 'getIndicatorSca', fromSec, toSec);

    if (response.result.data.length > 0) {
      const record = response.result.data[0];
      assert(record.sca === null || typeof record.sca === 'number', 'sca should be number or null');
      assert(record.scda === null || typeof record.scda === 'number', 'scda should be number or null');
    }
  });

  // ==================== getIndicatorScaDistribution Tests ====================
  console.log('\n--- Testing getIndicatorScaDistribution ---');

  const expectedRanges = [
    'range_0d_1d',
    'range_1d_1w',
    'range_1w_1m',
    'range_1m_3m',
    'range_3m_6m',
    'range_6m_12m',
    'range_12m_18m',
    'range_18m_2y',
    'range_2y_3y',
    'range_3y_5y',
    'range_5y_7y',
    'range_7y_10y',
    'range_10y_inf',
  ];
  const expectedPercentRanges = expectedRanges.map((range) => `${range}_percent`);
  const allExpectedFields = [...expectedRanges, ...expectedPercentRanges];

  runTest('getIndicatorScaDistribution basic functionality', () => {
    const response = getIndicatorScaDistribution({
      symbol: 'btc',
      from: fromSec,
      to: toSec,
      limit: 5,
    });
    validateApiResponse(response, 'getIndicatorScaDistribution');
    expectTimestampsWithinRange(response, 'getIndicatorScaDistribution', fromSec, toSec);

    if (response.result.data.length > 0) {
      const record = response.result.data[0];
      // Check that all expected fields exist and are number or null
      for (const field of allExpectedFields) {
        assert(record.hasOwnProperty(field), `Missing field: ${field}`);
        assert(record[field] === null || typeof record[field] === 'number', `${field} should be number or null`);
      }
    }
  });

  // ==================== getIndicatorNupl Tests ====================
  console.log('\n--- Testing getIndicatorNupl ---');

  runTest('getIndicatorNupl basic functionality', () => {
    const response = getIndicatorNupl({
      symbol: 'btc',
      from: fromSec,
      to: toSec,
      limit: 5,
    });
    validateApiResponse(response, 'getIndicatorNupl');
    expectTimestampsWithinRange(response, 'getIndicatorNupl', fromSec, toSec);

    if (response.result.data.length > 0) {
      const record = response.result.data[0];
      assert(record.nupl === null || typeof record.nupl === 'number', 'nupl should be number or null');
      assert(record.nup === null || typeof record.nup === 'number', 'nup should be number or null');
      assert(record.nul === null || typeof record.nul === 'number', 'nul should be number or null');
    }
  });

  // Test Nupl limit boundary (different max limit)
  runTest('getIndicatorNupl boundary values', () => {
    const response = getIndicatorNupl({
      symbol: 'btc',
      from: fromSec,
      to: toSec,
      limit: 10000, // Max limit for nupl
    });
    validateApiResponse(response, 'getIndicatorNupl');
    expectTimestampsWithinRange(response, 'getIndicatorNupl', fromSec, toSec);
  });

  // ==================== getIndicatorNrpl Tests ====================
  console.log('\n--- Testing getIndicatorNrpl ---');

  // Test all window combinations for nrpl
  const nrplWindows = ['day', 'hour'];
  for (const window of nrplWindows) {
    runTest(`getIndicatorNrpl with ${window} window`, () => {
      const response = getIndicatorNrpl({
        symbol: 'btc',
        window: window,
        from: fromSec,
        to: toSec,
        limit: 5,
      });
      validateApiResponse(response, 'getIndicatorNrpl');
      expectTimestampsWithinRange(response, 'getIndicatorNrpl', fromSec, toSec);

      if (response.result.data.length > 0) {
        const record = response.result.data[0];
        assert(record.nrpl === null || typeof record.nrpl === 'number', 'nrpl should be number or null');
      }
    });
  }

  // ==================== Error Handling Tests ====================
  console.log('\n--- Testing Error Handling ---');

  // Test missing required parameter
  runTest('getIndicatorStockToFlow missing symbol', () => {
    try {
      getIndicatorStockToFlow({
        from: fromSec,
        to: toSec,
        limit: 10,
      });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(e.message.includes('symbol') && e.message.includes('required'), 'Should handle missing symbol');
    }
  });

  // Test invalid symbol for all functions
  const testFunctions = [
    { name: 'getIndicatorStockToFlow', func: getIndicatorStockToFlow },
    { name: 'getIndicatorNvt', func: getIndicatorNvt },
    { name: 'getIndicatorPuellMultiple', func: getIndicatorPuellMultiple },
    { name: 'getIndicatorCdd', func: getIndicatorCdd },
    { name: 'getIndicatorMca', func: getIndicatorMca },
    { name: 'getIndicatorSca', func: getIndicatorSca },
    { name: 'getIndicatorScaDistribution', func: getIndicatorScaDistribution },
    { name: 'getIndicatorNupl', func: getIndicatorNupl },
    { name: 'getIndicatorNrpl', func: getIndicatorNrpl },
  ];

  for (const { name, func } of testFunctions) {
    runTest(`${name} invalid symbol`, () => {
      try {
        func({
          symbol: 'invalid',
          from: fromSec,
          to: toSec,
          limit: 10,
        });
        throw new Error('Expected error but function succeeded');
      } catch (e) {
        assert(
          e.message.includes('Unsupported symbol') && e.message.includes('btc'),
          `${name} should handle invalid symbol`
        );
      }
    });
  }

  // Test invalid window parameters for each function
  const windowTests = [
    { name: 'getIndicatorStockToFlow', func: getIndicatorStockToFlow, validWindows: ['day', 'hour', 'block'] },
    { name: 'getIndicatorNvt', func: getIndicatorNvt, validWindows: ['day'] },
    { name: 'getIndicatorPuellMultiple', func: getIndicatorPuellMultiple, validWindows: ['day'] },
    { name: 'getIndicatorCdd', func: getIndicatorCdd, validWindows: ['day'] },
    { name: 'getIndicatorMca', func: getIndicatorMca, validWindows: ['day'] },
    { name: 'getIndicatorSca', func: getIndicatorSca, validWindows: ['day'] },
    { name: 'getIndicatorScaDistribution', func: getIndicatorScaDistribution, validWindows: ['day'] },
    { name: 'getIndicatorNupl', func: getIndicatorNupl, validWindows: ['day'] },
    { name: 'getIndicatorNrpl', func: getIndicatorNrpl, validWindows: ['day', 'hour'] },
  ];

  for (const { name, func } of windowTests) {
    runTest(`${name} invalid window`, () => {
      try {
        func({
          symbol: 'btc',
          window: 'invalid',
          from: fromSec,
          to: toSec,
          limit: 10,
        });
        throw new Error('Expected error but function succeeded');
      } catch (e) {
        assert(e.message.includes('Invalid window') && e.message.includes('only supports'), `${name} should handle invalid window`);
      }
    });
  }

  // Test limit parameter boundary values for all functions
  const limitTests = [
    { name: 'getIndicatorNupl', func: getIndicatorNupl, maxLimit: 10000 },
    ...testFunctions.filter((f) => f.name !== 'getIndicatorNupl').map((f) => ({ ...f, maxLimit: 100000 })),
  ];

  for (const { name, func, maxLimit } of limitTests) {
    // Test below minimum
    runTest(`${name} limit below minimum`, () => {
      try {
        func({
          symbol: 'btc',
          from: fromSec,
          to: toSec,
          limit: 1, // Below minimum of 2
        });
        throw new Error('Expected error but function succeeded');
      } catch (e) {
        assert(e.message.includes('Invalid limit') && e.message.includes('at least 2'), `${name} should handle limit below minimum`);
      }
    });

    // Test above maximum
    runTest(`${name} limit above maximum`, () => {
      try {
        func({
          symbol: 'btc',
          from: fromSec,
          to: toSec,
          limit: maxLimit + 1,
        });
        throw new Error('Expected error but function succeeded');
      } catch (e) {
        assert(e.message.includes('Invalid limit') && e.message.includes('cannot exceed'), `${name} should handle limit above maximum`);
      }
    });

    // Test non-integer limit
    runTest(`${name} non-integer limit`, () => {
      try {
        func({
          symbol: 'btc',
          from: fromSec,
          to: toSec,
          limit: 10.5,
        });
        throw new Error('Expected error but function succeeded');
      } catch (e) {
        assert(e.message.includes('Invalid limit') && e.message.includes('must be an integer'), `${name} should handle non-integer limit`);
      }
    });
  }

  // Test invalid time range (both from and to provided, but from >= to)
  runTest('getIndicatorStockToFlow invalid time range (from >= to)', () => {
    try {
      getIndicatorStockToFlow({
        symbol: 'btc',
        from: toSec,
        to: fromSec, // to is before from
        limit: 10,
      });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(
        e.message.includes('Invalid time range') && e.message.includes('from') && e.message.includes('to'),
        'Should handle invalid time range'
      );
    }
  });

  // Test invalid timestamp types (both provided)
  runTest('getIndicatorStockToFlow invalid timestamp types (both parameters)', () => {
    try {
      getIndicatorStockToFlow({
        symbol: 'btc',
        from: 'invalid_timestamp',
        to: '2023-01-01',
        limit: 10,
      });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(
        e.message.includes('Invalid time range') && e.message.includes('Unix timestamps'),
        'Should handle invalid timestamp types'
      );
    }
  });

  // Test edge cases for symbol case sensitivity
  runTest('getIndicatorStockToFlow symbol case sensitivity', () => {
    try {
      getIndicatorStockToFlow({
        symbol: 'BTC', // uppercase
        from: fromSec,
        to: toSec,
        limit: 10,
      });
      // This may be rejected depending on implementation; ensure behavior is validated
    } catch (e) {
      // Function rejects uppercase, that's acceptable
      assert(e.message.includes('Unsupported symbol'), 'Function should handle symbol case appropriately');
    }
  });

  // Test special character inputs
  runTest('getIndicatorStockToFlow special characters', () => {
    try {
      getIndicatorStockToFlow({
        symbol: 'btc@#$%',
        window: 'day@#',
        from: fromSec,
        to: toSec,
        limit: 10,
      });
      throw new Error('Expected error but function succeeded');
    } catch (e) {
      assert(
        e.message.includes('Unsupported symbol') || e.message.includes('Invalid window'),
        'Should handle special characters in input'
      );
    }
  });

  // ==================== Special Value Tests ====================
  console.log('\n--- Testing Special Values ---');

  runTest('getIndicatorStockToFlow with extreme timestamps', () => {
    const veryOldTimestamp = 946684800; // Year 2000
    const response = getIndicatorStockToFlow({
      symbol: 'btc',
      from: veryOldTimestamp,
      to: toSec,
      limit: 2,
    });
    validateApiResponse(response, 'getIndicatorStockToFlow');
    expectTimestampsWithinRange(response, 'getIndicatorStockToFlow', veryOldTimestamp, toSec);
  });

  // Test with explicit parameters including required from/to
  runTest('getIndicatorNvt with explicit parameters', () => {
    const response = getIndicatorNvt({
      symbol: 'btc',
      from: fromSec,
      to: toSec,
    });
    validateApiResponse(response, 'getIndicatorNvt');
    expectTimestampsWithinRange(response, 'getIndicatorNvt', fromSec, toSec);
    assert(response.result.data.length <= 100, 'Default limit should be 100');
  });

  // ==================== Comprehensive Parameter Tests ====================
  console.log('\n--- Testing Comprehensive Parameter Combinations ---');

  // Test all functions with comprehensive parameter sets (always include from/to)
  const comprehensiveParamsBase = [
    { symbol: 'btc', limit: 10 },
    { symbol: 'btc', limit: 50, window: 'day' },
    { symbol: 'btc', limit: 100 },
  ];

  for (const base of comprehensiveParamsBase) {
    const params = { ...base, from: fromSec, to: toSec };
    const functions = [
      { name: 'getIndicatorStockToFlow', func: getIndicatorStockToFlow },
      { name: 'getIndicatorNvt', func: getIndicatorNvt },
      { name: 'getIndicatorPuellMultiple', func: getIndicatorPuellMultiple },
      { name: 'getIndicatorCdd', func: getIndicatorCdd },
      { name: 'getIndicatorMca', func: getIndicatorMca },
      { name: 'getIndicatorSca', func: getIndicatorSca },
      { name: 'getIndicatorScaDistribution', func: getIndicatorScaDistribution },
      { name: 'getIndicatorNupl', func: getIndicatorNupl },
      { name: 'getIndicatorNrpl', func: getIndicatorNrpl },
    ];

    for (const { name, func } of functions) {
      runTest(`${name} with comprehensive params`, () => {
        const response = func(params);
        validateApiResponse(response, name);
        expectTimestampsWithinRange(response, name, fromSec, toSec);
      });
    }
  }

  // ==================== Test Summary ====================
  console.log('\n=== Direct Function Test Summary ===');
  console.log(`Total tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${totalTests - passedTests}`);
  console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

  if (passedTests === totalTests) {
    console.log('🎉 All direct function tests passed!');
  } else {
    console.log('⚠️  Some direct function tests failed. Please review the output above.');
  }
}

main();
