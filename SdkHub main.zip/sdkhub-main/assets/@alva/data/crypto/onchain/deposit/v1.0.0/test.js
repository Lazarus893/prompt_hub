// Assertion helpers for testing
function assert(cond, msg) {
    if (!cond) throw new Error(msg || 'assertion failed');
}

function isInteger(n) {
    return Number.isInteger(n);
}

function isMsEpoch(n) {
    return typeof n === 'number' && isInteger(n) && n > 0 && n > 10_000_000_000;
}

function hasUniqueDates(rows) {
    const s = new Set();
    for (const r of rows) {
        if (s.has(r.date)) return false;
        s.add(r.date);
    }
    return true;
}

function expectFieldsMatch(rows, fieldNames) {
    for (const r of rows) {
        const got = Object.keys(r);
        assert(got.includes('date'), 'missing required field: "date"');
        for (const f of fieldNames) assert(got.includes(f), `missing field: ${f}`);
    }
}

// Global time range for tests (in seconds, inclusive)
const NOW_S = Math.floor(Date.now() / 1000);
const TO_S = NOW_S - 3600; // up to 1 hour ago to avoid partial current bucket
const FROM_S = TO_S - 30 * 24 * 3600; // last 30 days

function assertResultTimestampsInRange(result, fromS, toS) {
    const data = result && result.result && Array.isArray(result.result.data) ? result.result.data : null;
    if (!data) return;
    for (const point of data) {
        if (point && typeof point.timestamp === 'number') {
            assert(point.timestamp >= fromS, `timestamp out of range: ${point.timestamp} < from(${fromS})`);
            assert(point.timestamp <= toS, `timestamp out of range: ${point.timestamp} > to(${toS})`);
        }
    }
}

// Generic graph output checker
function checkNodeOutput(graph, jagentId, nodeId, outputName, { expectFields = [], preloadLast = '200', extra = null, timeRangeSeconds = null } = {}) {
    const { TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const uri = new TimeSeriesUri(jagentId, nodeId, outputName, { last: preloadLast });
    const view = new TimeSeries(uri, graph.store);
    view.init();
    const rows = view.data.slice();

    if (rows.length === 0) {
        throw new Error(`no rows returned for node ${nodeId} output ${outputName}`);
    }

    const hasRange = timeRangeSeconds && typeof timeRangeSeconds.from === 'number' && typeof timeRangeSeconds.to === 'number';
    const fromMs = hasRange ? timeRangeSeconds.from * 1000 : null;
    const toMs = hasRange ? timeRangeSeconds.to * 1000 : null;

    for (const r of rows) {
        assert(typeof r === 'object' && r != null, 'row must be object');
        assert(isMsEpoch(r.date), `date must be ms epoch, got: ${r.date}`);
        if (hasRange) {
            assert(r.date >= fromMs, `node row date out of range: ${r.date} < from(${fromMs})`);
            assert(r.date <= toMs, `node row date out of range: ${r.date} > to(${toMs})`);
        }
    }
    assert(hasUniqueDates(rows), 'duplicate "date" values within one output');
    expectFieldsMatch(rows, expectFields);

    if (typeof extra === 'function') extra(rows, view);
    return rows;
}

function main() {
    const { Graph } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const { makeDepositorCountTotalNode, makeDepositorCountNewNode } = require('@alva/data/crypto/onchain/deposit:v1.0.0');

    const params = {
        symbol: 'eth2',
        window: 'day',
        limit: 5,
        from: FROM_S,
        to: TO_S,
    };

    const g = new Graph(jagentId);
    g.addNode('depositor_count_total', makeDepositorCountTotalNode(params));
    g.addNode('depositor_count_new', makeDepositorCountNewNode(params));
    g.run();

    // Test makeDepositorCountTotalNode output
    const totalRows = checkNodeOutput(g, jagentId, 'depositor_count_total', 'total', {
        expectFields: ['depositor_count_total'],
        preloadLast: '10',
        timeRangeSeconds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.depositor_count_total === 'number', 'depositor_count_total must be number');
                assert(r.depositor_count_total >= 0, 'depositor_count_total must be non-negative');
            }
        },
    });

    // Test makeDepositorCountNewNode output
    const newRows = checkNodeOutput(g, jagentId, 'depositor_count_new', 'new_depositors', {
        expectFields: ['depositor_count_new'],
        preloadLast: '10',
        timeRangeSeconds: { from: FROM_S, to: TO_S },
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.depositor_count_new === 'number', 'depositor_count_new must be number');
                assert(r.depositor_count_new >= 0, 'depositor_count_new must be non-negative');
            }
        },
    });

    // Verify refs for outputs
    const totalRefs = g.getRefsForOutput('depositor_count_total', 'total');
    if (totalRefs.length > 0) {
        const ref = totalRefs[0];
        const expected = {
            id: '@alva/data/crypto/onchain/deposit/getDepositorCountTotal',
            module_name: '@alva/data/crypto/onchain/deposit',
            module_display_name: 'On-chain Token Depositor',
            sdk_name: 'getDepositorCountTotal',
            sdk_display_name: 'ETH Total Depositor Count',
            source_name: 'CryptoQuant',
            source: 'https://cryptoquant.com/en/docs#tag/ETH-2.0/operation/ETHgetDepositorCountTotal',
        };

        if (ref.id !== expected.id) {
            throw new Error(`Assertion failed: ref.id expected ${expected.id}, got ${ref.id}`);
        }
        if (ref.module_name !== expected.module_name) {
            throw new Error(`Assertion failed: ref.module_name expected ${expected.module_name}, got ${ref.module_name}`);
        }
        if (ref.module_display_name !== expected.module_display_name) {
            throw new Error(`Assertion failed: ref.module_display_name expected ${expected.module_display_name}, got ${ref.module_display_name}`);
        }
        if (ref.sdk_name !== expected.sdk_name) {
            throw new Error(`Assertion failed: ref.sdk_name expected ${expected.sdk_name}, got ${ref.sdk_name}`);
        }
        if (ref.sdk_display_name !== expected.sdk_display_name) {
            throw new Error(`Assertion failed: ref.sdk_display_name expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
        }
        if (ref.source_name !== expected.source_name) {
            throw new Error(`Assertion failed: ref.source_name expected ${expected.source_name}, got ${ref.source_name}`);
        }
        if (ref.source !== expected.source) {
            throw new Error(`Assertion failed: ref.source expected ${expected.source}, got ${ref.source}`);
        }
    } else {
        throw new Error('Assertion failed: refs array is empty for output depositor_count_total.total');
    }

    const newRefs = g.getRefsForOutput('depositor_count_new', 'new_depositors');
    if (newRefs.length > 0) {
        const ref = newRefs[0];
        const expected = {
            id: '@alva/data/crypto/onchain/deposit/getDepositorCountNew',
            module_name: '@alva/data/crypto/onchain/deposit',
            module_display_name: 'On-chain Token Depositor',
            sdk_name: 'getDepositorCountNew',
            sdk_display_name: 'ETH New Depositor Count',
            source_name: 'CryptoQuant',
            source: 'https://cryptoquant.com/en/docs#tag/ETH-2.0/operation/ETHgetDepositorCountNew',
        };

        if (ref.id !== expected.id) {
            throw new Error(`Assertion failed: ref.id expected ${expected.id}, got ${ref.id}`);
        }
        if (ref.module_name !== expected.module_name) {
            throw new Error(`Assertion failed: ref.module_name expected ${expected.module_name}, got ${ref.module_name}`);
        }
        if (ref.module_display_name !== expected.module_display_name) {
            throw new Error(`Assertion failed: ref.module_display_name expected ${expected.module_display_name}, got ${ref.module_display_name}`);
        }
        if (ref.sdk_name !== expected.sdk_name) {
            throw new Error(`Assertion failed: ref.sdk_name expected ${expected.sdk_name}, got ${ref.sdk_name}`);
        }
        if (ref.sdk_display_name !== expected.sdk_display_name) {
            throw new Error(`Assertion failed: ref.sdk_display_name expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
        }
        if (ref.source_name !== expected.source_name) {
            throw new Error(`Assertion failed: ref.source_name expected ${expected.source_name}, got ${ref.source_name}`);
        }
        if (ref.source !== expected.source) {
            throw new Error(`Assertion failed: ref.source expected ${expected.source}, got ${ref.source}`);
        }
    } else {
        throw new Error('Assertion failed: refs array is empty for output depositor_count_new.new_depositors');
    }

    console.log('✓ All make*Node functions tested successfully');

    // Test get functions
    testGetFunctions();

    return 0;
}

function testGetFunctions() {
    console.log('\n=== Testing getDepositorCountTotal and getDepositorCountNew ===');

    const {
        getDepositorCountTotal,
        getDepositorCountNew,
    } = require('@alva/data/crypto/onchain/deposit:v1.0.0');

    // Define test parameters
    const SUPPORTED_SYMBOLS = ['eth2'];
    const WINDOWS = ['day', 'hour'];
    const LIMIT_VALUES = [2, 5, 10, 100, 1000, 100000];

    let totalTests = 0;
    let passedTests = 0;

    // Helper function to run test and track results
    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    // ============ Happy Path Tests ============
    console.log('\n--- Testing Happy Paths ---');

    // Test all symbol-window combinations
    for (const symbol of SUPPORTED_SYMBOLS) {
        for (const window of WINDOWS) {
            runTest(`getDepositorCountTotal with ${symbol} - ${window}`, () => {
                const result = getDepositorCountTotal({
                    symbol: symbol,
                    window: window,
                    from: FROM_S,
                    to: TO_S,
                    limit: 5
                });
                assert(result && typeof result === 'object', 'Should return object');
                assert(result.status && typeof result.status === 'object', 'Should have status object');
                assert(result.result && typeof result.result === 'object', 'Should have result object');
                assert(Array.isArray(result.result.data), 'Should have data array in result');
                assert(result.result.data.length <= 5, 'Should respect limit parameter');
                assertResultTimestampsInRange(result, FROM_S, TO_S);
            });

            runTest(`getDepositorCountNew with ${symbol} - ${window}`, () => {
                const result = getDepositorCountNew({
                    symbol: symbol,
                    window: window,
                    from: FROM_S,
                    to: TO_S,
                    limit: 5
                });
                assert(result && typeof result === 'object', 'Should return object');
                assert(result.status && typeof result.status === 'object', 'Should have status object');
                assert(result.result && typeof result.result === 'object', 'Should have result object');
                assert(Array.isArray(result.result.data), 'Should have data array in result');
                assert(result.result.data.length <= 5, 'Should respect limit parameter');
                assertResultTimestampsInRange(result, FROM_S, TO_S);
            });
        }
    }

    // ============ Boundary Value Analysis Tests ============
    console.log('\n--- Testing Boundary Values ---');

    // Test limit boundaries
    for (const limit of [2, 100000]) {
        runTest(`getDepositorCountTotal with limit ${limit}`, () => {
            const result = getDepositorCountTotal({
                symbol: 'eth2',
                from: FROM_S,
                to: TO_S,
                limit: limit
            });
            assert(result && typeof result === 'object', 'Should return object');
            assert(Array.isArray(result.result.data), 'Should have data array');
            assert(result.result.data.length <= limit, 'Should respect max limit');
            assertResultTimestampsInRange(result, FROM_S, TO_S);
        });

        runTest(`getDepositorCountNew with limit ${limit}`, () => {
            const result = getDepositorCountNew({
                symbol: 'eth2',
                from: FROM_S,
                to: TO_S,
                limit: limit
            });
            assert(result && typeof result === 'object', 'Should return object');
            assert(Array.isArray(result.result.data), 'Should have data array');
            assert(result.result.data.length <= limit, 'Should respect max limit');
            assertResultTimestampsInRange(result, FROM_S, TO_S);
        });
    }

    // Test limit just outside boundaries
    for (const limit of [100001]) {
        runTest(`getDepositorCountTotal with out-of-range limit ${limit}`, () => {
            try {
                const result = getDepositorCountTotal({
                    symbol: 'eth2',
                    from: FROM_S,
                    to: TO_S,
                    limit: limit
                });
                if (limit < 2) {
                    throw new Error('Expected error for limit < 2 but function succeeded');
                }
                assert(result && typeof result === 'object', 'Should handle out-of-range limit gracefully');
            } catch (e) {
                if (limit < 2) {
                    assert(e.message.includes('Error') || e.message.includes('Invalid'), 'Should handle invalid limit');
                }
            }
        });
    }

    // ============ Data Validation Tests ============
    console.log('\n--- Testing Data Validation ---');

    runTest('getDepositorCountTotal data structure validation', () => {
        const result = getDepositorCountTotal({
            symbol: 'eth2',
            from: FROM_S,
            to: TO_S,
            limit: 5
        });
        assert(result && typeof result === 'object', 'Should return object');
        assert(result.status && typeof result.status === 'object', 'Should have status');
        assert(result.result && typeof result.result === 'object', 'Should have result');
        assert(Array.isArray(result.result.data), 'Should have data array');

        for (const point of result.result.data) {
            assert(typeof point === 'object' && point !== null, 'Data point should be object');
            assert(typeof point.timestamp === 'number', 'Timestamp should be number');
            assert(typeof point.depositor_count_total === 'number', 'depositor_count_total should be number');
            assert(point.depositor_count_total >= 0, 'depositor_count_total should be non-negative');
            assert(Number.isInteger(point.timestamp), 'Timestamp should be integer');
            assert(Number.isInteger(point.depositor_count_total), 'depositor_count_total should be integer');
            assert(point.timestamp >= FROM_S && point.timestamp <= TO_S, 'Timestamp should be within [from, to]');
        }
    });

    runTest('getDepositorCountNew data structure validation', () => {
        const result = getDepositorCountNew({
            symbol: 'eth2',
            from: FROM_S,
            to: TO_S,
            limit: 5
        });
        assert(result && typeof result === 'object', 'Should return object');
        assert(result.status && typeof result.status === 'object', 'Should have status');
        assert(result.result && typeof result.result === 'object', 'Should have result');
        assert(Array.isArray(result.result.data), 'Should have data array');

        for (const point of result.result.data) {
            assert(typeof point === 'object' && point !== null, 'Data point should be object');
            assert(typeof point.timestamp === 'number', 'Timestamp should be number');
            assert(typeof point.depositor_count_new === 'number', 'depositor_count_new should be number');
            assert(point.depositor_count_new >= 0, 'depositor_count_new should be non-negative');
            assert(Number.isInteger(point.timestamp), 'Timestamp should be integer');
            assert(Number.isInteger(point.depositor_count_new), 'depositor_count_new should be integer');
            assert(point.timestamp >= FROM_S && point.timestamp <= TO_S, 'Timestamp should be within [from, to]');
        }
    });

    // ============ Default Parameter Tests ============
    console.log('\n--- Testing Default Parameters ---');

    runTest('getDepositorCountTotal with required from/to only', () => {
        const result = getDepositorCountTotal({
            symbol: 'eth2',
            from: FROM_S,
            to: TO_S,
        });
        assert(result && typeof result === 'object', 'Should return object');
        assert(Array.isArray(result.result.data), 'Should have data array');
        assert(result.result.data.length <= 100, 'Should use default limit of 100');
        assertResultTimestampsInRange(result, FROM_S, TO_S);
    });

    runTest('getDepositorCountNew with required from/to only', () => {
        const result = getDepositorCountNew({
            symbol: 'eth2',
            from: FROM_S,
            to: TO_S,
        });
        assert(result && typeof result === 'object', 'Should return object');
        assert(Array.isArray(result.result.data), 'Should have data array');
        assert(result.result.data.length <= 100, 'Should use default limit of 100');
        assertResultTimestampsInRange(result, FROM_S, TO_S);
    });

    // ============ Error Handling Tests ============
    console.log('\n--- Testing Error Handling ---');

    runTest('getDepositorCountTotal with invalid symbol', () => {
        try {
            getDepositorCountTotal({
                symbol: 'invalid',
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Unsupported'), 'Should handle invalid symbol');
        }
    });

    runTest('getDepositorCountNew with invalid symbol', () => {
        try {
            getDepositorCountNew({
                symbol: 'invalid',
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Unsupported'), 'Should handle invalid symbol');
        }
    });

    runTest('getDepositorCountTotal with invalid window', () => {
        try {
            getDepositorCountTotal({
                symbol: 'eth2',
                window: 'invalid',
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid'), 'Should handle invalid window');
        }
    });

    runTest('getDepositorCountNew with invalid window', () => {
        try {
            getDepositorCountNew({
                symbol: 'eth2',
                window: 'invalid',
                from: FROM_S,
                to: TO_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid'), 'Should handle invalid window');
        }
    });

    runTest('getDepositorCountTotal with negative limit', () => {
        try {
            getDepositorCountTotal({
                symbol: 'eth2',
                from: FROM_S,
                to: TO_S,
                limit: -5
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid'), 'Should handle negative limit');
        }
    });

    runTest('getDepositorCountNew with negative limit', () => {
        try {
            getDepositorCountNew({
                symbol: 'eth2',
                from: FROM_S,
                to: TO_S,
                limit: -5
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid'), 'Should handle negative limit');
        }
    });

    // ============ Special Values Tests ============
    console.log('\n--- Testing Special Values ---');

    runTest('getDepositorCountTotal with zero limit', () => {
        try {
            getDepositorCountTotal({
                symbol: 'eth2',
                from: FROM_S,
                to: TO_S,
                limit: 0
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid'), 'Should handle zero limit');
        }
    });

    runTest('getDepositorCountNew with very large timestamp', () => {
        const futureTo = 9_999_999_999; // far future
        const futureFrom = futureTo - 86_400; // 1 day before
        try {
            const result = getDepositorCountNew({
                symbol: 'eth2',
                from: futureFrom,
                to: futureTo,
                limit: 5
            });
            assert(result && typeof result === 'object', 'Should handle large timestamp');
            // If any data returned, ensure it is within the provided range
            assertResultTimestampsInRange(result, futureFrom, futureTo);
        } catch (e) {
            // Should handle gracefully if timestamp is too large
            assert(e.message.includes('Error') || e.message.includes('Invalid'), 'Should handle large timestamp');
        }
    });

    // ============ Performance and Edge Cases ============
    console.log('\n--- Testing Performance and Edge Cases ---');

    runTest('getDepositorCountTotal with maximum limit', () => {
        const result = getDepositorCountTotal({
            symbol: 'eth2',
            from: FROM_S,
            to: TO_S,
            limit: 100000
        });
        assert(result && typeof result === 'object', 'Should handle maximum limit');
        assert(Array.isArray(result.result.data), 'Should return data array');
        assert(result.result.data.length <= 100000, 'Should respect maximum limit');
        assertResultTimestampsInRange(result, FROM_S, TO_S);
    });

    runTest('getDepositorCountNew with maximum limit', () => {
        const result = getDepositorCountNew({
            symbol: 'eth2',
            from: FROM_S,
            to: TO_S,
            limit: 100000
        });
        assert(result && typeof result === 'object', 'Should handle maximum limit');
        assert(Array.isArray(result.result.data), 'Should return data array');
        assert(result.result.data.length <= 100000, 'Should respect maximum limit');
        assertResultTimestampsInRange(result, FROM_S, TO_S);
    });

    // Print test summary
    console.log('\n=== Get Functions Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    if (passedTests === totalTests) {
        console.log('🎉 All get function tests passed!');
    } else {
        console.log('⚠️  Some get function tests failed. Please review the output above.');
    }
}

main();
