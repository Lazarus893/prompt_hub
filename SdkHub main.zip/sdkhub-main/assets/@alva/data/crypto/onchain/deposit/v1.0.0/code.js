const { useCredit } = require('internal');
const cryptoQuantSDK = require('@alva/external/cryptoquant:v1.0.0');

// Refs from tool.json for SDKs used in this module
const getDepositorCountTotalRef = {
  id: '@alva/data/crypto/onchain/deposit/getDepositorCountTotal',
  module_name: '@alva/data/crypto/onchain/deposit',
  module_display_name: 'On-chain Token Depositor',
  sdk_name: 'getDepositorCountTotal',
  sdk_display_name: 'ETH Total Depositor Count',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/ETH-2.0/operation/ETHgetDepositorCountTotal',
};

const getDepositorCountNewRef = {
  id: '@alva/data/crypto/onchain/deposit/getDepositorCountNew',
  module_name: '@alva/data/crypto/onchain/deposit',
  module_display_name: 'On-chain Token Depositor',
  sdk_name: 'getDepositorCountNew',
  sdk_display_name: 'ETH New Depositor Count',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs#tag/ETH-2.0/operation/ETHgetDepositorCountNew',
};

// ----------------------------------------------
// Internal base descriptions (from doc summaries)
// Not exported
const baseGetDepositorCountTotalDescription = 'Get historical total unique depositor count';
const baseGetDepositorCountNewDescription = 'Get historical new unique depositor count';

// ----------------------------------------------
// Internal dynamic description builders per function
// Not exported
function buildGetDepositorCountTotalCallDescription(actualParams = {}) {
  const parts = [baseGetDepositorCountTotalDescription];

  // Add target symbol (staking protocol)
  if (actualParams.symbol) {
    parts.push(`for ${actualParams.symbol}`);
  }

  // Optional filters
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }

  // Time range
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  } else if (actualParams.from) {
    filters.push(`Time from: ${actualParams.from}`);
  } else if (actualParams.to) {
    filters.push(`Time to: ${actualParams.to}`);
  }

  if (typeof actualParams.limit === 'number' && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }

  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }

  return parts.join(' ').trim();
}

function buildGetDepositorCountNewCallDescription(actualParams = {}) {
  const parts = [baseGetDepositorCountNewDescription];

  // Add target symbol (staking protocol)
  if (actualParams.symbol) {
    parts.push(`for ${actualParams.symbol}`);
  }

  // Optional filters
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }

  // Time range
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  } else if (actualParams.from) {
    filters.push(`Time from: ${actualParams.from}`);
  } else if (actualParams.to) {
    filters.push(`Time to: ${actualParams.to}`);
  }

  if (typeof actualParams.limit === 'number' && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }

  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }

  return parts.join(' ').trim();
}

// ----------------------------------------------
// Reference helper to attach dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
  // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
  const title = titleBuilder(params);

  // 2. 组合 refObject 和新 title
  const newObject = {
    ...refObject,
    title: title
  };

  // 3. 返回新对象
  return newObject;
}

function getDepositorCountTotal(params) {
  useCredit('getDepositorCountTotal', 350);
  return cryptoQuantSDK.getCQDepositorCountTotal(params);
}

function getDepositorCountNew(params) {
  useCredit('getDepositorCountNew', 350);
  return cryptoQuantSDK.getCQDepositorCountNew(params);
}

function toMs(value) {
  if (value == null) return null;
  if (typeof value === 'number') {
    return value > 1e12 ? value : value * 1000; // seconds → ms
  }
  if (typeof value === 'string') {
    const parsed = Date.parse(value);
    return Number.isNaN(parsed) ? null : parsed;
  }
  return null;
}

function extractSeries(response) {
  const data = response?.result?.data;
  return Array.isArray(data) ? data : [];
}

/**
 * Deduplicate by date (ms). Keeps the last occurrence for a given date.
 * Returns records sorted by date ascending.
 */
function dedupeByDate(records) {
  const byDate = new Map();
  for (const r of records) {
    if (r && typeof r.date === 'number') {
      byDate.set(r.date, r); // last wins
    }
  }
  const out = Array.from(byDate.values());
  out.sort((a, b) => a.date - b.date);
  return out;
}

function makeDepositorCountTotalNode(params) {
  return {
    inputs: {
      total_raw: () => getDepositorCountTotal(params),
    },
    outputs: {
      total: {
        name: 'depositor_count_total',
        description: 'Total unique depositors',
        fields: [
          { name: 'date', type: 'number', description: 'timestamp ms' },
          { name: 'depositor_count_total', type: 'number', description: 'total depositing accounts' },
        ],
        ref: createReferenceWithTitle(getDepositorCountTotalRef, params, buildGetDepositorCountTotalCallDescription),
      },
    },
    run: (inputs) => {
      const series = extractSeries(inputs.total_raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) return null;
          return {
            date: ts,
            depositor_count_total: item.depositor_count_total,
          };
        })
        .filter(Boolean);
      return { total: dedupeByDate(series) };
    },
  };
}

function makeDepositorCountNewNode(params) {
  return {
    inputs: {
      new_raw: () => getDepositorCountNew(params),
    },
    outputs: {
      new_depositors: {
        name: 'depositor_count_new',
        description: 'New unique depositors',
        fields: [
          { name: 'date', type: 'number', description: 'timestamp ms' },
          { name: 'depositor_count_new', type: 'number', description: 'new depositing accounts' },
        ],
        ref: createReferenceWithTitle(getDepositorCountNewRef, params, buildGetDepositorCountNewCallDescription),
      },
    },
    run: (inputs) => {
      const series = extractSeries(inputs.new_raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) return null;
          return {
            date: ts,
            depositor_count_new: item.depositor_count_new,
          };
        })
        .filter(Boolean);
      return { new_depositors: dedupeByDate(series) };
    },
  };
}

function getRefs() {
  return [
    getDepositorCountTotalRef,
    getDepositorCountNewRef,
  ];
}

module.exports = {
  getDepositorCountTotal,
  getDepositorCountNew,
  makeDepositorCountTotalNode,
  makeDepositorCountNewNode,
  getRefs,
};
