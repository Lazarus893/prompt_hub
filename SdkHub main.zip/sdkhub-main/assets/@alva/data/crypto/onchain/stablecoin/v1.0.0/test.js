const { Graph } = require('@alva/graph:v1.0.0');
const { TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');
const { makeSupplyNode } = require('@alva/data/crypto/onchain/stablecoin:v1.0.0');

// Assertion helpers
function assert(cond, msg) {
    if (!cond) throw new Error(msg || 'assertion failed');
}
function isInteger(n) {
    return Number.isInteger(n);
}
function isMsEpoch(n) {
    return typeof n === 'number' && isInteger(n) && n > 0 && n > 10_000_000_000;
}
function hasUniqueDates(rows) {
    const s = new Set();
    for (const r of rows) {
        if (s.has(r.date)) return false;
        s.add(r.date);
    }
    return true;
}
function expectFieldsMatch(rows, fieldNames) {
    for (const r of rows) {
        const got = Object.keys(r);
        assert(got.includes('date'), 'missing required field: "date"');
        for (const f of fieldNames) assert(got.includes(f), `missing field: ${f}`);
    }
}

// Ensure all timestamps (seconds) in result are within [from, to]
function assertTimestampsWithinSeconds(data, fromSec, toSec) {
    if (!Array.isArray(data)) return;
    for (const item of data) {
        if (item && typeof item === 'object' && typeof item.timestamp === 'number') {
            assert(item.timestamp >= fromSec, `timestamp ${item.timestamp} < from ${fromSec}`);
            assert(item.timestamp <= toSec, `timestamp ${item.timestamp} > to ${toSec}`);
        }
    }
}

// Generic graph-output checker
function checkNodeOutput(graph, jagentId, nodeId, outputName, { expectFields = [], preloadLast = '200', extra = null } = {}) {
    const uri = new TimeSeriesUri(jagentId, nodeId, outputName, { last: preloadLast });
    const view = new TimeSeries(uri, graph.store);
    view.init();
    const rows = view.data.slice();

    if (rows.length === 0) {
        throw new Error(`no rows returned for node ${nodeId} output ${outputName}`);
    }

    for (const r of rows) {
        assert(typeof r === 'object' && r != null, 'row must be object');
        assert(isMsEpoch(r.date), `date must be ms epoch, got: ${r.date}`);
    }
    assert(hasUniqueDates(rows), 'duplicate "date" values within one output');
    expectFieldsMatch(rows, expectFields);

    if (typeof extra === 'function') extra(rows, view);
    return rows;
}

function testDirectGetSupply() {
    console.log('\n=== Testing Direct getSupply Function Calls ===');

    // Import the getSupply function
    const { getSupply } = require('@alva/data/crypto/onchain/stablecoin:v1.0.0');

    // Define all supported tokens from the enum
    const SUPPORTED_TOKENS = [
        'all_token',
        'usdt_eth',
        'usdt_omni',
        'usdp',
        'usdc',
        'tusd',
        'dai',
        'sai'
    ];

    let totalTests = 0;
    let passedTests = 0;

    // Helper function to run test and track results
    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    // ============ Happy Path Tests ============
    console.log('\n--- Testing Happy Path Scenarios ---');

    // Test all token types (comprehensive enum coverage)
    for (const token of SUPPORTED_TOKENS) {
        runTest(`getSupply with token: ${token}`, () => {
            const params = {
                token: token,
                from: 1704067200, // 2024-01-01
                to: 1704585600,   // 2024-01-07
                limit: 10
            };
            const result = getSupply(params);

            assert(result && typeof result === 'object', `Should return object for token ${token}`);
            assert(result.status && typeof result.status === 'object', `Should have status object for token ${token}`);
            assert(typeof result.status.code === 'number', `Should have numeric status code for token ${token}`);
            assert(typeof result.status.message === 'string', `Should have string status message for token ${token}`);
            assert(result.result && typeof result.result === 'object', `Should have result object for token ${token}`);
            assert(Array.isArray(result.result.data), `Should have data array for token ${token}`);
            assertTimestampsWithinSeconds(result.result.data, params.from, params.to);
        });
    }

    // Test different time ranges
    runTest('getSupply with long time range', () => {
        const params = {
            token: 'usdt_eth',
            from: 1640995200, // 2022-01-01
            to: 1704067200,   // 2024-01-01
            limit: 100
        };
        const result = getSupply(params);
        assert(result && result.result && Array.isArray(result.result.data), 'Should handle long time ranges');
        assertTimestampsWithinSeconds(result.result.data, params.from, params.to);
    });

    runTest('getSupply with short time range', () => {
        const params = {
            token: 'usdt_eth',
            from: 1704067200, // 2024-01-01
            to: 1704153600,   // 2024-01-02
            limit: 50
        };
        const result = getSupply(params);
        assert(result && result.result && Array.isArray(result.result.data), 'Should handle short time ranges');
        assertTimestampsWithinSeconds(result.result.data, params.from, params.to);
    });

    // Test data structure validation
    runTest('getSupply data structure validation', () => {
        const params = {
            token: 'usdt_eth',
            from: 1704067200,
            to: 1704585600,
            limit: 5
        };
        const result = getSupply(params);

        assert(result.result.data.length > 0, 'Should return at least some data points');

        const dataPoint = result.result.data[0];
        assert(typeof dataPoint.timestamp === 'number', 'timestamp should be number');
        assert(dataPoint.timestamp > 1000000000, 'timestamp should be valid Unix timestamp');
        assertTimestampsWithinSeconds(result.result.data, params.from, params.to);

        // Check all supply fields can be null or numbers
        const supplyFields = ['supply_total', 'supply_minted', 'supply_burned', 'supply_circulating', 'supply_issued', 'supply_redeemed'];
        for (const field of supplyFields) {
            assert(
                dataPoint[field] === null || (typeof dataPoint[field] === 'number' && dataPoint[field] >= 0),
                `${field} should be null or non-negative number`
            );
        }
    });

    // ============ Boundary Value Analysis ============
    console.log('\n--- Testing Boundary Values ---');

    // Test limit boundaries
    runTest('getSupply with minimum limit (2)', () => {
        const params = {
            token: 'usdt_eth',
            from: 1704067200,
            to: 1704585600,
            limit: 2
        };
        const result = getSupply(params);
        assert(result && result.result && Array.isArray(result.result.data), 'Should work with minimum limit');
        assert(result.result.data.length <= 2, 'Should respect minimum limit');
        assertTimestampsWithinSeconds(result.result.data, params.from, params.to);
    });

    runTest('getSupply with maximum limit (100000)', () => {
        const params = {
            token: 'usdt_eth',
            from: 1704067200,
            to: 1704585600,
            limit: 100000
        };
        const result = getSupply(params);
        assert(result && result.result && Array.isArray(result.result.data), 'Should work with maximum limit');
        assert(result.result.data.length <= 100000, 'Should respect maximum limit');
        assertTimestampsWithinSeconds(result.result.data, params.from, params.to);
    });

    runTest('getSupply with default limit', () => {
        const params = {
            token: 'usdt_eth',
            from: 1704067200,
            to: 1704585600
        };
        const result = getSupply(params);
        assert(result && result.result && Array.isArray(result.result.data), 'Should work with default limit');
        assert(result.result.data.length <= 100, 'Default limit should be 100');
        assertTimestampsWithinSeconds(result.result.data, params.from, params.to);
    });

    // Test timestamp boundaries
    runTest('getSupply with very early timestamp', () => {
        const params = {
            token: 'usdt_eth',
            from: 1609459200, // 2021-01-01
            to: 1609545600,   // 2021-01-02
            limit: 10
        };
        const result = getSupply(params);
        assert(result && result.result && Array.isArray(result.result.data), 'Should handle early timestamps');
        assertTimestampsWithinSeconds(result.result.data, params.from, params.to);
    });

    runTest('getSupply with current timestamp', () => {
        const now = Math.floor(Date.now() / 1000);
        const params = {
            token: 'usdt_eth',
            from: now - 86400, // yesterday
            to: now,               // now
            limit: 10
        };
        const result = getSupply(params);
        assert(result && result.result && Array.isArray(result.result.data), 'Should handle current timestamps');
        assertTimestampsWithinSeconds(result.result.data, params.from, params.to);
    });

    // ============ Error Handling Tests ============
    console.log('\n--- Testing Error Handling ---');

    runTest('getSupply with invalid token', () => {
        try {
            // Intentionally using ms to ensure token validation triggers first
            const { getSupply } = require('@alva/data/crypto/onchain/stablecoin:v1.0.0');
            getSupply({
                token: 'invalid_token',
                from: 1704067200000,
                to: 1704585600000,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(
                e.message.includes('Error') || e.message.includes('Invalid') || e.message.includes('Unsupported'),
                'Should handle invalid token'
            );
        }
    });

    runTest('getSupply with from > to', () => {
        try {
            const { getSupply } = require('@alva/data/crypto/onchain/stablecoin:v1.0.0');
            getSupply({
                token: 'usdt_eth',
                from: 1704585600000,
                to: 1704067200000,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid') || e.message.includes('range'),
                'Should handle invalid time range');
        }
    });

    runTest('getSupply with negative limit', () => {
        try {
            const { getSupply } = require('@alva/data/crypto/onchain/stablecoin:v1.0.0');
            getSupply({
                token: 'usdt_eth',
                from: 1704067200000,
                to: 1704585600000,
                limit: -5
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid') || e.message.includes('limit'),
                'Should handle negative limit');
        }
    });

    runTest('getSupply with limit below minimum', () => {
        try {
            const { getSupply } = require('@alva/data/crypto/onchain/stablecoin:v1.0.0');
            getSupply({
                token: 'usdt_eth',
                from: 1704067200000,
                to: 1704585600000,
                limit: 1
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid') || e.message.includes('limit'),
                'Should handle limit below minimum');
        }
    });

    runTest('getSupply with limit above maximum', () => {
        try {
            const { getSupply } = require('@alva/data/crypto/onchain/stablecoin:v1.0.0');
            getSupply({
                token: 'usdt_eth',
                from: 1704067200000,
                to: 1704585600000,
                limit: 100001
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid') || e.message.includes('limit'),
                'Should handle limit above maximum');
        }
    });

    runTest('getSupply with zero timestamps', () => {
        try {
            const { getSupply } = require('@alva/data/crypto/onchain/stablecoin:v1.0.0');
            getSupply({
                token: 'usdt_eth',
                from: 0,
                to: 0,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid') || e.message.includes('timestamp') || e.message.includes('range'),
                'Should handle zero timestamps');
        }
    });

    runTest('getSupply with negative timestamps', () => {
        try {
            const { getSupply } = require('@alva/data/crypto/onchain/stablecoin:v1.0.0');
            getSupply({
                token: 'usdt_eth',
                from: -1000000,
                to: -2000000,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid') || e.message.includes('timestamp') || e.message.includes('range'),
                'Should handle negative timestamps');
        }
    });

    runTest('getSupply with missing token parameter', () => {
        try {
            const { getSupply } = require('@alva/data/crypto/onchain/stablecoin:v1.0.0');
            getSupply({
                from: 1704067200000,
                to: 1704585600000,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Missing') || e.message.includes('token') || e.message.includes('required'),
                'Should handle missing token parameter');
        }
    });

    // Print test summary
    console.log('\n=== getSupply Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    if (passedTests === totalTests) {
        console.log('🎉 All getSupply tests passed!');
    } else {
        console.log('⚠️  Some getSupply tests failed. Please review the output above.');
    }
}

function main() {
    const g = new Graph(jagentId);

    const RANGE_FROM_SEC = 1704067200;
    const RANGE_TO_SEC = 1704585600;

    g.addNode(
        'stablecoin_supply',
        makeSupplyNode({
            token: 'usdt_eth',
            from: RANGE_FROM_SEC,
            to: RANGE_TO_SEC,
            limit: 10,
        })
    );

    g.run();

    // Test supply node output
    const supplyRows = checkNodeOutput(g, jagentId, 'stablecoin_supply', 'supply', {
        expectFields: ['supply_total', 'supply_minted', 'supply_burned', 'supply_circulating', 'supply_issued', 'supply_redeemed'],
        preloadLast: '50',
        extra: (rows) => {
            for (const r of rows) {
                ['supply_total', 'supply_minted', 'supply_burned', 'supply_circulating', 'supply_issued', 'supply_redeemed'].forEach((k) => assert(typeof r[k] === 'number', `${k} must be number`));
                // Validate date is within [from, to] range when present
                const minMs = RANGE_FROM_SEC * 1000;
                const maxMs = RANGE_TO_SEC * 1000;
                assert(r.date >= minMs, `node row date ${r.date} < from(ms) ${minMs}`);
                assert(r.date <= maxMs, `node row date ${r.date} > to(ms) ${maxMs}`);
            }
        },
    });

    // Validate reference metadata for output 'supply'
    const refs = g.getRefsForOutput('stablecoin_supply', 'supply');
    if (refs.length > 0) {
        const ref = refs[0];
        const expected = {
            id: '@alva/data/crypto/onchain/stablecoin/getSupply',
            module_name: '@alva/data/crypto/onchain/stablecoin',
            module_display_name: 'Stablecoin Supply',
            sdk_name: 'getSupply',
            sdk_display_name: 'Stablecoin Supply',
            source_name: 'CryptoQuant',
            source: 'https://cryptoquant.com/docs#tag/Stablecoin-Network-Data/operation/getSupplySC',
        };

        if (ref.id !== expected.id) {
            throw new Error(`Assertion failed: ref.id mismatch. expected ${expected.id}, got ${ref.id}`);
        }
        if (ref.module_name !== expected.module_name) {
            throw new Error(`Assertion failed: ref.module_name mismatch. expected ${expected.module_name}, got ${ref.module_name}`);
        }
        if (ref.module_display_name !== expected.module_display_name) {
            throw new Error(`Assertion failed: ref.module_display_name mismatch. expected ${expected.module_display_name}, got ${ref.module_display_name}`);
        }
        if (ref.sdk_name !== expected.sdk_name) {
            throw new Error(`Assertion failed: ref.sdk_name mismatch. expected ${expected.sdk_name}, got ${ref.sdk_name}`);
        }
        if (ref.sdk_display_name !== expected.sdk_display_name) {
            throw new Error(`Assertion failed: ref.sdk_display_name mismatch. expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
        }
        if (ref.source_name !== expected.source_name) {
            throw new Error(`Assertion failed: ref.source_name mismatch. expected ${expected.source_name}, got ${ref.source_name}`);
        }
        if (ref.source !== expected.source) {
            throw new Error(`Assertion failed: ref.source mismatch. expected ${expected.source}, got ${ref.source}`);
        }
    } else {
        throw new Error('Assertion failed: refs array is empty.');
    }

    // Run direct function tests
    testDirectGetSupply();

    // as long as no throw, it is considered passed
    return 0;
}

main();
