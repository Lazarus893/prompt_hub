const { useCredit } = require('internal');
const cryptoQuantSDK = require('@alva/external/cryptoquant:v1.0.0');

// Reference metadata for getSupply derived from tool.json
const getSupplyRef = {
    id: '@alva/data/crypto/onchain/stablecoin/getSupply',
    module_name: '@alva/data/crypto/onchain/stablecoin',
    module_display_name: 'Stablecoin Supply',
    sdk_name: 'getSupply',
    sdk_display_name: 'Stablecoin Supply',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/docs#tag/Stablecoin-Network-Data/operation/getSupplySC',
};

// Base description strings (from doc summaries)
// getSupply: Fetches historical stablecoin supply data for specific tokens.
const baseGetSupplyDescription = 'Fetch historical stablecoin supply';

// Dynamic description builders (use params from doc)
function buildGetSupplyCallDescription(actualParams = {}) {
    const parts = [baseGetSupplyDescription];

    // token filter
    if (actualParams.token) {
        if (actualParams.token === 'all_token') {
            parts.push('(all tokens)');
        } else {
            parts.push(`for ${actualParams.token}`);
        }
    }

    // time window (from/to are required by SDK; only include if provided)
    const filters = [];
    if (actualParams.from && actualParams.to) {
        filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
    } else if (actualParams.from) {
        filters.push(`Time from: ${actualParams.from}`);
    } else if (actualParams.to) {
        filters.push(`Time to: ${actualParams.to}`);
    }

    // limit (default 100)
    if (actualParams.limit != null && actualParams.limit !== 100) {
        filters.push(`Limit: ${actualParams.limit}`);
    }

    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }

    return parts.join(' ').trim();
}

// Helper to create a ref object with a dynamic title built from params
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getSupply(params) {
    useCredit('getSupplySC', 350);
    return cryptoQuantSDK.getCQSupplySC(params);
}

function toMs(value) {
    if (value == null) return null;
    if (typeof value === 'number') return value > 1e12 ? value : value * 1000;
    if (typeof value === 'string') {
        const parsed = Date.parse(value);
        if (!Number.isNaN(parsed)) return parsed;
    }
    return null;
}

function extractSeries(response) {
    const data = response?.result?.data;
    return Array.isArray(data) ? data : [];
}

function dedupeByDateKeepLast(records) {
    // Keep the last occurrence for each date (ms) and return ascending by date
    const map = new Map();
    for (const r of records) {
        map.set(r.date, r);
    }
    return Array.from(map.values()).sort((a, b) => a.date - b.date);
}

function makeSupplyNode(params) {
    return {
        inputs: {
            // Fetch raw data via SDK; no transformation here
            supply_raw: () => getSupply(params),
        },
        outputs: {
            supply: {
                name: 'stablecoin_supply',
                description: 'Stablecoin supply metrics',
                fields: [
                    { name: 'date', type: 'number', description: 'timestamp ms' },
                    { name: 'supply_total', type: 'number', description: 'total amount of tokens in existence' },
                    { name: 'supply_minted', type: 'number', description: 'amount of tokens minted (increase in total supply)' },
                    { name: 'supply_burned', type: 'number', description: 'amount of tokens burned (decrease in total supply)' },
                    { name: 'supply_circulating', type: 'number', description: 'approximation of tokens circulating in the market' },
                    { name: 'supply_issued', type: 'number', description: 'amount of tokens issued (increase in circulating supply)' },
                    { name: 'supply_redeemed', type: 'number', description: 'amount of tokens redeemed (decrease in circulating supply)' },
                ],
                ref: createReferenceWithTitle(getSupplyRef, params, buildGetSupplyCallDescription),
            },
        },
        run: (inputs) => {
            const raw = extractSeries(inputs.supply_raw);
            const series = [];
            for (const item of raw) {
                const timestampMs = toMs(item.timestamp);
                if (timestampMs == null) continue;
                series.push({
                    date: timestampMs,
                    supply_total: item.supply_total,
                    supply_minted: item.supply_minted,
                    supply_burned: item.supply_burned,
                    supply_circulating: item.supply_circulating,
                    supply_issued: item.supply_issued,
                    supply_redeemed: item.supply_redeemed,
                });
            }
            // Ensure no duplicate dates by deduping (keep last), no micro-shifting
            return { supply: dedupeByDateKeepLast(series) };
        },
    };
}

function getRefs() {
    return [
        getSupplyRef,
    ];
}

module.exports = {
    getSupply,
    makeSupplyNode,
    getRefs,
};