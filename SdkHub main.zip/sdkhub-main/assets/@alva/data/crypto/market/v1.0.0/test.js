// Assertion helpers
function assert(cond, msg) {
    if (!cond) throw new Error(msg || 'assertion failed');
}

function isInteger(n) {
    return Number.isInteger(n);
}

function isMsEpoch(n) {
    return typeof n === 'number' && isInteger(n) && n > 0 && n > 10_000_000_000;
}

function hasUniqueDates(rows) {
    const s = new Set();
    for (const r of rows) {
        if (s.has(r.date)) return false;
        s.add(r.date);
    }
    return true;
}

function expectFieldsMatch(rows, fieldNames) {
    if (!Array.isArray(rows)) {
        throw new Error('Input "rows" must be an array.');
    }

    for (const r of rows) {
        const got = Object.keys(r);
        assert(got.includes('date'), 'missing required field: "date"');

        // 对其他字段的检查保持不变，.includes() 本身就是不依赖顺序的。
        for (const f of fieldNames) {
            assert(got.includes(f), `missing field: ${f}`);
        }
    }
}

// Node output checker
const { TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');

function checkNodeOutput(
    graph,
    jagentId,
    nodeId,
    outputName,
    {
        expectFields = [], // fields AFTER 'date'
        preloadLast = '200', // how many to read back
        extra = null, // (rows, view) => void for custom assertions
    } = {}
) {
    const uri = new TimeSeriesUri(jagentId, nodeId, outputName, { last: preloadLast });
    const view = new TimeSeries(uri, graph.store);
    view.init(); // preload
    // NOTE: TimeSeries.data is newest-first (descending)
    const rows = view.data.slice(); // array of records

    if (rows.length === 0) {
        throw new Error(`no rows returned for node ${nodeId} output ${outputName}`);
    }

    // Basic invariants
    for (const r of rows) {
        assert(typeof r === 'object' && r != null, 'row must be object');
        assert(isMsEpoch(r.date), `date must be ms epoch, got: ${r.date}`);
    }
    assert(hasUniqueDates(rows), 'duplicate "date" values within one output');

    // Schema check (date-first + declared fields)
    expectFieldsMatch(rows, expectFields);

    // Optional additional checks
    if (typeof extra === 'function') extra(rows, view);
    return rows;
}

// Schema validation helpers
function expectKeysOrdered(row, expected) {
    const keys = Object.keys(row);
    for (let i = 0; i < expected.length; i++) {
        if (keys[i] !== expected[i]) throw new Error(`schema mismatch at ${i}: expected ${expected[i]}, got ${keys[i]}`);
    }
}

function main() {
    const { Graph } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');

    const {
        makePriceNode,
        makeOpenInterestNode,
        makeFundingRateNode,
        makeLiquidationHistoryNode,
        makeTakerBuySellVolumeFutureNode,
        makeFuturePriceNode,
        makeAltcoinSeasonIndexNode,
        makeBitcoinDominanceNode,
        makeBitcoinReserveRiskNode,
        makeBitcoinBubbleIndexNode,
        makeBitcoinCorrelationsNode,
        makeBitcoinRainbowChartNode,
        makeBorrowInterestRateHistoryNode,
        makeBullMarketPeakIndicatorsNode,
        makeCryptoFearAndGreedIndexNode,
        makeFuturesBasisHistoryNode,
        makeMarginLongShortNode,
        makeMarketIndicatorSoprNode,
        makeWhaleIndexHistoryNode,
        makeCoinbasePremiumIndexNode,
		makeTokenHistoricalQuotesNode,
        makePredictionMarketDataNode,
    } = require('@alva/data/crypto/market');

    const nowSeconds = Math.floor(Date.now() / 1000);
    const daySeconds = 24 * 60 * 60;
    const oneWeekAgoSeconds = nowSeconds - 7 * daySeconds;

    const graph = new Graph(jagentId);
    graph.addNode(
        'btc_price',
        makePriceNode({
            symbol: 'BTC',
            time_start: nowSeconds - 7 * daySeconds,
            time_end: nowSeconds,
            interval: '1h',
        })
    );
    graph.addNode(
        'btc_open_interest',
        makeOpenInterestNode({
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            interval: '4h',
            limit: 60,
        })
    );
    graph.addNode(
        'btc_funding_rate',
        makeFundingRateNode({
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            interval: '4h',
            limit: 60,
        })
    );
    graph.addNode(
        'eth_liquidations',
        makeLiquidationHistoryNode({
            symbol: 'ETH',
            exchange: 'binance',
            time_start: nowSeconds - daySeconds,
            time_end: nowSeconds,
            interval: '1h',
        })
    );
    graph.addNode(
        'btc_taker_volume',
        makeTakerBuySellVolumeFutureNode({
            symbol: 'BTC',
            exchange: 'binance',
            time_start: nowSeconds - daySeconds,
            time_end: nowSeconds,
            interval: '1d',
        })
    );
    graph.addNode(
        'btc_futures_price',
        makeFuturePriceNode({
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            interval: '1h',
            limit: 50,
        })
    );

    graph.addNode('altcoin_season_index', makeAltcoinSeasonIndexNode({}));

    graph.addNode('bitcoin_dominance', makeBitcoinDominanceNode({}));

    graph.addNode('bitcoin_reserve_risk', makeBitcoinReserveRiskNode({}));

    graph.addNode('bitcoin_bubble_index', makeBitcoinBubbleIndexNode({}));

    graph.addNode('bitcoin_correlations', makeBitcoinCorrelationsNode({}));

    graph.addNode('bitcoin_rainbow_chart', makeBitcoinRainbowChartNode({}));

    graph.addNode(
        'borrow_interest_rate',
        makeBorrowInterestRateHistoryNode({
            exchange: 'Binance',
            symbol: 'BTC',
            interval: '1h',
            limit: 5,
        })
    );

    graph.addNode('bull_market_peak_indicators', makeBullMarketPeakIndicatorsNode({}));

    graph.addNode('crypto_fear_and_greed_index', makeCryptoFearAndGreedIndexNode({}));

    graph.addNode(
        'futures_basis_history',
        makeFuturesBasisHistoryNode({
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            interval: '1h',
            limit: 5,
        })
    );

    graph.addNode(
        'margin_long_short',
        makeMarginLongShortNode({
            exchange: 'Bitfinex',
            symbol: 'ETH',
            interval: '1d',
            limit: 60,
        })
    );

    graph.addNode(
        'market_indicator_sopr',
        makeMarketIndicatorSoprNode({
            symbol: 'btc',
            from: oneWeekAgoSeconds,
            to: nowSeconds,
            limit: 5,
        })
    );

    graph.addNode(
        'whale_index_history',
        makeWhaleIndexHistoryNode({
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            interval: '1d',
            limit: 5,
        })
    );


    graph.addNode(
        'coinbase_premium_index',
        makeCoinbasePremiumIndexNode({
            exchange: 'Coinbase',
            symbol: 'BTC',
            interval: '1h',
            limit: 5,
        })
    );


    graph.addNode(
        'prediction_market_data',
        makePredictionMarketDataNode({
            q: 'US Bitcoin price',
        })
    );

	graph.addNode(
		'token_historical_quotes',
		makeTokenHistoricalQuotesNode({
			symbols: ['BTC', 'ETH'],
			start_time: 1725148800000,
            end_time: 1727740800000,
			interval: '1d',
		})
	);

    graph.run();

    // Test outputs using the framework
    log('🧪 Testing node outputs...');

    // Test OHLCV price data
    const priceRows = checkNodeOutput(graph, jagentId, 'btc_price', 'ohlcv', {
        expectFields: ['open', 'high', 'low', 'close', 'volume', 'trades_count'],
        preloadLast: '20',
        extra: (rows) => {
            for (const r of rows) {
                ['open', 'high', 'low', 'close', 'volume', 'trades_count'].forEach((k) => assert(typeof r[k] === 'number', `field ${k} must be number`));
                assert(r.high >= r.low, 'high must be >= low');
                assert(r.high >= r.open, 'high must be >= open');
                assert(r.high >= r.close, 'high must be >= close');
                assert(r.low <= r.open, 'low must be <= open');
                assert(r.low <= r.close, 'low must be <= close');
            }
        },
    });

    // Test open interest data
    const oiRows = checkNodeOutput(graph, jagentId, 'btc_open_interest', 'open_interest', {
        expectFields: ['open', 'close', 'low', 'high'],
        preloadLast: '20',
        extra: (rows) => {
            for (const r of rows) {
                ['open', 'close', 'low', 'high'].forEach((k) => assert(typeof r[k] === 'number' || r[k] === null, `field ${k} must be number or null`));
                if (r.high !== null && r.low !== null) {
                    assert(r.high >= r.low, 'high must be >= low');
                    assert(r.high >= r.open, 'high must be >= open');
                    assert(r.high >= r.close, 'high must be >= close');
                    assert(r.low <= r.open, 'low must be <= open');
                    assert(r.low <= r.close, 'low must be <= close');
                }
            }
        },
    });

    // Test funding rate data
    const frRows = checkNodeOutput(graph, jagentId, 'btc_funding_rate', 'funding_rate', {
        expectFields: ['open', 'close', 'low', 'high'],
        preloadLast: '20',
        extra: (rows) => {
            for (const r of rows) {
                ['open', 'close', 'low', 'high'].forEach((k) => assert(typeof r[k] === 'number' || r[k] === null, `field ${k} must be number or null`));
                if (r.high !== null && r.low !== null) {
                    assert(r.high >= r.low, 'high must be >= low');
                    assert(r.high >= r.open, 'high must be >= open');
                    assert(r.high >= r.close, 'high must be >= close');
                    assert(r.low <= r.open, 'low must be <= open');
                    assert(r.low <= r.close, 'low must be <= close');
                }
            }
        },
    });

    // Test liquidation data
    const liqRows = checkNodeOutput(graph, jagentId, 'eth_liquidations', 'liquidations', {
        expectFields: ['long_liquidation_usdt', 'short_liquidation_usdt'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.long_liquidation_usdt === 'number', 'long_liquidation_usdt must be number');
                assert(typeof r.short_liquidation_usdt === 'number', 'short_liquidation_usdt must be number');
                assert(r.long_liquidation_usdt >= 0, 'long liquidation must be non-negative');
                assert(r.short_liquidation_usdt >= 0, 'short liquidation must be non-negative');
            }
        },
    });

    // Test taker volume data
    const volRows = checkNodeOutput(graph, jagentId, 'btc_taker_volume', 'taker_volume', {
        expectFields: ['buy_volume_usd', 'sell_volume_usd'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.buy_volume_usd === 'number', 'buy_volume_usd must be number');
                assert(typeof r.sell_volume_usd === 'number', 'sell_volume_usd must be number');
                assert(r.buy_volume_usd >= 0, 'buy volume must be non-negative');
                assert(r.sell_volume_usd >= 0, 'sell volume must be non-negative');
            }
        },
    });

    // Test altcoin season index
    const altcoinRows = checkNodeOutput(graph, jagentId, 'altcoin_season_index', 'altcoin_season_index', {
        expectFields: ['altcoin_index', 'altcoin_marketcap'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.altcoin_index === 'number', 'altcoin_index must be number');
                assert(r.altcoin_index >= 0 && r.altcoin_index <= 100, 'altcoin_index must be 0-100');
                if (r.altcoin_marketcap !== null) {
                    assert(typeof r.altcoin_marketcap === 'number', 'altcoin_marketcap must be number');
                    assert(r.altcoin_marketcap >= 0, 'altcoin_marketcap must be non-negative');
                }
            }
        },
    });

    // Test Bitcoin dominance
    const domRows = checkNodeOutput(graph, jagentId, 'bitcoin_dominance', 'bitcoin_dominance', {
        expectFields: ['price', 'bitcoin_dominance', 'market_cap'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.price === 'number' || r.price === null, 'price must be number');
                assert(typeof r.bitcoin_dominance === 'number', 'bitcoin_dominance must be number');
                assert(typeof r.market_cap === 'number', 'market_cap must be number');
                assert(r.bitcoin_dominance >= 0 && r.bitcoin_dominance <= 100, 'dominance must be 0-100');
                assert(r.market_cap >= 0, 'market_cap must be non-negative');
            }
        },
    });

    // Test whale index
    const whaleRows = checkNodeOutput(graph, jagentId, 'whale_index_history', 'whale_index_history', {
        expectFields: ['whale_index_value'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.whale_index_value === 'number' || r.value === null, 'value must be a number or null');
            }
        },
    });

    // Coinbase Premium Index node is added to validate refs metadata below. We skip data assertions due to potential empty datasets in mock.

    // Test futures price
    const futuresRows = checkNodeOutput(graph, jagentId, 'btc_futures_price', 'future_ohlcv', {
        expectFields: ['open', 'high', 'low', 'close', 'volume'],
        preloadLast: '20',
        extra: (rows) => {
            for (const r of rows) {
                ['open', 'high', 'low', 'close', 'volume'].forEach((k) => assert(typeof r[k] === 'number', `field ${k} must be number`));
                assert(r.high >= r.low, 'high must be >= low');
                assert(r.volume >= 0, 'volume must be non-negative');
            }
        },
    });

    // Test Bitcoin reserve risk
    const reserveRows = checkNodeOutput(graph, jagentId, 'bitcoin_reserve_risk', 'bitcoin_reserve_risk', {
        expectFields: ['price', 'reserve_risk_index', 'movcd', 'hodl_bank', 'vocd'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                ['price', 'reserve_risk_index', 'movcd', 'hodl_bank', 'vocd'].forEach((k) => assert(typeof r[k] === 'number', `field ${k} must be number`));
                assert(r.price > 0, 'price must be positive');
                assert(r.reserve_risk_index >= 0, 'reserve risk index must be non-negative');
            }
        },
    });

    // Test Bitcoin bubble index
    const bubbleRows = checkNodeOutput(graph, jagentId, 'bitcoin_bubble_index', 'bitcoin_bubble_index', {
        expectFields: ['price', 'bubble_index', 'google_trend_percent', 'mining_difficulty', 'transaction_count', 'address_send_count', 'tweet_count'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                ['price', 'bubble_index', 'google_trend_percent', 'mining_difficulty', 'transaction_count', 'address_send_count', 'tweet_count'].forEach((k) =>
                    assert(typeof r[k] === 'number', `field ${k} must be number`)
                );
                assert(r.price > 0, 'price must be positive');
                assert(r.bubble_index >= 0, 'bubble index must be non-negative');
                assert(r.mining_difficulty >= 0, 'mining difficulty must be non-negative');
                assert(r.transaction_count >= 0, 'transaction count must be non-negative');
                assert(r.address_send_count >= 0, 'address send count must be non-negative');
                assert(r.tweet_count >= 0, 'tweet count must be non-negative');
            }
        },
    });

    // Test Bitcoin correlations
    const corrRows = checkNodeOutput(graph, jagentId, 'bitcoin_correlations', 'bitcoin_correlations', {
        expectFields: ['price', 'gld', 'iwm', 'qqq', 'spy', 'tlt'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                ['price', 'gld', 'iwm', 'qqq', 'spy', 'tlt'].forEach((k) => assert(typeof r[k] === 'number', `field ${k} must be number`));
                assert(r.price > 0, 'price must be positive');
                // correlations should be between -1 and 1
                ['gld', 'iwm', 'qqq', 'spy', 'tlt'].forEach((k) => {
                    assert(r[k] >= -1 && r[k] <= 1, `${k} correlation must be between -1 and 1`);
                });
            }
        },
    });

    // Test Bitcoin rainbow chart
    const rainbowRows = checkNodeOutput(graph, jagentId, 'bitcoin_rainbow_chart', 'bitcoin_rainbow_chart', {
        expectFields: [
            'price',
            'band_fire_sale',
            'band_buy_zone',
            'band_accumulate',
            'band_still_cheap',
            'band_hold',
            'band_is_this_a_bubble',
            'band_fomo_intensifies',
            'band_sell',
            'band_maximum_bubble',
            'band_top',
        ],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                [
                    'price',
                    'band_fire_sale',
                    'band_buy_zone',
                    'band_accumulate',
                    'band_still_cheap',
                    'band_hold',
                    'band_is_this_a_bubble',
                    'band_fomo_intensifies',
                    'band_sell',
                    'band_maximum_bubble',
                    'band_top',
                ].forEach((k) => assert(typeof r[k] === 'number' || r[k] === null, `field ${k} must be number or null`));
            }
        },
    });

    // Test borrow interest rate history
    const borrowRows = checkNodeOutput(graph, jagentId, 'borrow_interest_rate', 'borrow_interest_rate_history', {
        expectFields: ['exchange', 'symbol', 'interval', 'interest_rate'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.exchange === 'string', 'exchange must be string');
                assert(typeof r.symbol === 'string', 'symbol must be string');
                assert(typeof r.interval === 'string', 'interval must be string');
                assert(typeof r.interest_rate === 'number', 'interest_rate must be number');
                assert(r.interest_rate >= 0, 'interest_rate must be non-negative');
            }
        },
    });

    // Test bull market peak indicators
    const peakRows = checkNodeOutput(graph, jagentId, 'bull_market_peak_indicators', 'bull_market_peak_indicators', {
        expectFields: ['indicators'],
        preloadLast: '5',
        extra: (rows) => {
            for (const r of rows) {
                assert(Array.isArray(r.indicators), 'indicators must be array');
                for (const indicator of r.indicators) {
                    assert(typeof indicator.indicator_name === 'string' || indicator.indicator_name === null, `indicator_name must be a string, but got ${typeof indicator.indicator_name}`);
                    assert(typeof indicator.current_value === 'string' || indicator.current_value === null, `current_value must be a string, but got ${typeof indicator.current_value}`);
                    assert(typeof indicator.target_value === 'string' || indicator.target_value === null, `target_value must be a string, but got ${typeof indicator.target_value}`);
                    assert(typeof indicator.previous_value === 'string' || indicator.previous_value === null, `previous_value must be a string, but got ${typeof indicator.previous_value}`);
                    assert(typeof indicator.change_value === 'string' || indicator.change_value === null, `change_value must be a string, but got ${typeof indicator.change_value}`);
                    assert(typeof indicator.comparison_type === 'string' || indicator.comparison_type === null, `comparison_type must be a string, but got ${typeof indicator.comparison_type}`);
                    assert(typeof indicator.hit_status === 'boolean' || indicator.hit_status === null, `hit_status must be a boolean, but got ${typeof indicator.hit_status}`);
                }
            }
        },
    });

    // Test crypto fear and greed index
    const fearRows = checkNodeOutput(graph, jagentId, 'crypto_fear_and_greed_index', 'crypto_fear_and_greed_index', {
        expectFields: ['index_value', 'price'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.index_value === 'number', 'index_value must be number');
                assert(typeof r.price === 'number', 'price must be number');
                assert(r.index_value >= 0 && r.index_value <= 100, 'fear and greed index must be 0-100');
                assert(r.price > 0, 'price must be positive');
            }
        },
    });

    // Test futures basis history
    const basisRows = checkNodeOutput(graph, jagentId, 'futures_basis_history', 'futures_basis_history', {
        expectFields: ['open_basis', 'close_basis', 'open_change', 'close_change'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                ['open_basis', 'close_basis', 'open_change', 'close_change'].forEach((k) => assert(typeof r[k] === 'number', `field ${k} must be number`));
            }
        },
    });

    // Test margin long short
    const marginRows = checkNodeOutput(graph, jagentId, 'margin_long_short', 'margin_long_short', {
        expectFields: ['long_quantity', 'short_quantity'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.long_quantity === 'number', 'long_quantity must be number');
                assert(typeof r.short_quantity === 'number', 'short_quantity must be number');
                assert(r.long_quantity >= 0, 'long_quantity must be non-negative');
                assert(r.short_quantity >= 0, 'short_quantity must be non-negative');
            }
        },
    });

    // Test market indicator SOPR
    const soprRows = checkNodeOutput(graph, jagentId, 'market_indicator_sopr', 'market_indicator_sopr', {
        expectFields: ['sopr', 'a_sopr', 'sth_sopr', 'lth_sopr'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                ['sopr', 'a_sopr', 'sth_sopr', 'lth_sopr'].forEach((k) => assert(typeof r[k] === 'number' || r[k] === null, `field ${k} must be number or null`));
                if (r.sopr !== null) assert(r.sopr > 0, 'sopr must be positive when not null');
                // Validate date within [from, to]
                const fromMs = oneWeekAgoSeconds * 1000;
                const toMs = nowSeconds * 1000;
                assert(r.date >= fromMs && r.date <= toMs, `date ${r.date} must satisfy from<=date<=to`);
            }
        },
    });

    const predictionRows = checkNodeOutput(graph, jagentId, 'prediction_market_data', 'prediction_markets', {
        expectFields: ['query', 'events'],
        preloadLast: '5',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.query === 'string', 'query must be string');
                assert(Array.isArray(r.events), 'events must be array');
                for (const event of r.events) {
                    assert(typeof event.event_title === 'string', 'event_title must be string');
                    assert(typeof event.category === 'string', 'category must be string');
                    assert(typeof event.volume === 'number', 'volume must be number');
                    assert(typeof event.end_date === 'string', 'end_date must be string');
                    assert(typeof event.event_url === 'string', 'event_url must be string');
                    assert(Array.isArray(event.markets), 'markets must be array');
                    for (const market of event.markets) {
                        assert(typeof market.market_question === 'string', 'market_question must be string');
                        assert(typeof market.market_volume === 'number', 'market_volume must be number');
                        assert(typeof market.outcome_prices === 'object', 'outcome_prices must be object');
                    }
                }
            }
        },
    });

    // Validate refs metadata for all outputs with ref definitions
    log('🧪 Validating refs metadata...');

    // 1) btc_price -> ohlcv (getPrice)
    {
        const refs = graph.getRefsForOutput('btc_price', 'ohlcv');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getPrice',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getPrice',
                sdk_display_name: 'Token Market Price',
                source_name: 'Binance',
                source: 'https://developers.binance.com/docs/binance-spot-api-docs/web-socket-streams#klinecandlestick-streams-for-utc',
            };

            if (ref.id !== expected.id) throw new Error(`ref.id mismatch: expected ${expected.id}, got ${ref.id}`);
            if (ref.module_name !== expected.module_name) throw new Error(`ref.module_name mismatch: expected ${expected.module_name}, got ${ref.module_name}`);
            if (ref.module_display_name !== expected.module_display_name)
                throw new Error(`ref.module_display_name mismatch: expected ${expected.module_display_name}, got ${ref.module_display_name}`);
            if (ref.sdk_name !== expected.sdk_name) throw new Error(`ref.sdk_name mismatch: expected ${expected.sdk_name}, got ${ref.sdk_name}`);
            if (ref.sdk_display_name !== expected.sdk_display_name)
                throw new Error(`ref.sdk_display_name mismatch: expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
            if (ref.source_name !== expected.source_name) throw new Error(`ref.source_name mismatch: expected ${expected.source_name}, got ${ref.source_name}`);
            if (ref.source !== expected.source) throw new Error(`ref.source mismatch: expected ${expected.source}, got ${ref.source}`);
        } else {
            throw new Error('Assertion failed: refs array is empty for btc_price/ohlcv.');
        }
    }

    // 2) btc_open_interest -> open_interest (getOpenInterest)
    {
        const refs = graph.getRefsForOutput('btc_open_interest', 'open_interest');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getOpenInterest',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getOpenInterest',
                sdk_display_name: 'Token Open Interest',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/oi-ohlc-histroy',
            };
            if (ref.id !== expected.id) throw new Error(`ref.id mismatch: expected ${expected.id}, got ${ref.id}`);
            if (ref.module_name !== expected.module_name) throw new Error(`ref.module_name mismatch: expected ${expected.module_name}, got ${ref.module_name}`);
            if (ref.module_display_name !== expected.module_display_name)
                throw new Error(`ref.module_display_name mismatch: expected ${expected.module_display_name}, got ${ref.module_display_name}`);
            if (ref.sdk_name !== expected.sdk_name) throw new Error(`ref.sdk_name mismatch: expected ${expected.sdk_name}, got ${ref.sdk_name}`);
            if (ref.sdk_display_name !== expected.sdk_display_name)
                throw new Error(`ref.sdk_display_name mismatch: expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
            if (ref.source_name !== expected.source_name) throw new Error(`ref.source_name mismatch: expected ${expected.source_name}, got ${ref.source_name}`);
            if (ref.source !== expected.source) throw new Error(`ref.source mismatch: expected ${expected.source}, got ${ref.source}`);
        } else {
            throw new Error('Assertion failed: refs array is empty for btc_open_interest/open_interest.');
        }
    }

    // 3) bitcoin_rainbow_chart -> bitcoin_rainbow_chart (getBitcoinRainbowChart)
    {
        const refs = graph.getRefsForOutput('bitcoin_rainbow_chart', 'bitcoin_rainbow_chart');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getBitcoinRainbowChart',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getBitcoinRainbowChart',
                sdk_display_name: 'BTC Rainbow Chart',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/bitcoin-rainbow-chart',
            };
            if (ref.id !== expected.id) throw new Error(`ref.id mismatch: expected ${expected.id}, got ${ref.id}`);
            if (ref.module_name !== expected.module_name) throw new Error(`ref.module_name mismatch: expected ${expected.module_name}, got ${ref.module_name}`);
            if (ref.module_display_name !== expected.module_display_name)
                throw new Error(`ref.module_display_name mismatch: expected ${expected.module_display_name}, got ${ref.module_display_name}`);
            if (ref.sdk_name !== expected.sdk_name) throw new Error(`ref.sdk_name mismatch: expected ${expected.sdk_name}, got ${ref.sdk_name}`);
            if (ref.sdk_display_name !== expected.sdk_display_name)
                throw new Error(`ref.sdk_display_name mismatch: expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
            if (ref.source_name !== expected.source_name) throw new Error(`ref.source_name mismatch: expected ${expected.source_name}, got ${ref.source_name}`);
            if (ref.source !== expected.source) throw new Error(`ref.source mismatch: expected ${expected.source}, got ${ref.source}`);
        } else {
            throw new Error('Assertion failed: refs array is empty for bitcoin_rainbow_chart/bitcoin_rainbow_chart.');
        }
    }

    // 4) prediction_market_data -> prediction_markets (getPredictionMarketData)
    {
        const refs = graph.getRefsForOutput('prediction_market_data', 'prediction_markets');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getPredictionMarketData',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getPredictionMarketData',
                sdk_display_name: 'Polymarket Data',
                source_name: 'Polymarket',
                source: 'https://docs.polymarket.com/developers/gamma-markets-api/overview',
            };
            if (ref.id !== expected.id) throw new Error(`ref.id mismatch: expected ${expected.id}, got ${ref.id}`);
            if (ref.module_name !== expected.module_name) throw new Error(`ref.module_name mismatch: expected ${expected.module_name}, got ${ref.module_name}`);
            if (ref.module_display_name !== expected.module_display_name)
                throw new Error(`ref.module_display_name mismatch: expected ${expected.module_display_name}, got ${ref.module_display_name}`);
            if (ref.sdk_name !== expected.sdk_name) throw new Error(`ref.sdk_name mismatch: expected ${expected.sdk_name}, got ${ref.sdk_name}`);
            if (ref.sdk_display_name !== expected.sdk_display_name)
                throw new Error(`ref.sdk_display_name mismatch: expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
            if (ref.source_name !== expected.source_name) throw new Error(`ref.source_name mismatch: expected ${expected.source_name}, got ${ref.source_name}`);
            if (ref.source !== expected.source) throw new Error(`ref.source mismatch: expected ${expected.source}, got ${ref.source}`);
        } else {
            throw new Error('Assertion failed: refs array is empty for prediction_market_data/prediction_markets.');
        }
    }

    // 5) btc_funding_rate -> funding_rate (getFundingRate)
    {
        const refs = graph.getRefsForOutput('btc_funding_rate', 'funding_rate');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getFundingRate',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getFundingRate',
                sdk_display_name: 'Token Funding Rate',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/fr-ohlc-histroy',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for funding_rate');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for funding_rate');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for funding_rate');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for funding_rate');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for funding_rate');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for funding_rate');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for funding_rate');
        } else {
            throw new Error('Assertion failed: refs array is empty for btc_funding_rate/funding_rate.');
        }
    }

    // 6) eth_liquidations -> liquidations (getLiquidationHistory)
    {
        const refs = graph.getRefsForOutput('eth_liquidations', 'liquidations');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getLiquidationHistory',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getLiquidationHistory',
                sdk_display_name: 'Token Liquidation History',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/aggregated-liquidation-history',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for liquidations');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for liquidations');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for liquidations');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for liquidations');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for liquidations');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for liquidations');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for liquidations');
        } else {
            throw new Error('Assertion failed: refs array is empty for eth_liquidations/liquidations.');
        }
    }

    // 7) btc_taker_volume -> taker_volume (getTakerBuySellVolumeFuture)
    {
        const refs = graph.getRefsForOutput('btc_taker_volume', 'taker_volume');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getTakerBuySellVolumeFuture',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getTakerBuySellVolumeFuture',
                sdk_display_name: 'Token Futures Analyzer',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/aggregated-taker-buysell-volume-history',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for taker_volume');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for taker_volume');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for taker_volume');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for taker_volume');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for taker_volume');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for taker_volume');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for taker_volume');
        } else {
            throw new Error('Assertion failed: refs array is empty for btc_taker_volume/taker_volume.');
        }
    }

    // 8) btc_futures_price -> future_ohlcv (getFuturePrice)
    {
        const refs = graph.getRefsForOutput('btc_futures_price', 'future_ohlcv');
		console.log("debug")
		console.log(refs);
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getFuturePrice',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getFuturePrice',
                sdk_display_name: 'Token Futures Price',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/price-ohlc-history',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for future_ohlcv');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for future_ohlcv');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for future_ohlcv');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for future_ohlcv');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for future_ohlcv');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for future_ohlcv');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for future_ohlcv');
        } else {
            throw new Error('Assertion failed: refs array is empty for btc_futures_price/future_ohlcv.');
        }
    }

    // 9) altcoin_season_index -> altcoin_season_index (getAltcoinSeasonIndex)
    {
        const refs = graph.getRefsForOutput('altcoin_season_index', 'altcoin_season_index');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getAltcoinSeasonIndex',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getAltcoinSeasonIndex',
                sdk_display_name: 'Altcoin Season index',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/altcoin-season-index',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for altcoin_season_index');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for altcoin_season_index');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for altcoin_season_index');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for altcoin_season_index');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for altcoin_season_index');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for altcoin_season_index');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for altcoin_season_index');
        } else {
            throw new Error('Assertion failed: refs array is empty for altcoin_season_index/altcoin_season_index.');
        }
    }

    // 10) bitcoin_dominance -> bitcoin_dominance (getBitcoinDominance)
    {
        const refs = graph.getRefsForOutput('bitcoin_dominance', 'bitcoin_dominance');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getBitcoinDominance',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getBitcoinDominance',
                sdk_display_name: 'BTC Dominance Index',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/bitcoin-dominance',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for bitcoin_dominance');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for bitcoin_dominance');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for bitcoin_dominance');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for bitcoin_dominance');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for bitcoin_dominance');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for bitcoin_dominance');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for bitcoin_dominance');
        } else {
            throw new Error('Assertion failed: refs array is empty for bitcoin_dominance/bitcoin_dominance.');
        }
    }

    // 11) bitcoin_reserve_risk -> bitcoin_reserve_risk (getBitcoinReserveRisk)
    {
        const refs = graph.getRefsForOutput('bitcoin_reserve_risk', 'bitcoin_reserve_risk');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getBitcoinReserveRisk',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getBitcoinReserveRisk',
                sdk_display_name: 'BTC Reserve Risk Index',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/bitcoin-reserve-risk',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for bitcoin_reserve_risk');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for bitcoin_reserve_risk');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for bitcoin_reserve_risk');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for bitcoin_reserve_risk');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for bitcoin_reserve_risk');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for bitcoin_reserve_risk');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for bitcoin_reserve_risk');
        } else {
            throw new Error('Assertion failed: refs array is empty for bitcoin_reserve_risk/bitcoin_reserve_risk.');
        }
    }

    // 12) bitcoin_bubble_index -> bitcoin_bubble_index (getBitcoinBubbleIndex)
    {
        const refs = graph.getRefsForOutput('bitcoin_bubble_index', 'bitcoin_bubble_index');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getBitcoinBubbleIndex',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getBitcoinBubbleIndex',
                sdk_display_name: 'BTC Bubble Index',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/bitcoin-bubble-index',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for bitcoin_bubble_index');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for bitcoin_bubble_index');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for bitcoin_bubble_index');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for bitcoin_bubble_index');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for bitcoin_bubble_index');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for bitcoin_bubble_index');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for bitcoin_bubble_index');
        } else {
            throw new Error('Assertion failed: refs array is empty for bitcoin_bubble_index/bitcoin_bubble_index.');
        }
    }

    // 13) bitcoin_correlations -> bitcoin_correlations (getBitcoinCorrelations)
    {
        const refs = graph.getRefsForOutput('bitcoin_correlations', 'bitcoin_correlations');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getBitcoinCorrelations',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getBitcoinCorrelations',
                sdk_display_name: 'BTC Correlations Index',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/btc-correlations-gld-iwm-qqq-spy-tlt',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for bitcoin_correlations');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for bitcoin_correlations');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for bitcoin_correlations');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for bitcoin_correlations');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for bitcoin_correlations');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for bitcoin_correlations');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for bitcoin_correlations');
        } else {
            throw new Error('Assertion failed: refs array is empty for bitcoin_correlations/bitcoin_correlations.');
        }
    }

    // 14) borrow_interest_rate -> borrow_interest_rate_history (getBorrowInterestRateHistory)
    {
        const refs = graph.getRefsForOutput('borrow_interest_rate', 'borrow_interest_rate_history');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getBorrowInterestRateHistory',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getBorrowInterestRateHistory',
                sdk_display_name: 'Token Borrow Interest Rate',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/borrow-interest-rate',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for borrow_interest_rate_history');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for borrow_interest_rate_history');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for borrow_interest_rate_history');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for borrow_interest_rate_history');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for borrow_interest_rate_history');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for borrow_interest_rate_history');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for borrow_interest_rate_history');
        } else {
            throw new Error('Assertion failed: refs array is empty for borrow_interest_rate/borrow_interest_rate_history.');
        }
    }

    // 15) bull_market_peak_indicators -> bull_market_peak_indicators (getBullMarketPeakIndicators)
    {
        const refs = graph.getRefsForOutput('bull_market_peak_indicators', 'bull_market_peak_indicators');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getBullMarketPeakIndicators',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getBullMarketPeakIndicators',
                sdk_display_name: 'Bull Market Peak Indicators',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/bull-market-peak-indicator',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for bull_market_peak_indicators');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for bull_market_peak_indicators');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for bull_market_peak_indicators');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for bull_market_peak_indicators');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for bull_market_peak_indicators');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for bull_market_peak_indicators');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for bull_market_peak_indicators');
        } else {
            throw new Error('Assertion failed: refs array is empty for bull_market_peak_indicators/bull_market_peak_indicators.');
        }
    }

    // 16) crypto_fear_and_greed_index -> crypto_fear_and_greed_index (getCryptoFearAndGreedIndex)
    {
        const refs = graph.getRefsForOutput('crypto_fear_and_greed_index', 'crypto_fear_and_greed_index');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getCryptoFearAndGreedIndex',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getCryptoFearAndGreedIndex',
                sdk_display_name: 'Crypto Fear and Greed Index',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/cryptofear-greedindex',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for crypto_fear_and_greed_index');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for crypto_fear_and_greed_index');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for crypto_fear_and_greed_index');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for crypto_fear_and_greed_index');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for crypto_fear_and_greed_index');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for crypto_fear_and_greed_index');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for crypto_fear_and_greed_index');
        } else {
            throw new Error('Assertion failed: refs array is empty for crypto_fear_and_greed_index/crypto_fear_and_greed_index.');
        }
    }

    // 17) futures_basis_history -> futures_basis_history (getFuturesBasisHistory)
    {
        const refs = graph.getRefsForOutput('futures_basis_history', 'futures_basis_history');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getFuturesBasisHistory',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getFuturesBasisHistory',
                sdk_display_name: 'Token Futures Basis',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/basis',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for futures_basis_history');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for futures_basis_history');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for futures_basis_history');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for futures_basis_history');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for futures_basis_history');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for futures_basis_history');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for futures_basis_history');
        } else {
            throw new Error('Assertion failed: refs array is empty for futures_basis_history/futures_basis_history.');
        }
    }

    // 18) margin_long_short -> margin_long_short (getMarginLongShort)
    {
        const refs = graph.getRefsForOutput('margin_long_short', 'margin_long_short');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getMarginLongShort',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getMarginLongShort',
                sdk_display_name: 'Bitfinex Margin Long/Short Positions',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/bitfinex-margin-long-short',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for margin_long_short');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for margin_long_short');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for margin_long_short');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for margin_long_short');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for margin_long_short');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for margin_long_short');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for margin_long_short');
        } else {
            throw new Error('Assertion failed: refs array is empty for margin_long_short/margin_long_short.');
        }
    }

    // 19) market_indicator_sopr -> market_indicator_sopr (getMarketIndicatorSopr)
    {
        const refs = graph.getRefsForOutput('market_indicator_sopr', 'market_indicator_sopr');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getMarketIndicatorSopr',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getMarketIndicatorSopr',
                sdk_display_name: 'Bitcoin Profit/Loss Ratio',
                source_name: 'CryptoQuant',
                source: 'https://cryptoquant.com/docs#tag/BTC-Market-Indicator/operation/getSOPR',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for market_indicator_sopr');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for market_indicator_sopr');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for market_indicator_sopr');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for market_indicator_sopr');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for market_indicator_sopr');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for market_indicator_sopr');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for market_indicator_sopr');
        } else {
            throw new Error('Assertion failed: refs array is empty for market_indicator_sopr/market_indicator_sopr.');
        }
    }

    // 20) whale_index_history -> whale_index_history (getWhaleIndexHistory)
    {
        const refs = graph.getRefsForOutput('whale_index_history', 'whale_index_history');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getWhaleIndexHistory',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getWhaleIndexHistory',
                sdk_display_name: 'Crypto Whale Index',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/whale-index',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for whale_index_history');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for whale_index_history');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for whale_index_history');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for whale_index_history');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for whale_index_history');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for whale_index_history');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for whale_index_history');
        } else {
            throw new Error('Assertion failed: refs array is empty for whale_index_history/whale_index_history.');
        }
    }

    // 21) coinbase_premium_index -> coinbase_premium_index (getCoinbasePremiumIndex)
    {
        const refs = graph.getRefsForOutput('coinbase_premium_index', 'coinbase_premium_index');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getCoinbasePremiumIndex',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getCoinbasePremiumIndex',
                sdk_display_name: 'Coinbase Premium Index',
                source_name: 'Coinglass',
                source: 'https://docs.coinglass.com/reference/coinbase-premium-index',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for coinbase_premium_index');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for coinbase_premium_index');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for coinbase_premium_index');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for coinbase_premium_index');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for coinbase_premium_index');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for coinbase_premium_index');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for coinbase_premium_index');
        } else {
            throw new Error('Assertion failed: refs array is empty for coinbase_premium_index/coinbase_premium_index.');
        }
    }

    // 22) token_historical_quotes -> token_historical_quotes (getTokenHistoricalQuotes)
    {
        const refs = graph.getRefsForOutput('token_historical_quotes', 'token_historical_quotes');
        if (refs.length > 0) {
            const ref = refs[0];
            const expected = {
                id: '@alva/data/crypto/market/getTokenHistoricalQuotes',
                module_name: '@alva/data/crypto/market ',
                module_display_name: 'Crypto Market Analytics',
                sdk_name: 'getTokenHistoricalQuotes',
                sdk_display_name: 'Historical Token Quotes',
                source_name: 'CoinMarketCap',
                source: 'https://coinmarketcap.com/api/documentation/v1/#operation/getV3CryptocurrencyQuotesHistorical',
            };
            if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for historical_token_quotes');
            if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for historical_token_quotes');
            if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for historical_token_quotes');
            if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for historical_token_quotes');
            if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for historical_token_quotes');
            if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for historical_token_quotes');
            if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for historical_token_quotes');
        } else {
            throw new Error('Assertion failed: refs array is empty for token_historical_quotes/token_historical_quotes.');
        }
    }

	testCryptoMarketFunctions();

    log(`✅ All tests passed! `);

    return 0;
}

function testCryptoMarketFunctions() {
	console.log('\n=== Testing Crypto Market Functions ===');

	const {
		getPrice,
		getOpenInterest,
		getFundingRate,
		getLiquidationHistory,
		getTakerBuySellVolumeFuture,
		getFuturePrice,
		getMarginLongShort,
		getBorrowInterestRateHistory,
		getBullMarketPeakIndicators,
		getFuturesBasisHistory,
		getWhaleIndexHistory,
		getAltcoinSeasonIndex,
		getBitcoinReserveRisk,
		getBitcoinDominance,
		getBitcoinRainbowChart,
		getCryptoFearAndGreedIndex,
		getBitcoinBubbleIndex,
		getBitcoinCorrelations,
		getMarketIndicatorSopr,
		getTokenHistoricalQuotes,
		getPredictionMarketData,
		getCoinbasePremiumIndex,
	} = require('@alva/data/crypto/market');

	// Define test constants
	const nowSeconds = Math.floor(Date.now() / 1000);
	const oneDayAgo = nowSeconds - 24 * 60 * 60;
	const oneWeekAgo = nowSeconds - 7 * 24 * 60 * 60;
	const oneMonthAgo = nowSeconds - 30 * 24 * 60 * 60;

	const EXCHANGES = ['Binance', 'OKX', 'Bybit'];
	const SYMBOLS = ['BTC', 'ETH', 'BTCUSDT', 'ETHUSDT'];
	const INTERVALS = ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'];
	const PRICE_INTERVALS = ['1m', '3m', '5m', '15m', '30m', '1h', '4h', '6h', '8h', '12h', '1d', '1w'];

	let totalTests = 0;
	let passedTests = 0;

	// Helper function to run test and track results
	function runTest(testName, testFunc) {
		totalTests++;
		try {
			testFunc();
			console.log(`✅ ${testName}`);
			passedTests++;
		} catch (e) {
			console.log(`❌ ${testName}: ${e.message}`);
		}
	}

	// ============ getPrice Tests ============
	console.log('\n--- Testing getPrice ---');

	// Test all valid intervals
	for (const interval of PRICE_INTERVALS) {
		runTest(`getPrice with interval ${interval}`, () => {
			const priceData = getPrice({
				symbol: 'BTC',
				time_start: oneWeekAgo,
				time_end: nowSeconds,
				interval: interval
			});
			assert(Array.isArray(priceData), `Should return array for interval ${interval}`);
			if (priceData.length > 0) {
				const candle = priceData[0];
				assert(typeof candle.date === 'number', 'date should be number');
				assert(typeof candle.open === 'number', 'price_open should be number');
				assert(typeof candle.close === 'number', 'price_close should be number');
				assert(typeof candle.low === 'number', 'price_low should be number');
				assert(typeof candle.high === 'number', 'price_high should be number');
				assert(typeof candle.trades_count === 'number', 'trades_count should be number');
				assert(typeof candle.volume === 'number', 'volume_traded should be number');
				assert(candle.high >= candle.low, 'high should be >= low');
				assert(candle.high >= candle.open, 'high should be >= open');
				assert(candle.high >= candle.close, 'high should be >= close');
			}
		});
	}

	// Test different symbols
	for (const symbol of ['BTC', 'ETH', 'ADA', 'DOT']) {
		runTest(`getPrice with symbol ${symbol}`, () => {
			const priceData = getPrice({
				symbol: symbol,
				time_start: oneWeekAgo,
				time_end: nowSeconds,
				interval: '1h'
			});
			assert(Array.isArray(priceData), `Should return array for symbol ${symbol}`);
		});
	}

	// ============ getOpenInterest Tests ============
	console.log('\n--- Testing getOpenInterest ---');
	// Test all exchanges and symbols combinations
	for (const exchange of ['Binance', 'Bybit']) {
		for (const symbol of ['BTCUSDT', 'ETHUSDT']) {
			runTest(`getOpenInterest with ${exchange} - ${symbol}`, () => {
				const oiData = getOpenInterest({
					symbol: symbol,
					start_time: oneWeekAgo,
					end_time: nowSeconds,
					interval: '1h',
					exchange: exchange
				});
				assert(Array.isArray(oiData), `Should return array for ${exchange}-${symbol}`);
				if (oiData.length > 0) {
					const point = oiData[0];
					assert(typeof point.time === 'number', 'time should be number');
					assert(typeof point.open === 'string', 'open should be number');
					assert(typeof point.close === 'string', 'close should be number');
					assert(typeof point.low === 'string', 'low should be number');
					assert(typeof point.high === 'string', 'high should be number');
				}
			});
		}
	}

	// Test all intervals for open interest
	for (const interval of INTERVALS) {
		runTest(`getOpenInterest with interval ${interval}`, () => {
			const oiData = getOpenInterest({
				symbol: 'BTCUSDT',
				start_time: oneDayAgo,
				end_time: nowSeconds,
				interval: interval,
				exchange: 'Binance'
			});
			assert(Array.isArray(oiData), `Should return array for interval ${interval}`);
		});
	}

	// ============ getFundingRate Tests ============
	console.log('\n--- Testing getFundingRate ---');

	// Test all valid symbol combinations
	for (const symbol of ['BTCUSDt', 'ETHUSDT']) {
		for (const exchange of ['Binance', 'Bybit']) {
			runTest(`getFundingRate with ${exchange} - ${symbol}`, () => {
				const frData = getFundingRate({
					symbol: symbol,
					start_time: oneWeekAgo,
					end_time: nowSeconds,
					interval: '4h',
					exchange: exchange
				});
				assert(Array.isArray(frData), `Should return array for ${exchange}-${symbol}`);
				if (frData.length > 0) {
					const point = frData[0];
					assert(typeof point.time === 'number', 'time should be number');
					assert(typeof point.open === 'string', 'open should be number');
					assert(typeof point.close === 'string', 'close should be number');
					assert(typeof point.low === 'string', 'low should be number');
					assert(typeof point.high === 'string', 'high should be number');
				}
			});
		}
	}

	// ============ getLiquidationHistory Tests ============
	console.log('\n--- Testing getLiquidationHistory ---');

	for (const exchange of EXCHANGES) {
		for (const symbol of ['BTC', 'ETH']) {
			runTest(`getLiquidationHistory with ${exchange} - ${symbol}`, () => {
				const liqData = getLiquidationHistory({
					symbol: symbol,
					time_start: oneWeekAgo,
					time_end: nowSeconds,
					interval: '1h',
					exchange: exchange
				});
				assert(typeof liqData === 'object', `Should return object for ${exchange}-${symbol}`);
				assert(typeof liqData.long_liquidation_usdt === 'number', 'long_liquidation_usdt should be number');
				assert(typeof liqData.short_liquidation_usdt === 'number', 'short_liquidation_usdt should be number');
				assert(liqData.long_liquidation_usdt >= 0, 'long liquidation should be non-negative');
				assert(liqData.short_liquidation_usdt >= 0, 'short liquidation should be non-negative');
			});
		}
	}

	// ============ getTakerBuySellVolumeFuture Tests ============
	console.log('\n--- Testing getTakerBuySellVolumeFuture ---');

	for (const exchange of EXCHANGES) {
		for (const symbol of ['BTC', 'ETH']) {
			runTest(`getTakerBuySellVolumeFuture with ${exchange} - ${symbol}`, () => {
				const volData = getTakerBuySellVolumeFuture({
					symbol: symbol,
					time_start: oneWeekAgo,
					time_end: nowSeconds,
					interval: '1h',
					exchange: exchange
				});
				assert(typeof volData === 'object', `Should return object for ${exchange}-${symbol}`);
				assert(typeof volData.buy_volume_usd === 'number', 'buy_volume_usd should be number');
				assert(typeof volData.sell_volume_usd === 'number', 'sell_volume_usd should be number');
				assert(volData.buy_volume_usd >= 0, 'buy volume should be non-negative');
				assert(volData.sell_volume_usd >= 0, 'sell volume should be non-negative');
			});
		}
	}

	// ============ getFuturePrice Tests ============
	console.log('\n--- Testing getFuturePrice ---');

	// Test all exchanges and intervals
	for (const exchange of ['Binance', 'Bybit']) {
		for (const interval of INTERVALS) {
			runTest(`getFuturePrice with ${exchange} - ${interval}`, () => {
				const fpData = getFuturePrice({
					exchange: exchange,
					symbol: 'BTCUSDT',
					interval: interval,
					limit: 10
				});
				assert(Array.isArray(fpData), `Should return array for ${exchange}-${interval}`);
				if (fpData.length > 0) {
					const point = fpData[0];
					assert(typeof point.date === 'number', 'time should be number');
					assert(typeof point.open === 'number', 'open should be string');
					assert(typeof point.high === 'number', 'high should be string');
					assert(typeof point.low === 'number', 'low should be string');
					assert(typeof point.close === 'number', 'close should be string');
					assert(typeof point.volume === 'number', 'volume_usd should be string');
				}
			});
		}
	}

	// Test limit boundaries
	runTest('getFuturePrice limit boundaries', () => {
		const fpMin = getFuturePrice({
			exchange: 'Binance',
			symbol: 'BTCUSDT',
			interval: '1h',
			limit: 1
		});
		assert(Array.isArray(fpMin), 'Should work with minimum limit');
		assert(fpMin.length <= 1, 'Should respect minimum limit');

		const fpMax = getFuturePrice({
			exchange: 'Binance',
			symbol: 'BTCUSDT',
			interval: '1h',
			limit: 100
		});
		assert(Array.isArray(fpMax), 'Should work with larger limit');
	});

	// ============ getMarginLongShort Tests ============
	console.log('\n--- Testing getMarginLongShort ---');

	// Test all exchanges and symbols combinations
	const MARGIN_EXCHANGES = ['Binance', 'OKX', 'Bybit', 'Bitfinex'];
	const MARGIN_SYMBOLS = ['BTC', 'ETH'];

	for (const exchange of MARGIN_EXCHANGES) {
		for (const symbol of MARGIN_SYMBOLS) {
			runTest(`getMarginLongShort with ${exchange} - ${symbol}`, () => {
				const mlData = getMarginLongShort({
					exchange: exchange,
					symbol: symbol,
					interval: '1d',
					limit: 30
				});
				assert(Array.isArray(mlData), `Should return array for ${exchange}-${symbol}`);
				if (mlData.length > 0) {
					const point = mlData[0];
					assert(typeof point.time === 'number', 'time should be number');
					assert(typeof point.long_quantity === 'number', 'long_quantity should be number');
					assert(typeof point.short_quantity === 'number', 'short_quantity should be number');
					assert(point.long_quantity >= 0, 'long quantity should be non-negative');
					assert(point.short_quantity >= 0, 'short quantity should be non-negative');
				}
			});
		}
	}

	// Test all intervals
	for (const interval of ['1m', '5m', '15m', '30m', '1h', '4h', '1d']) {
		runTest(`getMarginLongShort with interval ${interval}`, () => {
			const mlData = getMarginLongShort({
				exchange: 'Bitfinex',
				symbol: 'BTC',
				interval: interval,
				limit: 10
			});
			assert(Array.isArray(mlData), `Should return array for interval ${interval}`);
		});
	}

	// ============ getBorrowInterestRateHistory Tests ============
	console.log('\n--- Testing getBorrowInterestRateHistory ---');

	for (const exchange of EXCHANGES) {
		for (const symbol of ['BTC', 'ETH', 'USDT']) {
			runTest(`getBorrowInterestRateHistory with ${exchange} - ${symbol}`, () => {
				const irData = getBorrowInterestRateHistory({
					exchange: exchange,
					symbol: symbol,
					interval: '1h',
					limit: 24
				});
				assert(Array.isArray(irData), `Should return array for ${exchange}-${symbol}`);
				if (irData.length > 0) {
					const point = irData[0];
					assert(typeof point.time === 'number', 'time should be number');
					assert(typeof point.interest_rate === 'number', 'interest_rate should be number');
					assert(point.interest_rate >= 0, 'interest_rate should be non-negative');
				}
			});
		}
	}

	// ============ getBullMarketPeakIndicators Tests ============
	console.log('\n--- Testing getBullMarketPeakIndicators ---');

	runTest('getBullMarketPeakIndicators structure', () => {
		const indicators = getBullMarketPeakIndicators();
		assert(Array.isArray(indicators), 'Should return array');
		if (indicators.length > 0) {
			const indicator = indicators[0];
			assert(typeof indicator.indicator_name === 'string', 'indicator_name should be string');
			assert(typeof indicator.current_value === 'string', 'current_value should be string');
			assert(typeof indicator.target_value === 'string', 'target_value should be string');
			assert(typeof indicator.previous_value === 'string', 'previous_value should be string');
			assert(typeof indicator.change_value === 'string', 'change_value should be string');
			assert(typeof indicator.comparison_type === 'string', 'comparison_type should be string');
			assert(typeof indicator.hit_status === 'boolean', 'hit_status should be boolean');
		}
	});

	// ============ getFuturesBasisHistory Tests ============
	console.log('\n--- Testing getFuturesBasisHistory ---');

	// Define supported exchanges and symbols for futures basis
	const BASIS_EXCHANGES = ['Binance', 'Bybit'];
	const BASIS_SYMBOLS = ['BTCUSDT', 'ETHUSDT'];
	const BASIS_INTERVALS = ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'];

	// Test all exchanges and symbols combinations
	for (const exchange of BASIS_EXCHANGES) {
		for (const symbol of BASIS_SYMBOLS) {
			runTest(`getFuturesBasisHistory with ${exchange} - ${symbol}`, () => {
				const basisData = getFuturesBasisHistory({
					exchange: exchange,
					symbol: symbol,
					interval: '1h',
					limit: 24
				});
				assert(Array.isArray(basisData), `Should return array for ${exchange}-${symbol}`);
				if (basisData.length > 0) {
					const point = basisData[0];
					assert(typeof point.time === 'number', 'time should be number (milliseconds)');
					assert(typeof point.open_basis === 'number', 'open_basis should be number');
					assert(typeof point.close_basis === 'number', 'close_basis should be number');
					assert(typeof point.open_change === 'number', 'open_change should be number');
					assert(typeof point.close_change === 'number', 'close_change should be number');
				}
			});
		}
	}

	// Test all intervals for futures basis
	for (const interval of BASIS_INTERVALS) {
		runTest(`getFuturesBasisHistory with interval ${interval}`, () => {
			const basisData = getFuturesBasisHistory({
				exchange: 'Binance',
				symbol: 'BTCUSDT',
				interval: interval,
				limit: 10
			});
			assert(Array.isArray(basisData), `Should return array for interval ${interval}`);
		});
	}

	// Test with time range
	runTest('getFuturesBasisHistory with time range', () => {
		const basisData = getFuturesBasisHistory({
			exchange: 'Binance',
			symbol: 'BTCUSDT',
			interval: '1h',
			start_time: oneDayAgo,
			end_time: nowSeconds,
			limit: 24
		});
		assert(Array.isArray(basisData), 'Should work with time range');
	});

	// ============ getWhaleIndexHistory Tests ============
	console.log('\n--- Testing getWhaleIndexHistory ---');

	// Define supported exchanges and symbols for whale index
	const WHALE_EXCHANGES = ['Binance', 'Bybit'];
	const WHALE_SYMBOLS = ['BTCUSDT', 'ETHUSDT'];
	const WHALE_INTERVALS = ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'];

	// Test all exchanges and symbols combinations
	for (const exchange of WHALE_EXCHANGES) {
		for (const symbol of WHALE_SYMBOLS) {
			runTest(`getWhaleIndexHistory with ${exchange} - ${symbol}`, () => {
				const whaleData = getWhaleIndexHistory({
					exchange: exchange,
					symbol: symbol,
					interval: '1d',
					limit: 30
				});
				assert(Array.isArray(whaleData), `Should return array for ${exchange}-${symbol}`);
				if (whaleData.length > 0) {
					const point = whaleData[0];
					assert(typeof point.time === 'number', 'time should be number (milliseconds)');
					assert(typeof point.whale_index_value === 'number', 'whale_index_value should be number');
				}
			});
		}
	}

	// Test all intervals for whale index
	for (const interval of WHALE_INTERVALS) {
		runTest(`getWhaleIndexHistory with interval ${interval}`, () => {
			const whaleData = getWhaleIndexHistory({
				exchange: 'Binance',
				symbol: 'BTCUSDT',
				interval: interval,
				limit: 10
			});
			assert(Array.isArray(whaleData), `Should return array for interval ${interval}`);
		});
	}

	// Test limit boundaries
	runTest('getWhaleIndexHistory limit boundaries', () => {
		const whaleMin = getWhaleIndexHistory({
			exchange: 'Binance',
			symbol: 'BTCUSDT',
			interval: '1d',
			limit: 1
		});
		assert(Array.isArray(whaleMin), 'Should work with minimum limit');
		assert(whaleMin.length <= 1, 'Should respect minimum limit');

		const whaleMax = getWhaleIndexHistory({
			exchange: 'Binance',
			symbol: 'BTCUSDT',
			interval: '1d',
			limit: 100
		});
		assert(Array.isArray(whaleMax), 'Should work with larger limit');
	});

	// Test with time range
	runTest('getWhaleIndexHistory with time range', () => {
		const whaleData = getWhaleIndexHistory({
			exchange: 'Binance',
			symbol: 'BTCUSDT',
			interval: '1h',
			start_time: oneDayAgo,
			end_time: nowSeconds,
			limit: 24
		});
		assert(Array.isArray(whaleData), 'Should work with time range');
	});

	// Test whale index value interpretation
	runTest('getWhaleIndexHistory value interpretation', () => {
		const whaleData = getWhaleIndexHistory({
			exchange: 'Binance',
			symbol: 'BTCUSDT',
			interval: '1d',
			limit: 30
		});
		if (whaleData.length > 0) {
			const point = whaleData[0];
			assert(typeof point.whale_index_value === 'number', 'whale_index_value should be number');
			// Whale index can be positive (bullish) or negative (bearish)
			// No specific range constraint, but should be a valid number
			assert(!isNaN(point.whale_index_value), 'whale_index_value should not be NaN');
			assert(isFinite(point.whale_index_value), 'whale_index_value should be finite');
		}
	});

	// ============ getAltcoinSeasonIndex Tests ============
	console.log('\n--- Testing getAltcoinSeasonIndex ---');

	runTest('getAltcoinSeasonIndex structure', () => {
		const altData = getAltcoinSeasonIndex();
		assert(Array.isArray(altData), 'Should return array');
		if (altData.length > 0) {
			const point = altData[0];
			assert(typeof point.timestamp === 'number', 'timestamp should be number');
			assert(typeof point.altcoin_index === 'number', 'altcoin_index should be number');
			assert(point.altcoin_index >= 0 && point.altcoin_index <= 100, 'altcoin_index should be 0-100');
			if (point.altcoin_marketcap !== null) {
				assert(typeof point.altcoin_marketcap === 'number', 'altcoin_marketcap should be number');
				assert(point.altcoin_marketcap >= 0, 'altcoin_marketcap should be non-negative');
			}
		}
	});

	// ============ Bitcoin Index Tests ============
	console.log('\n--- Testing Bitcoin Index Functions ---');

	// Test Bitcoin Reserve Risk
	runTest('getBitcoinReserveRisk structure', () => {
		const reserveData = getBitcoinReserveRisk();
		assert(Array.isArray(reserveData), 'Should return array');
		if (reserveData.length > 0) {
			const point = reserveData[0];
			assert(typeof point.timestamp === 'number', 'timestamp should be number');
			assert(typeof point.price === 'number', 'price should be number');
			assert(typeof point.reserve_risk_index === 'number', 'reserve_risk_index should be number');
			assert(typeof point.movcd === 'number', 'movcd should be number');
			assert(typeof point.hodl_bank === 'number', 'hodl_bank should be number');
			assert(typeof point.vocd === 'number', 'vocd should be number');
			assert(point.price > 0, 'price should be positive');
			assert(point.reserve_risk_index >= 0, 'reserve_risk_index should be non-negative');
		}
	});

	// Test Bitcoin Dominance
	runTest('getBitcoinDominance structure', () => {
		const domData = getBitcoinDominance();
		assert(Array.isArray(domData), 'Should return array');
		if (domData.length > 0) {
			const point = domData[0];
			assert(typeof point.timestamp === 'number', 'timestamp should be number');
			assert(typeof point.price === 'number', 'price should be number');
			assert(typeof point.bitcoin_dominance === 'number', 'bitcoin_dominance should be number');
			assert(typeof point.market_cap === 'number', 'market_cap should be number');
			assert(point.price > 0, 'price should be positive');
			assert(point.bitcoin_dominance >= 0 && point.bitcoin_dominance <= 100, 'dominance should be 0-100');
			assert(point.market_cap >= 0, 'market_cap should be non-negative');
		}
	});

	// Test Bitcoin Rainbow Chart
	runTest('getBitcoinRainbowChart structure', () => {
		const rainbowData = getBitcoinRainbowChart();
		assert(Array.isArray(rainbowData), 'Should return array');
		if (rainbowData.length > 0) {
			const point = rainbowData[0];
			assert(Array.isArray(point), 'Each data point should be array');
			assert(point.length === 12, 'Each data point should have 12 elements');
			assert(typeof point[0] === 'number', 'Current price should be number');
			assert(typeof point[11] === 'number', 'Timestamp should be number');
			// All bands should be numbers or null
			for (let i = 1; i <= 10; i++) {
				assert(typeof point[i] === 'number' || point[i] === null, `Band ${i} should be number or null`);
			}
		}
	});

	// Test Crypto Fear & Greed Index
	runTest('getCryptoFearAndGreedIndex structure', () => {
		const fearData = getCryptoFearAndGreedIndex();
		if (fearData !== null) {
			assert(typeof fearData === 'object', 'Should return object');
			assert(Array.isArray(fearData.data_list), 'data_list should be array');
			assert(Array.isArray(fearData.price_list), 'price_list should be array');
			assert(Array.isArray(fearData.time_list), 'time_list should be array');

			if (fearData.data_list.length > 0) {
				assert(typeof fearData.data_list[0] === 'number', 'index values should be numbers');
				assert(typeof fearData.price_list[0] === 'number', 'prices should be numbers');
				assert(typeof fearData.time_list[0] === 'number', 'timestamps should be numbers');
				assert(fearData.data_list[0] >= 0 && fearData.data_list[0] <= 100, 'fear index should be 0-100');
			}
		}
	});

	// Test Bitcoin Bubble Index
	runTest('getBitcoinBubbleIndex structure', () => {
		const bubbleData = getBitcoinBubbleIndex();
		assert(Array.isArray(bubbleData), 'Should return array');
		if (bubbleData.length > 0) {
			const point = bubbleData[0];
			assert(typeof point.price === 'number', 'price should be number');
			assert(typeof point.bubble_index === 'number', 'bubble_index should be number');
			assert(typeof point.google_trend_percent === 'number', 'google_trend_percent should be number');
			assert(typeof point.mining_difficulty === 'number', 'mining_difficulty should be number');
			assert(typeof point.transaction_count === 'number', 'transaction_count should be number');
			assert(typeof point.address_send_count === 'number', 'address_send_count should be number');
			assert(typeof point.tweet_count === 'number', 'tweet_count should be number');
			assert(typeof point.date_string === 'string', 'date_string should be string');
			assert(point.price > 0, 'price should be positive');
			assert(point.mining_difficulty >= 0, 'mining_difficulty should be non-negative');
			assert(point.transaction_count >= 0, 'transaction_count should be non-negative');
			assert(point.address_send_count >= 0, 'address_send_count should be non-negative');
			assert(point.tweet_count >= 0, 'tweet_count should be non-negative');
		}
	});

	// Test Bitcoin Correlations
	runTest('getBitcoinCorrelations structure', () => {
		const corrData = getBitcoinCorrelations();
		assert(Array.isArray(corrData), 'Should return array');
		if (corrData.length > 0) {
			const point = corrData[0];
			assert(typeof point.timestamp === 'number', 'timestamp should be number');
			assert(typeof point.price === 'number', 'price should be number');
			assert(typeof point.gld === 'number', 'gld correlation should be number');
			assert(typeof point.iwm === 'number', 'iwm correlation should be number');
			assert(typeof point.qqq === 'number', 'qqq correlation should be number');
			assert(typeof point.spy === 'number', 'spy correlation should be number');
			assert(typeof point.tlt === 'number', 'tlt correlation should be number');
			assert(point.price > 0, 'price should be positive');
			// Correlations should be between -1 and 1
			['gld', 'iwm', 'qqq', 'spy', 'tlt'].forEach(asset => {
				assert(point[asset] >= -1 && point[asset] <= 1, `${asset} correlation should be between -1 and 1`);
			});
		}
	});

	// ============ getMarketIndicatorSopr Tests ============
	console.log('\n--- Testing getMarketIndicatorSopr ---');

	runTest('getMarketIndicatorSopr with BTC', () => {
		const soprData = getMarketIndicatorSopr({
			symbol: 'btc',
			from: oneWeekAgo,
			to: nowSeconds,
			limit: 10
		});
		assert(typeof soprData === 'object', 'Should return object');
		assert(soprData.result && Array.isArray(soprData.result.data), 'Should have data array');
		if (soprData.result.data.length > 0) {
			const point = soprData.result.data[0];
			assert(point.sopr === null || typeof point.sopr === 'number', 'sopr should be number or null');
			assert(point.a_sopr === null || typeof point.a_sopr === 'number', 'a_sopr should be number or null');
			assert(point.sth_sopr === null || typeof point.sth_sopr === 'number', 'sth_sopr should be number or null');
			assert(point.lth_sopr === null || typeof point.lth_sopr === 'number', 'lth_sopr should be number or null');
			if (point.sopr !== null) assert(point.sopr > 0, 'sopr should be positive when not null');
			// time range assertion: timestamp is in seconds
			for (const item of soprData.result.data) {
				assert(typeof item.timestamp === 'number', 'timestamp should be number');
				assert(item.timestamp >= oneWeekAgo && item.timestamp <= nowSeconds, `timestamp ${item.timestamp} must satisfy from<=timestamp<=to`);
			}
		}
	});

	// Test boundary values for limit
	runTest('getMarketIndicatorSopr boundary values', () => {
		const fromTs = oneDayAgo;
		const toTs = nowSeconds;
		const soprMin = getMarketIndicatorSopr({
			symbol: 'btc',
			from: fromTs,
			to: toTs,
			limit: 2
		});
		assert(typeof soprMin === 'object', 'Should work with minimum limit');
		if (soprMin.result && Array.isArray(soprMin.result.data)) {
			for (const item of soprMin.result.data) {
				assert(item.timestamp >= fromTs && item.timestamp <= toTs, 'timestamp must be within [from, to]');
			}
		}

		const soprMax = getMarketIndicatorSopr({
			symbol: 'btc',
			from: fromTs,
			to: toTs,
			limit: 1000
		});
		assert(typeof soprMax === 'object', 'Should work with larger limit');
		if (soprMax.result && Array.isArray(soprMax.result.data)) {
			for (const item of soprMax.result.data) {
				assert(item.timestamp >= fromTs && item.timestamp <= toTs, 'timestamp must be within [from, to]');
			}
		}
	});


	// ============ getPredictionMarketData Tests ============
	console.log('\n--- Testing getPredictionMarketData ---');

	// Test different search queries
	const searchQueries = ['US Bitcoin price', 'Election 2024', 'Crypto market', 'Sports'];
	for (const query of searchQueries) {
		runTest(`getPredictionMarketData with query "${query}"`, () => {
			const predData = getPredictionMarketData({
				q: query
			});
			assert(Array.isArray(predData), `Should return array for query "${query}"`);
			if (predData.length > 0) {
				const event = predData[0];
				assert(typeof event.event_title === 'string', 'event_title should be string');
				assert(typeof event.volume === 'number', 'volume should be number');
				assert(typeof event.end_date === 'string', 'end_date should be string');
				assert(typeof event.event_url === 'string', 'event_url should be string');
				assert(Array.isArray(event.markets), 'markets should be array');

				if (event.markets.length > 0) {
					const market = event.markets[0];
					assert(typeof market.market_question === 'string', 'market_question should be string');
					assert(typeof market.market_volume === 'number', 'market_volume should be number');
					assert(typeof market.outcome_prices === 'object', 'outcome_prices should be object');
				}
			}
		});
	}

	// ============ getCoinbasePremiumIndex Tests ============
	console.log('\n--- Testing getCoinbasePremiumIndex ---');

	// Test all intervals
	for (const interval of INTERVALS) {
		runTest(`getCoinbasePremiumIndex with interval ${interval}`, () => {
			const premiumData = getCoinbasePremiumIndex({
				interval: interval,
				limit: 24
			});

			assert(Array.isArray(premiumData), `Should return array for interval ${interval}`);
			if (premiumData.length > 0) {
				const point = premiumData[0];
				assert(typeof point.time === 'number', 'time should be number');
				assert(typeof point.premium === 'number', 'premium should be number');
				assert(typeof point.premium_rate === 'number', 'premium_rate should be number');
			}
		});
	}

	// ============ Boundary Value Tests ============
	console.log('\n--- Testing Boundary Values ---');

	// Test timestamp boundaries
	runTest('Timestamp boundary values', () => {
		const priceData = getPrice({
			symbol: 'BTC',
			time_start: 0,
			time_end: nowSeconds,
			interval: '1d'
		});
		assert(Array.isArray(priceData), 'Should handle timestamp 0');
	});

	// Test minimum and maximum reasonable limits
	runTest('Limit parameter boundaries', () => {
		const testData = getFuturePrice({
			exchange: 'Binance',
			symbol: 'BTCUSDT',
			interval: '1h',
			limit: 4500 // Maximum mentioned in docs
		});
		assert(Array.isArray(testData), 'Should handle maximum limit');
	});

	// ============ Special Value Tests ============
	console.log('\n--- Testing Special Values ---');

	// Test with very recent timestamps
	runTest('Very recent timestamps', () => {
		const recentData = getPrice({
			symbol: 'BTC',
			time_start: nowSeconds - 3600, // 1 hour ago
			time_end: nowSeconds,
			interval: '5m'
		});
		assert(Array.isArray(recentData), 'Should handle very recent timestamps');
	});

	// Test with single character symbol (if supported)
	runTest('Minimum symbol length', () => {
		try {
			const singleCharData = getPrice({
				symbol: 'X',
				time_start: oneDayAgo,
				time_end: nowSeconds,
				interval: '1h'
			});
			assert(Array.isArray(singleCharData), 'Should handle single character symbol');
		} catch (e) {
			// Expected to fail, which is fine
			console.log(`⚠️ Single character symbol test failed as expected: ${e.message}`);
		}
	});

	// Print test summary
	console.log('\n=== Crypto Market Functions Test Summary ===');
	console.log(`Total tests: ${totalTests}`);
	console.log(`Passed: ${passedTests}`);
	console.log(`Failed: ${totalTests - passedTests}`);
	console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

	if (passedTests === totalTests) {
		console.log('🎉 All crypto market function tests passed!');
	} else {
		console.log('⚠️  Some crypto market function tests failed. Please review the output above.');
	}
}

main();
