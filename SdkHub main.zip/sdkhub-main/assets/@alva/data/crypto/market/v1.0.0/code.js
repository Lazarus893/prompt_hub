// the 'prd' in module is a temporary workaround since those functions lack data in stg.
const { sdkRelay } = require('sdkrelay');
const { useCredit } = require('internal');
const { load } = require('@alva/secret');
const { syncFetch: fetch } = require('net/http');
const coinGlassSDK = require('@alva/external/coinglass:v1.0.0');

const cryptoQuantSDK = require('@alva/external/cryptoquant:v1.0.0');

// Refs derived from tool.json for tracking source metadata
const getPriceRef = {
    id: '@alva/data/crypto/market/getPrice',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getPrice',
    sdk_display_name: 'Token Market Price',
    source_name: 'Binance',
    source: 'https://developers.binance.com/docs/binance-spot-api-docs/web-socket-streams#klinecandlestick-streams-for-utc',
};

const getOpenInterestRef = {
    id: '@alva/data/crypto/market/getOpenInterest',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getOpenInterest',
    sdk_display_name: 'Token Open Interest',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/oi-ohlc-histroy',
};

const getLiquidationHistoryRef = {
    id: '@alva/data/crypto/market/getLiquidationHistory',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getLiquidationHistory',
    sdk_display_name: 'Token Liquidation History',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/aggregated-liquidation-history',
};

const getFundingRateRef = {
    id: '@alva/data/crypto/market/getFundingRate',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getFundingRate',
    sdk_display_name: 'Token Funding Rate',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/fr-ohlc-histroy',
};

const getTakerBuySellVolumeFutureRef = {
    id: '@alva/data/crypto/market/getTakerBuySellVolumeFuture',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getTakerBuySellVolumeFuture',
    sdk_display_name: 'Token Futures Analyzer',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/aggregated-taker-buysell-volume-history',
};

const getFuturePriceRef = {
    id: '@alva/data/crypto/market/getFuturePrice',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getFuturePrice',
    sdk_display_name: 'Token Futures Price',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/price-ohlc-history',
};

const getMarginLongShortRef = {
    id: '@alva/data/crypto/market/getMarginLongShort',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getMarginLongShort',
    sdk_display_name: 'Bitfinex Margin Long/Short Positions',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/bitfinex-margin-long-short',
};

const getBorrowInterestRateHistoryRef = {
    id: '@alva/data/crypto/market/getBorrowInterestRateHistory',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getBorrowInterestRateHistory',
    sdk_display_name: 'Token Borrow Interest Rate',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/borrow-interest-rate',
};

const getBullMarketPeakIndicatorsRef = {
    id: '@alva/data/crypto/market/getBullMarketPeakIndicators',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getBullMarketPeakIndicators',
    sdk_display_name: 'Bull Market Peak Indicators',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/bull-market-peak-indicator',
};

const getFuturesBasisHistoryRef = {
    id: '@alva/data/crypto/market/getFuturesBasisHistory',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getFuturesBasisHistory',
    sdk_display_name: 'Token Futures Basis',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/basis',
};

const getWhaleIndexHistoryRef = {
    id: '@alva/data/crypto/market/getWhaleIndexHistory',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getWhaleIndexHistory',
    sdk_display_name: 'Crypto Whale Index',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/whale-index',
};

const getAltcoinSeasonIndexRef = {
    id: '@alva/data/crypto/market/getAltcoinSeasonIndex',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getAltcoinSeasonIndex',
    sdk_display_name: 'Altcoin Season index',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/altcoin-season-index',
};

const getBitcoinReserveRiskRef = {
    id: '@alva/data/crypto/market/getBitcoinReserveRisk',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getBitcoinReserveRisk',
    sdk_display_name: 'BTC Reserve Risk Index',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/bitcoin-reserve-risk',
};

const getBitcoinDominanceRef = {
    id: '@alva/data/crypto/market/getBitcoinDominance',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getBitcoinDominance',
    sdk_display_name: 'BTC Dominance Index',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/bitcoin-dominance',
};

const getBitcoinRainbowChartRef = {
    id: '@alva/data/crypto/market/getBitcoinRainbowChart',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getBitcoinRainbowChart',
    sdk_display_name: 'BTC Rainbow Chart',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/bitcoin-rainbow-chart',
};

const getCryptoFearAndGreedIndexRef = {
    id: '@alva/data/crypto/market/getCryptoFearAndGreedIndex',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getCryptoFearAndGreedIndex',
    sdk_display_name: 'Crypto Fear and Greed Index',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/cryptofear-greedindex',
};

const getBitcoinBubbleIndexRef = {
    id: '@alva/data/crypto/market/getBitcoinBubbleIndex',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getBitcoinBubbleIndex',
    sdk_display_name: 'BTC Bubble Index',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/bitcoin-bubble-index',
};

const getBitcoinCorrelationsRef = {
    id: '@alva/data/crypto/market/getBitcoinCorrelations',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getBitcoinCorrelations',
    sdk_display_name: 'BTC Correlations Index',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/btc-correlations-gld-iwm-qqq-spy-tlt',
};

const getMarketIndicatorSoprRef = {
    id: '@alva/data/crypto/market/getMarketIndicatorSopr',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getMarketIndicatorSopr',
    sdk_display_name: 'Bitcoin Profit/Loss Ratio',
    source_name: 'CryptoQuant',
    source: 'https://cryptoquant.com/docs#tag/BTC-Market-Indicator/operation/getSOPR',
};

const getCoinbasePremiumIndexRef = {
    id: '@alva/data/crypto/market/getCoinbasePremiumIndex',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getCoinbasePremiumIndex',
    sdk_display_name: 'Coinbase Premium Index',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/coinbase-premium-index',
};

const getPredictionMarketDataRef = {
    id: '@alva/data/crypto/market/getPredictionMarketData',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getPredictionMarketData',
    sdk_display_name: 'Polymarket Data',
    source_name: 'Polymarket',
    source: 'https://docs.polymarket.com/developers/gamma-markets-api/overview',
};

const getTokenHistoricalQuotesRef = {
    id: '@alva/data/crypto/market/getTokenHistoricalQuotes',
    module_name: '@alva/data/crypto/market ',
    module_display_name: 'Crypto Market Analytics',
    sdk_name: 'getTokenHistoricalQuotes',
    sdk_display_name: 'Historical Token Quotes',
    source_name: 'CoinMarketCap',
    source: 'https://coinmarketcap.com/api/documentation/v1/#operation/getV3CryptocurrencyQuotesHistorical',
};

// Utility to create a reference object with a dynamic title
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title,
    };

    // 3. 返回新对象
    return newObject;
}

function getPrice(params) {
    useCredit('getPrice', 3500);

    const rawData = sdkRelay('GetPrice', params);

    const transformedData = rawData.map(item => {
        return {
            date: toMs(item.time_open),
            open: item.price_open,
            high: item.price_high,
            low: item.price_low,
            close: item.price_close,
            volume: item.volume_traded,
            trades_count: item.trades_count,
        };
    });

    return transformedData;
}

function getOpenInterest(params) {
    useCredit('getOpenInterest', 3500);
    return coinGlassSDK.getCGOpenInterest(params);
}

function getFundingRate(params) {
    useCredit('getFundingRate', 3500);
    return coinGlassSDK.getCGFundingRate(params);
}

function getLiquidationHistory(params) {
    useCredit('getLiquidationHistory', 3500);
    return sdkRelay('GetLiquidationHistory', params);
}

function getTakerBuySellVolumeFuture(params) {
    useCredit('getTakerBuySellVolumeFuture', 3500);
    return sdkRelay('GetTakerBuySellVolumeFuture', params);
}

function getFuturePrice(params) {
    useCredit('getFuturePrice', 350);
    const items = coinGlassSDK.getFuturePrice(params);
    return items.map((item) => {
        return {
            date: toMs(item.time),
            open: parseNumber(item.open),
            high: parseNumber(item.high),
            low: parseNumber(item.low),
            close: parseNumber(item.close),
            volume: parseNumber(item.volume_usd),
        };
    });
}

function getMarginLongShort(params) {
    useCredit('getMarginLongShort', 350);
    return coinGlassSDK.getMarginLongShort(params);
}

function getBorrowInterestRateHistory(params) {
    useCredit('getBorrowInterestRateHistory', 350);
    return coinGlassSDK.getBorrowInterestRateHistory(params);
}

function getBullMarketPeakIndicators(params) {
    useCredit('getBullMarketPeakIndicators', 350);
    return coinGlassSDK.getBullMarketPeakIndicators(params);
}

function getFuturesBasisHistory(params) {
    useCredit('getFuturesBasisHistory', 350);
    return coinGlassSDK.getFuturesBasisHistory(params);
}

function getWhaleIndexHistory(params) {
    useCredit('getWhaleIndexHistory', 350);
    return coinGlassSDK.getWhaleIndexHistory(params);
}

function getAltcoinSeasonIndex(params) {
    useCredit('getAltcoinSeasonIndex', 350);
    return coinGlassSDK.getAltcoinSeasonIndex(params);
}

function getBitcoinReserveRisk(params) {
    useCredit('getBitcoinReserveRisk', 350);
    return coinGlassSDK.getBitcoinReserveRisk(params);
}

function getBitcoinDominance(params) {
    useCredit('getBitcoinDominance', 350);
    return coinGlassSDK.getBitcoinDominance(params);
}

function getBitcoinRainbowChart(params) {
    useCredit('getBitcoinRainbowChart', 350);
    return coinGlassSDK.getBitcoinRainbowChart(params);
}

function getCryptoFearAndGreedIndex(params) {
    useCredit('getCryptoFearAndGreedIndex', 350);
    return coinGlassSDK.getCryptoFearAndGreedIndex(params);
}

function getBitcoinBubbleIndex(params) {
    useCredit('getBitcoinBubbleIndex', 350);
    return coinGlassSDK.getBitcoinBubbleIndex(params);
}

function getBitcoinCorrelations(params) {
    useCredit('getBitcoinCorrelations', 350);
    return coinGlassSDK.getBitcoinCorrelations(params);
}

function getMarketIndicatorSopr(params) {
    useCredit('getMarketIndicatorSopr', 350);
    return cryptoQuantSDK.getCQMarketIndicatorSopr(params);
}

function getCoinbasePremiumIndex(params) {
    useCredit('getCoinbasePremiumIndex', 350);
    return coinGlassSDK.getCoinbasePremiumIndex(params);
}

function getTokenHistoricalQuotes(params) {
    useCredit('getTokenHistoricalQuotes', 350);
    return sdkRelay('GetTokenHistoricalQuotes', params);
}

function parsePredictionNumber(value) {
    if (value == null) {
        throw new Error(`Expected number but got null/undefined: ${value}`);
    }
    const n = Number(value);
    if (Number.isNaN(n)) {
        throw new Error(`Cannot convert to number: ${value}`);
    }
    return n;
}

function getPredictionMarketData(params) {
    useCredit('getPredictionMarketData', 350);

    const baseUrl = 'https://gamma-api.polymarket.com';
    const { syncFetch: fetch } = require('net/http');

    const url = baseUrl + '/public-search';
    const keyValuePairs = Object.keys(params).map((key) => {
        const value = params[key];
        return encodeURIComponent(key) + '=' + encodeURIComponent(value);
    });
    const queryString = keyValuePairs.join('&');
    const fullUrl = queryString ? `${url}?${queryString}` : url;
    const fetchOptions = {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        },
    };
    const r = fetch(fullUrl, fetchOptions);
    const rawData = r.json();

    // Process the events directly without defensive checks
    return rawData.events.map(event => {
        const formattedMarkets = event.markets.map(market => {
            const outcomePricesObject = {};
            const outcomeLabels = JSON.parse(market.outcomes);
            const outcomePriceValues = JSON.parse(market.outcomePrices);
            outcomeLabels.forEach((label, index) => {
                outcomePricesObject[label] = outcomePriceValues[index];
            });
            return {
                market_question: market.question,
                outcome_prices: outcomePricesObject,
                market_volume: parsePredictionNumber(market.volumeNum)
            };
        });
        return {
            event_title: event.title,
            category: event.category,
            volume: parsePredictionNumber(event.volume),
            liquidity: event.liquidity,
            end_date: event.endDate,
            event_url: `https://polymarket.com/event/${event.slug}`,
            markets: formattedMarkets
        };
    });
}

function toMs(value) {
    if (value == null) {
        return null;
    }
    if (typeof value === 'number') {
        return value > 1e12 ? value : value * 1000;
    }
    if (typeof value === 'string') {
        const parsed = Date.parse(value);
        if (!Number.isNaN(parsed)) {
            return parsed;
        }
    }
    return null;
}

function ensureUniqueDates(records) {
    const used = new Set();
    return records.map((item) => {
        const { date: originalDate, ...rest } = item;

        let date = originalDate; // 使用原始日期开始检查
        while (used.has(date)) {
            date += 1;
        }
        used.add(date);

        return {
            date: date,
            ...rest,
        };
    });
}

function parseNumber(value) {
    if (value == null) {
        return null;
    }
    const n = Number(value);
    return Number.isNaN(n) ? null : n;
}

function deriveRangeDate(params) {
    const end = toMs(params?.time_end || params?.end_time || params?.endTime);
    if (end != null) {
        return end;
    }
    const start = toMs(params?.time_start || params?.start_time || params?.startTime);
    if (start != null) {
        return start;
    }
    return Date.now();
}

function extractCqSeries(response) {
    const data = response?.result?.data;
    return Array.isArray(data) ? data : [];
}

function resolveTimestamp(item, fallback) {
    if (!item || typeof item !== 'object') {
        return fallback ?? null;
    }
    const candidates = [
        'timestamp',
        'time',
        'time_ms',
        'timeMs',
        'time_unix',
        'timeUnix',
        'time_unix_ms',
        'date',
        'date_ms',
        'dateString',
        'date_string',
        'updated_at',
        'update_at',
        'updatedAt',
        'updateTime',
        'update_time',
        'created_at',
        'create_time',
        'createTime',
    ];
    for (const key of candidates) {
        if (item[key] == null) {
            continue;
        }
        const ts = toMs(item[key]);
        if (ts != null) {
            return ts;
        }
    }
    return fallback ?? null;
}

// ---------------- Internal dynamic descriptions (do not export) ----------------

const getPriceBaseDesc = 'Get historical OHLCV prices';
function buildGetPriceCallDescription(actualParams = {}) {
    const parts = [getPriceBaseDesc];
    if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
    const filters = [];
    const interval = actualParams.interval;
    if (interval && interval !== '1d') filters.push(`Interval: ${interval}`);
    const start = actualParams.time_start ?? actualParams.start_time;
    const end = actualParams.time_end ?? actualParams.end_time;
    if (start && end) filters.push(`Time: ${start} to ${end}`);
    else if (start) filters.push(`Time from: ${start}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

const getOpenInterestBaseDesc = 'Get futures open interest';
function buildGetOpenInterestCallDescription(actualParams = {}) {
    const parts = [getOpenInterestBaseDesc];
    if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
    if (actualParams.exchange) parts.push(`from ${actualParams.exchange}`);
    const filters = [];
    if (actualParams.interval && actualParams.interval !== '1d') filters.push(`Interval: ${actualParams.interval}`);
    const start = actualParams.start_time ?? actualParams.time_start;
    const end = actualParams.end_time ?? actualParams.time_end;
    if (start && end) filters.push(`Time: ${start} to ${end}`); else if (start) filters.push(`Time from: ${start}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

const getFundingRateBaseDesc = 'Get futures funding rates';
function buildGetFundingRateCallDescription(actualParams = {}) {
    const parts = [getFundingRateBaseDesc];
    if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
    if (actualParams.exchange) parts.push(`from ${actualParams.exchange}`);
    const filters = [];
    if (actualParams.interval && actualParams.interval !== '1d') filters.push(`Interval: ${actualParams.interval}`);
    const start = actualParams.start_time ?? actualParams.time_start;
    const end = actualParams.end_time ?? actualParams.time_end;
    if (start && end) filters.push(`Time: ${start} to ${end}`); else if (start) filters.push(`Time from: ${start}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

const getLiquidationHistoryBaseDesc = 'Get liquidation history';
function buildGetLiquidationHistoryCallDescription(actualParams = {}) {
    const parts = [getLiquidationHistoryBaseDesc];
    if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
    if (actualParams.exchange) parts.push(`from ${actualParams.exchange}`);
    const filters = [];
    if (actualParams.interval && actualParams.interval !== '1d') filters.push(`Interval: ${actualParams.interval}`);
    const start = actualParams.time_start ?? actualParams.start_time;
    const end = actualParams.time_end ?? actualParams.end_time;
    if (start && end) filters.push(`Time: ${start} to ${end}`); else if (start) filters.push(`Time from: ${start}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

const getTakerBuySellVolumeFutureBaseDesc = 'Get futures taker buy/sell volume';
function buildGetTakerBuySellVolumeFutureCallDescription(actualParams = {}) {
    const parts = [getTakerBuySellVolumeFutureBaseDesc];
    if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
    if (actualParams.exchange) parts.push(`from ${actualParams.exchange}`);
    const filters = [];
    if (actualParams.interval && actualParams.interval !== '1d') filters.push(`Interval: ${actualParams.interval}`);
    const start = actualParams.time_start ?? actualParams.start_time;
    const end = actualParams.time_end ?? actualParams.end_time;
    if (start && end) filters.push(`Time: ${start} to ${end}`); else if (start) filters.push(`Time from: ${start}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

const getFuturePriceBaseDesc = 'Get futures OHLCV prices';
function buildGetFuturePriceCallDescription(actualParams = {}) {
    const parts = [getFuturePriceBaseDesc];
    if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
    if (actualParams.exchange) parts.push(`from ${actualParams.exchange}`);
    const filters = [];
    if (actualParams.interval && actualParams.interval !== '1d') filters.push(`Interval: ${actualParams.interval}`);
    if (actualParams.limit && actualParams.limit !== 10) filters.push(`Limit: ${actualParams.limit}`);
    const start = actualParams.start_time ?? actualParams.time_start;
    const end = actualParams.end_time ?? actualParams.time_end;
    if (start && end) filters.push(`Time: ${start} to ${end}`); else if (start) filters.push(`Time from: ${start}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

const getMarginLongShortBaseDesc = 'Get margin long/short positions';
function buildGetMarginLongShortCallDescription(actualParams = {}) {
    const parts = [getMarginLongShortBaseDesc];
    if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
    if (actualParams.exchange) parts.push(`from ${actualParams.exchange}`);
    const filters = [];
    if (actualParams.interval && actualParams.interval !== '1d') filters.push(`Interval: ${actualParams.interval}`);
    if (actualParams.limit && actualParams.limit !== 1000) filters.push(`Limit: ${actualParams.limit}`);
    const start = actualParams.start_time ?? actualParams.time_start;
    const end = actualParams.end_time ?? actualParams.time_end;
    if (start && end) filters.push(`Time: ${start} to ${end}`); else if (start) filters.push(`Time from: ${start}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

const getBorrowInterestRateHistoryBaseDesc = 'Get borrow interest rate history';
function buildGetBorrowInterestRateHistoryCallDescription(actualParams = {}) {
    const parts = [getBorrowInterestRateHistoryBaseDesc];
    if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
    if (actualParams.exchange) parts.push(`from ${actualParams.exchange}`);
    const filters = [];
    if (actualParams.interval && actualParams.interval !== '1d') filters.push(`Interval: ${actualParams.interval}`);
    if (actualParams.limit && actualParams.limit !== 500) filters.push(`Limit: ${actualParams.limit}`);
    const start = actualParams.start_time ?? actualParams.time_start;
    const end = actualParams.end_time ?? actualParams.time_end;
    if (start && end) filters.push(`Time: ${start} to ${end}`); else if (start) filters.push(`Time from: ${start}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

const getBullMarketPeakIndicatorsBaseDesc = 'Get bull market peak indicators';
function buildGetBullMarketPeakIndicatorsCallDescription(actualParams = {}) {
    const parts = [getBullMarketPeakIndicatorsBaseDesc];
    return parts.join(' ').trim();
}

const getFuturesBasisHistoryBaseDesc = 'Get futures basis history';
function buildGetFuturesBasisHistoryCallDescription(actualParams = {}) {
    const parts = [getFuturesBasisHistoryBaseDesc];
    if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
    if (actualParams.exchange) parts.push(`from ${actualParams.exchange}`);
    const filters = [];
    if (actualParams.interval && actualParams.interval !== '1d') filters.push(`Interval: ${actualParams.interval}`);
    if (actualParams.limit && actualParams.limit !== 10) filters.push(`Limit: ${actualParams.limit}`);
    const start = actualParams.start_time ?? actualParams.time_start;
    const end = actualParams.end_time ?? actualParams.time_end;
    if (start && end) filters.push(`Time: ${start} to ${end}`); else if (start) filters.push(`Time from: ${start}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

const getWhaleIndexHistoryBaseDesc = 'Get Whale Index history';
function buildGetWhaleIndexHistoryCallDescription(actualParams = {}) {
    const parts = [getWhaleIndexHistoryBaseDesc];
    if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
    if (actualParams.exchange) parts.push(`from ${actualParams.exchange}`);
    const filters = [];
    if (actualParams.interval && actualParams.interval !== '1d') filters.push(`Interval: ${actualParams.interval}`);
    if (actualParams.limit && actualParams.limit !== 1000) filters.push(`Limit: ${actualParams.limit}`);
    const start = actualParams.start_time ?? actualParams.time_start;
    const end = actualParams.end_time ?? actualParams.time_end;
    if (start && end) filters.push(`Time: ${start} to ${end}`); else if (start) filters.push(`Time from: ${start}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

const getAltcoinSeasonIndexBaseDesc = 'Get Altcoin Season Index';
function buildGetAltcoinSeasonIndexCallDescription(actualParams = {}) {
    const parts = [getAltcoinSeasonIndexBaseDesc];
    return parts.join(' ').trim();
}

const getBitcoinReserveRiskBaseDesc = 'Get Bitcoin Reserve Risk';
function buildGetBitcoinReserveRiskCallDescription(actualParams = {}) {
    const parts = [getBitcoinReserveRiskBaseDesc];
    return parts.join(' ').trim();
}

const getBitcoinDominanceBaseDesc = 'Get Bitcoin Dominance';
function buildGetBitcoinDominanceCallDescription(actualParams = {}) {
    const parts = [getBitcoinDominanceBaseDesc];
    return parts.join(' ').trim();
}

const getBitcoinRainbowChartBaseDesc = 'Get Bitcoin Rainbow Chart bands';
function buildGetBitcoinRainbowChartCallDescription(actualParams = {}) {
    const parts = [getBitcoinRainbowChartBaseDesc];
    return parts.join(' ').trim();
}

const getCryptoFearAndGreedIndexBaseDesc = 'Get Crypto Fear & Greed Index';
function buildGetCryptoFearAndGreedIndexCallDescription(actualParams = {}) {
    const parts = [getCryptoFearAndGreedIndexBaseDesc];
    return parts.join(' ').trim();
}

const getBitcoinBubbleIndexBaseDesc = 'Get Bitcoin Bubble Index';
function buildGetBitcoinBubbleIndexCallDescription(actualParams = {}) {
    const parts = [getBitcoinBubbleIndexBaseDesc];
    return parts.join(' ').trim();
}

const getBitcoinCorrelationsBaseDesc = 'Get Bitcoin correlations with tradfi ETFs';
function buildGetBitcoinCorrelationsCallDescription(actualParams = {}) {
    const parts = [getBitcoinCorrelationsBaseDesc];
    return parts.join(' ').trim();
}

const getMarketIndicatorSoprBaseDesc = 'Get SOPR metrics';
function buildGetMarketIndicatorSoprCallDescription(actualParams = {}) {
    const parts = [getMarketIndicatorSoprBaseDesc];
    if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
    const filters = [];
    if (actualParams.window && actualParams.window !== 'day') filters.push(`Window: ${actualParams.window}`);
    const start = actualParams.from;
    const end = actualParams.to;
    if (start && end) filters.push(`Time: ${start} to ${end}`); else if (start) filters.push(`Time from: ${start}`);
    if (actualParams.limit && actualParams.limit !== 100) filters.push(`Limit: ${actualParams.limit}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

const getTokenHistoricalQuotesBaseDesc = 'Get historical token quotes';
function buildGetTokenHistoricalQuotesCallDescription(actualParams = {}) {
    const parts = [getTokenHistoricalQuotesBaseDesc];
    if (actualParams.symbol) parts.push(`for ${actualParams.symbol}`);
    const filters = [];
    if (actualParams.interval) filters.push(`Interval: ${actualParams.interval}`);
    if (actualParams.convert && actualParams.convert !== 'USD') filters.push(`Convert: ${actualParams.convert}`);
    const start = actualParams.time_start;
    const end = actualParams.time_end;
    if (start && end) filters.push(`Time: ${start} to ${end}`); else if (start) filters.push(`Time from: ${start}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

const getPredictionMarketDataBaseDesc = 'Search Polymarket markets';
function buildGetPredictionMarketDataCallDescription(actualParams = {}) {
    const parts = [getPredictionMarketDataBaseDesc];
    if (actualParams.q) parts.push(`for "${actualParams.q}"`);
    return parts.join(' ').trim();
}

const getCoinbasePremiumIndexBaseDesc = 'Get Coinbase Premium Index';
function buildGetCoinbasePremiumIndexCallDescription(actualParams = {}) {
    const parts = [getCoinbasePremiumIndexBaseDesc];
    const filters = [];
    if (actualParams.interval && actualParams.interval !== '1d') filters.push(`Interval: ${actualParams.interval}`);
    if (actualParams.limit && actualParams.limit !== 1000) filters.push(`Limit: ${actualParams.limit}`);
    const start = actualParams.start_time ?? actualParams.time_start;
    const end = actualParams.end_time ?? actualParams.time_end;
    if (start && end) filters.push(`Time: ${start} to ${end}`); else if (start) filters.push(`Time from: ${start}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

// ----------------------------------------------------------------------------

function buildTimeSeriesNode(fetchFn, params, config) {
    const { outputName, description, fields, mapRecords, ensureUnique = true, ref } = config;

    return {
        inputs: {
            raw: () => fetchFn(params),
        },
        outputs: {
            [outputName]: {
                name: outputName,
                description,
                fields,
                ...(ref ? { ref } : {}),
            },
        },
        run: (inputs) => {
            const mapped = mapRecords(inputs.raw, params) || [];
            const filtered = mapped
                .map((item) => {
                    if (!item || item.date == null || Number.isNaN(item.date)) {
                        return null;
                    }
                    return item;
                })
                .filter(Boolean);

            const result = ensureUnique ? ensureUniqueDates(filtered) : filtered;
            return { [outputName]: result };
        },
    };
}

const RAINBOW_BANDS = [
    {
        key: 'band_fire_sale',
        description: 'Rainbow band price: Basically a Fire Sale',
    },
    { key: 'band_buy_zone', description: 'Rainbow band price: BUY!' },
    {
        key: 'band_accumulate',
        description: 'Rainbow band price: Accumulate',
    },
    {
        key: 'band_still_cheap',
        description: 'Rainbow band price: Still cheap',
    },
    { key: 'band_hold', description: 'Rainbow band price: HOLD' },
    {
        key: 'band_is_this_a_bubble',
        description: 'Rainbow band price: Is this a bubble?',
    },
    {
        key: 'band_fomo_intensifies',
        description: 'Rainbow band price: FOMO intensifies',
    },
    {
        key: 'band_sell',
        description: 'Rainbow band price: Sell. Seriously, SELL!',
    },
    {
        key: 'band_maximum_bubble',
        description: 'Rainbow band price: Maximum Bubble Territory',
    },
    { key: 'band_top', description: 'Rainbow band price: Top band' },
];

function makePriceNode(params) {
    return {
        inputs: {
            price_raw: () => getPrice(params),
        },
        outputs: {
            ohlcv: {
                name: 'ohlcv',
                description: 'Historic OHLCV price data',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'interval start time ms since epoch',
                    },
                    { name: 'open', type: 'number' },
                    { name: 'high', type: 'number' },
                    { name: 'low', type: 'number' },
                    {
                        name: 'close',
                        type: 'number',
                    },
                    {
                        name: 'volume',
                        type: 'number',
                    },
                    {
                        name: 'trades_count',
                        type: 'number',
                    },
                ],
                ref: createReferenceWithTitle(getPriceRef, params, buildGetPriceCallDescription),
            },
        },
        run: (inputs) => {
            const series = inputs.price_raw;
            return { ohlcv: ensureUniqueDates(series) };
        },
    };
}

function makeOpenInterestNode(params) {
    return {
        inputs: {
            open_interest_raw: () => getOpenInterest(params),
        },
        outputs: {
            open_interest: {
                name: 'open_interest',
                description: 'Open interest time series',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'timestamp ms',
                    },
                    {
                        name: 'open',
                        type: 'number',
                        description: 'opening price',
                    },
                    {
                        name: 'close',
                        type: 'number',
                        description: 'closing price',
                    },
                    {
                        name: 'low',
                        type: 'number',
                        description: 'lowest price',
                    },
                    {
                        name: 'high',
                        type: 'number',
                        description: 'highest price',
                    },
                ],
                ref: createReferenceWithTitle(getOpenInterestRef, params, buildGetOpenInterestCallDescription),
            },
        },
        run: (inputs) => {
            const series = Array.isArray(inputs.open_interest_raw)
                ? inputs.open_interest_raw
                        .map((item) => {
                            const date = toMs(item.time);
                            if (date == null) {
                                return null;
                            }
                            return {
                                date,
                                open: parseNumber(item.open),
                                close: parseNumber(item.close),
                                low: parseNumber(item.low),
                                high: parseNumber(item.high),
                            };
                        })
                        .filter(Boolean)
                : [];
            return { open_interest: ensureUniqueDates(series) };
        },
    };
}

function makeFundingRateNode(params) {
    return {
        inputs: {
            funding_rate_raw: () => getFundingRate(params),
        },
        outputs: {
            funding_rate: {
                name: 'funding_rate',
                description: 'Futures funding rate time series',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'timestamp ms',
                    },
                    {
                        name: 'open',
                        type: 'number',
                        description: 'opening price',
                    },
                    {
                        name: 'close',
                        type: 'number',
                        description: 'closing price',
                    },
                    {
                        name: 'low',
                        type: 'number',
                        description: 'lowest price',
                    },
                    {
                        name: 'high',
                        type: 'number',
                        description: 'highest price',
                    },
                ],
                ref: createReferenceWithTitle(getFundingRateRef, params, buildGetFundingRateCallDescription),
            },
        },
        run: (inputs) => {
            const series = Array.isArray(inputs.funding_rate_raw)
                ? inputs.funding_rate_raw
                        .map((item) => {
                            const date = toMs(item.time);
                            if (date == null) {
                                return null;
                            }
                            return {
                                date,
                                open: parseNumber(item.open),
                                close: parseNumber(item.close),
                                low: parseNumber(item.low),
                                high: parseNumber(item.high),
                            };
                        })
                        .filter(Boolean)
                : [];
            return { funding_rate: ensureUniqueDates(series) };
        },
    };
}

function makeLiquidationHistoryNode(params) {
    return {
        inputs: {
            liquidation_raw: () => getLiquidationHistory(params),
        },
        outputs: {
            liquidations: {
                name: 'liquidations',
                description: 'Aggregated liquidation statistics',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'snapshot time ms',
                    },
                    {
                        name: 'long_liquidation_usdt',
                        type: 'number',
                        description: 'long liquidation volume in USDT',
                    },
                    {
                        name: 'short_liquidation_usdt',
                        type: 'number',
                        description: 'short liquidation volume in USDT',
                    },
                ],
                ref: createReferenceWithTitle(getLiquidationHistoryRef, params, buildGetLiquidationHistoryCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.liquidation_raw || {};
            const date = deriveRangeDate(params);
            return {
                liquidations: [
                    {
                        date,
                        long_liquidation_usdt: parseNumber(raw.long_liquidation_usdt),
                        short_liquidation_usdt: parseNumber(raw.short_liquidation_usdt),
                    },
                ],
            };
        },
    };
}

function makeTakerBuySellVolumeFutureNode(params) {
    return {
        inputs: {
            taker_volume_raw: () => getTakerBuySellVolumeFuture(params),
        },
        outputs: {
            taker_volume: {
                name: 'taker_volume',
                description: 'Taker buy/sell volume snapshot',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'snapshot time ms',
                    },
                    {
                        name: 'buy_volume_usd',
                        type: 'number',
                        description: 'taker buy volume USD',
                    },
                    {
                        name: 'sell_volume_usd',
                        type: 'number',
                        description: 'taker sell volume USD',
                    },
                ],
                ref: createReferenceWithTitle(getTakerBuySellVolumeFutureRef, params, buildGetTakerBuySellVolumeFutureCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.taker_volume_raw || {};
            return {
                taker_volume: [
                    {
                        date: deriveRangeDate(params),
                        buy_volume_usd: parseNumber(raw.buy_volume_usd),
                        sell_volume_usd: parseNumber(raw.sell_volume_usd),
                    },
                ],
            };
        },
    };
}

function makeFuturePriceNode(params) {
    return {
        inputs: {
            future_price_raw: () => getFuturePrice(params),
        },
        outputs: {
            future_ohlcv: {
                name: 'future_ohlcv',
                description: 'Futures OHLCV price data',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'interval start time ms',
                    },
                    { name: 'open', type: 'number', description: 'open price' },
                    { name: 'high', type: 'number', description: 'high price' },
                    { name: 'low', type: 'number', description: 'low price' },
                    {
                        name: 'close',
                        type: 'number',
                        description: 'close price',
                    },
                    {
                        name: 'volume',
                        type: 'number',
                        description: 'trading volume',
                    },
                ],
                ref: createReferenceWithTitle(getFuturePriceRef, params, buildGetFuturePriceCallDescription),
            },
        },
        run: (inputs) => {
            const series = Array.isArray(inputs.future_price_raw) ? inputs.future_price_raw : [];
            return { future_ohlcv: ensureUniqueDates(series) };
        },
    };
}

function makeAltcoinSeasonIndexNode(params) {
    return buildTimeSeriesNode(getAltcoinSeasonIndex, params, {
        outputName: 'altcoin_season_index',
        description: 'Altcoin Season Index history',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            {
                name: 'altcoin_index',
                type: 'number',
                description: 'Altcoin season index (0-100)',
            },
            {
                name: 'altcoin_marketcap',
                type: 'number',
                description: 'Altcoin market capitalization USD',
            },
        ],
        ref: createReferenceWithTitle(getAltcoinSeasonIndexRef, params, buildGetAltcoinSeasonIndexCallDescription),
        mapRecords: (raw) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = toMs(item.timestamp);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    altcoin_index: parseNumber(item.altcoin_index ?? item.index),
                    altcoin_marketcap: parseNumber(item.altcoin_marketcap ?? item.marketcap),
                };
            });
        },
    });
}

function makeBitcoinDominanceNode(params) {
    return buildTimeSeriesNode(getBitcoinDominance, params, {
        outputName: 'bitcoin_dominance',
        description: 'Bitcoin dominance and market capitalization history',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            { name: 'price', type: 'number', description: 'BTC price USD' },
            {
                name: 'bitcoin_dominance',
                type: 'number',
                description: 'Bitcoin dominance percentage',
            },
            {
                name: 'market_cap',
                type: 'number',
                description: 'BTC market cap USD',
            },
        ],
        ref: createReferenceWithTitle(getBitcoinDominanceRef, params, buildGetBitcoinDominanceCallDescription),
        mapRecords: (raw) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = toMs(item.timestamp);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    price: parseNumber(item.price),
                    bitcoin_dominance: parseNumber(item.bitcoin_dominance),
                    market_cap: parseNumber(item.market_cap),
                };
            });
        },
    });
}

function makeBitcoinReserveRiskNode(params) {
    return buildTimeSeriesNode(getBitcoinReserveRisk, params, {
        outputName: 'bitcoin_reserve_risk',
        description: 'Bitcoin reserve risk components',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            { name: 'price', type: 'number', description: 'BTC price USD' },
            {
                name: 'reserve_risk_index',
                type: 'number',
                description: 'Reserve risk index value',
            },
            { name: 'movcd', type: 'number', description: 'MOVCD component' },
            {
                name: 'hodl_bank',
                type: 'number',
                description: 'HODL Bank component',
            },
            { name: 'vocd', type: 'number', description: 'VOCD component' },
        ],
        ref: createReferenceWithTitle(getBitcoinReserveRiskRef, params, buildGetBitcoinReserveRiskCallDescription),
        mapRecords: (raw) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = toMs(item.timestamp);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    price: parseNumber(item.price),
                    reserve_risk_index: parseNumber(item.reserve_risk_index),
                    movcd: parseNumber(item.movcd),
                    hodl_bank: parseNumber(item.hodl_bank),
                    vocd: parseNumber(item.vocd),
                };
            });
        },
    });
}

function makeBitcoinBubbleIndexNode(params) {
    return buildTimeSeriesNode(getBitcoinBubbleIndex, params, {
        outputName: 'bitcoin_bubble_index',
        description: 'Bitcoin bubble index components',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            { name: 'price', type: 'number', description: 'BTC price USD' },
            {
                name: 'bubble_index',
                type: 'number',
                description: 'Bubble index value',
            },
            {
                name: 'google_trend_percent',
                type: 'number',
                description: 'Google trend contribution %',
            },
            {
                name: 'mining_difficulty',
                type: 'number',
                description: 'Mining difficulty',
            },
            {
                name: 'transaction_count',
                type: 'number',
                description: 'On-chain transaction count',
            },
            {
                name: 'address_send_count',
                type: 'number',
                description: 'Unique sending addresses',
            },
            { name: 'tweet_count', type: 'number', description: 'Tweet count' },
        ],
        ref: createReferenceWithTitle(getBitcoinBubbleIndexRef, params, buildGetBitcoinBubbleIndexCallDescription),
        mapRecords: (raw) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = toMs(item.date_string);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    price: parseNumber(item.price),
                    bubble_index: parseNumber(item.bubble_index),
                    google_trend_percent: parseNumber(item.google_trend_percent),
                    mining_difficulty: parseNumber(item.mining_difficulty),
                    transaction_count: parseNumber(item.transaction_count),
                    address_send_count: parseNumber(item.address_send_count),
                    tweet_count: parseNumber(item.tweet_count),
                };
            });
        },
    });
}

function makeBitcoinCorrelationsNode(params) {
    return buildTimeSeriesNode(getBitcoinCorrelations, params, {
        outputName: 'bitcoin_correlations',
        description: 'Bitcoin correlation coefficients with traditional assets',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            { name: 'price', type: 'number', description: 'BTC price USD' },
            { name: 'gld', type: 'number', description: 'Correlation vs GLD' },
            { name: 'iwm', type: 'number', description: 'Correlation vs IWM' },
            { name: 'qqq', type: 'number', description: 'Correlation vs QQQ' },
            { name: 'spy', type: 'number', description: 'Correlation vs SPY' },
            { name: 'tlt', type: 'number', description: 'Correlation vs TLT' },
        ],
        ref: createReferenceWithTitle(getBitcoinCorrelationsRef, params, buildGetBitcoinCorrelationsCallDescription),
        mapRecords: (raw) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = toMs(item.timestamp);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    price: parseNumber(item.price),
                    gld: parseNumber(item.gld),
                    iwm: parseNumber(item.iwm),
                    qqq: parseNumber(item.qqq),
                    spy: parseNumber(item.spy),
                    tlt: parseNumber(item.tlt),
                };
            });
        },
    });
}


function makeBitcoinRainbowChartNode(params) {
    return buildTimeSeriesNode(getBitcoinRainbowChart, params, {
        outputName: 'bitcoin_rainbow_chart',
        description: 'Bitcoin rainbow valuation bands',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            { name: 'price', type: 'number', description: 'BTC price USD' },
            ...RAINBOW_BANDS.map(({ key, description }) => ({
                name: key,
                type: 'number',
                description,
            })),
        ],
        ref: createReferenceWithTitle(getBitcoinRainbowChartRef, params, buildGetBitcoinRainbowChartCallDescription),
        mapRecords: (raw) => {
            const rows = Array.isArray(raw) ? raw : [];
            return rows.map((row) => {
                if (!Array.isArray(row) || row.length < 12) {
                    return null;
                }
                // row[11] is the timestamp (ms), per original API doc
                const date = toMs(row[11]);
                if (date == null) {
                    return null;
                }
                const record = {
                    date,
                    price: parseNumber(row[0]),
                };
                RAINBOW_BANDS.forEach(({ key }, index) => {
                    record[key] = parseNumber(row[index + 1]);
                });
                return record;
            });
        },
    });
}

function makeBorrowInterestRateHistoryNode(params) {
    return buildTimeSeriesNode(getBorrowInterestRateHistory, params, {
        outputName: 'borrow_interest_rate_history',
        description: 'Borrow interest rate history',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            {
                name: 'exchange',
                type: 'string',
                description: 'Exchange name',
            },
            { name: 'symbol', type: 'string', description: 'Asset symbol' },
            {
                name: 'interval',
                type: 'string',
                description: 'Data interval',
            },
            {
                name: 'interest_rate',
                type: 'number',
                description: 'Borrow interest rate (decimal)',
            },
        ],
        ref: createReferenceWithTitle(getBorrowInterestRateHistoryRef, params, buildGetBorrowInterestRateHistoryCallDescription),
        mapRecords: (raw, params) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = toMs(item.time);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    exchange: params?.exchange || null,
                    symbol: params?.symbol || null,
                    interval: params?.interval || null,
                    interest_rate: parseNumber(item.interest_rate),
                };
            });
        },
    });
}

function makeBullMarketPeakIndicatorsNode(params) {
    // This endpoint returns a simultaneous snapshot across multiple indicators with no per-item timestamp.
    // Per graph design rules, emit a single record at snapshot time with a nested array of indicators.
    return {
        inputs: {
            raw: () => getBullMarketPeakIndicators(params),
        },
        outputs: {
            bull_market_peak_indicators: {
                name: 'bull_market_peak_indicators',
                description: 'Snapshot of bull market peak indicators',
                fields: [
                    { name: 'date', type: 'number', description: 'snapshot time ms' },
                    {
                        name: 'indicators',
                        type: 'array',
                        description: 'Indicators included in the snapshot',
                        fields: [
                            { name: 'indicator_name', type: 'string', description: 'Indicator name' },
                            { name: 'current_value', type: 'string', description: 'Current indicator value' },
                            { name: 'target_value', type: 'string', description: 'Target value signalling peak' },
                            { name: 'previous_value', type: 'string', description: 'Previous indicator value' },
                            { name: 'change_value', type: 'string', description: 'Change from previous' },
                            { name: 'comparison_type', type: 'string', description: 'Comparison operator' },
                            { name: 'hit_status', type: 'boolean', description: 'Indicator target met flag' },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getBullMarketPeakIndicatorsRef, params, buildGetBullMarketPeakIndicatorsCallDescription),
            },
        },
        run: (inputs) => {
            const items = Array.isArray(inputs.raw) ? inputs.raw : [];
            const indicators = items.map((item) => ({
                indicator_name: item?.indicator_name ?? null,
                current_value: item?.current_value ?? null,
                target_value: item?.target_value ?? null,
                previous_value: item?.previous_value ?? null,
                change_value: item?.change_value ?? null,
                comparison_type: item?.comparison_type ?? null,
                hit_status: item?.hit_status != null ? Boolean(item.hit_status) : null,
            }));
            // Acceptable: single snapshot record when no per-event time exists
            const snapshotTime = Date.now();
            return {
                bull_market_peak_indicators: [{ date: snapshotTime, indicators }],
            };
        },
    };
}

function makeCryptoFearAndGreedIndexNode(params) {
    return buildTimeSeriesNode(getCryptoFearAndGreedIndex, params, {
        outputName: 'crypto_fear_and_greed_index',
        description: 'Crypto Fear & Greed index time series',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            { name: 'index_value', type: 'number', description: 'Index value' },
            { name: 'price', type: 'number', description: 'BTC price USD' },
        ],
        ref: createReferenceWithTitle(getCryptoFearAndGreedIndexRef, params, buildGetCryptoFearAndGreedIndexCallDescription),
        mapRecords: (raw) => {
            const dataList = Array.isArray(raw?.data_list) ? raw.data_list : [];
            const priceList = Array.isArray(raw?.price_list) ? raw.price_list : [];
            const timeList = Array.isArray(raw?.time_list) ? raw.time_list : [];
            const length = Math.min(dataList.length, priceList.length, timeList.length);
            const series = [];
            for (let i = 0; i < length; i += 1) {
                const date = toMs(timeList[i]);
                if (date == null) {
                    continue;
                }
                series.push({
                    date,
                    index_value: parseNumber(dataList[i]),
                    price: parseNumber(priceList[i]),
                });
            }
            return series;
        },
    });
}

function makeFuturesBasisHistoryNode(params) {
    return buildTimeSeriesNode(getFuturesBasisHistory, params, {
        outputName: 'futures_basis_history',
        description: 'Futures basis history',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            {
                name: 'open_basis',
                type: 'number',
                description: 'Opening basis',
            },
            {
                name: 'close_basis',
                type: 'number',
                description: 'Closing basis',
            },
            {
                name: 'open_change',
                type: 'number',
                description: 'Opening basis change %',
            },
            {
                name: 'close_change',
                type: 'number',
                description: 'Closing basis change %',
            },
        ],
        ref: createReferenceWithTitle(getFuturesBasisHistoryRef, params, buildGetFuturesBasisHistoryCallDescription),
        mapRecords: (raw) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = toMs(item.time);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    open_basis: parseNumber(item.open_basis),
                    close_basis: parseNumber(item.close_basis),
                    open_change: parseNumber(item.open_change),
                    close_change: parseNumber(item.close_change),
                };
            });
        },
    });
}

function makeMarginLongShortNode(params) {
    return buildTimeSeriesNode(getMarginLongShort, params, {
        outputName: 'margin_long_short',
        description: 'Margin long vs short balances',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            {
                name: 'long_quantity',
                type: 'number',
                description: 'Margin long quantity',
            },
            {
                name: 'short_quantity',
                type: 'number',
                description: 'Margin short quantity',
            },
        ],
        ref: createReferenceWithTitle(getMarginLongShortRef, params, buildGetMarginLongShortCallDescription),
        mapRecords: (raw) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = toMs(item.time);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    long_quantity: parseNumber(item.long_quantity),
                    short_quantity: parseNumber(item.short_quantity),
                };
            });
        },
    });
}

function makeMarketIndicatorSoprNode(params) {
    return buildTimeSeriesNode(getMarketIndicatorSopr, params, {
        outputName: 'market_indicator_sopr',
        description: 'CryptoQuant SOPR metrics',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            { name: 'sopr', type: 'number', description: 'Standard SOPR' },
            { name: 'a_sopr', type: 'number', description: 'Adjusted SOPR' },
            {
                name: 'sth_sopr',
                type: 'number',
                description: 'Short-term holder SOPR',
            },
            {
                name: 'lth_sopr',
                type: 'number',
                description: 'Long-term holder SOPR',
            },
        ],
        ref: createReferenceWithTitle(getMarketIndicatorSoprRef, params, buildGetMarketIndicatorSoprCallDescription),
        mapRecords: (raw) => {
            const items = extractCqSeries(raw);
            return items.map((item) => {
                const date = toMs(item.timestamp);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    sopr: parseNumber(item.sopr),
                    a_sopr: parseNumber(item.a_sopr),
                    sth_sopr: parseNumber(item.sth_sopr),
                    lth_sopr: parseNumber(item.lth_sopr),
                };
            });
        },
    });
}

function makeWhaleIndexHistoryNode(params) {
    return buildTimeSeriesNode(getWhaleIndexHistory, params, {
        outputName: 'whale_index_history',
        description: 'Whale index history',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            {
                name: 'whale_index_value',
                type: 'number',
                description: 'Whale index value',
            },
        ],
        ref: createReferenceWithTitle(getWhaleIndexHistoryRef, params, buildGetWhaleIndexHistoryCallDescription),
        mapRecords: (raw) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = resolveTimestamp(item);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    whale_index_value: parseNumber(item.whale_index_value ?? item.value),
                };
            });
        },
    });
}

function makeCoinbasePremiumIndexNode(params) {
    return buildTimeSeriesNode(getCoinbasePremiumIndex, params, {
        outputName: 'coinbase_premium_index',
        description: 'Coinbase Bitcoin Premium Index history',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            {
                name: 'premium',
                type: 'number',
                description: 'Premium amount in USD',
            },
            {
                name: 'premium_rate',
                type: 'number',
                description: 'Premium as decimal rate',
            },
        ],
        ref: createReferenceWithTitle(getCoinbasePremiumIndexRef, params, buildGetCoinbasePremiumIndexCallDescription),
        mapRecords: (raw) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = toMs(item.time);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    premium: parseNumber(item.premium),
                    premium_rate: parseNumber(item.premium_rate),
                };
            });
        },
    });
}

function makeTokenHistoricalQuotesNode(params) {
    return {
        inputs: {
            token_historical_quotes_raw: () => getTokenHistoricalQuotes(params),
        },
        outputs: {
            token_historical_quotes: {
                name: 'token_historical_quotes',
                description: 'Historical cryptocurrency quotes data from CoinMarketCap',
                fields: [
                    { name: 'date', type: 'number', description: 'quote timestamp in ms' },
                    { name: 'name', type: 'string', description: 'cryptocurrency full name' },
                    { name: 'symbol', type: 'string', description: 'cryptocurrency trading symbol' },
                    { name: 'volume_24h', type: 'number', description: 'trading volume in last 24 hours' },
                    { name: 'market_cap', type: 'number', description: 'market capitalization' },
                    { name: 'circulating_supply', type: 'number', description: 'circulating supply' },
                    { name: 'total_supply', type: 'number', description: 'total supply' },
                ],
                ref: createReferenceWithTitle(getTokenHistoricalQuotesRef, params, buildGetTokenHistoricalQuotesCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.token_historical_quotes_raw;

            const results = [];
            const convert = params.convert || 'USD';

            for (const symbolKey in raw) {
                const tokenArray = raw[symbolKey];
                if (!Array.isArray(tokenArray)) continue;

                let tokenIndex = 0;
                for (const tokenData of tokenArray) {
                    if (!tokenData || !tokenData.quotes || tokenData.quotes.length === 0) {
                        tokenIndex++;
                        continue;
                    }

                    for (const quoteItem of tokenData.quotes) {
                        const quoteData = quoteItem.quote[convert];
                        const timestamp = new Date(quoteItem.timestamp).getTime();
                        const uniqueTimestamp = timestamp + (tokenData.id || tokenIndex * 100000);

                        results.push({
                            date: uniqueTimestamp,
                            name: String(tokenData.name),
                            symbol: String(tokenData.symbol),
                            volume_24h: quoteData.volume_24h,
                            market_cap: quoteData.market_cap,
                            circulating_supply: quoteData.circulating_supply,
                            total_supply: quoteData.total_supply,
                        });
                    }

                    tokenIndex++;
                }
            }

            return {
                token_historical_quotes: results,
            };
        },
    };
}

function makePredictionMarketDataNode(params) {
    return {
        inputs: {
            prediction_market_raw: () => getPredictionMarketData(params),
        },
        outputs: {
            prediction_markets: {
                name: 'prediction_markets',
                description: 'Polymarket prediction market data snapshot',
                fields: [
                    { name: 'date', type: 'number', description: 'snapshot time ms' },
                    { name: 'query', type: 'string', description: 'search query used' },
                    {
                        name: 'events',
                        type: 'array',
                        description: 'prediction market events',
                        fields: [
                            { name: 'event_title', type: 'string', description: 'event title' },
                            { name: 'category', type: 'string', description: 'event category' },
                            { name: 'volume', type: 'number', description: 'total volume' },
                            { name: 'end_date', type: 'string', description: 'event end date' },
                            { name: 'event_url', type: 'string', description: 'event URL' },
                            {
                                name: 'markets',
                                type: 'array',
                                description: 'markets within the event',
                                fields: [
                                    { name: 'market_question', type: 'string', description: 'market question' },
                                    { name: 'market_volume', type: 'number', description: 'market volume' },
                                    {
                                        name: 'outcome',
                                        type: 'string',
                                        description: 'outcome',
                                    },
                                    {
                                        name: 'outcome_prices',
                                        type: 'object',
                                        description: 'outcome prices as key-value pairs',
                                        fields: [
                                            { name: 'outcome_label', type: 'string', description: 'outcome label' },
                                            { name: 'price', type: 'number', description: 'outcome price' },
                                        ],
                                    },
                                ],
                            },
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getPredictionMarketDataRef, params, buildGetPredictionMarketDataCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.prediction_market_raw;

            return {
                prediction_markets: [
                    {
                        date: Date.now(),
                        query: params.q,
                        events: raw.map(event => ({
                            event_title: String(event.event_title),
                            category: String(event.category),
                            volume: event.volume,
                            end_date: String(event.end_date),
                            event_url: String(event.event_url),
                            markets: event.markets.map(market => ({
                                market_question: String(market.market_question),
                                market_volume: market.market_volume,
                                outcome: market.outcome,
                                outcome_prices: market.outcome_prices,
                            })),
                        })),
                    },
                ],
            };
        },
    };
}

// New helper: return all Ref objects in this module
function getRefs() {
    return [
        getPriceRef,
        getOpenInterestRef,
        getLiquidationHistoryRef,
        getFundingRateRef,
        getTakerBuySellVolumeFutureRef,
        getFuturePriceRef,
        getMarginLongShortRef,
        getBorrowInterestRateHistoryRef,
        getBullMarketPeakIndicatorsRef,
        getFuturesBasisHistoryRef,
        getWhaleIndexHistoryRef,
        getAltcoinSeasonIndexRef,
        getBitcoinReserveRiskRef,
        getBitcoinDominanceRef,
        getBitcoinRainbowChartRef,
        getCryptoFearAndGreedIndexRef,
        getBitcoinBubbleIndexRef,
        getBitcoinCorrelationsRef,
        getMarketIndicatorSoprRef,
        getCoinbasePremiumIndexRef,
        getPredictionMarketDataRef,
        getHistoricalTokenDataRef,
    ];
}

module.exports = {
    getPrice,
    getOpenInterest,
    getFundingRate,
    getLiquidationHistory,
    getTakerBuySellVolumeFuture,
    getFuturePrice,
    getMarginLongShort,
    getBorrowInterestRateHistory,
    getBullMarketPeakIndicators,
    getFuturesBasisHistory,
    getWhaleIndexHistory,
    getAltcoinSeasonIndex,
    getBitcoinReserveRisk,
    getBitcoinDominance,
    getBitcoinRainbowChart,
    getCryptoFearAndGreedIndex,
    getBitcoinBubbleIndex,
    getBitcoinCorrelations,
    getMarketIndicatorSopr,
    getCoinbasePremiumIndex,
    getTokenHistoricalQuotes,
    getPredictionMarketData,
    makePriceNode,
    makeOpenInterestNode,
    makeFundingRateNode,
    makeLiquidationHistoryNode,
    makeTakerBuySellVolumeFutureNode,
    makeFuturePriceNode,
    makeAltcoinSeasonIndexNode,
    makeBitcoinDominanceNode,
    makeBitcoinReserveRiskNode,
    makeBitcoinBubbleIndexNode,
    makeBitcoinCorrelationsNode,
    makeBitcoinRainbowChartNode,
    makeBorrowInterestRateHistoryNode,
    makeBullMarketPeakIndicatorsNode,
    makeCryptoFearAndGreedIndexNode,
    makeFuturesBasisHistoryNode,
    makeMarginLongShortNode,
    makeMarketIndicatorSoprNode,
    makeWhaleIndexHistoryNode,
    makeCoinbasePremiumIndexNode,
    makeTokenHistoricalQuotesNode,
    makePredictionMarketDataNode,
    getRefs,
};