// Test assertion helpers
function assert(cond, msg) {
    if (!cond) throw new Error(msg || 'assertion failed');
}
function isInteger(n) {
    return Number.isInteger(n);
}
function isMsEpoch(n) {
    return typeof n === 'number' && isInteger(n) && n > 0 && n > 10_000_000_000;
} // > ~1970s in ms
function hasUniqueDates(rows) {
    const s = new Set();
    for (const r of rows) {
        if (s.has(r.date)) return false;
        s.add(r.date);
    }
    return true;
}
function expectFieldsMatch(rows, fieldNames) {
    for (const r of rows) {
        const got = Object.keys(r);
        // date MUST be first field
        assert(got[0] === 'date', 'first field must be "date"');
        for (const f of fieldNames) assert(got.includes(f), `missing field: ${f}`);
    }
}

// Helper: validate time range for direct get* responses that accept from/to
function expectTimestampsWithin(res, from, to) {
    if (!res || !res.result || !Array.isArray(res.result.data)) return;
    for (const item of res.result.data) {
        if (item && typeof item === 'object') {
            // Prefer 'timestamp' (Unix seconds). Fall back to other common keys if present.
            const ts = (item.timestamp != null ? item.timestamp : (item.date != null ? item.date : item.datetime));
            if (ts != null) {
                assert(typeof ts === 'number' && Number.isFinite(ts), `timestamp must be number, got: ${ts}`);
                assert(ts >= from, `timestamp ${ts} < from ${from}`);
                assert(ts <= to, `timestamp ${ts} > to ${to}`);
            }
        }
    }
}

// Node output checker
function checkNodeOutput(
    graph,
    jagentId,
    nodeId,
    outputName,
    {
        expectFields = [], // fields AFTER 'date'
        preloadLast = '200', // how many to read back
        extra = null, // (rows, view) => void for custom assertions
    } = {}
) {
    const { TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const uri = new TimeSeriesUri(jagentId, nodeId, outputName, { last: preloadLast });
    const view = new TimeSeries(uri, graph.store);
    view.init(); // preload
    // NOTE: TimeSeries.data is newest-first (descending)
    const rows = view.data.slice(); // array of records

    // Basic invariants
    for (const r of rows) {
        assert(typeof r === 'object' && r != null, 'row must be object');
        assert(isMsEpoch(r.date), `date must be ms epoch, got: ${r.date}`);
    }
    assert(hasUniqueDates(rows), 'duplicate "date" values within one output');

    // Schema check (date-first + declared fields)
    expectFieldsMatch(rows, expectFields);

    // Optional additional checks
    if (typeof extra === 'function') extra(rows, view);
    return rows;
}

function main() {
    const { Graph } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');

    const {
        makeExchangeAnnouncementsNode,
        makeExchangeAssetsNode,
        makeExchangeReserveNode,
        makeExchangeNetflowNode,
        makeExchangeInflowNode,
        makeExchangeOutflowNode,
        makeExchangeTransactionsCountNode,
        makeExchangeAddressesCountNode,
        makeExchangeInHouseFlowNode,
        makeExchangeShareNode,
    } = require('@alva/data/crypto/exchange:v1.0.0');

    const g = new Graph(jagentId);

    // Common time range (seconds) required by CryptoQuant SDK
    const NOW_S = Math.floor(Date.now() / 1000);
    const FROM_S = NOW_S - 7 * 24 * 60 * 60; // last 7 days

    // Announcements (ms-based window per original doc)
    g.addNode(
        'exchange_ann',
        makeExchangeAnnouncementsNode({
            exchange: 'Binance',
            start_time: Date.now() - 7 * 24 * 60 * 60 * 1000,
            end_time: Date.now(),
            limit: 5,
        })
    );

    // Assets snapshot
    g.addNode('exchange_assets', makeExchangeAssetsNode({ exchange: 'Binance', per_page: 5, page: 1 }));

    // CQ series-based nodes (limit only; server-side defaults for time window)
    g.addNode(
        'exchange_reserve',
        makeExchangeReserveNode({
            symbol: 'btc',
            exchange: 'binance',
            from: FROM_S,
            to: NOW_S,
            limit: 5,
        })
    );
    g.addNode(
        'exchange_netflow',
        makeExchangeNetflowNode({
            symbol: 'btc',
            exchange: 'binance',
            from: FROM_S,
            to: NOW_S,
            limit: 5,
        })
    );
    g.addNode('exchange_inflow', makeExchangeInflowNode({ symbol: 'btc', exchange: 'binance', from: FROM_S, to: NOW_S, limit: 5 }));
    g.addNode(
        'exchange_outflow',
        makeExchangeOutflowNode({
            symbol: 'btc',
            exchange: 'binance',
            from: FROM_S,
            to: NOW_S,
            limit: 5,
        })
    );
    g.addNode(
        'exchange_tx_count',
        makeExchangeTransactionsCountNode({
            symbol: 'btc',
            exchange: 'binance',
            from: FROM_S,
            to: NOW_S,
            limit: 5,
        })
    );
    g.addNode(
        'exchange_address_count',
        makeExchangeAddressesCountNode({
            symbol: 'btc',
            exchange: 'binance',
            from: FROM_S,
            to: NOW_S,
            limit: 5,
        })
    );
    g.addNode(
        'exchange_in_house',
        makeExchangeInHouseFlowNode({
            symbol: 'btc',
            exchange: 'binance',
            from: FROM_S,
            to: NOW_S,
            limit: 5,
        })
    );
    g.addNode('exchange_share', makeExchangeShareNode({ symbol: 'xrp', exchange: 'binance', from: FROM_S, to: NOW_S, limit: 5 }));

    g.run();

    // Test announcements node output
    const annRows = checkNodeOutput(g, jagentId, 'exchange_ann', 'exchange_announcements', {
        expectFields: ['exchange_name', 'symbol', 'url', 'title', 'content', 'listed_pairs'],
        preloadLast: '100',
        extra: (rows) => {
            for (const r of rows) {
                ['exchange_name', 'url', 'title'].forEach((k) => assert(typeof r[k] === 'string', `${k} must be string`));
                assert(Array.isArray(r.listed_pairs), 'listed_pairs must be array');
                for (const lp of r.listed_pairs) {
                    assert(typeof lp.trading_pair === 'string', 'trading_pair must be string');
                    if (lp.listed_at != null) assert(isMsEpoch(lp.listed_at), 'listed_at must be ms if present');
                }
            }
        },
    });

    // Test assets node output
    const assetRows = checkNodeOutput(g, jagentId, 'exchange_assets', 'exchange_assets_snapshot', {
        expectFields: ['holdings'],
        preloadLast: '50',
        extra: (rows) => {
            for (const r of rows) {
                assert(Array.isArray(r.holdings), 'holdings must be array');
                for (const h of r.holdings) {
                    ['wallet_address', 'symbol', 'assets_name'].forEach((k) => assert(typeof h[k] === 'string', `holding ${k} must be string`));
                    ['balance', 'balance_usd', 'price'].forEach((k) => assert(typeof h[k] === 'number', `holding ${k} must be number`));
                }
            }
        },
    });

    // Test reserve node output
    const reserveRows = checkNodeOutput(g, jagentId, 'exchange_reserve', 'exchange_reserve', {
        expectFields: ['reserve', 'reserve_usd'],
        preloadLast: '50',
        extra: (rows) => {
            for (const r of rows) {
                ['reserve', 'reserve_usd'].forEach((k) => assert(typeof r[k] === 'number', `${k} must be number`));
            }
        },
    });

    // Test netflow node output
    const netflowRows = checkNodeOutput(g, jagentId, 'exchange_netflow', 'exchange_netflow', {
        expectFields: ['netflow_total'],
        preloadLast: '50',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.netflow_total === 'number', 'netflow_total must be number');
            }
        },
    });

    // Test inflow node output
    const inflowRows = checkNodeOutput(g, jagentId, 'exchange_inflow', 'exchange_inflow', {
        expectFields: ['inflow_total'],
        preloadLast: '50',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.inflow_total === 'number', 'inflow_total must be number');
            }
        },
    });

    // Test outflow node output
    const outflowRows = checkNodeOutput(g, jagentId, 'exchange_outflow', 'exchange_outflow', {
        expectFields: ['outflow_total'],
        preloadLast: '50',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.outflow_total === 'number', 'outflow_total must be number');
            }
        },
    });

    // Test transactions count node output
    const txCountRows = checkNodeOutput(g, jagentId, 'exchange_tx_count', 'exchange_transactions_count', {
        expectFields: ['transactions_count_inflow', 'transactions_count_outflow'],
        preloadLast: '50',
        extra: (rows) => {
            for (const r of rows) {
                ['transactions_count_inflow', 'transactions_count_outflow'].forEach((k) => assert(typeof r[k] === 'number', `${k} must be number`));
            }
        },
    });

    // Test addresses count node output
    const addrCountRows = checkNodeOutput(g, jagentId, 'exchange_address_count', 'exchange_addresses_count', {
        expectFields: ['addresses_count_inflow', 'addresses_count_outflow'],
        preloadLast: '50',
        extra: (rows) => {
            for (const r of rows) {
                ['addresses_count_inflow', 'addresses_count_outflow'].forEach((k) => assert(typeof r[k] === 'number', `${k} must be number`));
            }
        },
    });

    // Test in-house flow node output
    const inHouseRows = checkNodeOutput(g, jagentId, 'exchange_in_house', 'exchange_in_house_flow', {
        expectFields: ['flow_total', 'flow_mean', 'transactions_count_flow'],
        preloadLast: '50',
        extra: (rows) => {
            for (const r of rows) {
                ['flow_total', 'flow_mean', 'transactions_count_flow'].forEach((k) => assert(typeof r[k] === 'number', `${k} must be number`));
            }
        },
    });

    // Test share node output
    const shareRows = checkNodeOutput(g, jagentId, 'exchange_share', 'exchange_share', {
        expectFields: ['share'],
        preloadLast: '50',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.share === 'number', 'share must be number');
            }
        },
    });

    console.log(typeof g);

    const refs = g.getRefsForOutput('exchange_ann', 'announcements');

    if (refs.length > 0) {
        const ref = refs[0];
		console.log(ref.title);
        const expected = {
            id: '@alva/data/crypto/exchange/getExchangeAnnouncements',
            module_name: '@alva/data/crypto/exchange',
            module_display_name: 'Crypto Exchange Analytics',
            sdk_name: 'getExchangeAnnouncements',
            sdk_display_name: 'Exchange Announcement Tracker',
            source_name: 'Binance',
            source: 'https://www.notion.so/Tool-Get-Exchange-Announcement-242c6bac30df813fa6d2c2e86fa6cc9c?pvs=21',
        };

        // 开始断言
        if (ref.id !== expected.id) {
            throw new Error(`Assertion failed: ref.id. Expected '${expected.id}', but got '${ref.id}'`);
        }
        if (ref.module_name !== expected.module_name) {
            throw new Error(`Assertion failed: ref.module_name. Expected '${expected.module_name}', but got '${ref.module_name}'`);
        }
        if (ref.module_display_name !== expected.module_display_name) {
            throw new Error(`Assertion failed: ref.module_display_name. Expected '${expected.module_display_name}', but got '${ref.module_display_name}'`);
        }
        if (ref.sdk_name !== expected.sdk_name) {
            throw new Error(`Assertion failed: ref.sdk_name. Expected '${expected.sdk_name}', but got '${ref.sdk_name}'`);
        }
        if (ref.sdk_display_name !== expected.sdk_display_name) {
            throw new Error(`Assertion failed: ref.sdk_display_name. Expected '${expected.sdk_display_name}', but got '${ref.sdk_display_name}'`);
        }
        if (ref.source_name !== expected.source_name) {
            throw new Error(`Assertion failed: ref.source_name. Expected '${expected.source_name}', but got '${ref.source_name}'`);
        }
        if (ref.source !== expected.source) {
            throw new Error(`Assertion failed: ref.source. Expected '${expected.source}', but got '${ref.source}'`);
        }

    } else {
        throw new Error('Assertion failed: refs array is empty.');
    }

    // Validate refs for Exchange Assets output
    const refsAssets = g.getRefsForOutput('exchange_assets', 'assets_snapshot');
    if (refsAssets.length > 0) {
        const ref = refsAssets[0];
        const expected = {
            id: '@alva/data/crypto/exchange/getExchangeAssets',
            module_name: '@alva/data/crypto/exchange',
            module_display_name: 'Crypto Exchange Analytics',
            sdk_name: 'getExchangeAssets',
            sdk_display_name: 'Exchange Holding Asset ',
            source_name: 'Coinglass',
            source: 'https://docs.coinglass.com/reference/exchange-assets',
        };
		console.log(ref.title);
        if (ref.id !== expected.id) {
            throw new Error(`Assertion failed: ref.id (assets). Expected '${expected.id}', but got '${ref.id}'`);
        }
        if (ref.module_name !== expected.module_name) {
            throw new Error(`Assertion failed: ref.module_name (assets). Expected '${expected.module_name}', but got '${ref.module_name}'`);
        }
        if (ref.module_display_name !== expected.module_display_name) {
            throw new Error(`Assertion failed: ref.module_display_name (assets). Expected '${expected.module_display_name}', but got '${ref.module_display_name}'`);
        }
        if (ref.sdk_name !== expected.sdk_name) {
            throw new Error(`Assertion failed: ref.sdk_name (assets). Expected '${expected.sdk_name}', but got '${ref.sdk_name}'`);
        }
        if (ref.sdk_display_name !== expected.sdk_display_name) {
            throw new Error(`Assertion failed: ref.sdk_display_name (assets). Expected '${expected.sdk_display_name}', but got '${ref.sdk_display_name}'`);
        }
        if (ref.source_name !== expected.source_name) {
            throw new Error(`Assertion failed: ref.source_name (assets). Expected '${expected.source_name}', but got '${ref.source_name}'`);
        }
        if (ref.source !== expected.source) {
            throw new Error(`Assertion failed: ref.source (assets). Expected '${expected.source}', but got '${ref.source}'`);
        }

    } else {
        throw new Error('Assertion failed: refs array is empty for assets.');
    }

    // Validate refs for Exchange Netflow output
    const refsNetflow = g.getRefsForOutput('exchange_netflow', 'netflow');
    if (refsNetflow.length > 0) {
        const ref = refsNetflow[0];
        const expected = {
            id: '@alva/data/crypto/exchange/getExchangeNetflow',
            module_name: '@alva/data/crypto/exchange',
            module_display_name: 'Crypto Exchange Analytics',
            sdk_name: 'getExchangeNetflow',
            sdk_display_name: 'Exchange Flow',
            source_name: 'CryptoQuant',
            source:
                'https://cryptoquant.com/en/docs#tag/BTC-Exchange-Flows\n\nhttps://cryptoquant.com/en/docs#tag/ETH-Exchange-Flows\n\nhttps://cryptoquant.com/en/docs#tag/XRP-Entity-Flows',
        };
		console.log(ref.title);
        if (ref.id !== expected.id) {
            throw new Error(`Assertion failed: ref.id (netflow). Expected '${expected.id}', but got '${ref.id}'`);
        }
        if (ref.module_name !== expected.module_name) {
            throw new Error(`Assertion failed: ref.module_name (netflow). Expected '${expected.module_name}', but got '${ref.module_name}'`);
        }
        if (ref.module_display_name !== expected.module_display_name) {
            throw new Error(`Assertion failed: ref.module_display_name (netflow). Expected '${expected.module_display_name}', but got '${ref.module_display_name}'`);
        }
        if (ref.sdk_name !== expected.sdk_name) {
            throw new Error(`Assertion failed: ref.sdk_name (netflow). Expected '${expected.sdk_name}', but got '${ref.sdk_name}'`);
        }
        if (ref.sdk_display_name !== expected.sdk_display_name) {
            throw new Error(`Assertion failed: ref.sdk_display_name (netflow). Expected '${expected.sdk_display_name}', but got '${ref.sdk_display_name}'`);
        }
        if (ref.source_name !== expected.source_name) {
            throw new Error(`Assertion failed: ref.source_name (netflow). Expected '${expected.source_name}', but got '${ref.source_name}'`);
        }
        if (ref.source !== expected.source) {
            throw new Error(`Assertion failed: ref.source (netflow). Expected '${expected.source}', but got '${ref.source}'`);
        }

    } else {
        throw new Error('Assertion failed: refs array is empty for netflow.');
    }

    // Validate refs for Exchange Transactions Count output
    const refsTx = g.getRefsForOutput('exchange_tx_count', 'transactions');
    if (refsTx.length > 0) {
        const ref = refsTx[0];
        const expected = {
            id: '@alva/data/crypto/exchange/getExchangeTransactionsCount',
            module_name: '@alva/data/crypto/exchange',
            module_display_name: 'Crypto Exchange Analytics',
            sdk_name: 'getExchangeTransactionsCount',
            sdk_display_name: 'Exchange Transaction',
            source_name: 'Coinglass',
            source: 'https://docs.coinglass.com/reference/exchange-onchain-transfers',
        };
        if (ref.id !== expected.id) {
            throw new Error(`Assertion failed: ref.id (tx). Expected '${expected.id}', but got '${ref.id}'`);
        }
        if (ref.module_name !== expected.module_name) {
            throw new Error(`Assertion failed: ref.module_name (tx). Expected '${expected.module_name}', but got '${ref.module_name}'`);
        }
        if (ref.module_display_name !== expected.module_display_name) {
            throw new Error(`Assertion failed: ref.module_display_name (tx). Expected '${expected.module_display_name}', but got '${ref.module_display_name}'`);
        }
        if (ref.sdk_name !== expected.sdk_name) {
            throw new Error(`Assertion failed: ref.sdk_name (tx). Expected '${expected.sdk_name}', but got '${ref.sdk_name}'`);
        }
        if (ref.sdk_display_name !== expected.sdk_display_name) {
            throw new Error(`Assertion failed: ref.sdk_display_name (tx). Expected '${expected.sdk_display_name}', but got '${ref.sdk_display_name}'`);
        }
        if (ref.source_name !== expected.source_name) {
            throw new Error(`Assertion failed: ref.source_name (tx). Expected '${expected.source_name}', but got '${ref.source_name}'`);
        }
        if (ref.source !== expected.source) {
            throw new Error(`Assertion failed: ref.source (tx). Expected '${expected.source}', but got '${ref.source}'`);
        }
    } else {
        throw new Error('Assertion failed: refs array is empty for transactions count.');
    }

    // Validate refs for Exchange Reserve output
    const refsReserve = g.getRefsForOutput('exchange_reserve', 'reserve');
    if (refsReserve.length > 0) {
        const ref = refsReserve[0];
        const expected = {
            id: '@alva/data/crypto/exchange/getExchangeReserve',
            module_name: '@alva/data/crypto/exchange',
            module_display_name: 'Crypto Exchange Analytics',
            sdk_name: 'getExchangeReserve',
            sdk_display_name: 'Exchange Reserve',
            source_name: 'CryptoQuant',
            source: 'https://cryptoquant.com/en/docs',
        };
        if (ref.id !== expected.id) {
            throw new Error(`Assertion failed: ref.id (reserve). Expected '${expected.id}', but got '${ref.id}'`);
        }
        if (ref.module_name !== expected.module_name) {
            throw new Error(`Assertion failed: ref.module_name (reserve). Expected '${expected.module_name}', but got '${ref.module_name}'`);
        }
        if (ref.module_display_name !== expected.module_display_name) {
            throw new Error(`Assertion failed: ref.module_display_name (reserve). Expected '${expected.module_display_name}', but got '${ref.module_display_name}'`);
        }
        if (ref.sdk_name !== expected.sdk_name) {
            throw new Error(`Assertion failed: ref.sdk_name (reserve). Expected '${expected.sdk_name}', but got '${ref.sdk_name}'`);
        }
        if (ref.sdk_display_name !== expected.sdk_display_name) {
            throw new Error(`Assertion failed: ref.sdk_display_name (reserve). Expected '${expected.sdk_display_name}', but got '${ref.sdk_display_name}'`);
        }
        if (ref.source_name !== expected.source_name) {
            throw new Error(`Assertion failed: ref.source_name (reserve). Expected '${expected.source_name}', but got '${ref.source_name}'`);
        }
        if (ref.source !== expected.source) {
            throw new Error(`Assertion failed: ref.source (reserve). Expected '${expected.source}', but got '${ref.source}'`);
        }
    } else {
        throw new Error('Assertion failed: refs array is empty for reserve.');
    }

    // Validate refs for Exchange Inflow output
    const refsInflow = g.getRefsForOutput('exchange_inflow', 'inflow');
    if (refsInflow.length > 0) {
        const ref = refsInflow[0];
        const expected = {
            id: '@alva/data/crypto/exchange/getExchangeInflow',
            module_name: '@alva/data/crypto/exchange',
            module_display_name: 'Crypto Exchange Analytics',
            sdk_name: 'getExchangeInflow',
            sdk_display_name: 'Exchange Inflow',
            source_name: 'CryptoQuant',
            source: 'https://cryptoquant.com/en/docs',
        };
        if (ref.id !== expected.id) {
            throw new Error(`Assertion failed: ref.id (inflow). Expected '${expected.id}', but got '${ref.id}'`);
        }
        if (ref.module_name !== expected.module_name) {
            throw new Error(`Assertion failed: ref.module_name (inflow). Expected '${expected.module_name}', but got '${ref.module_name}'`);
        }
        if (ref.module_display_name !== expected.module_display_name) {
            throw new Error(`Assertion failed: ref.module_display_name (inflow). Expected '${expected.module_display_name}', but got '${ref.module_display_name}'`);
        }
        if (ref.sdk_name !== expected.sdk_name) {
            throw new Error(`Assertion failed: ref.sdk_name (inflow). Expected '${expected.sdk_name}', but got '${ref.sdk_name}'`);
        }
        if (ref.sdk_display_name !== expected.sdk_display_name) {
            throw new Error(`Assertion failed: ref.sdk_display_name (inflow). Expected '${expected.sdk_display_name}', but got '${ref.sdk_display_name}'`);
        }
        if (ref.source_name !== expected.source_name) {
            throw new Error(`Assertion failed: ref.source_name (inflow). Expected '${expected.source_name}', but got '${ref.source_name}'`);
        }
        if (ref.source !== expected.source) {
            throw new Error(`Assertion failed: ref.source (inflow). Expected '${expected.source}', but got '${ref.source}'`);
        }
    } else {
        throw new Error('Assertion failed: refs array is empty for inflow.');
    }

    // Validate refs for Exchange Outflow output
    const refsOutflow = g.getRefsForOutput('exchange_outflow', 'outflow');
    if (refsOutflow.length > 0) {
        const ref = refsOutflow[0];
        const expected = {
            id: '@alva/data/crypto/exchange/getExchangeOutflow',
            module_name: '@alva/data/crypto/exchange',
            module_display_name: 'Crypto Exchange Analytics',
            sdk_name: 'getExchangeOutflow',
            sdk_display_name: 'Exchange Outflow',
            source_name: 'CryptoQuant',
            source: 'https://cryptoquant.com/en/docs',
        };
        if (ref.id !== expected.id) {
            throw new Error(`Assertion failed: ref.id (outflow). Expected '${expected.id}', but got '${ref.id}'`);
        }
        if (ref.module_name !== expected.module_name) {
            throw new Error(`Assertion failed: ref.module_name (outflow). Expected '${expected.module_name}', but got '${ref.module_name}'`);
        }
        if (ref.module_display_name !== expected.module_display_name) {
            throw new Error(`Assertion failed: ref.module_display_name (outflow). Expected '${expected.module_display_name}', but got '${ref.module_display_name}'`);
        }
        if (ref.sdk_name !== expected.sdk_name) {
            throw new Error(`Assertion failed: ref.sdk_name (outflow). Expected '${expected.sdk_name}', but got '${ref.sdk_name}'`);
        }
        if (ref.sdk_display_name !== expected.sdk_display_name) {
            throw new Error(`Assertion failed: ref.sdk_display_name (outflow). Expected '${expected.sdk_display_name}', but got '${ref.sdk_display_name}'`);
        }
        if (ref.source_name !== expected.source_name) {
            throw new Error(`Assertion failed: ref.source_name (outflow). Expected '${expected.source_name}', but got '${ref.source_name}'`);
        }
        if (ref.source !== expected.source) {
            throw new Error(`Assertion failed: ref.source (outflow). Expected '${expected.source}', but got '${ref.source}'`);
        }
    } else {
        throw new Error('Assertion failed: refs array is empty for outflow.');
    }

    // Validate refs for Exchange Addresses Count output
    const refsAddr = g.getRefsForOutput('exchange_address_count', 'addresses');
    if (refsAddr.length > 0) {
        const ref = refsAddr[0];
        const expected = {
            id: '@alva/data/crypto/exchange/getExchangeAddressesCount',
            module_name: '@alva/data/crypto/exchange',
            module_display_name: 'Crypto Exchange Analytics',
            sdk_name: 'getExchangeAddressesCount',
            sdk_display_name: 'Exchange Addresses',
            source_name: 'CryptoQuant',
            source: 'https://cryptoquant.com/en/docs',
        };
        if (ref.id !== expected.id) {
            throw new Error(`Assertion failed: ref.id (addresses). Expected '${expected.id}', but got '${ref.id}'`);
        }
        if (ref.module_name !== expected.module_name) {
            throw new Error(`Assertion failed: ref.module_name (addresses). Expected '${expected.module_name}', but got '${ref.module_name}'`);
        }
        if (ref.module_display_name !== expected.module_display_name) {
            throw new Error(`Assertion failed: ref.module_display_name (addresses). Expected '${expected.module_display_name}', but got '${ref.module_display_name}'`);
        }
        if (ref.sdk_name !== expected.sdk_name) {
            throw new Error(`Assertion failed: ref.sdk_name (addresses). Expected '${expected.sdk_name}', but got '${ref.sdk_name}'`);
        }
        if (ref.sdk_display_name !== expected.sdk_display_name) {
            throw new Error(`Assertion failed: ref.sdk_display_name (addresses). Expected '${expected.sdk_display_name}', but got '${ref.sdk_display_name}'`);
        }
        if (ref.source_name !== expected.source_name) {
            throw new Error(`Assertion failed: ref.source_name (addresses). Expected '${expected.source_name}', but got '${ref.source_name}'`);
        }
        if (ref.source !== expected.source) {
            throw new Error(`Assertion failed: ref.source (addresses). Expected '${expected.source}', but got '${ref.source}'`);
        }
    } else {
        throw new Error('Assertion failed: refs array is empty for addresses count.');
    }

    // Validate refs for Exchange In-house Flow output
    const refsInHouse = g.getRefsForOutput('exchange_in_house', 'in_house_flow');
    if (refsInHouse.length > 0) {
        const ref = refsInHouse[0];
        const expected = {
            id: '@alva/data/crypto/exchange/getExchangeInHouseFlow',
            module_name: '@alva/data/crypto/exchange',
            module_display_name: 'Crypto Exchange Analytics',
            sdk_name: 'getExchangeInHouseFlow',
            sdk_display_name: 'Exchange In-house Flow',
            source_name: 'CryptoQuant',
            source: 'https://cryptoquant.com/en/docs',
        };
        if (ref.id !== expected.id) {
            throw new Error(`Assertion failed: ref.id (in_house). Expected '${expected.id}', but got '${ref.id}'`);
        }
        if (ref.module_name !== expected.module_name) {
            throw new Error(`Assertion failed: ref.module_name (in_house). Expected '${expected.module_name}', but got '${ref.module_name}'`);
        }
        if (ref.module_display_name !== expected.module_display_name) {
            throw new Error(`Assertion failed: ref.module_display_name (in_house). Expected '${expected.module_display_name}', but got '${ref.module_display_name}'`);
        }
        if (ref.sdk_name !== expected.sdk_name) {
            throw new Error(`Assertion failed: ref.sdk_name (in_house). Expected '${expected.sdk_name}', but got '${ref.sdk_name}'`);
        }
        if (ref.sdk_display_name !== expected.sdk_display_name) {
            throw new Error(`Assertion failed: ref.sdk_display_name (in_house). Expected '${expected.sdk_display_name}', but got '${ref.sdk_display_name}'`);
        }
        if (ref.source_name !== expected.source_name) {
            throw new Error(`Assertion failed: ref.source_name (in_house). Expected '${expected.source_name}', but got '${ref.source_name}'`);
        }
        if (ref.source !== expected.source) {
            throw new Error(`Assertion failed: ref.source (in_house). Expected '${expected.source}', but got '${ref.source}'`);
        }
    } else {
        throw new Error('Assertion failed: refs array is empty for in-house flow.');
    }

    // Validate refs for Exchange Share output
    const refsShare = g.getRefsForOutput('exchange_share', 'share');
    if (refsShare.length > 0) {
        const ref = refsShare[0];
        const expected = {
            id: '@alva/data/crypto/exchange/getExchangeShare',
            module_name: '@alva/data/crypto/exchange',
            module_display_name: 'Crypto Exchange Analytics',
            sdk_name: 'getExchangeShare',
            sdk_display_name: 'Exchange Share',
            source_name: 'CryptoQuant',
            source: 'https://cryptoquant.com/en/docs',
        };
        if (ref.id !== expected.id) {
            throw new Error(`Assertion failed: ref.id (share). Expected '${expected.id}', but got '${ref.id}'`);
        }
        if (ref.module_name !== expected.module_name) {
            throw new Error(`Assertion failed: ref.module_name (share). Expected '${expected.module_name}', but got '${ref.module_name}'`);
        }
        if (ref.module_display_name !== expected.module_display_name) {
            throw new Error(`Assertion failed: ref.module_display_name (share). Expected '${expected.module_display_name}', but got '${ref.module_display_name}'`);
        }
        if (ref.sdk_name !== expected.sdk_name) {
            throw new Error(`Assertion failed: ref.sdk_name (share). Expected '${expected.sdk_name}', but got '${ref.sdk_name}'`);
        }
        if (ref.sdk_display_name !== expected.sdk_display_name) {
            throw new Error(`Assertion failed: ref.sdk_display_name (share). Expected '${expected.sdk_display_name}', but got '${ref.sdk_display_name}'`);
        }
        if (ref.source_name !== expected.source_name) {
            throw new Error(`Assertion failed: ref.source_name (share). Expected '${expected.source_name}', but got '${ref.source_name}'`);
        }
        if (ref.source !== expected.source) {
            throw new Error(`Assertion failed: ref.source (share). Expected '${expected.source}', but got '${ref.source}'`);
        }
    } else {
        throw new Error('Assertion failed: refs array is empty for share.');
    }

    console.log('✅ Exchange make*Node tests passed');

    // ====== Direct Function Tests ======
    testDirectFunctions();

    return 0;
}

// Test direct function calls with comprehensive test cases using iteration
function testDirectFunctions() {
    console.log('\n=== Testing Direct Function Calls ===');

    // Common time range (seconds) required by CryptoQuant SDK
    const NOW_S = Math.floor(Date.now() / 1000);
    const FROM_S = NOW_S - 7 * 24 * 60 * 60; // last 7 days

    const {
        getExchangeAnnouncements,
        getExchangeAssets,
        getExchangeReserve,
        getExchangeNetflow,
        getExchangeInflow,
        getExchangeOutflow,
        getExchangeTransactionsCount,
        getExchangeAddressesCount,
        getExchangeInHouseFlow,
        getExchangeShare,
    } = require('@alva/data/crypto/exchange:v1.0.0');

    // Define supported exchanges and symbols for different functions
    const FULL_EXCHANGES = [
        'Binance', 'Bitfinex', 'Bitget', 'Bithumb', 'Bitstamp',
        'Bybit', 'Kucoin', 'OKX', 'Upbit'
    ];

    const ANNOUNCEMENT_EXCHANGES = ['Binance', 'Binance Alpha', 'okx', 'upbit'];

    const BTC_ETH_SYMBOLS = ['btc', 'eth'];
    const XRP_SYMBOLS = ['xrp'];
    const BTC_ONLY_SYMBOLS = ['btc'];
    const XRP_ONLY_SYMBOLS = ['xrp'];

    let totalTests = 0;
    let passedTests = 0;

    // Helper function to run test and track results
    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }
    // ============ getExchangeAssets Tests ============
    console.log('\n--- Testing getExchangeAssets ---');

    // Test all exchanges for getExchangeAssets
    for (const exchange of FULL_EXCHANGES) {
        runTest(`getExchangeAssets with ${exchange}`, () => {
            const assets = getExchangeAssets({
                exchange: exchange,
                per_page: 5,
                page: 1
            });
            assert(Array.isArray(assets), `Should return array for ${exchange}`);
            assert(assets.length <= 5, `Should respect per_page parameter for ${exchange}`);
        });
    }

    runTest('getExchangeAssets boundary values', () => {
        const assetsMin = getExchangeAssets({
            exchange:FULL_EXCHANGES[0],
            per_page: 1,
            page: 1
        });
        assert(Array.isArray(assetsMin), 'Should work with minimum values');

        const assetsMax = getExchangeAssets({
            exchange:FULL_EXCHANGES[0],
            per_page: 100,
            page: 10
        });
        assert(Array.isArray(assetsMax), 'Should handle large page numbers');
    });

    // ============ getExchangeReserve Tests ============
    console.log('\n--- Testing getExchangeReserve ---');

    // Test all combinations of exchanges and symbols
    for (const exchange of FULL_EXCHANGES) {
        for (const symbol of ['btc', 'eth', 'xrp']) {
            runTest(`getExchangeReserve with ${exchange} - ${symbol}`, () => {
                const reserve = getExchangeReserve({
                    symbol: symbol,
                    exchange: exchange,
                    from: FROM_S,
                    to: NOW_S,
                    limit: 5
                });
                assert(reserve && typeof reserve === 'object', `Should return object for ${exchange}-${symbol}`);
                assert(reserve.result && Array.isArray(reserve.result.data), `Should have data array for ${exchange}-${symbol}`);
                expectTimestampsWithin(reserve, FROM_S, NOW_S);
            });
        }
    }

    runTest('getExchangeReserve boundary values', () => {
        const reserveMin = getExchangeReserve({
            symbol: 'btc',
            exchange: 'Binance',
            from: FROM_S,
            to: NOW_S,
            limit: 2
        });
        assert(reserveMin && typeof reserveMin === 'object', 'Should work with minimum limit');
        expectTimestampsWithin(reserveMin, FROM_S, NOW_S);

        const reserveMax = getExchangeReserve({
            symbol: 'btc',
            exchange: 'Binance',
            from: FROM_S,
            to: NOW_S,
            limit: 100000
        });
        assert(reserveMax && typeof reserveMax === 'object', 'Should handle maximum limit');
        expectTimestampsWithin(reserveMax, FROM_S, NOW_S);
    });

    // ============ getExchangeNetflow Tests ============
    console.log('\n--- Testing getExchangeNetflow ---');

    // Test all exchanges with btc/eth symbols
    for (const exchange of FULL_EXCHANGES) {
        for (const symbol of BTC_ETH_SYMBOLS) {
            runTest(`getExchangeNetflow with ${exchange} - ${symbol}`, () => {
                const netflow = getExchangeNetflow({
                    symbol: symbol,
                    exchange: exchange,
                    from: FROM_S,
                    to: NOW_S,
                    limit: 5
                });
                assert(netflow && typeof netflow === 'object', `Should return object for ${exchange}-${symbol}`);
                assert(netflow.result && Array.isArray(netflow.result.data), `Should have data array for ${exchange}-${symbol}`);
                expectTimestampsWithin(netflow, FROM_S, NOW_S);
            });
        }
    }

    runTest('getExchangeNetflow boundary values', () => {
        const netflowMin = getExchangeNetflow({
            symbol: 'btc',
            exchange: 'Binance',
            from: FROM_S,
            to: NOW_S,
            limit: 2
        });
        assert(netflowMin && typeof netflowMin === 'object', 'Should work with minimum limit');
        expectTimestampsWithin(netflowMin, FROM_S, NOW_S);
    });

    // ============ getExchangeInflow Tests ============
    console.log('\n--- Testing getExchangeInflow ---');

    // Test all exchanges with btc/eth symbols
    for (const exchange of FULL_EXCHANGES) {
        for (const symbol of BTC_ETH_SYMBOLS) {
            runTest(`getExchangeInflow with ${exchange} - ${symbol}`, () => {
                const inflow = getExchangeInflow({
                    symbol: symbol,
                    exchange: exchange,
                    from: FROM_S,
                    to: NOW_S,
                    limit: 5
                });
                assert(inflow && typeof inflow === 'object', `Should return object for ${exchange}-${symbol}`);
                assert(inflow.result && Array.isArray(inflow.result.data), `Should have data array for ${exchange}-${symbol}`);
                expectTimestampsWithin(inflow, FROM_S, NOW_S);
            });
        }
    }

    // ============ getExchangeOutflow Tests ============
    console.log('\n--- Testing getExchangeOutflow ---');

    // Test all exchanges with btc/eth symbols
    for (const exchange of FULL_EXCHANGES) {
        for (const symbol of BTC_ETH_SYMBOLS) {
            runTest(`getExchangeOutflow with ${exchange} - ${symbol}`, () => {
                const outflow = getExchangeOutflow({
                    symbol: symbol,
                    exchange: exchange,
                    from: FROM_S,
                    to: NOW_S,
                    limit: 5
                });
                assert(outflow && typeof outflow === 'object', `Should return object for ${exchange}-${symbol}`);
                assert(outflow.result && Array.isArray(outflow.result.data), `Should have data array for ${exchange}-${symbol}`);
                expectTimestampsWithin(outflow, FROM_S, NOW_S);
            });
        }
    }

    // ============ getExchangeTransactionsCount Tests ============
    console.log('\n--- Testing getExchangeTransactionsCount ---');

    // Test all exchanges with supported symbols
    for (const exchange of FULL_EXCHANGES) {
        for (const symbol of ['btc', 'eth', 'xrp']) {
            runTest(`getExchangeTransactionsCount with ${exchange} - ${symbol}`, () => {
                const txCount = getExchangeTransactionsCount({
                    symbol: symbol,
                    exchange: exchange,
                    from: FROM_S,
                    to: NOW_S,
                    limit: 5
                });
                assert(txCount && typeof txCount === 'object', `Should return object for ${exchange}-${symbol}`);
                assert(txCount.result && Array.isArray(txCount.result.data), `Should have data array for ${exchange}-${symbol}`);
                expectTimestampsWithin(txCount, FROM_S, NOW_S);
            });
        }
    }

    // ============ getExchangeAddressesCount Tests ============
    console.log('\n--- Testing getExchangeAddressesCount ---');

    // Test all exchanges with supported symbols
    for (const exchange of FULL_EXCHANGES) {
        for (const symbol of ['btc', 'eth', 'xrp']) {
            runTest(`getExchangeAddressesCount with ${exchange} - ${symbol}`, () => {
                const addrCount = getExchangeAddressesCount({
                    symbol: symbol,
                    exchange: exchange,
                    from: FROM_S,
                    to: NOW_S,
                    limit: 5
                });
                assert(addrCount && typeof addrCount === 'object', `Should return object for ${exchange}-${symbol}`);
                assert(addrCount.result && Array.isArray(addrCount.result.data), `Should have data array for ${exchange}-${symbol}`);
                expectTimestampsWithin(addrCount, FROM_S, NOW_S);
            });
        }
    }

    // ============ getExchangeInHouseFlow Tests ============
    console.log('\n--- Testing getExchangeInHouseFlow ---');

    // Test all exchanges with btc only
    for (const exchange of FULL_EXCHANGES) {
        for (const symbol of BTC_ONLY_SYMBOLS) {
            runTest(`getExchangeInHouseFlow with ${exchange} - ${symbol}`, () => {
                const inHouse = getExchangeInHouseFlow({
                    symbol: symbol,
                    exchange: exchange,
                    from: FROM_S,
                    to: NOW_S,
                    limit: 5
                });
                assert(inHouse && typeof inHouse === 'object', `Should return object for ${exchange}-${symbol}`);
                assert(inHouse.result && Array.isArray(inHouse.result.data), `Should have data array for ${exchange}-${symbol}`);
                expectTimestampsWithin(inHouse, FROM_S, NOW_S);
            });
        }
    }

    runTest('getExchangeInHouseFlow boundary values', () => {
        const inHouseMin = getExchangeInHouseFlow({
            symbol: 'btc',
            exchange: 'Binance',
            from: FROM_S,
            to: NOW_S,
            limit: 2
        });
        assert(inHouseMin && typeof inHouseMin === 'object', 'Should work with minimum limit');
        expectTimestampsWithin(inHouseMin, FROM_S, NOW_S);
    });

    // ============ getExchangeShare Tests ============
    console.log('\n--- Testing getExchangeShare ---');

    // Test all exchanges with xrp only
    for (const exchange of FULL_EXCHANGES) {
        for (const symbol of XRP_ONLY_SYMBOLS) {
            runTest(`getExchangeShare with ${exchange} - ${symbol}`, () => {
                const share = getExchangeShare({
                    symbol: symbol,
                    exchange: exchange,
                    from: FROM_S,
                    to: NOW_S,
                    limit: 5
                });
                assert(share && typeof share === 'object', `Should return object for ${exchange}-${symbol}`);
                assert(share.result && Array.isArray(share.result.data), `Should have data array for ${exchange}-${symbol}`);
                expectTimestampsWithin(share, FROM_S, NOW_S);
            });
        }
    }

    runTest('getExchangeShare window parameters', () => {
        const shareHour = getExchangeShare({
            symbol: 'xrp',
            exchange: 'Binance',
            window: 'hour',
            from: FROM_S,
            to: NOW_S,
            limit: 3
        });
        assert(shareHour && typeof shareHour === 'object', 'Should work with hour window');
        expectTimestampsWithin(shareHour, FROM_S, NOW_S);

        const shareDay = getExchangeShare({
            symbol: 'xrp',
            exchange: 'Binance',
            window: 'day',
            from: FROM_S,
            to: NOW_S,
            limit: 3
        });
        assert(shareDay && typeof shareDay === 'object', 'Should work with day window');
        expectTimestampsWithin(shareDay, FROM_S, NOW_S);
    });

    runTest('getExchangeShare boundary values', () => {
        const shareMin = getExchangeShare({
            symbol: 'xrp',
            exchange: 'binance',
            from: FROM_S,
            to: NOW_S,
            limit: 2
        });
        assert(shareMin && typeof shareMin === 'object', 'Should work with minimum limit');
        expectTimestampsWithin(shareMin, FROM_S, NOW_S);
    });

    // ============ Error Handling Tests ============
    console.log('\n--- Testing Error Handling ---');

    runTest('getExchangeReserve invalid symbol', () => {
        try {
            getExchangeReserve({
                symbol: 'invalid',
                exchange: 'Binance',
                from: FROM_S,
                to: NOW_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('invalid'), 'Should handle invalid symbol');
        }
    });

    runTest('getExchangeNetflow invalid exchange', () => {
        try {
            getExchangeNetflow({
                symbol: 'btc',
                exchange: 'InvalidExchange',
                from: FROM_S,
                to: NOW_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Unsupported'), 'Should handle invalid exchange');
        }
    });

    runTest('getExchangeInHouseFlow unsupported symbol', () => {
        try {
            getExchangeInHouseFlow({
                symbol: 'eth', // Only btc supported
                exchange: 'Binance',
                from: FROM_S,
                to: NOW_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            assert(e.message.includes('Error') || e.message.includes('Invalid'), 'Should handle unsupported symbol');
        }
    });

    runTest('getExchangeShare invalid exchange', () => {
        try {
            getExchangeShare({
                symbol: 'xrp',
                exchange: 'InvalidExchange',
                from: FROM_S,
                to: NOW_S,
                limit: 10
            });
            throw new Error('Expected error but function succeeded');
        } catch (e) {
            console.log(e.message);
            assert(e.message.includes('Error') || e.message.includes('Unsupported'), 'Should handle invalid exchange');
        }
    });

    // Print test summary
    console.log('\n=== Test Summary ===');
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    if (passedTests === totalTests) {
        console.log('🎉 All tests passed!');
    } else {
        console.log('⚠️  Some tests failed. Please review the output above.');
    }
}

main();
