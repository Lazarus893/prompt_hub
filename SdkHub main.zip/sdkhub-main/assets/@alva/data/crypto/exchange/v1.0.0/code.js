const { sdkRelay } = require('sdkrelay');
const { useCredit } = require('internal');
const { getCGExchangeAssets } = require('@alva/external/coinglass:v1.0.0');
const cryptoQuantSDK = require('@alva/external/cryptoquant:v1.0.0');

// Refs added from tool.json for corresponding get* functions
const getExchangeAnnouncementsRef = {
  id: '@alva/data/crypto/exchange/getExchangeAnnouncements',
  module_name: '@alva/data/crypto/exchange',
  module_display_name: 'Crypto Exchange Analytics',
  sdk_name: 'getExchangeAnnouncements',
  sdk_display_name: 'Exchange Announcement Tracker',
  source_name: 'Binance',
  source: 'https://www.notion.so/Tool-Get-Exchange-Announcement-242c6bac30df813fa6d2c2e86fa6cc9c?pvs=21',
};

const getExchangeAssetsRef = {
  id: '@alva/data/crypto/exchange/getExchangeAssets',
  module_name: '@alva/data/crypto/exchange',
  module_display_name: 'Crypto Exchange Analytics',
  sdk_name: 'getExchangeAssets',
  sdk_display_name: 'Exchange Holding Asset ',
  source_name: 'Coinglass',
  source: 'https://docs.coinglass.com/reference/exchange-assets',
};

const getExchangeNetflowRef = {
  id: '@alva/data/crypto/exchange/getExchangeNetflow',
  module_name: '@alva/data/crypto/exchange',
  module_display_name: 'Crypto Exchange Analytics',
  sdk_name: 'getExchangeNetflow',
  sdk_display_name: 'Exchange Flow',
  source_name: 'CryptoQuant',
  source:
    'https://cryptoquant.com/en/docs#tag/BTC-Exchange-Flows\n\nhttps://cryptoquant.com/en/docs#tag/ETH-Exchange-Flows\n\nhttps://cryptoquant.com/en/docs#tag/XRP-Entity-Flows',
};

const getExchangeTransactionsCountRef = {
  id: '@alva/data/crypto/exchange/getExchangeTransactionsCount',
  module_name: '@alva/data/crypto/exchange',
  module_display_name: 'Crypto Exchange Analytics',
  sdk_name: 'getExchangeTransactionsCount',
  sdk_display_name: 'Exchange Transaction',
  source_name: 'Coinglass',
  source: 'https://docs.coinglass.com/reference/exchange-onchain-transfers',
};

// Drafted refs for get* functions that were missing
const getExchangeReserveRef = {
  id: '@alva/data/crypto/exchange/getExchangeReserve',
  module_name: '@alva/data/crypto/exchange',
  module_display_name: 'Crypto Exchange Analytics',
  sdk_name: 'getExchangeReserve',
  sdk_display_name: 'Exchange Reserve',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs',
};

const getExchangeInflowRef = {
  id: '@alva/data/crypto/exchange/getExchangeInflow',
  module_name: '@alva/data/crypto/exchange',
  module_display_name: 'Crypto Exchange Analytics',
  sdk_name: 'getExchangeInflow',
  sdk_display_name: 'Exchange Inflow',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs',
};

const getExchangeOutflowRef = {
  id: '@alva/data/crypto/exchange/getExchangeOutflow',
  module_name: '@alva/data/crypto/exchange',
  module_display_name: 'Crypto Exchange Analytics',
  sdk_name: 'getExchangeOutflow',
  sdk_display_name: 'Exchange Outflow',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs',
};

const getExchangeAddressesCountRef = {
  id: '@alva/data/crypto/exchange/getExchangeAddressesCount',
  module_name: '@alva/data/crypto/exchange',
  module_display_name: 'Crypto Exchange Analytics',
  sdk_name: 'getExchangeAddressesCount',
  sdk_display_name: 'Exchange Addresses',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs',
};

const getExchangeInHouseFlowRef = {
  id: '@alva/data/crypto/exchange/getExchangeInHouseFlow',
  module_name: '@alva/data/crypto/exchange',
  module_display_name: 'Crypto Exchange Analytics',
  sdk_name: 'getExchangeInHouseFlow',
  sdk_display_name: 'Exchange In-house Flow',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs',
};

const getExchangeShareRef = {
  id: '@alva/data/crypto/exchange/getExchangeShare',
  module_name: '@alva/data/crypto/exchange',
  module_display_name: 'Crypto Exchange Analytics',
  sdk_name: 'getExchangeShare',
  sdk_display_name: 'Exchange Share',
  source_name: 'CryptoQuant',
  source: 'https://cryptoquant.com/en/docs',
};
function getRefs() {
  return [
    getExchangeAnnouncementsRef,
    getExchangeAssetsRef,
    getExchangeNetflowRef,
    getExchangeTransactionsCountRef,
    getExchangeReserveRef,
    getExchangeInflowRef,
    getExchangeOutflowRef,
    getExchangeAddressesCountRef,
    getExchangeInHouseFlowRef,
    getExchangeShareRef,
  ];
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
  // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
  const title = titleBuilder(params);

  // 2. 组合 refObject 和新 title
  const newObject = {
    ...refObject,
    title: title
  };

  // 3. 返回新对象
  return newObject;
}

function getExchangeAnnouncements(params) {
  useCredit('getExchangeAnnouncements', 350);
  return sdkRelay('GetExchangeAnnouncements', params);
}

function getExchangeAssets(params) {
  useCredit('getExchangeAssets', 350);
  return getCGExchangeAssets(params);
}

function getExchangeReserve(params) {
  useCredit('getExchangeReserve', 350);
  return cryptoQuantSDK.getCQExchangeReserve(params);
}

function getExchangeInflow(params) {
  useCredit('getExchangeInflow', 350);
  return cryptoQuantSDK.getCQExchangeInflow(params);
}

function getExchangeNetflow(params) {
  useCredit('getExchangeNetflow', 350);
  return cryptoQuantSDK.getCQExchangeNetflow(params);
}

function getExchangeOutflow(params) {
  useCredit('getExchangeOutflow', 350);
  return cryptoQuantSDK.getCQExchangeOutflow(params);
}

function getExchangeTransactionsCount(params) {
  useCredit('getExchangeTransactionsCount', 350);
  return cryptoQuantSDK.getCQExchangeTransactionsCount(params);
}

function getExchangeAddressesCount(params) {
  useCredit('getExchangeAddressesCount', 350);
  return cryptoQuantSDK.getCQExchangeAddressesCount(params);
}

function getExchangeInHouseFlow(params) {
  useCredit('getExchangeInHouseFlow', 350);
  return cryptoQuantSDK.getCQExchangeInHouseFlow(params);
}

function getExchangeShare(params) {
  useCredit('getExchangeShare', 350);
  return cryptoQuantSDK.getCQExchangeShare(params);
}

function toMs(value) {
  if (value == null) {
    return null;
  }
  if (typeof value === 'number') {
    return value > 1e12 ? value : value * 1000;
  }
  if (typeof value === 'string') {
    const parsed = Date.parse(value);
    if (!Number.isNaN(parsed)) {
      return parsed;
    }
  }
  return null;
}

function extractCqSeries(response) {
  const data = response?.result?.data;
  return Array.isArray(data) ? data : [];
}

// kept for potential reuse; currently not used by the node (we adjust in ms precision inside run)
function adjustAnnouncementTimestamps(raw) {
  const arr = Array.isArray(raw) ? raw.slice() : [];
  arr.sort((a, b) => a.published_at - b.published_at);
  for (let i = 0; i < arr.length - 1; i++) {
    if (arr[i].published_at === arr[i + 1]?.published_at) {
      arr[i + 1].published_at += 1;
    }
  }
  return arr;
}

function deriveAssetsSnapshotDate(holdings, params) {
  const fromHoldings = Array.isArray(holdings)
    ? holdings
        .map((item) =>
          toMs(item.updated_at || item.updatedAt || item.last_updated || item.lastUpdated)
        )
        .find((value) => value != null)
    : null;
  if (fromHoldings != null) {
    return fromHoldings;
  }
  const fromParams = toMs(params?.snapshot_time || params?.snapshotTime || params?.time);
  if (fromParams != null) {
    return fromParams;
  }
  return Date.UTC(1970, 0, 1);
}

function makeExchangeAnnouncementsNode(params) {
  return {
    inputs: {
      announcements_raw: () => getExchangeAnnouncements(params),
    },
    outputs: {
      announcements: {
        name: 'exchange_announcements',
        description: 'Official Exchange Announcements',
        fields: [
          {
            name: 'date',
            type: 'number',
            description: 'publication time ms',
          },
          {
            name: 'exchange_name',
            type: 'string',
            description: 'exchange name',
          },
          {
            name: 'symbol',
            type: 'string',
            description: 'related symbol if applicable',
          },
          {
            name: 'url',
            type: 'string',
            description: 'announcement URL',
          },
          {
            name: 'title',
            type: 'string',
            description: 'announcement title',
          },
          {
            name: 'content',
            type: 'string',
            description: 'announcement content/description',
          },
          {
            name: 'listed_pairs',
            type: 'array',
            description: 'pairs listed in this announcement (if any)',
            fields: [
              {
                name: 'trading_pair',
                type: 'string',
                description: 'pair symbol, e.g., BTC/USDT',
              },
              {
                name: 'listed_at',
                type: 'number',
                description: 'listing time ms',
              },
            ],
          },
        ],
        ref: createReferenceWithTitle(
          getExchangeAnnouncementsRef,
          params,
          buildGetExchangeAnnouncementsCallDescription
        ),
      },
    },
    run: (inputs) => {
      const raw = Array.isArray(inputs.announcements_raw) ? inputs.announcements_raw.slice() : [];
      // sort by published_at seconds
      raw.sort((a, b) => (a?.published_at ?? 0) - (b?.published_at ?? 0));
      const out = [];
      for (let i = 0; i < raw.length; i++) {
        const a = raw[i] || {};
        const baseMs = toMs(a.published_at);
        if (baseMs == null) continue;
        let date = baseMs;
        // ensure uniqueness by shifting 1 ms only when necessary
        if (out.length > 0 && out[out.length - 1].date === date) {
          date = date + 1;
        }
        out.push({
          date,
          exchange_name: a.exchange_name,
          symbol: a.symbol,
          url: a.url,
          title: a.title,
          content: a.content,
          listed_pairs: Array.isArray(a.listed_pairs)
            ? a.listed_pairs.map((lp) => ({
                trading_pair: lp.trading_pair,
                listed_at: toMs(lp.listed_at),
              }))
            : [],
        });
      }
      return { announcements: out };
    },
  };
}

function makeExchangeAssetsNode(params) {
  return {
    inputs: {
      assets_raw: () => getExchangeAssets(params),
    },
    outputs: {
      assets_snapshot: {
        name: 'exchange_assets_snapshot',
        description: 'Current asset holdings reported by the exchange',
        fields: [
          {
            name: 'date',
            type: 'number',
            description: 'snapshot time ms',
          },
          {
            name: 'holdings',
            type: 'array',
            description: 'asset holdings',
            fields: [
              {
                name: 'wallet_address',
                type: 'string',
                description: 'wallet address',
              },
              {
                name: 'symbol',
                type: 'string',
                description: 'token symbol',
              },
              {
                name: 'assets_name',
                type: 'string',
                description: 'asset name',
              },
              {
                name: 'balance',
                type: 'number',
                description: 'asset balance',
              },
              {
                name: 'balance_usd',
                type: 'number',
                description: 'balance in USD',
              },
              {
                name: 'price',
                type: 'number',
                description: 'asset price in USD',
              },
            ],
          },
        ],
        ref: createReferenceWithTitle(
          getExchangeAssetsRef,
          params,
          buildGetExchangeAssetsCallDescription
        ),
      },
    },
    run: (inputs) => {
      const holdings = Array.isArray(inputs.assets_raw)
        ? inputs.assets_raw.map((item) => ({
            wallet_address: item.wallet_address,
            symbol: item.symbol,
            assets_name: item.assets_name,
            balance: item.balance,
            balance_usd: item.balance_usd,
            price: item.price,
          }))
        : [];
      return {
        assets_snapshot: [
          {
            date: deriveAssetsSnapshotDate(inputs.assets_raw, params),
            holdings,
          },
        ],
      };
    },
  };
}

function makeExchangeReserveNode(params) {
  return {
    inputs: {
      reserve_raw: () => getExchangeReserve(params),
    },
    outputs: {
      reserve: {
        name: 'exchange_reserve',
        description: 'On-chain reserve levels for the specified exchange',
        fields: [
          {
            name: 'date',
            type: 'number',
            description: 'timestamp ms',
          },
          {
            name: 'reserve',
            type: 'number',
            description: 'reserve amount in native units',
          },
          {
            name: 'reserve_usd',
            type: 'number',
            description: 'reserve value in USD',
          },
        ],
        ref: createReferenceWithTitle(
          getExchangeReserveRef,
          params,
          buildGetExchangeReserveCallDescription
        ),
      },
    },
    run: (inputs) => {
      const series = extractCqSeries(inputs.reserve_raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) {
            return null;
          }
          return {
            date: ts,
            reserve: item.reserve,
            reserve_usd: item.reserve_usd,
          };
        })
        .filter(Boolean);
      return { reserve: series };
    },
  };
}

function makeExchangeNetflowNode(params) {
  return {
    inputs: {
      netflow_raw: () => getExchangeNetflow(params),
    },
    outputs: {
      netflow: {
        name: 'exchange_netflow',
        description: 'Net asset flow onto the exchange',
        fields: [
          {
            name: 'date',
            type: 'number',
            description: 'timestamp ms',
          },
          {
            name: 'netflow_total',
            type: 'number',
            description: 'netflow amount',
          },
        ],
        ref: createReferenceWithTitle(
          getExchangeNetflowRef,
          params,
          buildGetExchangeNetflowCallDescription
        ),
      },
    },
    run: (inputs) => {
      const series = extractCqSeries(inputs.netflow_raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) {
            return null;
          }
          return {
            date: ts,
            netflow_total: item.netflow_total,
          };
        })
        .filter(Boolean);
      return { netflow: series };
    },
  };
}

function makeExchangeInflowNode(params) {
  return {
    inputs: {
      inflow_raw: () => getExchangeInflow(params),
    },
    outputs: {
      inflow: {
        name: 'exchange_inflow',
        description: 'Asset inflows onto the exchange',
        fields: [
          {
            name: 'date',
            type: 'number',
            description: 'timestamp ms',
          },
          {
            name: 'inflow_total',
            type: 'number',
            description: 'inflow amount',
          },
        ],
        ref: createReferenceWithTitle(
          getExchangeInflowRef,
          params,
          buildGetExchangeInflowCallDescription
        ),
      },
    },
    run: (inputs) => {
      const series = extractCqSeries(inputs.inflow_raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) {
            return null;
          }
          return {
            date: ts,
            inflow_total: item.inflow_total,
          };
        })
        .filter(Boolean);
      return { inflow: series };
    },
  };
}

function makeExchangeOutflowNode(params) {
  return {
    inputs: {
      outflow_raw: () => getExchangeOutflow(params),
    },
    outputs: {
      outflow: {
        name: 'exchange_outflow',
        description: 'Asset outflows from the exchange',
        fields: [
          {
            name: 'date',
            type: 'number',
            description: 'timestamp ms',
          },
          {
            name: 'outflow_total',
            type: 'number',
            description: 'outflow amount',
          },
        ],
        ref: createReferenceWithTitle(
          getExchangeOutflowRef,
          params,
          buildGetExchangeOutflowCallDescription
        ),
      },
    },
    run: (inputs) => {
      const series = extractCqSeries(inputs.outflow_raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) {
            return null;
          }
          return {
            date: ts,
            outflow_total: item.outflow_total,
          };
        })
        .filter(Boolean);
      return { outflow: series };
    },
  };
}

function makeExchangeTransactionsCountNode(params) {
  return {
    inputs: {
      transactions_raw: () => getExchangeTransactionsCount(params),
    },
    outputs: {
      transactions: {
        name: 'exchange_transactions_count',
        description: 'Transaction counts by direction',
        fields: [
          {
            name: 'date',
            type: 'number',
            description: 'timestamp ms',
          },
          {
            name: 'transactions_count_inflow',
            type: 'number',
            description: 'inflow transaction count',
          },
          {
            name: 'transactions_count_outflow',
            type: 'number',
            description: 'outflow transaction count',
          },
        ],
        ref: createReferenceWithTitle(
          getExchangeTransactionsCountRef,
          params,
          buildGetExchangeTransactionsCountCallDescription
        ),
      },
    },
    run: (inputs) => {
      const series = extractCqSeries(inputs.transactions_raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) {
            return null;
          }
          return {
            date: ts,
            transactions_count_inflow: item.transactions_count_inflow,
            transactions_count_outflow: item.transactions_count_outflow,
          };
        })
        .filter(Boolean);
      return { transactions: series };
    },
  };
}

function makeExchangeAddressesCountNode(params) {
  return {
    inputs: {
      addresses_raw: () => getExchangeAddressesCount(params),
    },
    outputs: {
      addresses: {
        name: 'exchange_addresses_count',
        description: 'Unique addresses interacting with the exchange',
        fields: [
          {
            name: 'date',
            type: 'number',
            description: 'timestamp ms',
          },
          {
            name: 'addresses_count_inflow',
            type: 'number',
            description: 'unique inflow addresses',
          },
          {
            name: 'addresses_count_outflow',
            type: 'number',
            description: 'unique outflow addresses',
          },
        ],
        ref: createReferenceWithTitle(
          getExchangeAddressesCountRef,
          params,
          buildGetExchangeAddressesCountCallDescription
        ),
      },
    },
    run: (inputs) => {
      const series = extractCqSeries(inputs.addresses_raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) {
            return null;
          }
          return {
            date: ts,
            addresses_count_inflow: item.addresses_count_inflow,
            addresses_count_outflow: item.addresses_count_outflow,
          };
        })
        .filter(Boolean);
      return { addresses: series };
    },
  };
}

function makeExchangeInHouseFlowNode(params) {
  return {
    inputs: {
      in_house_raw: () => getExchangeInHouseFlow(params),
    },
    outputs: {
      in_house_flow: {
        name: 'exchange_in_house_flow',
        description: 'Internal flows within the exchange',
        fields: [
          {
            name: 'date',
            type: 'number',
            description: 'timestamp ms',
          },
          {
            name: 'flow_total',
            type: 'number',
            description: 'total internal flow',
          },
          {
            name: 'flow_mean',
            type: 'number',
            description: 'mean flow per transaction',
          },
          {
            name: 'transactions_count_flow',
            type: 'number',
            description: 'count of flow transactions',
          },
        ],
        ref: createReferenceWithTitle(
          getExchangeInHouseFlowRef,
          params,
          buildGetExchangeInHouseFlowCallDescription
        ),
      },
    },
    run: (inputs) => {
      const series = extractCqSeries(inputs.in_house_raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) {
            return null;
          }
          return {
            date: ts,
            flow_total: item.flow_total,
            flow_mean: item.flow_mean,
            transactions_count_flow: item.transactions_count_flow,
          };
        })
        .filter(Boolean);
      return { in_house_flow: series };
    },
  };
}

function makeExchangeShareNode(params) {
  return {
    inputs: {
      share_raw: () => getExchangeShare(params),
    },
    outputs: {
      share: {
        name: 'exchange_share',
        description: 'Entity share of total supply',
        fields: [
          {
            name: 'date',
            type: 'number',
            description: 'timestamp ms',
          },
          {
            name: 'share',
            type: 'number',
            description: 'percentage share',
          },
        ],
        ref: createReferenceWithTitle(
          getExchangeShareRef,
          params,
          buildGetExchangeShareCallDescription
        ),
      },
    },
    run: (inputs) => {
      const series = extractCqSeries(inputs.share_raw)
        .map((item) => {
          const ts = toMs(item.timestamp);
          if (ts == null) {
            return null;
          }
          return {
            date: ts,
            share: item.share,
          };
        })
        .filter(Boolean);
      return { share: series };
    },
  };
}

// -----------------------
// Internal dynamic descriptions (not exported)
// Base descriptions (concise summaries from docs)
const getExchangeAnnouncementsBaseDesc = 'Get official exchange announcements';
const getExchangeAssetsBaseDesc = 'Get exchange wallet asset holdings';
const getExchangeReserveBaseDesc = 'Get exchange on-chain reserve';
const getExchangeNetflowBaseDesc = 'Get exchange netflow';
const getExchangeInflowBaseDesc = 'Get exchange inflow';
const getExchangeOutflowBaseDesc = 'Get exchange outflow';
const getExchangeTransactionsCountBaseDesc = 'Get exchange inflow/outflow transaction counts';
const getExchangeAddressesCountBaseDesc = 'Get unique inflow/outflow address counts';
const getExchangeInHouseFlowBaseDesc = 'Get in-house flows within exchange wallets';
const getExchangeShareBaseDesc = 'Get entity share of total supply';

// Builders
function buildGetExchangeAnnouncementsCallDescription(actualParams = {}) {
  const parts = [getExchangeAnnouncementsBaseDesc];
  if (actualParams.exchange) {
    parts.push(`from ${actualParams.exchange}`);
  }
  const filters = [];
  if (actualParams.category) {
    filters.push(`Category: ${actualParams.category}`);
  }
  if (actualParams.limit != null && actualParams.limit !== 50) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (actualParams.start_time && actualParams.end_time) {
    filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
  } else if (actualParams.start_time) {
    filters.push(`Time from: ${actualParams.start_time}`);
  } else if (actualParams.end_time) {
    filters.push(`Time to: ${actualParams.end_time}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetExchangeAssetsCallDescription(actualParams = {}) {
  const parts = [getExchangeAssetsBaseDesc];
  if (actualParams.exchange) {
    parts.push(`from ${actualParams.exchange}`);
  }
  const filters = [];
  if (actualParams.per_page != null && actualParams.per_page !== 10) {
    filters.push(`PerPage: ${actualParams.per_page}`);
  }
  if (actualParams.page != null && actualParams.page !== 1) {
    filters.push(`Page: ${actualParams.page}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetExchangeReserveCallDescription(actualParams = {}) {
  const parts = [getExchangeReserveBaseDesc];
  if (actualParams.symbol) {
    parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
  }
  if (actualParams.exchange) {
    parts.push(`on ${actualParams.exchange}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.limit != null && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  } else if (actualParams.from) {
    filters.push(`From: ${actualParams.from}`);
  } else if (actualParams.to) {
    filters.push(`To: ${actualParams.to}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetExchangeNetflowCallDescription(actualParams = {}) {
  const parts = [getExchangeNetflowBaseDesc];
  if (actualParams.symbol) {
    parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
  }
  if (actualParams.exchange) {
    parts.push(`on ${actualParams.exchange}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.limit != null && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  } else if (actualParams.from) {
    filters.push(`From: ${actualParams.from}`);
  } else if (actualParams.to) {
    filters.push(`To: ${actualParams.to}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetExchangeInflowCallDescription(actualParams = {}) {
  const parts = [getExchangeInflowBaseDesc];
  if (actualParams.symbol) {
    parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
  }
  if (actualParams.exchange) {
    parts.push(`on ${actualParams.exchange}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.limit != null && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  } else if (actualParams.from) {
    filters.push(`From: ${actualParams.from}`);
  } else if (actualParams.to) {
    filters.push(`To: ${actualParams.to}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetExchangeOutflowCallDescription(actualParams = {}) {
  const parts = [getExchangeOutflowBaseDesc];
  if (actualParams.symbol) {
    parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
  }
  if (actualParams.exchange) {
    parts.push(`on ${actualParams.exchange}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.limit != null && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  } else if (actualParams.from) {
    filters.push(`From: ${actualParams.from}`);
  } else if (actualParams.to) {
    filters.push(`To: ${actualParams.to}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetExchangeTransactionsCountCallDescription(actualParams = {}) {
  const parts = [getExchangeTransactionsCountBaseDesc];
  if (actualParams.symbol) {
    parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
  }
  if (actualParams.exchange) {
    parts.push(`on ${actualParams.exchange}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.limit != null && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  } else if (actualParams.from) {
    filters.push(`From: ${actualParams.from}`);
  } else if (actualParams.to) {
    filters.push(`To: ${actualParams.to}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetExchangeAddressesCountCallDescription(actualParams = {}) {
  const parts = [getExchangeAddressesCountBaseDesc];
  if (actualParams.symbol) {
    parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
  }
  if (actualParams.exchange) {
    parts.push(`on ${actualParams.exchange}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.limit != null && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  } else if (actualParams.from) {
    filters.push(`From: ${actualParams.from}`);
  } else if (actualParams.to) {
    filters.push(`To: ${actualParams.to}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetExchangeInHouseFlowCallDescription(actualParams = {}) {
  const parts = [getExchangeInHouseFlowBaseDesc];
  if (actualParams.symbol) {
    parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
  }
  if (actualParams.exchange) {
    parts.push(`on ${actualParams.exchange}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.limit != null && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  } else if (actualParams.from) {
    filters.push(`From: ${actualParams.from}`);
  } else if (actualParams.to) {
    filters.push(`To: ${actualParams.to}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

function buildGetExchangeShareCallDescription(actualParams = {}) {
  const parts = [getExchangeShareBaseDesc];
  if (actualParams.symbol) {
    parts.push(`for ${String(actualParams.symbol).toUpperCase()}`);
  }
  if (actualParams.exchange) {
    parts.push(`by ${actualParams.exchange}`);
  }
  const filters = [];
  if (actualParams.window && actualParams.window !== 'day') {
    filters.push(`Window: ${actualParams.window}`);
  }
  if (actualParams.limit != null && actualParams.limit !== 100) {
    filters.push(`Limit: ${actualParams.limit}`);
  }
  if (actualParams.from && actualParams.to) {
    filters.push(`Time: ${actualParams.from} to ${actualParams.to}`);
  } else if (actualParams.from) {
    filters.push(`From: ${actualParams.from}`);
  } else if (actualParams.to) {
    filters.push(`To: ${actualParams.to}`);
  }
  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }
  return parts.join(' ').trim();
}

module.exports = {
  getExchangeAnnouncements,
  getExchangeAssets,
  getExchangeReserve,
  getExchangeNetflow,
  getExchangeInflow,
  getExchangeOutflow,
  getExchangeTransactionsCount,
  getExchangeAddressesCount,
  getExchangeInHouseFlow,
  getExchangeShare,
  makeExchangeAnnouncementsNode,
  makeExchangeAssetsNode,
  makeExchangeReserveNode,
  makeExchangeNetflowNode,
  makeExchangeInflowNode,
  makeExchangeOutflowNode,
  makeExchangeTransactionsCountNode,
  makeExchangeAddressesCountNode,
  makeExchangeInHouseFlowNode,
  makeExchangeShareNode,
  getRefs,
};