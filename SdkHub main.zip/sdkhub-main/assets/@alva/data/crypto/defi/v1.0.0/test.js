function main() {
    const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');
    const {
        makeDefiProtocolVolumeNode,
        makeDefiProtocolUserActivityNode,
        makeDefiProtocolFeesAndRevenueNode,
        makeProtocolChainMetricsNode,
        makeProtocolTokenMetricsNode,
        makeProtocolTokenUnlockSeriesDataNode,
        makeProtocolCliffAllocationNode,
        makeProtocolLinearAllocationNode,
        makeDexVolumeSummaryNode
    } = require('@alva/data/crypto/defi:v1.0.0');

    const graph = new Graph(jagentId);

    // Test 1: DEX Volume Node
    graph.addNode('dex_volume', makeDefiProtocolVolumeNode({
        protocol: 'uniswap'
    }));

    // Test 2: User Activity Node
    graph.addNode('user_activity', makeDefiProtocolUserActivityNode({
        name: 'uniswap',
        type: 'users'
    }));

    // Test 3: Fees and Revenue Node
    graph.addNode('fees_revenue', makeDefiProtocolFeesAndRevenueNode({
        protocol: 'uniswap',
        data_type: 'dailyFees',
        start_time: 1672531200,
        end_time: 1672617600
    }));

    graph.addNode('chain_tvls', makeProtocolChainMetricsNode({
        protocol_id: 'aave',
        start_time: 1672531200,
        end_time: 1672617600
    }));

    graph.addNode('token_tvls', makeProtocolTokenMetricsNode({
        protocol_id: 'aave',
        start_time: 1672531200,
        end_time: 1672617600
    }));

    // Add the node to the graph with specific parameters.
    graph.addNode('token_unlocks', makeProtocolTokenUnlockSeriesDataNode({
        protocol_id: 'aave',
        start_time: 1672531200,
        end_time: 1672617600
    }));

    graph.addNode('cliff_allocations_test', makeProtocolCliffAllocationNode({
        protocol_id: 'aave',
        start_time: 1512777600,
        end_time: 1512950400
    }));

    // 1. Add the node to the graph with specific parameters.
    graph.addNode('linear_allocations_test', makeProtocolLinearAllocationNode({
        protocol_id: 'rocket-pool',
        start_time: 1635897600,
        end_time: 1636070400
    }));

    // Add the node to the graph with specific parameters.
    graph.addNode('dex_volume_summary', makeDexVolumeSummaryNode({
        protocol_id: 'uniswap-v3',
        start_time: 1541289600, // Jan 1, 2023
        end_time: 1541376000    // Jan 2, 2023
    }));

    graph.run();

    // Validate DEX Volume Node Output
    const volumeUri = new TimeSeriesUri(jagentId, 'dex_volume', 'volume_summary', { last: '10' });
    const volumeSeries = new TimeSeries(volumeUri, graph.store);
    volumeSeries.init();
    const volumeData = volumeSeries.data;

    if (volumeData.length > 0) {
        const record = volumeData[0];
        if (typeof record.date !== 'number' || record.date <= 0) {
            throw new Error('dex_volume: date must be a positive number (ms)');
        }
        if (typeof record.protocol_name !== 'string') {
            throw new Error('dex_volume: protocol_name must be a string');
        }
        if (!Array.isArray(record.chains)) {
            throw new Error('dex_volume: chains must be an array');
        }
        if (typeof record.total_volume_24h !== 'number') {
            throw new Error('dex_volume: total_volume_24h must be a number');
        }
        if (typeof record.total_volume_all_time !== 'number') {
            throw new Error('dex_volume: total_volume_all_time must be a number');
        }
        log('✓ dex_volume node output validated');
    }

    // Validate User Activity Node Output
    const activityUri = new TimeSeriesUri(jagentId, 'user_activity', 'user_activity', { last: '10' });
    const activitySeries = new TimeSeries(activityUri, graph.store);
    activitySeries.init();
    const activityData = activitySeries.data;

    if (activityData.length > 0) {
        const record = activityData[0];
        if (typeof record.date !== 'number' || record.date <= 0) {
            throw new Error('user_activity: date must be a positive number (ms)');
        }
        if (typeof record.activity_type !== 'string') {
            throw new Error('user_activity: activity_type must be a string');
        }
        if (typeof record.value !== 'number') {
            throw new Error('user_activity: value must be a number');
        }
        log('✓ user_activity node output validated');
    }

    // Validate Fees and Revenue Node Output - Summary Snapshot
    const feesUri = new TimeSeriesUri(jagentId, 'fees_revenue', 'summary_snapshot', { last: '10' });
    const feesSeries = new TimeSeries(feesUri, graph.store);
    feesSeries.init();
    const feesData = feesSeries.data;

    if (feesData.length > 0) {
        const record = feesData[0];
        if (typeof record.date !== 'number' || record.date <= 0) {
            throw new Error('fees_revenue: date must be a positive number (ms)');
        }
        if (typeof record.protocol_name !== 'string') {
            throw new Error('fees_revenue: protocol_name must be a string');
        }
        if (typeof record.description !== 'string') {
            throw new Error('fees_revenue: description must be a string');
        }
        if (typeof record.symbol !== 'string') {
            throw new Error('fees_revenue: symbol must be a string');
        }
        if (!Array.isArray(record.chains)) {
            throw new Error('fees_revenue: chains must be an array');
        }
        log('✓ fees_revenue summary_snapshot output validated');
    }

    // Validate Fees and Revenue Node Output - Historical Breakdown
    const feesBreakdownUri = new TimeSeriesUri(jagentId, 'fees_revenue', 'historical_breakdown', { last: '10' });
    const feesBreakdownSeries = new TimeSeries(feesBreakdownUri, graph.store);
    feesBreakdownSeries.init();
    const feesBreakdownData = feesBreakdownSeries.data;

    if (feesBreakdownData.length > 0) {
        const record = feesBreakdownData[0];
        if (typeof record.date !== 'number' || record.date <= 0) {
            throw new Error('fees_revenue: breakdown date must be a positive number (ms)');
        }
        if (typeof record.chain_data !== 'string') {
            throw new Error('fees_revenue: chain_data must be a string');
        }
        // Validate that chain_data is valid JSON
        try {
            JSON.parse(record.chain_data);
        } catch (e) {
            throw new Error('fees_revenue: chain_data must be valid JSON string');
        }
        log('✓ fees_revenue historical_breakdown output validated');
    }


    const tvlsChainUri = new TimeSeriesUri(jagentId, 'chain_tvls', 'protocol_chain_tvls', { last: '10' });
    const tvlsChainSeries = new TimeSeries(tvlsChainUri, graph.store);
    tvlsChainSeries.init();
    const tvlsChainData = tvlsChainSeries.data;

    if (tvlsChainData.length > 0) {
        const record = tvlsChainData[0];
        if (typeof record.date !== 'number' || !record.date) {
            throw new Error('chain_tvls: date must be a non-empty string (Unix seconds)');
        }
        if (!Array.isArray(record.chains)) {
            throw new Error('chain_tvls: chains must be an array');
        }

        // Also validate the structure of the inner chain objects
        if (record.chains.length > 0) {
            const chainRecord = record.chains[0];
            if (typeof chainRecord.protocolId !== 'string') {
                throw new Error('chain_tvls: protocolId in chains array must be a string');
            }
            if (typeof chainRecord.chainName !== 'string') {
                throw new Error('chain_tvls: chainName in chains array must be a string');
            }
            if (typeof chainRecord.tvlUsd !== 'number') {
                throw new Error('chain_tvls: tvlUsd in chains array must be a number');
            }
        }
        log('✓ chain_tvls node output validated');
    }

    const tvlsTokenUri = new TimeSeriesUri(jagentId, 'token_tvls', 'protocol_token_tvls', { last: '10' });
    const tvlsTokenSeries = new TimeSeries(tvlsTokenUri, graph.store);
    tvlsTokenSeries.init();
    const tvlsTokenData = tvlsTokenSeries.data;

    if (tvlsTokenData.length > 0) {
        const record = tvlsTokenData[0];
        if (typeof record.date !== 'number' || !record.date) {
            throw new Error('token_tvls: date must be a non-empty string (Unix seconds)');
        }
        if (!Array.isArray(record.tokens)) {
            throw new Error('token_tvls: tokens must be an array');
        }

        // Also validate the structure of the inner token objects
        if (record.tokens.length > 0) {
            const tokenRecord = record.tokens[0];
            if (typeof tokenRecord.protocolId !== 'string') {
                throw new Error('token_tvls: protocolId in tokens array must be a string');
            }
            if (typeof tokenRecord.tokenName !== 'string') {
                throw new Error('token_tvls: tokenName in tokens array must be a string');
            }
            if (typeof tokenRecord.tvlUsd !== 'number') {
                throw new Error('token_tvls: tvlUsd in tokens array must be a number');
            }
        }
        log('✓ token_tvls node output validated');
    }

    // Create a URI and a TimeSeries object to access the node's output data.
    const unlocksUri = new TimeSeriesUri(jagentId, 'token_unlocks', 'protocol_unlock_series', { last: '10' });
    const unlocksSeries = new TimeSeries(unlocksUri, graph.store);
    unlocksSeries.init();
    const unlocksData = unlocksSeries.data;

    // Validate the structure of the data returned by the node.
    if (unlocksData.length > 0) {
        const record = unlocksData[0];

        // Validate the top-level fields: timestamp and recipients array.
        if (typeof record.date !== 'number' || !record.date) {
            throw new Error('token_unlocks: timestamp must be a non-empty number (Unix milliseconds)');
        }
        if (!Array.isArray(record.recipients)) {
            throw new Error('token_unlocks: recipients must be an array');
        }

        // Also validate the structure of the inner recipient objects.
        if (record.recipients.length > 0) {
            const recipientRecord = record.recipients[0];
            if (typeof recipientRecord.protocolSlug !== 'string') {
                throw new Error('token_unlocks: protocolSlug in recipients array must be a string');
            }
            if (typeof recipientRecord.name !== 'string') {
                throw new Error('token_unlocks: name in recipients array must be a string');
            }
            if (typeof recipientRecord.recipient !== 'string') {
                throw new Error('token_unlocks: recipient in recipients array must be a string');
            }
            if (typeof recipientRecord.unlockedAmount !== 'number') {
                throw new Error('token_unlocks: unlockedAmount in recipients array must be a number');
            }
            if (typeof recipientRecord.rawEmission !== 'number') {
                throw new Error('token_unlocks: rawEmission in recipients array must be a number');
            }
            if (typeof recipientRecord.burned !== 'number') {
                throw new Error('token_unlocks: burned in recipients array must be a number');
            }
        }
        log('✓ token_unlocks node output validated');
    }

    const allocationsUri = new TimeSeriesUri(jagentId, 'cliff_allocations_test', 'cliff_allocations', { last: '100' });
    const allocationsSeries = new TimeSeries(allocationsUri, graph.store);
    allocationsSeries.init();
    const allocationsData = allocationsSeries.data;

    // 4. Validate the structure of the data returned by the node.
    if (allocationsData.length > 0) {
        const record = allocationsData[0];

        // Validate the fields of the first record.
        if (typeof record.date !== 'number' || !record.date) {
            throw new Error('cliff_allocations: date must be a non-empty number (Unix milliseconds)');
        }
        if (typeof record.protocol_slug !== 'string') {
            throw new Error('cliff_allocations: protocol_slug must be a string');
        }
        if (typeof record.recipient !== 'string') {
            throw new Error('cliff_allocations: recipient must be a string');
        }
        if (typeof record.category !== 'string') {
            throw new Error('cliff_allocations: category must be a string');
        }
        if (typeof record.amount !== 'number') {
            throw new Error('cliff_allocations: amount must be a number');
        }
        if (typeof record.name !== 'string') {
            throw new Error('cliff_allocations: name must be a string');
        }

        // Also, validate that all 'date' values are unique across the dataset.
        const dates = allocationsData.map(d => d.date);
        const uniqueDates = new Set(dates);
        if (uniqueDates.size !== dates.length) {
            throw new Error('cliff_allocations: date values are not unique');
        }

        log('✓ cliff_allocations node output validated');
    }

    const linearUri = new TimeSeriesUri(jagentId, 'linear_allocations_test', 'linear_allocations', { last: '100' });
    const linearSeries = new TimeSeries(linearUri, graph.store);
    linearSeries.init();
    const linearData = linearSeries.data;

    if (linearData.length > 0) {
        const record = linearData[0];

        // Validate the fields of the first record.
        if (typeof record.date !== 'number' || !record.date) {
            throw new Error('linear_allocations: date must be a non-empty number (Unix milliseconds)');
        }
        if (typeof record.protocol_slug !== 'string') {
            throw new Error('linear_allocations: protocol_slug must be a string');
        }
        if (typeof record.recipient !== 'string') {
            throw new Error('linear_allocations: recipient must be a string');
        }
        if (typeof record.category !== 'string') {
            throw new Error('linear_allocations: category must be a string');
        }
        if (typeof record.new_rate_per_week !== 'number') {
            throw new Error('linear_allocations: new_rate_per_week must be a number');
        }
        // Also check end_timestamp, allowing for it to be null if the API can return it as such
        if (record.end_timestamp !== null && typeof record.end_timestamp !== 'number') {
            throw new Error('linear_allocations: end_timestamp must be a number or null');
        }
        if (typeof record.name !== 'string') {
            throw new Error('linear_allocations: name must be a string');
        }

        // Validate that all 'date' values are unique and sorted.
        const dates = linearData.map(d => d.date);
        const uniqueDates = new Set(dates);
        if (uniqueDates.size !== dates.length) {
            throw new Error('linear_allocations: date values are not unique');
        }

        log('✓ linear_allocations node output validated');
    }

    // Create a URI and a TimeSeries object to access the node's output data.
    const dexVolumeUri = new TimeSeriesUri(jagentId, 'dex_volume', 'dex_volume_series', { last: '10' });
    const dexVolumeSeries = new TimeSeries(dexVolumeUri, graph.store);
    dexVolumeSeries.init();
    const dexVolumeData = dexVolumeSeries.data;

    // Validate the structure of the data returned by the node.
    if (dexVolumeData.length > 0) {
        const record = dexVolumeData[0];

        // Validate the top-level fields: date and breakdowns array.
        if (typeof record.date !== 'number' || !record.date) {
            throw new Error('dex_volume: date must be a non-empty number');
        }
        if (!Array.isArray(record.breakdowns)) {
            throw new Error('dex_volume: breakdowns must be an array');
        }

        // Also validate the structure of the inner breakdown objects.
        if (record.breakdowns.length > 0) {
            const breakdownRecord = record.breakdowns[0];
            if (typeof breakdownRecord.chain !== 'string') {
                throw new Error('dex_volume: chain in breakdowns array must be a string');
            }
            if (typeof breakdownRecord.version !== 'string') {
                throw new Error('dex_volume: version in breakdowns array must be a string');
            }
            if (typeof breakdownRecord.volume !== 'number') {
                throw new Error('dex_volume: volume in breakdowns array must be a number');
            }
            if (typeof breakdownRecord.name !== 'string') {
                throw new Error('dex_volume: name in breakdowns array must be a string');
            }
            if (typeof breakdownRecord.symbol !== 'string') {
                throw new Error('dex_volume: symbol in breakdowns array must be a string');
            }
            if (typeof breakdownRecord.protocolSlug !== 'string') {
                throw new Error('dex_volume: protocolSlug in breakdowns array must be a string');
            }
        }
        log('✓ dex_volume node output validated');
    }

    // Validate refs for outputs
    // 1) DEX Volume -> volume_summary
    const refsVolume = graph.getRefsForOutput('dex_volume', 'volume_summary');
    if (refsVolume.length > 0) {
        const ref = refsVolume[0];
        const expected = {
            id: '@alva/data/crypto/defi/getDefiProtocolVolume',
            module_name: '@alva/data/crypto/defi',
            module_display_name: 'Crypto Project KPI & Operating Metrics',
            sdk_name: 'getDefiProtocolVolume',
            sdk_display_name: 'DEX Protocol Volume',
            source_name: 'DefiLlama',
            source: 'https://api-docs.defillama.com/#tag/volumes/get/api/summary/dexs/%7Bprotocol%7D',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for dex_volume');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for dex_volume');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for dex_volume');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for dex_volume');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for dex_volume');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for dex_volume');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for dex_volume');
        log('✓ dex_volume refs validated');
    } else {
        throw new Error('Assertion failed: refsVolume array is empty.');
    }

    // 2) User Activity -> user_activity
    const refsUserActivity = graph.getRefsForOutput('user_activity', 'user_activity');
    if (refsUserActivity.length > 0) {
        const ref = refsUserActivity[0];
        const expected = {
            id: '@alva/data/crypto/defi/getDefiProtocolUserActivity',
            module_name: '@alva/data/crypto/defi',
            module_display_name: 'Crypto Project KPI & Operating Metrics',
            sdk_name: 'getDefiProtocolUserActivity',
            sdk_display_name: 'Crypto Project User Activity',
            source_name: 'DefiLlama',
            source: 'https://api-docs.defillama.com/#tag/active-users/get/api/userData/%7Btype%7D/%7BprotocolId%7D',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for user_activity');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for user_activity');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for user_activity');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for user_activity');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for user_activity');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for user_activity');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for user_activity');
        log('✓ user_activity refs validated');
    } else {
        throw new Error('Assertion failed: refsUserActivity array is empty.');
    }

    // 3) Fees and Revenue -> summary_snapshot
    const refsFees = graph.getRefsForOutput('fees_revenue', 'summary_snapshot');
    if (refsFees.length > 0) {
        const ref = refsFees[0];
        const expected = {
            id: '@alva/data/crypto/defi/getDefiProtocolFeesAndRevenue',
            module_name: '@alva/data/crypto/defi',
            module_display_name: 'Crypto Project KPI & Operating Metrics',
            sdk_name: 'getDefiProtocolFeesAndRevenue',
            sdk_display_name: 'Crypto Project Fees and Revenue',
            source_name: 'DefiLlama',
            source: 'https://api-docs.defillama.com/#tag/fees-and-revenue/get/api/summary/fees/%7Bprotocol%7D',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for fees_revenue');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for fees_revenue');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for fees_revenue');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for fees_revenue');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for fees_revenue');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for fees_revenue');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for fees_revenue');
        log('✓ fees_revenue refs validated');
    } else {
        throw new Error('Assertion failed: refsFees array is empty.');
    }

    // 4) Token Unlocks -> protocol_unlock_series
    const refsUnlocks = graph.getRefsForOutput('token_unlocks', 'protocol_unlock_series');
    if (refsUnlocks.length > 0) {
        const ref = refsUnlocks[0];
        const expected = {
            id: '@alva/data/crypto/defi/getProtocolTokenUnlockSeriesData',
            module_name: '@alva/data/crypto/defi',
            module_display_name: 'Crypto Project KPI & Operating Metrics',
            sdk_name: 'getProtocolTokenUnlockSeriesData',
            sdk_display_name: 'Token Unlocks',
            source_name: 'DefiLlama',
            source: 'https://api-docs.defillama.com/#tag/unlocks/get/api/emission/%7Bprotocol%7D',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for token_unlocks');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for token_unlocks');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for token_unlocks');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for token_unlocks');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for token_unlocks');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for token_unlocks');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for token_unlocks');
        log('✓ token_unlocks refs validated');
    } else {
        throw new Error('Assertion failed: refsUnlocks array is empty.');
    }

    // 5) DEX Volume -> historical_volume
    const refsHistoricalVolume = graph.getRefsForOutput('dex_volume', 'historical_volume');
    if (refsHistoricalVolume.length > 0) {
        const ref = refsHistoricalVolume[0];
        const expected = {
            id: '@alva/data/crypto/defi/getDefiProtocolVolume',
            module_name: '@alva/data/crypto/defi',
            module_display_name: 'Crypto Project KPI & Operating Metrics',
            sdk_name: 'getDefiProtocolVolume',
            sdk_display_name: 'DEX Protocol Volume',
            source_name: 'DefiLlama',
            source: 'https://api-docs.defillama.com/#tag/volumes/get/api/summary/dexs/%7Bprotocol%7D',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for dex_volume (historical_volume)');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for dex_volume (historical_volume)');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for dex_volume (historical_volume)');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for dex_volume (historical_volume)');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for dex_volume (historical_volume)');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for dex_volume (historical_volume)');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for dex_volume (historical_volume)');
        log('✓ dex_volume (historical_volume) refs validated');
    } else {
        throw new Error('Assertion failed: refsHistoricalVolume array is empty.');
    }

    // 6) Fees and Revenue -> historical_breakdown
    const refsFeesBreakdownRef = graph.getRefsForOutput('fees_revenue', 'historical_breakdown');
    if (refsFeesBreakdownRef.length > 0) {
        const ref = refsFeesBreakdownRef[0];
        const expected = {
            id: '@alva/data/crypto/defi/getDefiProtocolFeesAndRevenue',
            module_name: '@alva/data/crypto/defi',
            module_display_name: 'Crypto Project KPI & Operating Metrics',
            sdk_name: 'getDefiProtocolFeesAndRevenue',
            sdk_display_name: 'Crypto Project Fees and Revenue',
            source_name: 'DefiLlama',
            source: 'https://api-docs.defillama.com/#tag/fees-and-revenue/get/api/summary/fees/%7Bprotocol%7D',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for fees_revenue (historical_breakdown)');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for fees_revenue (historical_breakdown)');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for fees_revenue (historical_breakdown)');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for fees_revenue (historical_breakdown)');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for fees_revenue (historical_breakdown)');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for fees_revenue (historical_breakdown)');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for fees_revenue (historical_breakdown)');
        log('✓ fees_revenue (historical_breakdown) refs validated');
    } else {
        throw new Error('Assertion failed: refsFeesBreakdownRef array is empty.');
    }

    // 7) Protocol Chain Metrics -> protocol_chain_tvls
    const refsChainTVLs = graph.getRefsForOutput('chain_tvls', 'protocol_chain_tvls');
    if (refsChainTVLs.length > 0) {
        const ref = refsChainTVLs[0];
        const expected = {
            id: '@alva/data/crypto/defi/getProtocolChainMetrics',
            module_name: '@alva/data/crypto/defi',
            module_display_name: 'Crypto Project KPI & Operating Metrics',
            sdk_name: 'getProtocolChainMetrics',
            sdk_display_name: 'Protocol Chain TVL',
            source_name: 'DefiLlama',
            source: 'https://api-docs.defillama.com/#tag/tvl',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for chain_tvls');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for chain_tvls');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for chain_tvls');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for chain_tvls');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for chain_tvls');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for chain_tvls');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for chain_tvls');
        log('✓ chain_tvls refs validated');
    } else {
        throw new Error('Assertion failed: refsChainTVLs array is empty.');
    }

    // 8) Protocol Token Metrics -> protocol_token_tvls
    const refsTokenTVLs = graph.getRefsForOutput('token_tvls', 'protocol_token_tvls');
    if (refsTokenTVLs.length > 0) {
        const ref = refsTokenTVLs[0];
        const expected = {
            id: '@alva/data/crypto/defi/getProtocolTokenMetrics',
            module_name: '@alva/data/crypto/defi',
            module_display_name: 'Crypto Project KPI & Operating Metrics',
            sdk_name: 'getProtocolTokenMetrics',
            sdk_display_name: 'Protocol Token TVL',
            source_name: 'DefiLlama',
            source: 'https://api-docs.defillama.com/#tag/tvl',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for token_tvls');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for token_tvls');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for token_tvls');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for token_tvls');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for token_tvls');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for token_tvls');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for token_tvls');
        log('✓ token_tvls refs validated');
    } else {
        throw new Error('Assertion failed: refsTokenTVLs array is empty.');
    }

    // 9) Cliff Allocations -> cliff_allocations
    const refsCliffAllocations = graph.getRefsForOutput('cliff_allocations_test', 'cliff_allocations');
    if (refsCliffAllocations.length > 0) {
        const ref = refsCliffAllocations[0];
        const expected = {
            id: '@alva/data/crypto/defi/getProtocolCliffAllocation',
            module_name: '@alva/data/crypto/defi',
            module_display_name: 'Crypto Project KPI & Operating Metrics',
            sdk_name: 'getProtocolCliffAllocation',
            sdk_display_name: 'Token Unlocks - Cliff Allocations',
            source_name: 'DefiLlama',
            source: 'https://api-docs.defillama.com/#tag/unlocks',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for cliff_allocations');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for cliff_allocations');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for cliff_allocations');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for cliff_allocations');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for cliff_allocations');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for cliff_allocations');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for cliff_allocations');
        log('✓ cliff_allocations refs validated');
    } else {
        throw new Error('Assertion failed: refsCliffAllocations array is empty.');
    }

    // 10) Linear Allocations -> linear_allocations
    const refsLinearAllocations = graph.getRefsForOutput('linear_allocations_test', 'linear_allocations');
    if (refsLinearAllocations.length > 0) {
        const ref = refsLinearAllocations[0];
        const expected = {
            id: '@alva/data/crypto/defi/getProtocolLinearAllocation',
            module_name: '@alva/data/crypto/defi',
            module_display_name: 'Crypto Project KPI & Operating Metrics',
            sdk_name: 'getProtocolLinearAllocation',
            sdk_display_name: 'Token Unlocks - Linear Allocations',
            source_name: 'DefiLlama',
            source: 'https://api-docs.defillama.com/#tag/unlocks',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for linear_allocations');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for linear_allocations');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for linear_allocations');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for linear_allocations');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for linear_allocations');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for linear_allocations');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for linear_allocations');
        log('✓ linear_allocations refs validated');
    } else {
        throw new Error('Assertion failed: refsLinearAllocations array is empty.');
    }

    // 11) DEX Volume Summary -> dex_volume_series
    const refsDexVolumeSeries = graph.getRefsForOutput('dex_volume_summary', 'dex_volume_series');
    if (refsDexVolumeSeries.length > 0) {
        const ref = refsDexVolumeSeries[0];
        const expected = {
            id: '@alva/data/crypto/defi/getDexVolumeSummary',
            module_name: '@alva/data/crypto/defi',
            module_display_name: 'Crypto Project KPI & Operating Metrics',
            sdk_name: 'getDexVolumeSummary',
            sdk_display_name: 'DEX Volume Series',
            source_name: 'DefiLlama',
            source: 'https://api-docs.defillama.com/#tag/volumes',
        };

        if (ref.id !== expected.id) throw new Error('Assertion failed: ref.id mismatch for dex_volume_series');
        if (ref.module_name !== expected.module_name) throw new Error('Assertion failed: ref.module_name mismatch for dex_volume_series');
        if (ref.module_display_name !== expected.module_display_name) throw new Error('Assertion failed: ref.module_display_name mismatch for dex_volume_series');
        if (ref.sdk_name !== expected.sdk_name) throw new Error('Assertion failed: ref.sdk_name mismatch for dex_volume_series');
        if (ref.sdk_display_name !== expected.sdk_display_name) throw new Error('Assertion failed: ref.sdk_display_name mismatch for dex_volume_series');
        if (ref.source_name !== expected.source_name) throw new Error('Assertion failed: ref.source_name mismatch for dex_volume_series');
        if (ref.source !== expected.source) throw new Error('Assertion failed: ref.source mismatch for dex_volume_series');
        log('✓ dex_volume_series refs validated');
    } else {
        throw new Error('Assertion failed: refsDexVolumeSeries array is empty.');
    }

    log('✅ DeFi make*Node tests passed');
    return 0;
}

main();