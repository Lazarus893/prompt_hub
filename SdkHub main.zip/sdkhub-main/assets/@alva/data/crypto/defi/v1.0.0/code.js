const { useCredit } = require('internal');
const defiLlamaSDK = require('@alva/external/defillama:v1.0.0');
const {sdkRelay} = require('sdkrelay');

/**
 * Internal helper: convert seconds to ms if needed, keep ms as is.
 * Returns number (ms) or null if input is null/undefined.
 */
function toMs(value) {
    if (value == null) {
        return null;
    }
    if (typeof value === 'number') {
        return value > 1e12 ? value : value * 1000;
    }
    if (typeof value === 'string') {
        const parsed = Date.parse(value);
        if (!Number.isNaN(parsed)) {
            return parsed;
        }
    }
    return null;
}


function ensureUniqueDates(items) {
    const used = new Set();
    return items.map((item) => {
        let { date } = item;
        if (date == null) {
            date = Date.now();
        }
        while (used.has(date)) {
            date += 1;
        }
        used.add(date);
        return { ...item, date };
    });
}

// Helper to decorate ref objects with a dynamic title built from params
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

// Reference metadata objects sourced from tool.json
const getDefiProtocolVolumeRef = {
    id: '@alva/data/crypto/defi/getDefiProtocolVolume',
    module_name: '@alva/data/crypto/defi',
    module_display_name: 'Crypto Project KPI \u0026 Operating Metrics',
    sdk_name: 'getDefiProtocolVolume',
    sdk_display_name: 'DEX Protocol Volume',
    source_name: 'DefiLlama',
    source: 'https://api-docs.defillama.com/#tag/volumes/get/api/summary/dexs/%7Bprotocol%7D'
};

const getDefiProtocolUserActivityRef = {
    id: '@alva/data/crypto/defi/getDefiProtocolUserActivity',
    module_name: '@alva/data/crypto/defi',
    module_display_name: 'Crypto Project KPI \u0026 Operating Metrics',
    sdk_name: 'getDefiProtocolUserActivity',
    sdk_display_name: 'Crypto Project User Activity',
    source_name: 'DefiLlama',
    source: 'https://api-docs.defillama.com/#tag/active-users/get/api/userData/%7Btype%7D/%7BprotocolId%7D'
};

const getDefiProtocolFeesAndRevenueRef = {
    id: '@alva/data/crypto/defi/getDefiProtocolFeesAndRevenue',
    module_name: '@alva/data/crypto/defi',
    module_display_name: 'Crypto Project KPI \u0026 Operating Metrics',
    sdk_name: 'getDefiProtocolFeesAndRevenue',
    sdk_display_name: 'Crypto Project Fees and Revenue',
    source_name: 'DefiLlama',
    source: 'https://api-docs.defillama.com/#tag/fees-and-revenue/get/api/summary/fees/%7Bprotocol%7D'
};

const getProtocolTokenUnlockSeriesDataRef = {
    id: '@alva/data/crypto/defi/getProtocolTokenUnlockSeriesData',
    module_name: '@alva/data/crypto/defi',
    module_display_name: 'Crypto Project KPI \u0026 Operating Metrics',
    sdk_name: 'getProtocolTokenUnlockSeriesData',
    sdk_display_name: 'Token Unlocks',
    source_name: 'DefiLlama',
    source: 'https://api-docs.defillama.com/#tag/unlocks/get/api/emission/%7Bprotocol%7D'
};

// Drafted reference metadata objects for missing get* functions
const getProtocolChainMetricsRef = {
    id: '@alva/data/crypto/defi/getProtocolChainMetrics',
    module_name: '@alva/data/crypto/defi',
    module_display_name: 'Crypto Project KPI & Operating Metrics',
    sdk_name: 'getProtocolChainMetrics',
    sdk_display_name: 'Protocol Chain TVL',
    source_name: 'DefiLlama',
    source: 'https://api-docs.defillama.com/#tag/tvl'
};

const getProtocolTokenMetricsRef = {
    id: '@alva/data/crypto/defi/getProtocolTokenMetrics',
    module_name: '@alva/data/crypto/defi',
    module_display_name: 'Crypto Project KPI & Operating Metrics',
    sdk_name: 'getProtocolTokenMetrics',
    sdk_display_name: 'Protocol Token TVL',
    source_name: 'DefiLlama',
    source: 'https://api-docs.defillama.com/#tag/tvl'
};

const getProtocolCliffAllocationRef = {
    id: '@alva/data/crypto/defi/getProtocolCliffAllocation',
    module_name: '@alva/data/crypto/defi',
    module_display_name: 'Crypto Project KPI & Operating Metrics',
    sdk_name: 'getProtocolCliffAllocation',
    sdk_display_name: 'Token Unlocks - Cliff Allocations',
    source_name: 'DefiLlama',
    source: 'https://api-docs.defillama.com/#tag/unlocks'
};

const getProtocolLinearAllocationRef = {
    id: '@alva/data/crypto/defi/getProtocolLinearAllocation',
    module_name: '@alva/data/crypto/defi',
    module_display_name: 'Crypto Project KPI & Operating Metrics',
    sdk_name: 'getProtocolLinearAllocation',
    sdk_display_name: 'Token Unlocks - Linear Allocations',
    source_name: 'DefiLlama',
    source: 'https://api-docs.defillama.com/#tag/unlocks'
};

const getDexVolumeSummaryRef = {
    id: '@alva/data/crypto/defi/getDexVolumeSummary',
    module_name: '@alva/data/crypto/defi',
    module_display_name: 'Crypto Project KPI & Operating Metrics',
    sdk_name: 'getDexVolumeSummary',
    sdk_display_name: 'DEX Volume Series',
    source_name: 'DefiLlama',
    source: 'https://api-docs.defillama.com/#tag/volumes'
};

function getDefiProtocolVolume(params) {
    useCredit('getDefiProtocolVolume', 350);
    return defiLlamaSDK.getDLDexVolumeSummary(params);
}

function getDefiProtocolUserActivity(params) {
    useCredit('getDefiProtocolUserActivity', 350);
    if (!params.name) {
        throw new Error("The 'name' parameter is required.");
    }
    const name = {name: params.name};
    const id = sdkRelay('GetProtocolId', name);
    const param = {
        protocol_id: id,
        type: params.type,
    }
    return defiLlamaSDK.getDLProtocolUserActivity(param);
}

/**
 * Get DeFi protocol fees and revenue data with credit tracking
 */
function getDefiProtocolFeesAndRevenue(params) {
    useCredit('getDefiProtocolFeesAndRevenue', 350);
    return sdkRelay('GetDefiProtocolFeesAndRevenue', params);
}

function getProtocolChainMetrics(params) {
    useCredit('getProtocolChainMetrics', 350);
    return sdkRelay('GetProtocolChainMetrics', params);
}

function getProtocolTokenMetrics(params) {
    useCredit('getProtocolTokenMetrics', 350);
    return sdkRelay('GetProtocolTokenMetrics', params);
}

function getProtocolTokenUnlockSeriesData(params){
    useCredit('getProtocolTokenUnlockSeriesData', 350);
    return sdkRelay('GetProtocolTokenUnlock', params);
}

function getProtocolCliffAllocation(params){
    useCredit('getProtocolCliffAllocation', 350);
    return sdkRelay('GetProtocolCliffAllocation', params);
}

function getProtocolLinearAllocation(params){
    useCredit('getProtocolLinearAllocation', 350);
    return sdkRelay('GetProtocolLinearAllocation', params);
}

function getDexVolumeSummary(params){
    useCredit('getDexVolumeSummary', 350);
    return sdkRelay('GetDexVolumeSummary',params);
}

/**
 * Nodified SDK: DEX Volume node
 * Params are exactly the same as getDefiProtocolVolume(params).
 */
function makeDefiProtocolVolumeNode(params) {
    return {
        inputs: {
            volume_raw: () => getDefiProtocolVolume(params),
        },
        outputs: {
            volume_summary: {
                name: 'dex_volume_summary',
                description: 'DEX volume summary snapshot at run time.',
                fields: [
                    { name: 'date', type: 'number', description: 'snapshot time ms (UTC)' },
                    { name: 'protocol_name', type: 'string', description: 'DEX protocol name' },
                    {
                        name: 'chains',
                        type: 'array',
                        description: 'blockchains where the DEX operates',
                        fields: [{ name: 'chain', type: 'string', description: 'blockchain name' }],
                    },
                    { name: 'total_volume_24h', type: 'number', description: 'total volume in the past 24 hours (USD)' },
                    { name: 'total_volume_all_time', type: 'number', description: 'cumulative total volume (USD)' },
                ],
                ref: createReferenceWithTitle(getDefiProtocolVolumeRef, params, buildGetDefiProtocolVolumeCallDescription),
            },
            historical_volume: {
                name: 'historical_volume',
                description: 'Daily volume time series for the DEX.',
                fields: [
                    { name: 'date', type: 'number', description: 'day start time ms (UTC)' },
                    { name: 'volume', type: 'number', description: 'daily volume in USD' },
                ],
                ref: createReferenceWithTitle(getDefiProtocolVolumeRef, params, buildGetDefiProtocolVolumeCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.volume_raw;
            const seriesIn = raw.totalDataChart;

            const mapPoint = (pt) => {
                return { date: toMs(pt[0]), volume: Number(pt[1]) };
            };

            const mapped = seriesIn.map(mapPoint);
            const historical = ensureUniqueDates(mapped);

            // Build summary snapshot
            const summary = {
                date: Date.now(),
                protocol_name: raw.name || raw.displayName,
                chains: raw.chains.map((c) => ({ chain: String(c) })),
                total_volume_24h: raw.total24h,
                total_volume_all_time: raw.totalAllTime,
            };

            return {
                volume_summary: [summary],
                historical_volume: historical,
            };
        },
    };
}

/**
 * Nodified SDK: Protocol User Activity node
 * Params are exactly the same as getDefiProtocolUserActivity(params).
 */
function makeDefiProtocolUserActivityNode(params) {
    const activityType = params && params.type ? params.type : 'users';
    return {
        inputs: {
            activity_raw: () => getDefiProtocolUserActivity(params),
        },
        outputs: {
            user_activity: {
                name: 'protocol_user_activity',
                description: 'Protocol user activity time series data.',
                fields: [
                    { name: 'date', type: 'number', description: 'day start time ms (UTC)' },
                    { name: 'protocol_id', type: 'number', description: 'protocol ID' },
                    { name: 'activity_type', type: 'string', description: "one of: 'users' | 'txs' | 'gas' | 'newusers'" },
                    { name: 'value', type: 'number', description: 'activity value (users count, tx count, gas cost, or new users)' },
                ],
                ref: createReferenceWithTitle(getDefiProtocolUserActivityRef, params, buildGetDefiProtocolUserActivityCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.activity_raw;

            if (!Array.isArray(raw)) {
                throw new Error(`Expected array but got ${typeof raw}: ${JSON.stringify(raw)}`);
            }

            const mapPoint = (pt) => {
                return {
                    date: toMs(pt[0]),
                    protocol_id: params.protocol_id,
                    activity_type: activityType,
                    value: Number(pt[1]),
                };
            };
            const mapped = raw.map(mapPoint);
            const userActivity = ensureUniqueDates(mapped);

            return {
                user_activity: userActivity,
            };
        },
    };
}

/**
 * Nodified SDK: Fees/Revenue node
 * Params are exactly the same as getDefiProtocolFeesAndRevenue(params).
 */
function makeDefiProtocolFeesAndRevenueNode(params) {
    const dataType = params && params.data_type ? params.data_type : 'dailyFees';
    return {
        inputs: {
            financials_raw: () => getDefiProtocolFeesAndRevenue(params),
        },
        outputs: {
            summary_snapshot: {
                name: 'protocol_financials_summary_snapshot',
                description: 'Summary snapshot for protocol financials (fees/revenue) at run time.',
                fields: [
                    { name: 'date', type: 'number', description: 'snapshot time ms (UTC)' },
                    { name: 'protocol_name', type: 'string', description: 'protocol name' },
                    { name: 'description', type: 'string', description: 'protocol description' },
                    { name: 'symbol', type: 'string', description: 'protocol token symbol' },
                    {
                        name: 'chains',
                        type: 'array',
                        description: 'blockchains where the protocol operates',
                        fields: [{ name: 'chain', type: 'string', description: 'blockchain name' }],
                    },
                ],
                ref: createReferenceWithTitle(getDefiProtocolFeesAndRevenueRef, params, buildGetDefiProtocolFeesAndRevenueCallDescription),
            },
            historical_breakdown: {
                name: 'protocol_financials_historical_breakdown',
                description: 'Historical breakdown of protocol financials by chain.',
                fields: [
                    { name: 'date', type: 'number', description: 'timestamp ms (UTC)' },
                    { name: 'chain_data', type: 'string', description: 'JSON string of chain-specific data for this timestamp' },
                ],
                ref: createReferenceWithTitle(getDefiProtocolFeesAndRevenueRef, params, buildGetDefiProtocolFeesAndRevenueCallDescription),
            },
        },
        run: (inputs) => {
            const raw = inputs.financials_raw;

            // Build simplified summary with fields that actually exist in the response
            const summary = {
                date: Date.now(),
                protocol_name: raw.name ,
                description: raw.description ,
                symbol: raw.symbol ,
                chains: (raw.chains ).map((c) => ({ chain: String(c) })),
            };

            // Process historical breakdown data
            const breakdown = (raw.total_data_chart_breakdown ).map((item) => ({
                date: toMs(item.timestamp),
                chain_data: JSON.stringify(item.data ),
            }));

            const uniqueBreakdown = ensureUniqueDates(breakdown);

            return {
                summary_snapshot: [summary],
                historical_breakdown: uniqueBreakdown
            };
        },
    };
}


/**
 * Node Factory: Creates a node for fetching and processing on-chain data for a protocol.
 * @param {object} params - Parameters to be passed to the SDK call.
 * @returns {object} A node object containing `inputs`, `outputs`, and a `run` method.
 */
function makeProtocolChainMetricsNode(params) {
    return {
        /**
         * Defines the input data sources for the node.
         */
        inputs: {
            raw_records: () => getProtocolChainMetrics(params),
        },
        /**
         * Defines the output data structure (schema) for the node.
         * MODIFIED: Simplified the structure to have tvlUsd directly.
         */
        outputs: {
            protocol_chain_tvls: {
                name: 'protocol_chain_tvls',
                description: 'Protocol TVL data, grouped by date. Each date contains TVL for all its chains.',
                fields: [
                    { name: 'date', type: 'string', description: 'Record date (Unix timestamp in seconds)' },
                    {
                        name: 'chains',
                        type: 'array',
                        description: 'Data for all chains on this date.',
                        fields: [
                            { name: 'protocolId', type: 'string', description: 'Protocol identifier' },
                            { name: 'chainName', type: 'string', description: 'The name of the chain' },
                            // The 'metrics' array has been replaced with a direct 'tvlUsd' field.
                            { name: 'tvlUsd', type: 'number', description: 'The Total Value Locked in USD' }
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getProtocolChainMetricsRef, params, buildGetProtocolChainMetricsCallDescription),
            },
        },
        /**
         * The node's execution logic, responsible for transforming input data into the output format.
         */
        run: (inputs) => {
            // Use optional chaining ?. for safer access, and provide a default empty array.
            const raw = inputs.raw_records;

            const byDate = new Map();

            for (const record of raw) {
                const dateKey = record.record_date;

                let chainsMap = byDate.get(dateKey);
                if (!chainsMap) {
                    chainsMap = new Map();
                    byDate.set(dateKey, chainsMap);
                }

                const chainKey = record.chain_name;

                // This logic correctly reads snake_case from the input `record`
                // and creates an object with camelCase keys for the output.
                chainsMap.set(chainKey, {
                    protocolId: record.protocol_id,
                    chainName: record.chain_name,
                    tvlUsd: record.tvl_usd
                });
            }

            const sortedDates = Array.from(byDate.keys()).sort((a, b) => Number(a) - Number(b));

            const out = sortedDates.map((date) => {
                const chainsMap = byDate.get(date);
                // The sort correctly accesses `a.chainName` (camelCase) because
                // you created the objects with that key.
                const chains = Array.from(chainsMap.values())
                    .sort((a, b) => String(a.chainName).localeCompare(String(b.chainName)));

                return { date, chains };
            });

            return { protocol_chain_tvls: out };
        },
    };
}

/**
 * Node Factory: Creates a node for fetching and processing on-chain data for a protocol.
 * @param {object} params - Parameters to be passed to the SDK call.
 * @returns {object} A node object containing `inputs`, `outputs`, and a `run` method.
 */
function makeProtocolTokenMetricsNode(params) {
    return {
        /**
         * Defines the input data sources for the node.
         */
        inputs: {
            raw_records: () => getProtocolTokenMetrics(params),
        },
        /**
         * Defines the output data structure (schema) for the node.
         * MODIFIED: Simplified the structure to have tvlUsd directly.
         */
        outputs: {
            protocol_token_tvls: {
                name: 'protocol_token_tvls',
                description: 'Protocol TVL data, grouped by date. Each date contains TVL for all its token.',
                fields: [
                    { name: 'date', type: 'string', description: 'Record date (Unix timestamp in seconds)' },
                    {
                        name: 'tokens',
                        type: 'array',
                        description: 'Data for all tokens on this date.',
                        fields: [
                            { name: 'protocolId', type: 'string', description: 'Protocol identifier' },
                            { name: 'tokenName', type: 'string', description: 'The name of the token' },
                            // The 'metrics' array has been replaced with a direct 'tvlUsd' field.
                            { name: 'tvlUsd', type: 'number', description: 'The Total Value Locked in USD' }
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getProtocolTokenMetricsRef, params, buildGetProtocolTokenMetricsCallDescription),
            },
        },
        /**
         * The node's execution logic, responsible for transforming input data into the output format.
         */
        run: (inputs) => {
            // Use optional tokening ?. for safer access, and provide a default empty array.
            const raw = inputs.raw_records

            const byDate = new Map();

            for (const record of raw) {
                const dateKey = record.record_date;

                let tokensMap = byDate.get(dateKey);
                if (!tokensMap) {
                    tokensMap = new Map();
                    byDate.set(dateKey, tokensMap);
                }

                const tokenKey = record.token_name;

                // This logic correctly reads snake_case from the input `record`
                // and creates an object with camelCase keys for the output.
                tokensMap.set(tokenKey, {
                    protocolId: record.protocol_id,
                    tokenName: record.token_name,
                    tvlUsd: record.tvl_usd
                });
            }

            const sortedDates = Array.from(byDate.keys()).sort((a, b) => Number(a) - Number(b));

            const out = sortedDates.map((date) => {
                const tokensMap = byDate.get(date);
                // The sort correctly accesses `a.tokenName` (camelCase) because
                // you created the objects with that key.
                const tokens = Array.from(tokensMap.values())
                    .sort((a, b) => String(a.tokenName).localeCompare(String(b.tokenName)));

                return { date, tokens };
            });

            return { protocol_token_tvls: out };
        },
    };
}

/**
 * Node Factory: Creates a node for fetching and processing token unlock time series data for a protocol.
 * @param {object} params - Parameters to be passed to the SDK call.
 * @returns {object} A node object containing `inputs`, `outputs`, and a `run` method.
 */
function makeProtocolTokenUnlockSeriesDataNode(params) {
    return {
        /**
         * Defines the input data sources for the node.
         */
        inputs: {
            raw_unlocks: () => getProtocolTokenUnlockSeriesData(params),
        },
        /**
         * Defines the output data structure (schema) for the node.
         * The data is structured as a time series, grouped by timestamp. Each timestamp
         * contains unlock data for all recipients on that date.
         */
        outputs: {
            protocol_unlock_series: {
                name: 'protocol_unlock_series',
                description: 'Protocol token unlock data, grouped by date. Each date contains unlock data for all recipients.',
                fields: [
                    { name: 'date', type: 'number', description: 'Record timestamp (Unix, in seconds)' },
                    {
                        name: 'recipients',
                        type: 'array',
                        description: 'Unlock data for all recipients on this date.',
                        fields: [
                            { name: 'protocolSlug', type: 'string', description: 'The slug identifier of the protocol' },
                            { name: 'name', type: 'string', description: 'The name of the token or unlock event' },
                            { name: 'recipient', type: 'string', description: 'The entity receiving the unlocked tokens' },
                            { name: 'unlockedAmount', type: 'number', description: 'The net amount of tokens unlocked' },
                            { name: 'rawEmission', type: 'number', description: 'The gross amount of tokens emitted' },
                            { name: 'burned', type: 'number', description: 'The amount of tokens burned' }
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getProtocolTokenUnlockSeriesDataRef, params, buildGetProtocolTokenUnlockSeriesDataCallDescription),
            },
        },
        /**
         * The node's execution logic, responsible for transforming input data into the output format.
         */
        run: (inputs) => {
            const raw = inputs.raw_unlocks;

            // Use a Map to group records by timestamp. The value will be another Map grouping by recipient.
            const byDate = new Map();

            for (const record of raw) {
                const dateKey = record.timestamp;

                // Get or create the inner map for the current date.
                let recipientMap = byDate.get(dateKey);
                if (!recipientMap) {
                    recipientMap = new Map();
                    byDate.set(dateKey, recipientMap);
                }

                const recipientKey = record.recipient;

                // Store the processed data, converting snake_case to camelCase.
                recipientMap.set(recipientKey, {
                    protocolSlug: record.protocol_slug,
                    name: record.name,
                    recipient: record.recipient,
                    unlockedAmount: record.unlocked_amount,
                    rawEmission: record.raw_emission,
                    burned: record.burned,
                });
            }

            // Get all unique timestamps and sort them chronologically.
            const sortedDates = Array.from(byDate.keys()).sort((a, b) => a - b);

            // Map over the sorted dates to create the final structured output.
            const out = sortedDates.map((date) => {
                const recipientMap = byDate.get(date);

                // For each date, get all recipient data and sort it alphabetically by recipient name.
                const recipients = Array.from(recipientMap.values())
                    .sort((a, b) => a.recipient.localeCompare(b.recipient));

                return { date: date, recipients: recipients };
            });

            return { protocol_unlock_series: out };
        },
    };
}

/**
 * Creates a node for fetching and processing protocol cliff allocation data.
 * @param {object} params - The parameters for the getProtocolCliffAllocation function.
 * @returns {object} A node object with inputs, outputs, and a run function.
 */
function makeProtocolCliffAllocationNode(params) {
    return {
        // Input source: fetches raw cliff allocation data.
        inputs: {
            cliff_allocations_raw: () => getProtocolCliffAllocation(params),
        },
        // Defines the structure of the final output data.
        outputs: {
            cliff_allocations: {
                name: 'Protocol Cliff Allocations',
                description: 'Vesting cliff events for a specified protocol',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'The unique timestamp for the vesting event (in milliseconds)',
                    },
                    {
                        name: 'protocol_slug',
                        type: 'string',
                        description: 'The slug of the protocol',
                    },
                    {
                        name: 'recipient',
                        type: 'string',
                        description: 'The recipient of the allocation',
                    },
                    {
                        name: 'category',
                        type: 'string',
                        description: 'The category of the allocation (e.g., "Team", "Investors")',
                    },
                    {
                        name: 'amount',
                        type: 'number',
                        description: 'The amount of tokens vested in this event',
                    },
                    {
                        name: 'name',
                        type: 'string',
                        description: 'The name associated with the allocation event',
                    },
                ],
                ref: createReferenceWithTitle(getProtocolCliffAllocationRef, params, buildGetProtocolCliffAllocationCallDescription),
            },
        },
        // The processing logic to transform raw data to the final output structure.
        run: (inputs) => {
            // Safely get the raw data and create a copy.
            const raw = Array.isArray(inputs.cliff_allocations_raw)
                ? inputs.cliff_allocations_raw.slice()
                : [];

            // 1. Sort the array by the event timestamp to handle potential duplicates correctly.
            raw.sort((a, b) => (a?.event_timestamp ?? 0) - (b?.event_timestamp ?? 0));

            const out = [];
            for (let i = 0; i < raw.length; i++) {
                const allocation = raw[i] || {};
                const baseMs = toMs(allocation.event_timestamp);

                // Skip if the timestamp is invalid.
                if (baseMs == null) continue;

                let date = baseMs;

                // 2. **CORRECTED LOGIC:** Get the last date from the output array.
                const lastDate = out.length > 0 ? out[out.length - 1].date : -1;

                // If the current timestamp is not strictly greater than the last one we added,
                // set it to be 1ms after the last one.
                if (date <= lastDate) {
                    date = lastDate + 1;
                }

                // 3. Push the processed object into the output array.
                out.push({
                    date, // The unique date in milliseconds
                    protocol_slug: allocation.protocol_slug,
                    recipient: allocation.recipient,
                    category: allocation.category,
                    amount: allocation.amount,
                    name: allocation.name,
                });
            }

            // 4. Return the final data structured as defined in 'outputs'.
            return { cliff_allocations: out };
        },
    };
}

/**
 * Creates a node for fetching and processing protocol linear allocation data.
 * @param {object} params - The parameters for the getLinearAllocation function.
 * @returns {object} A node object with inputs, outputs, and a run function.
 */
function makeProtocolLinearAllocationNode(params) {
    return {
        // Input source: fetches raw linear allocation data.
        inputs: {
            linear_allocations_raw: () => getProtocolLinearAllocation(params),
        },
        // Defines the structure of the final output data.
        outputs: {
            linear_allocations: {
                name: 'Protocol Linear Allocations',
                description: 'A time series of linear vesting events for a specified protocol.',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'The unique timestamp for the vesting rate change event (in milliseconds)',
                    },
                    {
                        name: 'protocol_slug',
                        type: 'string',
                        description: 'The slug of the protocol',
                    },
                    {
                        name: 'recipient',
                        type: 'string',
                        description: 'The recipient of the allocation',
                    },
                    {
                        name: 'category',
                        type: 'string',
                        description: 'The category of the allocation (e.g., "Team", "Investors")',
                    },
                    {
                        name: 'new_rate_per_week',
                        type: 'number',
                        description: 'The new rate of token emission per week',
                    },
                    {
                        name: 'end_timestamp',
                        type: 'number',
                        description: 'The timestamp when this emission period ends (in milliseconds)',
                    },
                    {
                        name: 'name',
                        type: 'string',
                        description: 'The name associated with the allocation event',
                    },
                ],
                ref: createReferenceWithTitle(getProtocolLinearAllocationRef, params, buildGetLinearAllocationCallDescription),
            },
        },
        // The processing logic to transform raw data to the final output structure.
        run: (inputs) => {
            const raw = Array.isArray(inputs.linear_allocations_raw)
                ? inputs.linear_allocations_raw.slice()
                : [];

            // 1. Sort the array by the event timestamp to ensure chronological order.
            raw.sort((a, b) => (a?.event_timestamp ?? 0) - (b?.event_timestamp ?? 0));

            const out = [];
            for (let i = 0; i < raw.length; i++) {
                const allocation = raw[i] || {};
                const baseMs = toMs(allocation.event_timestamp);

                if (baseMs == null) continue;

                let date = baseMs;

                // 2. Ensure date uniqueness using the robust method.
                const lastDate = out.length > 0 ? out[out.length - 1].date : -1;
                if (date <= lastDate) {
                    date = lastDate + 1;
                }

                // 3. Push the processed object into the output array.
                out.push({
                    date, // The unique date in milliseconds
                    protocol_slug: allocation.protocol_slug,
                    recipient: allocation.recipient,
                    category: allocation.category,
                    new_rate_per_week: allocation.new_rate_per_week,
                    end_timestamp: toMs(allocation.end_timestamp), // Also convert the end timestamp
                    name: allocation.name,
                });
            }

            // 4. Return the final data structured as defined in 'outputs'.
            return { linear_allocations: out };
        },
    };
}

/**
 * Creates a data processing node that fetches DEX volume data and transforms it
 * into a time series format. The resulting data is grouped by date, with each
 * date containing an array of all volume breakdowns for that day.
 * @param {object} params - The parameters required by the input data fetcher,
 * typically including protocol_id, start_time, and end_time.
 */
function makeDexVolumeSummaryNode(params) {
    return {
        /**
         * Defines the input data sources for the node.
         */
        inputs: {
            raw_volumes: () => getDexVolumeSummary(params),
        },

        /**
         * Defines the output data structure (schema) for the node.
         * The data is structured as a time series, grouped by timestamp. Each timestamp
         * contains an array of volume breakdown data points for that day.
         */
        outputs: {
            dex_volume_series: {
                name: 'dex_volume_series',
                description: 'DEX volume data, grouped by date. Each date contains an array of volume breakdowns.',
                fields: [
                    { name: 'date', type: 'number', description: 'Record timestamp (Unix, in seconds)' },
                    {
                        name: 'breakdowns',
                        type: 'array',
                        description: 'All volume breakdowns for this date.',
                        fields: [
                            { name: 'chain', type: 'string', description: 'The blockchain where the volume occurred' },
                            { name: 'version', type: 'string', description: 'The protocol version that generated the volume' },
                            { name: 'volume', type: 'number', description: 'The total trading volume for this entry' },
                            { name: 'name', type: 'string', description: 'The name of the protocol' },
                            { name: 'symbol', type: 'string', description: 'The symbol of the protocol\'s native token' },
                            { name: 'protocolSlug', type: 'string', description: 'The slug identifier of the protocol' }
                        ],
                    },
                ],
                ref: createReferenceWithTitle(getDexVolumeSummaryRef, params, buildGetDexVolumeSummaryCallDescription),
            },
        },

        /**
         * The node's execution logic, responsible for transforming the flat input array
         * into a grouped time series output.
         */
        run: (inputs) => {
            // The input is a flat array of daily volume records.
            const raw = inputs.raw_volumes;

            // Use a Map to group records by their 'date' timestamp.
            // The key is the timestamp, and the value is an array of breakdown objects for that day.
            const byDate = new Map();

            for (const record of raw) {
                const dateKey = record.date;

                // Get the existing array for this date, or create a new one if it's the first record for this date.
                let breakdowns = byDate.get(dateKey);
                if (!breakdowns) {
                    breakdowns = [];
                    byDate.set(dateKey, breakdowns);
                }

                // The input 'record' object has the desired structure for the breakdown.
                // Here we ensure consistency by creating a new object, which is good practice.
                // We also convert 'protocol_slug' to 'protocolSlug' if needed, though the JSDoc implies it's already camelCase.
                breakdowns.push({
                    chain: record.chain,
                    version: record.version,
                    volume: record.volume,
                    name: record.name,
                    symbol: record.symbol,
                    protocolSlug: record.protocol_slug, // Assuming input might be snake_case
                });
            }

            // Get all unique timestamps and sort them chronologically to ensure the time series is in order.
            const sortedDates = Array.from(byDate.keys()).sort((a, b) => a - b);

            // Map over the sorted dates to create the final structured output.
            const out = sortedDates.map((date) => {
                const breakdowns = byDate.get(date);

                // Optional: Sort breakdowns for deterministic output (e.g., by chain then version).
                breakdowns.sort((a, b) => {
                    const chainCompare = a.chain.localeCompare(b.chain);
                    if (chainCompare !== 0) return chainCompare;
                    return a.version.localeCompare(b.version);
                });

                return { date: date, breakdowns: breakdowns };
            });

            // The final return value must match the key defined in the 'outputs' schema.
            return { dex_volume_series: out };
        },
    };
}

// -----------------------------------------------------------------------------
// Auto-generated base descriptions and dynamic description builders from doc
// Note: These helpers are internal and intentionally not exported.
// -----------------------------------------------------------------------------

// getDefiProtocolVolume
const baseGetDefiProtocolVolumeDesc = 'Get DEX volume summary';
function buildGetDefiProtocolVolumeCallDescription(actualParams = {}) {
    const parts = [baseGetDefiProtocolVolumeDesc];
    if (actualParams.protocol) parts.push(`for ${actualParams.protocol}`);
    return parts.join(' ').trim();
}

// getDefiProtocolUserActivity
const baseGetDefiProtocolUserActivityDesc = 'Get protocol user activity';
function buildGetDefiProtocolUserActivityCallDescription(actualParams = {}) {
    const parts = [baseGetDefiProtocolUserActivityDesc];
    if (actualParams.name) parts.push(`for ${actualParams.name}`);
    const filters = [];
    if (actualParams.type) filters.push(`Type: ${actualParams.type}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

// getDefiProtocolFeesAndRevenue
const baseGetDefiProtocolFeesAndRevenueDesc = 'Get protocol fees/revenue';
function buildGetDefiProtocolFeesAndRevenueCallDescription(actualParams = {}) {
    const parts = [baseGetDefiProtocolFeesAndRevenueDesc];
    if (actualParams.protocol) parts.push(`for ${actualParams.protocol}`);
    const filters = [];
    if (actualParams.data_type && actualParams.data_type !== 'dailyFees') {
        filters.push(`Data: ${actualParams.data_type}`);
    }
    if (actualParams.start_time && actualParams.end_time) {
        filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
    } else if (actualParams.start_time) {
        filters.push(`Time from: ${actualParams.start_time}`);
    } else if (actualParams.end_time) {
        filters.push(`Time to: ${actualParams.end_time}`);
    }
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

// makeDefiProtocolVolumeNode
const baseMakeDefiProtocolVolumeNodeDesc = 'Create node: DEX volume';
function buildMakeDefiProtocolVolumeNodeCallDescription(actualParams = {}) {
    const parts = [baseMakeDefiProtocolVolumeNodeDesc];
    if (actualParams.protocol) parts.push(`for ${actualParams.protocol}`);
    return parts.join(' ').trim();
}

// makeDefiProtocolUserActivityNode
const baseMakeDefiProtocolUserActivityNodeDesc = 'Create node: protocol user activity';
function buildMakeDefiProtocolUserActivityNodeCallDescription(actualParams = {}) {
    const parts = [baseMakeDefiProtocolUserActivityNodeDesc];
    if (actualParams.name) parts.push(`for ${actualParams.name}`);
    const filters = [];
    if (actualParams.type) filters.push(`Type: ${actualParams.type}`);
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

// makeDefiProtocolFeesAndRevenueNode
const baseMakeDefiProtocolFeesAndRevenueNodeDesc = 'Create node: protocol fees/revenue';
function buildMakeDefiProtocolFeesAndRevenueNodeCallDescription(actualParams = {}) {
    const parts = [baseMakeDefiProtocolFeesAndRevenueNodeDesc];
    if (actualParams.protocol) parts.push(`for ${actualParams.protocol}`);
    const filters = [];
    if (actualParams.data_type && actualParams.data_type !== 'dailyFees') {
        filters.push(`Data: ${actualParams.data_type}`);
    }
    if (actualParams.start_time && actualParams.end_time) {
        filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
    } else if (actualParams.start_time) {
        filters.push(`Time from: ${actualParams.start_time}`);
    } else if (actualParams.end_time) {
        filters.push(`Time to: ${actualParams.end_time}`);
    }
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

// getProtocolChainMetrics
const baseGetProtocolChainMetricsDesc = 'Get protocol chain TVL series';
function buildGetProtocolChainMetricsCallDescription(actualParams = {}) {
    const parts = [baseGetProtocolChainMetricsDesc];
    if (actualParams.protocol_id) parts.push(`for ${actualParams.protocol_id}`);
    const filters = [];
    if (actualParams.start_time && actualParams.end_time) {
        filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
    } else if (actualParams.start_time) {
        filters.push(`Time from: ${actualParams.start_time}`);
    } else if (actualParams.end_time) {
        filters.push(`Time to: ${actualParams.end_time}`);
    }
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

// getProtocolTokenMetrics
const baseGetProtocolTokenMetricsDesc = 'Get protocol token TVL series';
function buildGetProtocolTokenMetricsCallDescription(actualParams = {}) {
    const parts = [baseGetProtocolTokenMetricsDesc];
    if (actualParams.protocol_id) parts.push(`for ${actualParams.protocol_id}`);
    const filters = [];
    if (actualParams.start_time && actualParams.end_time) {
        filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
    } else if (actualParams.start_time) {
        filters.push(`Time from: ${actualParams.start_time}`);
    } else if (actualParams.end_time) {
        filters.push(`Time to: ${actualParams.end_time}`);
    }
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

// getProtocolTokenUnlockSeriesData
const baseGetProtocolTokenUnlockSeriesDataDesc = 'Get token unlocks series';
function buildGetProtocolTokenUnlockSeriesDataCallDescription(actualParams = {}) {
    const parts = [baseGetProtocolTokenUnlockSeriesDataDesc];
    if (actualParams.protocol_id) parts.push(`for ${actualParams.protocol_id}`);
    const filters = [];
    if (actualParams.start_time && actualParams.end_time) {
        filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
    } else if (actualParams.start_time) {
        filters.push(`Time from: ${actualParams.start_time}`);
    } else if (actualParams.end_time) {
        filters.push(`Time to: ${actualParams.end_time}`);
    }
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

// getProtocolCliffAllocation
const baseGetProtocolCliffAllocationDesc = 'Get cliff allocations';
function buildGetProtocolCliffAllocationCallDescription(actualParams = {}) {
    const parts = [baseGetProtocolCliffAllocationDesc];
    if (actualParams.protocol_id) parts.push(`for ${actualParams.protocol_id}`);
    const filters = [];
    if (actualParams.start_time && actualParams.end_time) {
        filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
    } else if (actualParams.start_time) {
        filters.push(`Time from: ${actualParams.start_time}`);
    } else if (actualParams.end_time) {
        filters.push(`Time to: ${actualParams.end_time}`);
    }
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

// getLinearAllocation (doc name)
const baseGetLinearAllocationDesc = 'Get linear allocations';
function buildGetLinearAllocationCallDescription(actualParams = {}) {
    const parts = [baseGetLinearAllocationDesc];
    if (actualParams.protocol_id) parts.push(`for ${actualParams.protocol_id}`);
    const filters = [];
    if (actualParams.start_time && actualParams.end_time) {
        filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
    } else if (actualParams.start_time) {
        filters.push(`Time from: ${actualParams.start_time}`);
    } else if (actualParams.end_time) {
        filters.push(`Time to: ${actualParams.end_time}`);
    }
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

// getDexVolumeSummary
const baseGetDexVolumeSummaryDesc = 'Get DEX volume series';
function buildGetDexVolumeSummaryCallDescription(actualParams = {}) {
    const parts = [baseGetDexVolumeSummaryDesc];
    if (actualParams.protocol_id) parts.push(`for ${actualParams.protocol_id}`);
    const filters = [];
    if (actualParams.start_time && actualParams.end_time) {
        filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);
    } else if (actualParams.start_time) {
        filters.push(`Time from: ${actualParams.start_time}`);
    } else if (actualParams.end_time) {
        filters.push(`Time to: ${actualParams.end_time}`);
    }
    if (filters.length) parts.push(`(${filters.join(', ')})`);
    return parts.join(' ').trim();
}

function getRefs() {
    return [
        getDefiProtocolVolumeRef,
        getDefiProtocolUserActivityRef,
        getDefiProtocolFeesAndRevenueRef,
        getProtocolTokenUnlockSeriesDataRef,
        getProtocolChainMetricsRef,
        getProtocolTokenMetricsRef,
        getProtocolCliffAllocationRef,
        getProtocolLinearAllocationRef,
        getDexVolumeSummaryRef,
    ];
}

module.exports = {
    getDefiProtocolVolume,
    getDefiProtocolUserActivity,
    getDefiProtocolFeesAndRevenue,
    getProtocolChainMetrics,
    getProtocolTokenMetrics,
    getProtocolTokenUnlockSeriesData,
    getProtocolCliffAllocation,
    getProtocolLinearAllocation,
    getDexVolumeSummary,
    makeDefiProtocolVolumeNode,
    makeDefiProtocolUserActivityNode,
    makeDefiProtocolFeesAndRevenueNode,
    makeProtocolChainMetricsNode,
    makeProtocolTokenMetricsNode,
    makeProtocolTokenUnlockSeriesDataNode,
    makeProtocolCliffAllocationNode,
    makeProtocolLinearAllocationNode,
    makeDexVolumeSummaryNode,
    getRefs
};