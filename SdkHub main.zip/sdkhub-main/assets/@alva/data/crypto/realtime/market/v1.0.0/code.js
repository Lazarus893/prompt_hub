// the 'prd' in module is a temporary workaround since those functions lack data in stg.
const { sdkRelay } = require('sdkrelay');
const { useCredit } = require('internal');
const { load } = require('@alva/secret');
const { syncFetch: fetch } = require('net/http');
const coinGlassSDK = require('@alva/external/coinglass:v1.0.0');

const cryptoQuantSDK = require('@alva/external/cryptoquant:v1.0.0');

// Refs derived from tool.json for tracking source metadata
const getOpenInterestRef = {
    id: '@alva/data/crypto/realtime/market/getOpenInterest',
    module_name: '@alva/data/crypto/realtime/market ',
    module_display_name: 'Crypto Realtime Market Analytics',
    sdk_name: 'getOpenInterest',
    sdk_display_name: 'Token Open Interest',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/oi-ohlc-histroy',
};


const getFundingRateRef = {
    id: '@alva/data/crypto/realtime/market/getFundingRate',
    module_name: '@alva/data/crypto/realtime/market ',
    module_display_name: 'Crypto Realtime Market Analytics',
    sdk_name: 'getFundingRate',
    sdk_display_name: 'Token Funding Rate',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/fr-ohlc-histroy',
};


const getFuturePriceRef = {
    id: '@alva/data/crypto/realtime/market/getFuturePrice',
    module_name: '@alva/data/crypto/realtime/market ',
    module_display_name: 'Crypto Realtime Market Analytics',
    sdk_name: 'getFuturePrice',
    sdk_display_name: 'Token Futures Price',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/price-ohlc-history',
};

const getMarginLongShortRef = {
    id: '@alva/data/crypto/realtime/market/getMarginLongShort',
    module_name: '@alva/data/crypto/realtime/market ',
    module_display_name: 'Crypto Realtime Market Analytics',
    sdk_name: 'getMarginLongShort',
    sdk_display_name: 'Bitfinex Margin Long/Short Positions',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/bitfinex-margin-long-short',
};

const getBorrowInterestRateHistoryRef = {
    id: '@alva/data/crypto/realtime/market/getBorrowInterestRateHistory',
    module_name: '@alva/data/crypto/realtime/market ',
    module_display_name: 'Crypto Realtime Market Analytics',
    sdk_name: 'getBorrowInterestRateHistory',
    sdk_display_name: 'Token Borrow Interest Rate',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/borrow-interest-rate',
};

const getFuturesBasisHistoryRef = {
    id: '@alva/data/crypto/realtime/market/getFuturesBasisHistory',
    module_name: '@alva/data/crypto/realtime/market ',
    module_display_name: 'Crypto Realtime Market Analytics',
    sdk_name: 'getFuturesBasisHistory',
    sdk_display_name: 'Token Futures Basis',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/basis',
};

const getWhaleIndexHistoryRef = {
    id: '@alva/data/crypto/realtime/market/getWhaleIndexHistory',
    module_name: '@alva/data/crypto/realtime/market ',
    module_display_name: 'Crypto Realtime Market Analytics',
    sdk_name: 'getWhaleIndexHistory',
    sdk_display_name: 'Crypto Whale Index',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/whale-index',
};

const getCoinbasePremiumIndexRef = {
    id: '@alva/data/crypto/realtime/market/getCoinbasePremiumIndex',
    module_name: '@alva/data/crypto/realtime/market ',
    module_display_name: 'Crypto Realtime Market Analytics',
    sdk_name: 'getCoinbasePremiumIndex',
    sdk_display_name: 'Coinbase Premium Index',
    source_name: 'Coinglass',
    source: 'https://docs.coinglass.com/reference/coinbase-premium-index',
};

// ------------------------------------------------------------
// Auto-generated base descriptions and dynamic description builders
// Derived from docs in ./doc for each function
// These helpers are internal and not exported
// ------------------------------------------------------------

// Helpers for time param extraction
function __pickStartEnd(actualParams) {
    const start = actualParams?.start_time ?? actualParams?.time_start ?? actualParams?.startTime ?? actualParams?.timeStart;
    const end = actualParams?.end_time ?? actualParams?.time_end ?? actualParams?.endTime ?? actualParams?.timeEnd;
    return { start, end };
}

// getRealtimeOpenInterest
const baseGetRealtimeOpenInterestDesc = 'Get realtime open interest';
function buildGetRealtimeOpenInterestCallDescription(actualParams = {}) {
    const parts = [baseGetRealtimeOpenInterestDesc];
    if (actualParams.exchange) {
        parts.push(`from ${actualParams.exchange}`);
    }
    const filters = [];
    if (actualParams.symbol) {
        filters.push(`Symbol: ${actualParams.symbol}`);
    }
    if (actualParams.interval) {
        filters.push(`Interval: ${actualParams.interval}`);
    }
    const { start, end } = __pickStartEnd(actualParams);
    if (start && end) {
        filters.push(`Time: ${start} to ${end}`);
    } else if (start) {
        filters.push(`Time from: ${start}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

// getRealtimeFundingRate
const baseGetRealtimeFundingRateDesc = 'Get realtime futures funding rate';
function buildGetRealtimeFundingRateCallDescription(actualParams = {}) {
    const parts = [baseGetRealtimeFundingRateDesc];
    if (actualParams.exchange) {
        parts.push(`from ${actualParams.exchange}`);
    }
    const filters = [];
    if (actualParams.symbol) {
        filters.push(`Symbol: ${actualParams.symbol}`);
    }
    if (actualParams.interval) {
        filters.push(`Interval: ${actualParams.interval}`);
    }
    const { start, end } = __pickStartEnd(actualParams);
    if (start && end) {
        filters.push(`Time: ${start} to ${end}`);
    } else if (start) {
        filters.push(`Time from: ${start}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

// getRealtimeFuturePrice
const baseGetRealtimeFuturePriceDesc = 'Get realtime futures OHLCV price data';
function buildGetRealtimeFuturePriceCallDescription(actualParams = {}) {
    const parts = [baseGetRealtimeFuturePriceDesc];
    // defaults per doc
    const DEFAULT_EXCHANGE = 'Binance';
    const DEFAULT_SYMBOL = 'BTCUSDT';
    const DEFAULT_INTERVAL = '1d';
    const DEFAULT_LIMIT = 10;

    if (actualParams.exchange && actualParams.exchange !== DEFAULT_EXCHANGE) {
        parts.push(`from ${actualParams.exchange}`);
    } else if (actualParams.exchange && actualParams.exchange === DEFAULT_EXCHANGE) {
        // keep generic, do not show default
    }
    const filters = [];
    if (actualParams.symbol && actualParams.symbol !== DEFAULT_SYMBOL) {
        filters.push(`Symbol: ${actualParams.symbol}`);
    }
    if (actualParams.interval && actualParams.interval !== DEFAULT_INTERVAL) {
        filters.push(`Interval: ${actualParams.interval}`);
    }
    if (actualParams.limit && Number(actualParams.limit) !== DEFAULT_LIMIT) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    const { start, end } = __pickStartEnd(actualParams);
    if (start && end) {
        filters.push(`Time: ${start} to ${end}`);
    } else if (start) {
        filters.push(`Time from: ${start}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

// getRealtimeMarginLongShort
const baseGetRealtimeMarginLongShortDesc = 'Get realtime margin long vs short positions';
function buildGetRealtimeMarginLongShortCallDescription(actualParams = {}) {
    const parts = [baseGetRealtimeMarginLongShortDesc];
    const DEFAULT_SYMBOL = 'BTC';
    const DEFAULT_INTERVAL = '1d';
    const DEFAULT_LIMIT = 1000;

    if (actualParams.exchange) {
        parts.push(`from ${actualParams.exchange}`);
    }
    const filters = [];
    if (actualParams.symbol && actualParams.symbol !== DEFAULT_SYMBOL) {
        filters.push(`Symbol: ${actualParams.symbol}`);
    }
    if (actualParams.interval && actualParams.interval !== DEFAULT_INTERVAL) {
        filters.push(`Interval: ${actualParams.interval}`);
    }
    if (actualParams.limit && Number(actualParams.limit) !== DEFAULT_LIMIT) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    const { start, end } = __pickStartEnd(actualParams);
    if (start && end) {
        filters.push(`Time: ${start} to ${end}`);
    } else if (start) {
        filters.push(`Time from: ${start}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

// getRealtimeBorrowInterestRateHistory
const baseGetRealtimeBorrowInterestRateHistoryDesc = 'Get realtime borrow interest rate history';
function buildGetRealtimeBorrowInterestRateHistoryCallDescription(actualParams = {}) {
    const parts = [baseGetRealtimeBorrowInterestRateHistoryDesc];
    const DEFAULT_LIMIT = 500;

    if (actualParams.exchange) {
        parts.push(`from ${actualParams.exchange}`);
    }
    const filters = [];
    if (actualParams.symbol) {
        filters.push(`Symbol: ${actualParams.symbol}`);
    }
    if (actualParams.interval) {
        filters.push(`Interval: ${actualParams.interval}`);
    }
    if (actualParams.limit && Number(actualParams.limit) !== DEFAULT_LIMIT) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    const { start, end } = __pickStartEnd(actualParams);
    if (start && end) {
        filters.push(`Time: ${start} to ${end}`);
    } else if (start) {
        filters.push(`Time from: ${start}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

// getRealtimeFuturesBasisHistory
const baseGetRealtimeFuturesBasisHistoryDesc = 'Get realtime futures basis history';
function buildGetRealtimeFuturesBasisHistoryCallDescription(actualParams = {}) {
    const parts = [baseGetRealtimeFuturesBasisHistoryDesc];
    const DEFAULT_EXCHANGE = 'Binance';
    const DEFAULT_SYMBOL = 'BTCUSDT';
    const DEFAULT_INTERVAL = '1d';
    const DEFAULT_LIMIT = 10;

    if (actualParams.exchange && actualParams.exchange !== DEFAULT_EXCHANGE) {
        parts.push(`from ${actualParams.exchange}`);
    }
    const filters = [];
    if (actualParams.symbol && actualParams.symbol !== DEFAULT_SYMBOL) {
        filters.push(`Symbol: ${actualParams.symbol}`);
    }
    if (actualParams.interval && actualParams.interval !== DEFAULT_INTERVAL) {
        filters.push(`Interval: ${actualParams.interval}`);
    }
    if (actualParams.limit && Number(actualParams.limit) !== DEFAULT_LIMIT) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    const { start, end } = __pickStartEnd(actualParams);
    if (start && end) {
        filters.push(`Time: ${start} to ${end}`);
    } else if (start) {
        filters.push(`Time from: ${start}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

// getRealtimeWhaleIndexHistory
const baseGetRealtimeWhaleIndexHistoryDesc = 'Get realtime Whale Index history';
function buildGetRealtimeWhaleIndexHistoryCallDescription(actualParams = {}) {
    const parts = [baseGetRealtimeWhaleIndexHistoryDesc];
    const DEFAULT_EXCHANGE = 'Binance';
    const DEFAULT_SYMBOL = 'BTCUSDT';
    const DEFAULT_INTERVAL = '1d';
    const DEFAULT_LIMIT = 1000;

    if (actualParams.exchange && actualParams.exchange !== DEFAULT_EXCHANGE) {
        parts.push(`from ${actualParams.exchange}`);
    }
    const filters = [];
    if (actualParams.symbol && actualParams.symbol !== DEFAULT_SYMBOL) {
        filters.push(`Symbol: ${actualParams.symbol}`);
    }
    if (actualParams.interval && actualParams.interval !== DEFAULT_INTERVAL) {
        filters.push(`Interval: ${actualParams.interval}`);
    }
    if (actualParams.limit && Number(actualParams.limit) !== DEFAULT_LIMIT) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    const { start, end } = __pickStartEnd(actualParams);
    if (start && end) {
        filters.push(`Time: ${start} to ${end}`);
    } else if (start) {
        filters.push(`Time from: ${start}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

// getRealtimeCoinbasePremiumIndex
const baseGetRealtimeCoinbasePremiumIndexDesc = 'Get realtime Coinbase Bitcoin Premium Index';
function buildGetRealtimeCoinbasePremiumIndexCallDescription(actualParams = {}) {
    const parts = [baseGetRealtimeCoinbasePremiumIndexDesc];
    const DEFAULT_INTERVAL = '1d';
    const DEFAULT_LIMIT = 1000;

    const filters = [];
    if (actualParams.interval && actualParams.interval !== DEFAULT_INTERVAL) {
        filters.push(`Interval: ${actualParams.interval}`);
    }
    if (actualParams.limit && Number(actualParams.limit) !== DEFAULT_LIMIT) {
        filters.push(`Limit: ${actualParams.limit}`);
    }
    const { start, end } = __pickStartEnd(actualParams);
    if (start && end) {
        filters.push(`Time: ${start} to ${end}`);
    } else if (start) {
        filters.push(`Time from: ${start}`);
    }
    if (filters.length > 0) {
        parts.push(`(${filters.join(', ')})`);
    }
    return parts.join(' ').trim();
}

// Helper to attach a dynamic title to a reference object
function createReferenceWithTitle(refObject, params, titleBuilder) {
    // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
    const title = titleBuilder(params);

    // 2. 组合 refObject 和新 title
    const newObject = {
        ...refObject,
        title: title
    };

    // 3. 返回新对象
    return newObject;
}

function getRealtimeOpenInterest(params) {
    useCredit('getOpenInterest', 3500);
    const items = coinGlassSDK.getCGOpenInterest(params);
    return items.map((item) => {
        return {
            time: toMs(item.time),
            open: parseNumber(item.open),
            close: parseNumber(item.close),
            low: parseNumber(item.low),
            high: parseNumber(item.high)
        };
    });
}

function getRealtimeFundingRate(params) {
    useCredit('getFundingRate', 3500);
    const items = coinGlassSDK.getCGFundingRate(params);
    return items.map((item) => {
        return {
            time: toMs(item.time),
            open: parseNumber(item.open),
            close: parseNumber(item.close),
            low: parseNumber(item.low),
            high: parseNumber(item.high)
        };
    });
}


function getRealtimeFuturePrice(params) {
    useCredit('getFuturePrice', 350);
    const items = coinGlassSDK.getFuturePrice(params);
	return items.map((item) => {
		return {
			time: toMs(item.time),
			open: parseNumber(item.open),
			high: parseNumber(item.high),
			low: parseNumber(item.low),
			close: parseNumber(item.close),
			volume: parseNumber(item.volume_usd),
		};
	});
}

function getRealtimeMarginLongShort(params) {
    useCredit('getMarginLongShort', 350);
    const items = coinGlassSDK.getMarginLongShort(params);
    return items.map((item) => {
        return {
            time: toMs(item.time),
            long_quantity: parseNumber(item.longQuantity || item.long_quantity),
            short_quantity: parseNumber(item.shortQuantity || item.short_quantity)
        };
    });
}

function getRealtimeBorrowInterestRateHistory(params) {
    useCredit('getBorrowInterestRateHistory', 350);
    const items = coinGlassSDK.getBorrowInterestRateHistory(params);
    return items.map((item) => {
        return {
            time: toMs(item.time),
            interest_rate: parseNumber(item.interestRate || item.interest_rate)
        };
    });
}

function getRealtimeFuturesBasisHistory(params) {
    useCredit('getFuturesBasisHistory', 350);
    const items = coinGlassSDK.getFuturesBasisHistory(params);
    return items.map((item) => {
        return {
            time: toMs(item.time),
            open_basis: parseNumber(item.openBasis || item.open_basis),
            close_basis: parseNumber(item.closeBasis || item.close_basis),
            open_change: parseNumber(item.openChange || item.open_change),
            close_change: parseNumber(item.closeChange || item.close_change)
        };
    });
}

function getRealtimeWhaleIndexHistory(params) {
    useCredit('getWhaleIndexHistory', 350);
    const items = coinGlassSDK.getWhaleIndexHistory(params);
    return items.map((item) => {
        return {
            time: toMs(item.time),
            whale_index_value: parseNumber(item.whaleIndexValue || item.whale_index_value)
        };
    });
}

function getRealtimeCoinbasePremiumIndex(params) {
    useCredit('getCoinbasePremiumIndex', 350);
    const items = coinGlassSDK.getCoinbasePremiumIndex(params);
    return items.map((item) => {
        return {
            time: toMs(item.time),
            premium: parseNumber(item.premium),
            premium_rate: parseNumber(item.premiumRate || item.premium_rate)
        };
    });
}

function toMs(value) {
    if (value == null) {
        return null;
    }
    if (typeof value === 'number') {
        return value > 1e12 ? value : value * 1000;
    }
    if (typeof value === 'string') {
        const parsed = Date.parse(value);
        if (!Number.isNaN(parsed)) {
            return parsed;
        }
    }
    return null;
}

function parseNumber(value) {
    if (value == null) {
        return null;
    }
    const n = Number(value);
    return Number.isNaN(n) ? null : n;
}

function ensureUniqueDates(records) {
    const used = new Set();
    return records.map((item) => {
        const { date: originalDate, ...rest } = item;

        let date = originalDate; // 使用原始日期开始检查
        while (used.has(date)) {
            date += 1;
        }
        used.add(date);

        return {
            date: date,
            ...rest,
        };
    });
}

function deriveRangeDate(params) {
    const end = toMs(params?.time_end || params?.end_time || params?.endTime);
    if (end != null) {
        return end;
    }
    const start = toMs(params?.time_start || params?.start_time || params?.startTime);
    if (start != null) {
        return start;
    }
    return Date.now();
}

function resolveTimestamp(item, fallback) {
    if (!item || typeof item !== 'object') {
        return fallback ?? null;
    }
    const candidates = [
        'timestamp',
        'time',
        'time_ms',
        'timeMs',
        'time_unix',
        'timeUnix',
        'time_unix_ms',
        'date',
        'date_ms',
        'dateString',
        'date_string',
        'updated_at',
        'update_at',
        'updatedAt',
        'updateTime',
        'update_time',
        'created_at',
        'create_time',
        'createTime',
    ];
    for (const key of candidates) {
        if (item[key] == null) {
            continue;
        }
        const ts = toMs(item[key]);
        if (ts != null) {
            return ts;
        }
    }
    return fallback ?? null;
}

function buildTimeSeriesNode(fetchFn, params, config) {
    const { outputName, description, fields, mapRecords, ensureUnique = true, ref } = config;

    return {
        inputs: {
            raw: () => fetchFn(params),
        },
        outputs: {
            [outputName]: {
                name: outputName,
                description,
                fields,
                ...(ref ? { ref } : {}),
            },
        },
        run: (inputs) => {
            const mapped = mapRecords(inputs.raw, params) || [];
            const filtered = mapped
                .map((item) => {
                    if (!item || item.date == null || Number.isNaN(item.date)) {
                        return null;
                    }
                    return item;
                })
                .filter(Boolean);

            const result = ensureUnique ? ensureUniqueDates(filtered) : filtered;
            return { [outputName]: result };
        },
    };
}

function makeRealtimeOpenInterestNode(params) {
    return {
        inputs: {
            open_interest_raw: () => getRealtimeOpenInterest(params),
        },
        outputs: {
            open_interest: {
                name: 'open_interest',
                description: 'Open interest time series',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'timestamp ms',
                    },
                    {
                        name: 'open',
                        type: 'number',
                        description: 'opening price',
                    },
                    {
                        name: 'close',
                        type: 'number',
                        description: 'closing price',
                    },
                    {
                        name: 'low',
                        type: 'number',
                        description: 'lowest price',
                    },
                    {
                        name: 'high',
                        type: 'number',
                        description: 'highest price',
                    },
                ],
                ref: createReferenceWithTitle(getOpenInterestRef, params, buildGetRealtimeOpenInterestCallDescription),
            },
        },
        run: (inputs) => {
            const series = Array.isArray(inputs.open_interest_raw)
                ? inputs.open_interest_raw
                        .map((item) => {
                            const date = toMs(item.time);
                            if (date == null) {
                                return null;
                            }
                            return {
                                date,
                                open: parseNumber(item.open),
                                close: parseNumber(item.close),
                                low: parseNumber(item.low),
                                high: parseNumber(item.high),
                            };
                        })
                        .filter(Boolean)
                : [];
            return { open_interest: ensureUniqueDates(series) };
        },
    };
}

function makeRealtimeFundingRateNode(params) {
    return {
        inputs: {
            funding_rate_raw: () => getRealtimeFundingRate(params),
        },
        outputs: {
            funding_rate: {
                name: 'funding_rate',
                description: 'Futures funding rate time series',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'timestamp ms',
                    },
                    {
                        name: 'open',
                        type: 'number',
                        description: 'opening price',
                    },
                    {
                        name: 'close',
                        type: 'number',
                        description: 'closing price',
                    },
                    {
                        name: 'low',
                        type: 'number',
                        description: 'lowest price',
                    },
                    {
                        name: 'high',
                        type: 'number',
                        description: 'highest price',
                    },
                ],
                ref: createReferenceWithTitle(getFundingRateRef, params, buildGetRealtimeFundingRateCallDescription),
            },
        },
        run: (inputs) => {
            const series = Array.isArray(inputs.funding_rate_raw)
                ? inputs.funding_rate_raw
                        .map((item) => {
                            const date = toMs(item.time);
                            if (date == null) {
                                return null;
                            }
                            return {
                                date,
                                open: parseNumber(item.open),
                                close: parseNumber(item.close),
                                low: parseNumber(item.low),
                                high: parseNumber(item.high),
                            };
                        })
                        .filter(Boolean)
                : [];
            return { funding_rate: ensureUniqueDates(series) };
        },
    };
}


function makeRealtimeFuturePriceNode(params) {
    return {
        inputs: {
            future_price_raw: () => getRealtimeFuturePrice(params),
        },
        outputs: {
            future_ohlcv: {
                name: 'future_ohlcv',
                description: 'Futures OHLCV price data',
                fields: [
                    {
                        name: 'date',
                        type: 'number',
                        description: 'interval start time ms',
                    },
                    { name: 'open', type: 'number', description: 'open price' },
                    { name: 'high', type: 'number', description: 'high price' },
                    { name: 'low', type: 'number', description: 'low price' },
                    {
                        name: 'close',
                        type: 'number',
                        description: 'close price',
                    },
                    {
                        name: 'volume',
                        type: 'number',
                        description: 'trading volume',
                    },
                ],
                ref: createReferenceWithTitle(getFuturePriceRef, params, buildGetRealtimeFuturePriceCallDescription),
            },
        },
        run: (inputs) => {

			const series = Array.isArray(inputs.future_price_raw)
				? inputs.future_price_raw
					.map((item) => {
						const date = toMs(item.time);
						if (date == null) {
							return null;
						}
						return {
							date,
							open: parseNumber(item.open),
							close: parseNumber(item.close),
							low: parseNumber(item.low),
							high: parseNumber(item.high),
							volume:item.volume,
						};
					})
					.filter(Boolean)
				: [];
            return { future_ohlcv: ensureUniqueDates(series) };
        },
    };
}

function makeRealtimeMarginLongShortNode(params) {
    return buildTimeSeriesNode(getRealtimeMarginLongShort, params, {
        outputName: 'margin_long_short',
        description: 'Margin long vs short balances',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            {
                name: 'long_quantity',
                type: 'number',
                description: 'Margin long quantity',
            },
            {
                name: 'short_quantity',
                type: 'number',
                description: 'Margin short quantity',
            },
        ],
        ref: createReferenceWithTitle(getMarginLongShortRef, params, buildGetRealtimeMarginLongShortCallDescription),
        mapRecords: (raw) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = toMs(item.time);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    long_quantity: parseNumber(item.long_quantity),
                    short_quantity: parseNumber(item.short_quantity),
                };
            });
        },
    });
}

function makeRealtimeBorrowInterestRateHistoryNode(params) {
    return buildTimeSeriesNode(getRealtimeBorrowInterestRateHistory, params, {
        outputName: 'borrow_interest_rate_history',
        description: 'Borrow interest rate history',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            {
                name: 'exchange',
                type: 'string',
                description: 'Exchange name',
            },
            { name: 'symbol', type: 'string', description: 'Asset symbol' },
            {
                name: 'interval',
                type: 'string',
                description: 'Data interval',
            },
            {
                name: 'interest_rate',
                type: 'number',
                description: 'Borrow interest rate (decimal)',
            },
        ],
        ref: createReferenceWithTitle(getBorrowInterestRateHistoryRef, params, buildGetRealtimeBorrowInterestRateHistoryCallDescription),
        mapRecords: (raw, params) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = toMs(item.time);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    exchange: params?.exchange || null,
                    symbol: params?.symbol || null,
                    interval: params?.interval || null,
                    interest_rate: parseNumber(item.interest_rate),
                };
            });
        },
    });
}

function makeRealtimeFuturesBasisHistoryNode(params) {
    return buildTimeSeriesNode(getRealtimeFuturesBasisHistory, params, {
        outputName: 'futures_basis_history',
        description: 'Futures basis history',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            {
                name: 'open_basis',
                type: 'number',
                description: 'Opening basis',
            },
            {
                name: 'close_basis',
                type: 'number',
                description: 'Closing basis',
            },
            {
                name: 'open_change',
                type: 'number',
                description: 'Opening basis change %',
            },
            {
                name: 'close_change',
                type: 'number',
                description: 'Closing basis change %',
            },
        ],
        ref: createReferenceWithTitle(getFuturesBasisHistoryRef, params, buildGetRealtimeFuturesBasisHistoryCallDescription),
        mapRecords: (raw) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = toMs(item.time);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    open_basis: parseNumber(item.open_basis),
                    close_basis: parseNumber(item.close_basis),
                    open_change: parseNumber(item.open_change),
                    close_change: parseNumber(item.close_change),
                };
            });
        },
    });
}

function makeRealtimeWhaleIndexHistoryNode(params) {
    return buildTimeSeriesNode(getRealtimeWhaleIndexHistory, params, {
        outputName: 'whale_index_history',
        description: 'Whale index history',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            {
                name: 'whale_index_value',
                type: 'number',
                description: 'Whale index value',
            },
        ],
        ref: createReferenceWithTitle(getWhaleIndexHistoryRef, params, buildGetRealtimeWhaleIndexHistoryCallDescription),
        mapRecords: (raw) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = resolveTimestamp(item);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    whale_index_value: parseNumber(item.whale_index_value ?? item.value),
                };
            });
        },
    });
}

function makeRealtimeCoinbasePremiumIndexNode(params) {
    return buildTimeSeriesNode(getRealtimeCoinbasePremiumIndex, params, {
        outputName: 'coinbase_premium_index',
        description: 'Coinbase Bitcoin Premium Index history',
        fields: [
            { name: 'date', type: 'number', description: 'timestamp ms' },
            {
                name: 'premium',
                type: 'number',
                description: 'Premium amount in USD',
            },
            {
                name: 'premium_rate',
                type: 'number',
                description: 'Premium as decimal rate',
            },
        ],
        ref: createReferenceWithTitle(getCoinbasePremiumIndexRef, params, buildGetRealtimeCoinbasePremiumIndexCallDescription),
        mapRecords: (raw) => {
            const items = Array.isArray(raw) ? raw : [];
            return items.map((item) => {
                const date = toMs(item.time);
                if (date == null) {
                    return null;
                }
                return {
                    date,
                    premium: parseNumber(item.premium),
                    premium_rate: parseNumber(item.premium_rate),
                };
            });
        },
    });
}

function getRefs() {
    return [
        getOpenInterestRef,
        getFundingRateRef,
        getFuturePriceRef,
        getMarginLongShortRef,
        getBorrowInterestRateHistoryRef,
        getFuturesBasisHistoryRef,
        getWhaleIndexHistoryRef,
        getCoinbasePremiumIndexRef,
    ];
}

module.exports = {
	getRealtimeOpenInterest,
	getRealtimeFundingRate,
	getRealtimeFuturePrice,
	getRealtimeMarginLongShort,
	getRealtimeBorrowInterestRateHistory,
	getRealtimeFuturesBasisHistory,
	getRealtimeWhaleIndexHistory,
	getRealtimeCoinbasePremiumIndex,
	makeRealtimeOpenInterestNode,
	makeRealtimeFundingRateNode,
	makeRealtimeFuturePriceNode,
	makeRealtimeMarginLongShortNode,
	makeRealtimeBorrowInterestRateHistoryNode,
	makeRealtimeFuturesBasisHistoryNode,
	makeRealtimeWhaleIndexHistoryNode,
	makeRealtimeCoinbasePremiumIndexNode,
	getRefs,
};