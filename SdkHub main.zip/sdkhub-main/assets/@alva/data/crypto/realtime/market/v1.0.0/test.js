// Assertion helpers
function assert(cond, msg) {
    if (!cond) throw new Error(msg || 'assertion failed');
}

function isInteger(n) {
    return Number.isInteger(n);
}

function isMsEpoch(n) {
    return typeof n === 'number' && isInteger(n) && n > 0 && n > 10_000_000_000;
}

function hasUniqueDates(rows) {
    const s = new Set();
    for (const r of rows) {
        if (s.has(r.date)) return false;
        s.add(r.date);
    }
    return true;
}

function expectFieldsMatch(rows, fieldNames) {
    if (!Array.isArray(rows)) {
        throw new Error('Input "rows" must be an array.');
    }

    for (const r of rows) {
        const got = Object.keys(r);
        assert(got.includes('date'), 'missing required field: "date"');

        // 对其他字段的检查保持不变，.includes() 本身就是不依赖顺序的。
        for (const f of fieldNames) {
            assert(got.includes(f), `missing field: ${f}`);
        }
    }
}

// Node output checker
const { TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');

function checkNodeOutput(
    graph,
    jagentId,
    nodeId,
    outputName,
    {
        expectFields = [], // fields AFTER 'date'
        preloadLast = '200', // how many to read back
        extra = null, // (rows, view) => void for custom assertions
    } = {}
) {
    const uri = new TimeSeriesUri(jagentId, nodeId, outputName, { last: preloadLast });
    const view = new TimeSeries(uri, graph.store);
    view.init(); // preload
    // NOTE: TimeSeries.data is newest-first (descending)
    const rows = view.data.slice(); // array of records

    if (rows.length === 0) {
        throw new Error(`no rows returned for node ${nodeId} output ${outputName}`);
    }

    // Basic invariants
    for (const r of rows) {
        assert(typeof r === 'object' && r != null, 'row must be object');
        assert(isMsEpoch(r.date), `date must be ms epoch, got: ${r.date}`);
    }
    assert(hasUniqueDates(rows), 'duplicate "date" values within one output');

    // Schema check (date-first + declared fields)
    expectFieldsMatch(rows, expectFields);

    // Optional additional checks
    if (typeof extra === 'function') extra(rows, view);
    return rows;
}

// Schema validation helpers
function expectKeysOrdered(row, expected) {
    const keys = Object.keys(row);
    for (let i = 0; i < expected.length; i++) {
        if (keys[i] !== expected[i]) throw new Error(`schema mismatch at ${i}: expected ${expected[i]}, got ${keys[i]}`);
    }
}

function testGraph() {
    const { Graph } = require('@alva/graph:v1.0.0');
    const { jagentId } = require('env');

    const {
        makeRealtimeOpenInterestNode,
        makeRealtimeFundingRateNode,
        makeRealtimeFuturePriceNode,
        makeRealtimeMarginLongShortNode,
        makeRealtimeBorrowInterestRateHistoryNode,
        makeRealtimeFuturesBasisHistoryNode,
        makeRealtimeWhaleIndexHistoryNode,
        makeRealtimeCoinbasePremiumIndexNode,
    } = require('@alva/data/crypto/realtime/market:v1.0.0');

    const graph = new Graph(jagentId);

    // Test getRealtimeOpenInterest - only supports smaller intervals now
    graph.addNode(
        'btc_realtime_open_interest',
        makeRealtimeOpenInterestNode({
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            interval: '4h',
        })
    );

    // Test getRealtimeFundingRate - smaller intervals
    graph.addNode(
        'btc_realtime_funding_rate',
        makeRealtimeFundingRateNode({
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            interval: '4h',
        })
    );


    // Test getRealtimeFuturePrice - smaller intervals
    graph.addNode(
        'btc_realtime_futures_price',
        makeRealtimeFuturePriceNode({
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            interval: '1h',
            limit: 50,
        })
    );

    // Test getRealtimeMarginLongShort - smaller intervals
    graph.addNode(
        'realtime_margin_long_short',
        makeRealtimeMarginLongShortNode({
            exchange: 'Bitfinex',
            symbol: 'ETH',
            interval: '4h',
            limit: 60,
        })
    );

    // Test getRealtimeBorrowInterestRateHistory - smaller intervals
    graph.addNode(
        'realtime_borrow_interest_rate',
        makeRealtimeBorrowInterestRateHistoryNode({
            exchange: 'Binance',
            symbol: 'BTC',
            interval: '1h',
            limit: 5,
        })
    );

    // Test getRealtimeFuturesBasisHistory - smaller intervals
    graph.addNode(
        'realtime_futures_basis_history',
        makeRealtimeFuturesBasisHistoryNode({
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            interval: '1h',
            limit: 5,
        })
    );

    // Test getRealtimeWhaleIndexHistory - smaller intervals
    graph.addNode(
        'realtime_whale_index_history',
        makeRealtimeWhaleIndexHistoryNode({
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            interval: '4h',
            limit: 5,
        })
    );

    // Test getRealtimeCoinbasePremiumIndex - smaller intervals
    graph.addNode(
        'realtime_coinbase_premium_index',
        makeRealtimeCoinbasePremiumIndexNode({
            interval: '1h',
            limit: 5,
        })
    );

    graph.run();

    // Test outputs using the framework
    log('🧪 Testing realtime market node outputs...');

    // Test open interest data
    const oiRows = checkNodeOutput(graph, jagentId, 'btc_realtime_open_interest', 'open_interest', {
        expectFields: ['open', 'close', 'low', 'high'],
        preloadLast: '20',
        extra: (rows) => {
            for (const r of rows) {
                ['open', 'close', 'low', 'high'].forEach((k) => assert(typeof r[k] === 'number' || r[k] === null, `field ${k} must be number or null`));
                if (r.high !== null && r.low !== null) {
                    assert(r.high >= r.low, 'high must be >= low');
                    assert(r.high >= r.open, 'high must be >= open');
                    assert(r.high >= r.close, 'high must be >= close');
                    assert(r.low <= r.open, 'low must be <= open');
                    assert(r.low <= r.close, 'low must be <= close');
                }
            }
        },
    });

    // Test funding rate data
    const frRows = checkNodeOutput(graph, jagentId, 'btc_realtime_funding_rate', 'funding_rate', {
        expectFields: ['open', 'close', 'low', 'high'],
        preloadLast: '20',
        extra: (rows) => {
            for (const r of rows) {
                ['open', 'close', 'low', 'high'].forEach((k) => assert(typeof r[k] === 'number' || r[k] === null, `field ${k} must be number or null`));
                if (r.high !== null && r.low !== null) {
                    assert(r.high >= r.low, 'high must be >= low');
                    assert(r.high >= r.open, 'high must be >= open');
                    assert(r.high >= r.close, 'high must be >= close');
                    assert(r.low <= r.open, 'low must be <= open');
                    assert(r.low <= r.close, 'low must be <= close');
                }
            }
        },
    });

    // Test futures price data
    const futuresPriceRows = checkNodeOutput(graph, jagentId, 'btc_realtime_futures_price', 'future_ohlcv', {
        expectFields: ['open', 'high', 'low', 'close', 'volume'],
        preloadLast: '20',
        extra: (rows) => {
            for (const r of rows) {
                ['open', 'high', 'low', 'close', 'volume'].forEach((k) => assert(typeof r[k] === 'number', `field ${k} must be number`));
                assert(r.high >= r.low, 'high must be >= low');
                assert(r.high >= r.open, 'high must be >= open');
                assert(r.high >= r.close, 'high must be >= close');
                assert(r.low <= r.open, 'low must be <= open');
                assert(r.low <= r.close, 'low must be <= close');
                assert(r.volume >= 0, 'volume must be non-negative');
            }
        },
    });

    // Test margin long/short data
    const marginRows = checkNodeOutput(graph, jagentId, 'realtime_margin_long_short', 'margin_long_short', {
        expectFields: ['long_quantity', 'short_quantity'],
        preloadLast: '20',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.long_quantity === 'number', 'long_quantity must be number');
                assert(typeof r.short_quantity === 'number', 'short_quantity must be number');
                assert(r.long_quantity >= 0, 'long_quantity must be non-negative');
                assert(r.short_quantity >= 0, 'short_quantity must be non-negative');
            }
        },
    });

    // Test borrow interest rate data
    const borrowRows = checkNodeOutput(graph, jagentId, 'realtime_borrow_interest_rate', 'borrow_interest_rate_history', {
        expectFields: ['exchange', 'symbol', 'interval', 'interest_rate'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.exchange === 'string', 'exchange must be string');
                assert(typeof r.symbol === 'string', 'symbol must be string');
                assert(typeof r.interval === 'string', 'interval must be string');
                assert(typeof r.interest_rate === 'number', 'interest_rate must be number');
                assert(r.interest_rate >= 0, 'interest_rate must be non-negative');
            }
        },
    });

    // Test futures basis history data
    const basisRows = checkNodeOutput(graph, jagentId, 'realtime_futures_basis_history', 'futures_basis_history', {
        expectFields: ['open_basis', 'close_basis', 'open_change', 'close_change'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                ['open_basis', 'close_basis', 'open_change', 'close_change'].forEach((k) => {
                    assert(typeof r[k] === 'number', `field ${k} must be number`);
                });
            }
        },
    });

    // Test whale index history data
    const whaleRows = checkNodeOutput(graph, jagentId, 'realtime_whale_index_history', 'whale_index_history', {
        expectFields: ['whale_index_value'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.whale_index_value === 'number' || r.whale_index_value === null, 'whale_index_value must be a number or null');
            }
        },
    });

    // Test Coinbase premium index data
    const premiumRows = checkNodeOutput(graph, jagentId, 'realtime_coinbase_premium_index', 'coinbase_premium_index', {
        expectFields: ['premium', 'premium_rate'],
        preloadLast: '10',
        extra: (rows) => {
            for (const r of rows) {
                assert(typeof r.premium === 'number', 'premium must be number');
                assert(typeof r.premium_rate === 'number', 'premium_rate must be number');
            }
        },
    });

    log('✅ All realtime market tests passed!');
}

function testCryptoMarketFunctions() {
    console.log('\n=== Testing Realtime Crypto Market Functions ===');

    const {
        getRealtimeOpenInterest,
        getRealtimeFundingRate,
        getRealtimeFuturePrice,
        getRealtimeMarginLongShort,
        getRealtimeBorrowInterestRateHistory,
        getRealtimeFuturesBasisHistory,
        getRealtimeWhaleIndexHistory,
        getRealtimeCoinbasePremiumIndex,
    } = require('@alva/data/crypto/realtime/market:v1.0.0');

    // Define test constants for realtime version (smaller intervals only)
    const REALTIME_INTERVALS = ['1m', '3m', '5m', '15m', '30m', '1h', '4h', '6h', '8h', '12h'];
    const EXCHANGES = ['Binance', 'OKX', 'Bybit'];
    const SYMBOLS = ['BTC', 'ETH', 'BTCUSDT', 'ETHUSDT'];

    let totalTests = 0;
    let passedTests = 0;

    // Helper function to run test and track results
    function runTest(testName, testFunc) {
        totalTests++;
        try {
            testFunc();
            console.log(`✅ ${testName}`);
            passedTests++;
        } catch (e) {
            console.log(`❌ ${testName}: ${e.message}`);
        }
    }

    // ============ getOpenInterest Tests ============
    console.log('\n--- Testing getOpenInterest ---');

    // Test all exchanges and symbols combinations
    for (const exchange of ['Binance', 'Bybit']) {
        for (const symbol of ['BTCUSDT', 'ETHUSDT']) {
            runTest(`getRealtimeOpenInterest with ${exchange} - ${symbol}`, () => {
                const oiData = getRealtimeOpenInterest({
                    symbol: symbol,
                    interval: '1h',
                    exchange: exchange
                });
                assert(Array.isArray(oiData), `Should return array for ${exchange}-${symbol}`);
                if (oiData.length > 0) {
                    const point = oiData[0];
                    assert(typeof point.time === 'number', 'time should be number');
                    assert(typeof point.open === 'number', 'open should be number');
                    assert(typeof point.close === 'number', 'close should be number');
                    assert(typeof point.low === 'number', 'low should be number');
                    assert(typeof point.high === 'number', 'high should be number');
                }
            });
        }
    }

    // Test all realtime intervals for open interest
    for (const interval of REALTIME_INTERVALS) {
        runTest(`getRealtimeOpenInterest with interval ${interval}`, () => {
            const oiData = getRealtimeOpenInterest({
                symbol: 'BTCUSDT',
                interval: interval,
                exchange: 'Binance'
            });
            assert(Array.isArray(oiData), `Should return array for interval ${interval}`);
        });
    }

    // ============ getFundingRate Tests ============
    console.log('\n--- Testing getFundingRate ---');

    // Test all valid symbol combinations
    for (const symbol of ['BTCUSDt', 'ETHUSDT']) {
        for (const exchange of ['Binance', 'Bybit']) {
            runTest(`getRealtimeFundingRate with ${exchange} - ${symbol}`, () => {
                const frData = getRealtimeFundingRate({
                    symbol: symbol,
                    interval: '1h',
                    exchange: exchange
                });
                assert(Array.isArray(frData), `Should return array for ${exchange}-${symbol}`);
                if (frData.length > 0) {
                    const point = frData[0];
                    assert(typeof point.time === 'number', 'time should be number');
                    assert(typeof point.open === 'number', 'open should be number');
                    assert(typeof point.close === 'number', 'close should be number');
                    assert(typeof point.low === 'number', 'low should be number');
                    assert(typeof point.high === 'number', 'high should be number');
                }
            });
        }
    }

    // Test all realtime intervals for funding rate
    for (const interval of REALTIME_INTERVALS) {
        runTest(`getRealtimeFundingRate with interval ${interval}`, () => {
            const frData = getRealtimeFundingRate({
                symbol: 'BTCUSDt',
                interval: interval,
                exchange: 'Binance'
            });
            assert(Array.isArray(frData), `Should return array for interval ${interval}`);
        });
    }


    // ============ getFuturePrice Tests ============
    console.log('\n--- Testing getFuturePrice ---');

    // Test all exchanges and realtime intervals
    for (const exchange of ['Binance', 'Bybit']) {
        for (const interval of REALTIME_INTERVALS) {
            runTest(`getRealtimeFuturePrice with ${exchange} - ${interval}`, () => {
                const fpData = getRealtimeFuturePrice({
                    exchange: exchange,
                    symbol: 'BTCUSDT',
                    interval: interval,
                    limit: 10
                });
                assert(Array.isArray(fpData), `Should return array for ${exchange}-${interval}`);
                if (fpData.length > 0) {
                    const point = fpData[0];
                    assert(typeof point.time === 'number', 'time should be number');
                    assert(typeof point.open === 'number', 'open should be number');
                    assert(typeof point.high === 'number', 'high should be number');
                    assert(typeof point.low === 'number', 'low should be number');
                    assert(typeof point.close === 'number', 'close should be number');
                    assert(typeof point.volume === 'number', 'volume_usd should be number');
                }
            });
        }
    }

    // Test limit boundaries
    runTest('getFuturePrice limit boundaries', () => {
        const fpMin = getRealtimeFuturePrice({
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            interval: '1h',
            limit: 1
        });
        assert(Array.isArray(fpMin), 'Should work with minimum limit');
        assert(fpMin.length <= 1, 'Should respect minimum limit');

        const fpMax = getRealtimeFuturePrice({
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            interval: '1h',
            limit: 100
        });
        assert(Array.isArray(fpMax), 'Should work with larger limit');
    });

    // ============ getMarginLongShort Tests ============
    console.log('\n--- Testing getMarginLongShort ---');

    // Test all exchanges and symbols combinations
    const MARGIN_EXCHANGES = ['Binance', 'OKX', 'Bybit', 'Bitfinex'];
    const MARGIN_SYMBOLS = ['BTC', 'ETH'];

    for (const exchange of MARGIN_EXCHANGES) {
        for (const symbol of MARGIN_SYMBOLS) {
            runTest(`getRealtimeMarginLongShort with ${exchange} - ${symbol}`, () => {
                const mlData = getRealtimeMarginLongShort({
                    exchange: exchange,
                    symbol: symbol,
                    interval: '4h',
                    limit: 30
                });
                assert(Array.isArray(mlData), `Should return array for ${exchange}-${symbol}`);
                if (mlData.length > 0) {
                    const point = mlData[0];
                    assert(typeof point.time === 'number', 'time should be number');
                    assert(typeof point.long_quantity === 'number', 'long_quantity should be number');
                    assert(typeof point.short_quantity === 'number', 'short_quantity should be number');
                    assert(point.long_quantity >= 0, 'long quantity should be non-negative');
                    assert(point.short_quantity >= 0, 'short quantity should be non-negative');
                }
            });
        }
    }

    // Test all realtime intervals
    for (const interval of REALTIME_INTERVALS) {
        runTest(`getRealtimeMarginLongShort with interval ${interval}`, () => {
            const mlData = getRealtimeMarginLongShort({
                exchange: 'Bitfinex',
                symbol: 'BTC',
                interval: interval,
                limit: 10
            });
            assert(Array.isArray(mlData), `Should return array for interval ${interval}`);
        });
    }

    // ============ getBorrowInterestRateHistory Tests ============
    console.log('\n--- Testing getBorrowInterestRateHistory ---');

    for (const exchange of EXCHANGES) {
        for (const symbol of ['BTC', 'ETH', 'USDT']) {
            runTest(`getRealtimeBorrowInterestRateHistory with ${exchange} - ${symbol}`, () => {
                const irData = getRealtimeBorrowInterestRateHistory({
                    exchange: exchange,
                    symbol: symbol,
                    interval: '1h',
                    limit: 24
                });
                assert(Array.isArray(irData), `Should return array for ${exchange}-${symbol}`);
                if (irData.length > 0) {
                    const point = irData[0];
                    assert(typeof point.time === 'number', 'time should be number');
                    assert(typeof point.interest_rate === 'number', 'interest_rate should be number');
                    assert(point.interest_rate >= 0, 'interest_rate should be non-negative');
                }
            });
        }
    }

    // ============ getFuturesBasisHistory Tests ============
    console.log('\n--- Testing getFuturesBasisHistory ---');

    // Define supported exchanges and symbols for futures basis
    const BASIS_EXCHANGES = ['Binance', 'Bybit'];
    const BASIS_SYMBOLS = ['BTCUSDT', 'ETHUSDT'];

    // Test all exchanges and symbols combinations
    for (const exchange of BASIS_EXCHANGES) {
        for (const symbol of BASIS_SYMBOLS) {
            runTest(`getRealtimeFuturesBasisHistory with ${exchange} - ${symbol}`, () => {
                const basisData = getRealtimeFuturesBasisHistory({
                    exchange: exchange,
                    symbol: symbol,
                    interval: '1h',
                    limit: 24
                });
                assert(Array.isArray(basisData), `Should return array for ${exchange}-${symbol}`);
                if (basisData.length > 0) {
                    const point = basisData[0];
                    assert(typeof point.time === 'number', 'time should be number (milliseconds)');
                    assert(typeof point.open_basis === 'number', 'open_basis should be number');
                    assert(typeof point.close_basis === 'number', 'close_basis should be number');
                    assert(typeof point.open_change === 'number', 'open_change should be number');
                    assert(typeof point.close_change === 'number', 'close_change should be number');
                }
            });
        }
    }

    // Test all realtime intervals for futures basis
    for (const interval of REALTIME_INTERVALS) {
        runTest(`getRealtimeFuturesBasisHistory with interval ${interval}`, () => {
            const basisData = getRealtimeFuturesBasisHistory({
                exchange: 'Binance',
                symbol: 'BTCUSDT',
                interval: interval,
                limit: 10
            });
            assert(Array.isArray(basisData), `Should return array for interval ${interval}`);
        });
    }

    // ============ getWhaleIndexHistory Tests ============
    console.log('\n--- Testing getWhaleIndexHistory ---');

    // Define supported exchanges and symbols for whale index
    const WHALE_EXCHANGES = ['Binance', 'Bybit'];
    const WHALE_SYMBOLS = ['BTCUSDT', 'ETHUSDT'];

    // Test all exchanges and symbols combinations
    for (const exchange of WHALE_EXCHANGES) {
        for (const symbol of WHALE_SYMBOLS) {
            runTest(`getRealtimeWhaleIndexHistory with ${exchange} - ${symbol}`, () => {
                const whaleData = getRealtimeWhaleIndexHistory({
                    exchange: exchange,
                    symbol: symbol,
                    interval: '4h',
                    limit: 30
                });
                assert(Array.isArray(whaleData), `Should return array for ${exchange}-${symbol}`);
                if (whaleData.length > 0) {
                    const point = whaleData[0];
                    assert(typeof point.time === 'number', 'time should be number (milliseconds)');
                    assert(typeof point.whale_index_value === 'number', 'whale_index_value should be number');
                }
            });
        }
    }

    // Test all realtime intervals for whale index
    for (const interval of REALTIME_INTERVALS) {
        runTest(`getRealtimeWhaleIndexHistory with interval ${interval}`, () => {
            const whaleData = getRealtimeWhaleIndexHistory({
                exchange: 'Binance',
                symbol: 'BTCUSDT',
                interval: interval,
                limit: 10
            });
            assert(Array.isArray(whaleData), `Should return array for interval ${interval}`);
        });
    }

    // Test limit boundaries
    runTest('getWhaleIndexHistory limit boundaries', () => {
        const whaleMin = getRealtimeWhaleIndexHistory({
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            interval: '4h',
            limit: 1
        });
        assert(Array.isArray(whaleMin), 'Should work with minimum limit');
        assert(whaleMin.length <= 1, 'Should respect minimum limit');

        const whaleMax = getRealtimeWhaleIndexHistory({
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            interval: '4h',
            limit: 100
        });
        assert(Array.isArray(whaleMax), 'Should work with larger limit');
    });

    // ============ getCoinbasePremiumIndex Tests ============
    console.log('\n--- Testing getCoinbasePremiumIndex ---');

    // Test all realtime intervals
    for (const interval of REALTIME_INTERVALS) {
        runTest(`getRealtimeCoinbasePremiumIndex with interval ${interval}`, () => {
            const premiumData = getRealtimeCoinbasePremiumIndex({
                interval: interval,
                limit: 24
            });

            assert(Array.isArray(premiumData), `Should return array for interval ${interval}`);
            if (premiumData.length > 0) {
                const point = premiumData[0];
                assert(typeof point.time === 'number', 'time should be number');
                assert(typeof point.premium === 'number', 'premium should be number');
                assert(typeof point.premium_rate === 'number', 'premium_rate should be number');
            }
        });
    }

    // ============ Summary ============
    console.log(`\n=== Test Summary ===`);
    console.log(`Total tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(`Success rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

    if (passedTests === totalTests) {
        console.log('🎉 All realtime crypto market function tests passed!');
    } else {
        console.log('⚠️  Some tests failed. Please review the output above.');
    }
}

function main(){
	testCryptoMarketFunctions();
	testGraph();
	return 0;
}

main();
