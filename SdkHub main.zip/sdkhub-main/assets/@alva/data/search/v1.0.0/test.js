function main() {
	const { Graph } = require('@alva/graph:v1.0.0');
	const { jagentId } = require('env');
	const { makeSearchXNode, makeSearchKnowledgeNode, makeSearchBrowseNode, makeSearchRedditNode, makeGoogleTrendingSearchesNode } = require('@alva/data/search:v1.0.0');

	const graph = new Graph(jagentId);

	graph.addNode('search_x', makeSearchXNode({ query: 'AI blockchain' }));

	graph.addNode(
		'search_knowledge',
		makeSearchKnowledgeNode({
			query: 'nvidia',
			start_time: '03/01/2025',
			end_time: '10/01/2025',
			tier_filters: [
				{ tier: 1, comparator: 'EQ' },
			],
		})
	);

	graph.addNode(
		'browse',
		makeSearchBrowseNode({
			query: 'latest AI developments in healthcare',
			start_time: '03/26/2025',
			end_time: '04/01/2025',
		})
	);

	graph.addNode(
		'reddit_search',
		makeSearchRedditNode({
			subreddit: '',
			keywords: ['AI'],
			start_time: 1757395915,
			end_time: 1758003915,
		})
	);

	graph.addNode('google_trending', makeGoogleTrendingSearchesNode({
		geo: 'US',
		time: 'past_24_hours',
		category: 'technology',
	}));

	graph.run();

	const { TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');

	const searchXUri = new TimeSeriesUri(jagentId, 'search_x', 'search_results', { last: '10' });
	const searchXSeries = new TimeSeries(searchXUri, graph.store);
	searchXSeries.init();
	const searchXData = searchXSeries.data;

	if (searchXData.length > 0) {
		const record = searchXData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('search_x: date must be a positive number (ms)');
		}
		if (typeof record.query !== 'string') {
			throw new Error('search_x: query must be a string');
		}
		if (!Array.isArray(record.results)) {
			throw new Error('search_x: results must be an array');
		}
		log('✓ search_x node output validated');
	}

	const knowledgeUri = new TimeSeriesUri(jagentId, 'search_knowledge', 'knowledge_results', { last: '10' });
	const knowledgeSeries = new TimeSeries(knowledgeUri, graph.store);
	knowledgeSeries.init();
	const knowledgeData = knowledgeSeries.data;

	if (knowledgeData.length > 0) {
		const record = knowledgeData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('browse: date must be a positive number (ms)');
		}
		if (typeof record.query !== 'string') {
			throw new Error('browse: query must be a string');
		}
		if (typeof record.summary !== 'string') {
			throw new Error('browse: summary must be a string');
		}
		if (!Array.isArray(record.citations)) {
			throw new Error('browse: citations must be an array');
		}
		if (!Array.isArray(record.search_results)) {
			throw new Error('browse: search_results must be an array');
		}
		log('✓ knowledge node output validated');
	}

	const browseUri = new TimeSeriesUri(jagentId, 'browse', 'browse_results', { last: '10' });
	const browseSeries = new TimeSeries(browseUri, graph.store);
	browseSeries.init();
	const browseData = browseSeries.data;

	if (browseData.length === 0) {
		throw new Error(`no rows returned for browse`);
	}

	if (browseData.length > 0) {
		const record = browseData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('browse: date must be a positive number (ms)');
		}
		if (typeof record.query !== 'string') {
			throw new Error('browse: query must be a string');
		}
		if (typeof record.summary !== 'string') {
			throw new Error('browse: summary must be a string');
		}
		if (!Array.isArray(record.citations)) {
			throw new Error('browse: citations must be an array');
		}
		if (!Array.isArray(record.search_results)) {
			throw new Error('browse: search_results must be an array');
		}
		log('✓ browse node output validated');
	}

	const redditUri = new TimeSeriesUri(jagentId, 'reddit_search', 'reddit_posts', { last: '10' });
	const redditSeries = new TimeSeries(redditUri, graph.store);
	redditSeries.init();
	const redditData = redditSeries.data;

	if (redditData.length > 0) {
		const record = redditData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('reddit_search: date must be a positive number (ms)');
		}
		if (typeof record.post_id !== 'string') {
			throw new Error('reddit_search: post_id must be a string');
		}
		if (typeof record.title !== 'string') {
			throw new Error('reddit_search: title must be a string');
		}
		if (typeof record.author !== 'string') {
			throw new Error('reddit_search: author must be a string');
		}
		if (typeof record.subreddit !== 'string') {
			throw new Error('reddit_search: subreddit must be a string');
		}
		if (typeof record.score !== 'number') {
			throw new Error('reddit_search: score must be a number');
		}
		if (typeof record.num_comments !== 'number') {
			throw new Error('reddit_search: num_comments must be a number');
		}
		if (typeof record.url !== 'string') {
			throw new Error('reddit_search: url must be a string');
		}
		log('✓ reddit_search node output validated');
	}

	const googleTrendingUri = new TimeSeriesUri(jagentId, 'google_trending', 'trending_searches', { last: '10' });
	const googleTrendingSeries = new TimeSeries(googleTrendingUri, graph.store);
	googleTrendingSeries.init();
	const googleTrendingData = googleTrendingSeries.data;

	if (googleTrendingData.length > 0) {
		const record = googleTrendingData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('google_trending: date must be a positive number (ms)');
		}
		if (typeof record.geo !== 'string') {
			throw new Error('google_trending: geo must be a string');
		}
		if (typeof record.time_range !== 'string') {
			throw new Error('google_trending: time_range must be a string');
		}
		if (typeof record.category !== 'string') {
			throw new Error('google_trending: category must be a string');
		}
		if (!Array.isArray(record.trends)) {
			throw new Error('google_trending: trends must be an array');
		}
		log('✓ google_trending node output validated');
	}

	// Validate refs mapping for google trending node
	const refsGT = graph.getRefsForOutput('google_trending', 'trending_searches');
	if (refsGT.length > 0) {
		const ref = refsGT[0];
		const expected = {
			id: '@alva/data/topic/google/getGoogleTrendingSearches',
			module_name: '@alva/data/topic/google ',
			module_display_name: 'Google Trends Trending Topic',
			sdk_name: 'getGoogleTrendingSearches',
			sdk_display_name: 'Google Trends Trending Topics',
			source_name: 'SearchApi',
			source: 'https://www.searchapi.io/docs/google-trends-trending-now-api',
		};

		if (ref.id !== expected.id) {
			throw new Error(`Assertion failed: google_trending ref.id expected ${expected.id}, got ${ref.id}`);
		}
		if (ref.module_name !== expected.module_name) {
			throw new Error(`Assertion failed: google_trending ref.module_name expected ${expected.module_name}, got ${ref.module_name}`);
		}
		if (ref.module_display_name !== expected.module_display_name) {
			throw new Error(`Assertion failed: google_trending ref.module_display_name expected ${expected.module_display_name}, got ${ref.module_display_name}`);
		}
		if (ref.sdk_name !== expected.sdk_name) {
			throw new Error(`Assertion failed: google_trending ref.sdk_name expected ${expected.sdk_name}, got ${ref.sdk_name}`);
		}
		if (ref.sdk_display_name !== expected.sdk_display_name) {
			throw new Error(`Assertion failed: google_trending ref.sdk_display_name expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
		}
		if (ref.source_name !== expected.source_name) {
			throw new Error(`Assertion failed: google_trending ref.source_name expected ${expected.source_name}, got ${ref.source_name}`);
		}
		if (ref.source !== expected.source) {
			throw new Error(`Assertion failed: google_trending ref.source expected ${expected.source}, got ${ref.source}`);
		}
		log('✓ google_trending ref validated');
	} else {
		throw new Error('Assertion failed: google_trending refs array is empty.');
	}

	// Validate refs mapping for X/Twitter search node
	const refsSearchX = graph.getRefsForOutput('search_x', 'search_results');
	if (refsSearchX.length > 0) {
		const ref = refsSearchX[0];
		const expected = {
			id: 'searchX',
			module_name: '@alva/data/social/x ',
			module_display_name: 'Real-time X Search',
			sdk_name: 'searchX',
			sdk_display_name: 'X Content Search',
			source_name: 'X',
			source: 'https://docs.x.com/x-api/introduction',
		};

		if (ref.id !== expected.id) {
			throw new Error(`Assertion failed: search_x ref.id expected ${expected.id}, got ${ref.id}`);
		}
		if (ref.module_name !== expected.module_name) {
			throw new Error(`Assertion failed: search_x ref.module_name expected ${expected.module_name}, got ${ref.module_name}`);
		}
		if (ref.module_display_name !== expected.module_display_name) {
			throw new Error(`Assertion failed: search_x ref.module_display_name expected ${expected.module_display_name}, got ${ref.module_display_name}`);
		}
		if (ref.sdk_name !== expected.sdk_name) {
			throw new Error(`Assertion failed: search_x ref.sdk_name expected ${expected.sdk_name}, got ${ref.sdk_name}`);
		}
		if (ref.sdk_display_name !== expected.sdk_display_name) {
			throw new Error(`Assertion failed: search_x ref.sdk_display_name expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
		}
		if (ref.source_name !== expected.source_name) {
			throw new Error(`Assertion failed: search_x ref.source_name expected ${expected.source_name}, got ${ref.source_name}`);
		}
		if (ref.source !== expected.source) {
			throw new Error(`Assertion failed: search_x ref.source expected ${expected.source}, got ${ref.source}`);
		}
		log('✓ search_x ref validated');
	} else {
		throw new Error('Assertion failed: search_x refs array is empty.');
	}

	// Validate refs mapping for Knowledge search node
	const refsKnowledge = graph.getRefsForOutput('search_knowledge', 'knowledge_results');
	if (refsKnowledge.length > 0) {
		const ref = refsKnowledge[0];
		const expected = {
			id: 'searchKnowledge',
			module_name: '@alva/data/search ',
			module_display_name: 'Real-time Search',
			sdk_name: 'searchKnowledge',
			sdk_display_name: 'Internal Knowledge Base',
			source_name: 'Alva',
			source: '',
		};

		if (ref.id !== expected.id) {
			throw new Error(`Assertion failed: search_knowledge ref.id expected ${expected.id}, got ${ref.id}`);
		}
		if (ref.module_name !== expected.module_name) {
			throw new Error(`Assertion failed: search_knowledge ref.module_name expected ${expected.module_name}, got ${ref.module_name}`);
		}
		if (ref.module_display_name !== expected.module_display_name) {
			throw new Error(`Assertion failed: search_knowledge ref.module_display_name expected ${expected.module_display_name}, got ${ref.module_display_name}`);
		}
		if (ref.sdk_name !== expected.sdk_name) {
			throw new Error(`Assertion failed: search_knowledge ref.sdk_name expected ${expected.sdk_name}, got ${ref.sdk_name}`);
		}
		if (ref.sdk_display_name !== expected.sdk_display_name) {
			throw new Error(`Assertion failed: search_knowledge ref.sdk_display_name expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
		}
		if (ref.source_name !== expected.source_name) {
			throw new Error(`Assertion failed: search_knowledge ref.source_name expected ${expected.source_name}, got ${ref.source_name}`);
		}
		if (ref.source !== expected.source) {
			throw new Error(`Assertion failed: search_knowledge ref.source expected ${expected.source}, got ${ref.source}`);
		}
		log('✓ search_knowledge ref validated');
	} else {
		throw new Error('Assertion failed: search_knowledge refs array is empty.');
	}

	// Validate refs mapping for Browse search node
	const refsBrowse = graph.getRefsForOutput('browse', 'browse_results');
	if (refsBrowse.length > 0) {
		const ref = refsBrowse[0];
		const expected = {
			id: 'searchBrowse',
			module_name: '@alva/data/search ',
			module_display_name: 'Real-time Search',
			sdk_name: 'searchBrowse',
			sdk_display_name: 'Google Search',
			source_name: 'Google',
			source: 'http://google.com',
		};

		if (ref.id !== expected.id) {
			throw new Error(`Assertion failed: browse ref.id expected ${expected.id}, got ${ref.id}`);
		}
		if (ref.module_name !== expected.module_name) {
			throw new Error(`Assertion failed: browse ref.module_name expected ${expected.module_name}, got ${ref.module_name}`);
		}
		if (ref.module_display_name !== expected.module_display_name) {
			throw new Error(`Assertion failed: browse ref.module_display_name expected ${expected.module_display_name}, got ${ref.module_display_name}`);
		}
		if (ref.sdk_name !== expected.sdk_name) {
			throw new Error(`Assertion failed: browse ref.sdk_name expected ${expected.sdk_name}, got ${ref.sdk_name}`);
		}
		if (ref.sdk_display_name !== expected.sdk_display_name) {
			throw new Error(`Assertion failed: browse ref.sdk_display_name expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
		}
		if (ref.source_name !== expected.source_name) {
			throw new Error(`Assertion failed: browse ref.source_name expected ${expected.source_name}, got ${ref.source_name}`);
		}
		if (ref.source !== expected.source) {
			throw new Error(`Assertion failed: browse ref.source expected ${expected.source}, got ${ref.source}`);
		}
		log('✓ browse ref validated');
	} else {
		throw new Error('Assertion failed: browse refs array is empty.');
	}

	// Validate refs mapping for Reddit search node
	const refsReddit = graph.getRefsForOutput('reddit_search', 'reddit_posts');
	if (refsReddit.length > 0) {
		const ref = refsReddit[0];
		const expected = {
			id: 'searchReddit',
			module_name: '@alva/data/social/reddit ',
			module_display_name: 'Real-time Reddit Search',
			sdk_name: 'searchReddit',
			sdk_display_name: 'Reddit Search',
			source_name: 'Reddit',
			source: 'https://www.reddit.com/dev/api/',
		};

		if (ref.id !== expected.id) {
			throw new Error(`Assertion failed: reddit_search ref.id expected ${expected.id}, got ${ref.id}`);
		}
		if (ref.module_name !== expected.module_name) {
			throw new Error(`Assertion failed: reddit_search ref.module_name expected ${expected.module_name}, got ${ref.module_name}`);
		}
		if (ref.module_display_name !== expected.module_display_name) {
			throw new Error(`Assertion failed: reddit_search ref.module_display_name expected ${expected.module_display_name}, got ${ref.module_display_name}`);
		}
		if (ref.sdk_name !== expected.sdk_name) {
			throw new Error(`Assertion failed: reddit_search ref.sdk_name expected ${expected.sdk_name}, got ${ref.sdk_name}`);
		}
		if (ref.sdk_display_name !== expected.sdk_display_name) {
			throw new Error(`Assertion failed: reddit_search ref.sdk_display_name expected ${expected.sdk_display_name}, got ${ref.sdk_display_name}`);
		}
		if (ref.source_name !== expected.source_name) {
			throw new Error(`Assertion failed: reddit_search ref.source_name expected ${expected.source_name}, got ${ref.source_name}`);
		}
		if (ref.source !== expected.source) {
			throw new Error(`Assertion failed: reddit_search ref.source expected ${expected.source}, got ${ref.source}`);
		}
		log('✓ reddit_search ref validated');
	} else {
		throw new Error('Assertion failed: reddit_search refs array is empty.');
	}

	// Simple assert function for testing
	function assert(condition, message) {
		if (!condition) {
			throw new Error(`Assertion failed: ${message}`);
		}
	}

	// Import the search functions directly
	const {
		searchX,
		searchKnowledge,
		searchBrowse,
		searchReddit,
		searchGoogleTrendingTopic
	} = require('@alva/data/search:v1.0.0');

	// Test 1: Happy path tests with valid inputs
	log('\n=== Testing Happy Path Scenarios ===');

	// Test searchX with valid parameters
	try {
		const result =  searchX({
			query: 'AI blockchain technology',
			start_time: Math.floor(Date.now() / 1000) - 86400, // 24 hours ago
			end_time: Math.floor(Date.now() / 1000) // now
		});
		// Validate result structure
		assert(Array.isArray(result), 'searchX should return an array');
		if (result.length > 0) {
			const firstResult = result[0];
			assert(typeof firstResult.title === 'string', 'result.title should be string');
			assert(typeof firstResult.url === 'string', 'result.url should be string');
			assert(typeof firstResult.content === 'string', 'result.content should be string');
			assert(typeof firstResult.authorUsername === 'string', 'result.authorUsername should be string');
		}
		log('✓ searchX happy path test passed');
	} catch (error) {
		throw new Error(`searchX happy path test failed: ${error.message}`);
	}

	// Test searchKnowledge with valid parameters
	try {
		const result =  searchKnowledge({
			query: 'latest AI developments in healthcare',
			start_time: Date.now() - 7 * 24 * 60 * 60 * 1000, // 7 days ago in milliseconds
			end_time: Date.now(), // now in milliseconds
			tier_filters: [
				{ tier: 1, comparator: 'EQ' },
				{ tier: 2, comparator: 'GTE' }
			]
		});

		// Validate result structure - returns KnowledgeSearchResult object
		assert(typeof result === 'object', 'searchKnowledge should return an object');
		assert(typeof result.summary === 'string', 'result.summary should be string');
		assert(Array.isArray(result.citations), 'result.citations should be array of strings');
		assert(Array.isArray(result.search_results), 'result.search_results should be array');

		// Validate citations if present
		if (result.citations.length > 0) {
			assert(typeof result.citations[0] === 'string', 'citations should contain strings');
		}

		// Validate search_results structure if present
		if (result.search_results.length > 0) {
			const firstResult = result.search_results[0];
			assert(typeof firstResult.title === 'string', 'search_results.title should be string');
			assert(typeof firstResult.url === 'string', 'search_results.url should be string');
			assert(typeof firstResult.date === 'string', 'search_results.date should be string');
			assert(typeof firstResult.snippet === 'string', 'search_results.snippet should be string');
			assert(typeof firstResult.tier === 'number', 'search_results.tier should be number');
			assert(firstResult.tier >= 1 && firstResult.tier <= 4, 'search_results.tier should be 1-4');
		}
		log('✓ searchKnowledge happy path test passed');
	} catch (error) {
		throw new Error(`searchKnowledge happy path test failed: ${error.message}`);
	}

	// Test searchBrowse with valid parameters
	try {
		const result =  searchBrowse({
			query: 'artificial intelligence market trends 2024',
			start_time: "09/23/2024", // MM/DD/YYYY format
			end_time: "10/23/2024",   // MM/DD/YYYY format
			search_mode: 'academic'
		});

		console.log(typeof result.citations[0]);

		// Validate result structure - returns single SearchBrowseResult object
		assert(typeof result === 'object', 'searchBrowse should return an object');
		assert(typeof result.summary === 'string', 'result.summary should be string');
		assert(Array.isArray(result.citations), 'result.citations should be array');
		assert(typeof result.citations[0] === 'string', 'citations should contain strings');
		assert(Array.isArray(result.search_results), 'result.search_results should be array');

		// Validate search_results structure if present
		if (result.search_results.length > 0) {
			const firstResult = result.search_results[0];
			assert(typeof firstResult.date === 'string', 'search_results.date should be string');
			assert(typeof firstResult.snippet === 'string', 'search_results.snippet should be string');
			assert(typeof firstResult.title === 'string', 'search_results.title should be string');
			assert(typeof firstResult.url === 'string', 'search_results.url should be string');
		}
		log('✓ searchBrowse happy path test passed');
	} catch (error) {
		throw new Error(`searchBrowse happy path test failed: ${error.message}`);
	}

	// Test searchReddit with valid parameters
	try {
		const result =  searchReddit({
			subreddit: '',
			keywords: ['AI', 'machine learning', 'neural networks'],
			start_time: Math.floor(Date.now() / 1000) - 7 * 24 * 3600, // 7 days ago
			end_time: Math.floor(Date.now() / 1000)
		});

		// Validate result structure
		assert(Array.isArray(result), 'searchReddit should return an array');
		if (result.length > 0) {
			const firstResult = result[0];
			assert(typeof firstResult.post_id === 'string', 'result.post_id should be string');
			assert(typeof firstResult.title === 'string', 'result.title should be string');
			assert(typeof firstResult.selftext === 'string', 'result.selftext should be string');
			assert(typeof firstResult.author === 'string', 'result.author should be string');
			assert(typeof firstResult.subreddit === 'string', 'result.subreddit should be string');
			assert(typeof firstResult.created_at === 'number', 'result.created_at should be number');
			assert(typeof firstResult.score === 'number', 'result.score should be number');
			assert(typeof firstResult.num_comments === 'number', 'result.num_comments should be number');
			assert(typeof firstResult.url === 'string', 'result.url should be string');
		}
		log('✓ searchReddit happy path test passed');
	} catch (error) {
		throw new Error(`searchReddit happy path test failed: ${error.message}`);
	}

	// Test 2: Boundary value tests
	log('\n=== Testing Boundary Values ===');

	// Test with minimum valid time ranges (exactly 7 days ago)
	const now = Math.floor(Date.now() / 1000);
	const sevenDaysAgo = now - 7 * 24 * 3600;

	try {
		const result =  searchX({
			query: 'boundary test',
			start_time: sevenDaysAgo, // Exactly 7 days ago
			end_time: now
		});
		assert(Array.isArray(result), 'searchX boundary time test should return array');
		log('✓ searchX boundary time test passed');
	} catch (error) {
		throw new Error(`searchX boundary time test failed: ${error.message}`);
	}

	// Test with minimum length query
	try {
		const result =  searchX({
			query: 'a' // Single character
		});
		assert(Array.isArray(result), 'searchX minimum query length test should return array');
		log('✓ searchX minimum query length test passed');
	} catch (error) {
		throw new Error(`searchX minimum query length test failed: ${error.message}`);
	}

	// Test with maximum tier values
	try {
		const result =  searchKnowledge({
			query: 'test',
			tier_filters: [
				{ tier: 4, comparator: 'LTE' } // Maximum valid tier
			]
		});
		assert(typeof result === 'object', 'searchKnowledge maximum tier test should return object');
		assert(typeof result.summary === 'string', 'result.summary should be string');
		assert(Array.isArray(result.citations), 'result.citations should be array of strings');
		assert(Array.isArray(result.search_results), 'result.search_results should be array');
		log('✓ searchKnowledge maximum tier test passed');
	} catch (error) {
		throw new Error(`searchKnowledge maximum tier test failed: ${error.message}`);
	}

	// Test with multiple tier filters
	try {
		const result =  searchKnowledge({
			query: 'comprehensive test',
			tier_filters: [
				{ tier: 1, comparator: 'EQ' },
				{ tier: 2, comparator: 'GTE' },
				{ tier: 3, comparator: 'LTE' },
				{ tier: 4, comparator: 'GT' }
			]
		});
		assert(typeof result === 'object', 'searchKnowledge multiple filters test should return object');
		assert(typeof result.summary === 'string', 'result.summary should be string');
		assert(Array.isArray(result.citations), 'result.citations should be array of strings');
		assert(Array.isArray(result.search_results), 'result.search_results should be array');
		log('✓ searchKnowledge multiple tier filters test passed');
	} catch (error) {
		throw new Error(`searchKnowledge multiple filters test failed: ${error.message}`);
	}

	// Test searchKnowledge with minimum tier values
	try {
		const result =  searchKnowledge({
			query: 'minimum tier test',
			tier_filters: [
				{ tier: 1, comparator: 'EQ' }, // Minimum valid tier
				{ tier: 1, comparator: 'LTE' }  // Minimum valid tier with LTE
			]
		});
		assert(typeof result === 'object', 'searchKnowledge minimum tier test should return object');
		assert(typeof result.summary === 'string', 'result.summary should be string');
		assert(Array.isArray(result.citations), 'result.citations should be array of strings');
		assert(Array.isArray(result.search_results), 'result.search_results should be array');
		log('✓ searchKnowledge minimum tier test passed');
	} catch (error) {
		throw new Error(`searchKnowledge minimum tier test failed: ${error.message}`);
	}

	// Test 4: Special value tests
	log('\n=== Testing Special Values ===');

	// Test searchReddit without subreddit (should search all subreddits)
	try {
		const result =  searchReddit({
			keywords: ['global', 'trending'],
			start_time: sevenDaysAgo,
			end_time: now
		});
		assert(Array.isArray(result), 'searchReddit no subreddit test should return array');
		log('✓ searchReddit without subreddit passed');
	} catch (error) {
		throw new Error(`searchReddit no subreddit test failed: ${error.message}`);
	}

	// Test searchBrowse with default parameters
	try {
		const result =  searchBrowse({
			query: 'AI technology trends'
			// No optional parameters
		});
		assert(typeof result === 'object', 'searchBrowse defaults test should return object');
		assert(typeof result.summary === 'string', 'result.summary should be string');
		assert(Array.isArray(result.citations), 'result.citations should be array');
		assert(Array.isArray(result.search_results), 'result.search_results should be array');
		log('✓ searchBrowse with default parameters passed');
	} catch (error) {
		throw new Error(`searchBrowse defaults test failed: ${error.message}`);
	}

	// Test searchBrowse with valid date formats
	try {
		const result =  searchBrowse({
			query: 'date format test',
			start_time: "01/01/2024", // Valid MM/DD/YYYY format
			end_time: "12/31/2024"   // Valid MM/DD/YYYY format
		});
		assert(typeof result === 'object', 'searchBrowse date format test should return object');
		assert(typeof result.summary === 'string', 'result.summary should be string');
		assert(Array.isArray(result.citations), 'result.citations should be array');
		assert(Array.isArray(result.search_results), 'result.search_results should be array');
		log('✓ searchBrowse valid date format test passed');
	} catch (error) {
		throw new Error(`searchBrowse date format test failed: ${error.message}`);
	}

	// Test searchGoogleTrendingTopic with all category options
	const validCategories = ['all', 'autos_and_vehicles', 'business_and_finance', 'entertainment', 'health', 'politics', 'science', 'sports', 'technology'];
	for (const category of validCategories) {
		try {
			const result =  searchGoogleTrendingTopic({
				geo: 'US',
				time: 'past_24_hours',
				category: category
			});
			assert(typeof result === 'object', `searchGoogleTrendingTopic category ${category} test should return object`);
		} catch (error) {
			throw new Error(`searchGoogleTrendingTopic category ${category} test failed: ${error.message}`);
		}
	}
	log('✓ searchGoogleTrendingTopic all categories test passed');

	// Test 5: Edge cases and stress tests
	log('\n=== Testing Edge Cases ===');

	// Test with very long query
	try {
		const longQuery = 'a'.repeat(128); // 1000 character query
		console.log("start to test long query");

		const result =  searchX({
			query: longQuery
		});
		console.log("get long query result done");
		console.log(result);
		assert(Array.isArray(result), 'searchX long query test should return array');
		log('✓ searchX long query test passed');
	} catch (error) {
		throw new Error(`searchX long query test failed: ${error.message}`);
	}

	// Test with Unicode characters
	try {
		const unicodeQuery = '人工智能 🚀';
		const result =  searchX({
			query: unicodeQuery
		});
		assert(Array.isArray(result), 'searchX Unicode query test should return array');
		log('✓ searchX Unicode query test passed');
	} catch (error) {
		throw new Error(`searchX Unicode query test failed: ${error.message}`);
	}

	log('\n✅ All comprehensive test cases passed successfully');
	log('✅ Search make*Node tests passed');

	log('✅ Search make*Node tests passed');
	return 0;
}

main();
