const { sdkRelay } = require('sdkrelay');
const { useCredit } = require('internal');
const { syncFetch: fetch } = require('net/http');
const { load } = require('@alva/secret');
const key = load('SEARCHAPI_KEY');

// Refs mapped from tool.json metadata
const searchXRef = {
  id: 'searchX',
  module_name: '@alva/data/social/x ',
  module_display_name: 'Real-time X Search',
  sdk_name: 'searchX',
  sdk_display_name: 'X Content Search',
  source_name: 'X',
  source: 'https://docs.x.com/x-api/introduction',
};

const searchKnowledgeRef = {
  id: 'searchKnowledge',
  module_name: '@alva/data/search ',
  module_display_name: 'Real-time Search',
  sdk_name: 'searchKnowledge',
  sdk_display_name: 'Internal Knowledge Base',
  source_name: 'Alva',
  source: '',
};

const searchBrowseRef = {
  id: 'searchBrowse',
  module_name: '@alva/data/search ',
  module_display_name: 'Real-time Search',
  sdk_name: 'searchBrowse',
  sdk_display_name: 'Google Search',
  source_name: 'Google',
  source: 'http://google.com',
};

const searchRedditRef = {
  id: 'searchReddit',
  module_name: '@alva/data/social/reddit ',
  module_display_name: 'Real-time Reddit Search',
  sdk_name: 'searchReddit',
  sdk_display_name: 'Reddit Search',
  source_name: 'Reddit',
  source: 'https://www.reddit.com/dev/api/',
};

const getGoogleTrendingSearchesRef = {
  id: '@alva/data/topic/google/getGoogleTrendingSearches',
  module_name: '@alva/data/topic/google ',
  module_display_name: 'Google Trends Trending Topic',
  sdk_name: 'getGoogleTrendingSearches',
  sdk_display_name: 'Google Trends Trending Topics',
  source_name: 'SearchApi',
  source: 'https://www.searchapi.io/docs/google-trends-trending-now-api',
};

// Learned content: DefiLlama user activity reference
const getDefiProtocolUserActivityRef = {
  id: '@alva/data/crypto/defi/getDefiProtocolUserActivity',
  module_name: '@alva/data/crypto/defi',
  module_display_name: 'Crypto Project KPI \u0026 Operating Metrics',
  sdk_name: 'getDefiProtocolUserActivity',
  sdk_display_name: 'Crypto Project User Activity',
  source_name: 'DefiLlama',
  source: 'https://api-docs.defillama.com/#tag/active-users/get/api/userData/%7Btype%7D/%7BprotocolId%7D',
};

// Unified getter for all Ref objects
function getRefs() {
  return [
    searchXRef,
    searchKnowledgeRef,
    searchBrowseRef,
    searchRedditRef,
    getGoogleTrendingSearchesRef,
    getDefiProtocolUserActivityRef,
  ];
}

// =========================================
// Base function descriptions (concise)
// =========================================
const searchXBaseFuncDesc = 'Real-time X/Twitter search';
const searchKnowledgeBaseFuncDesc = 'Search Alva knowledge base';
const searchRedditBaseFuncDesc = 'Search Reddit posts';
const searchBrowseBaseFuncDesc = 'Real-time web browsing search';
const searchGoogleTrendingTopicBaseFuncDesc = 'Google Trends: trending searches';
const defiProtocolUserActivityBaseFuncDesc = 'DefiLlama protocol user activity';

// =========================================
// Utility: createReferenceWithTitle
// =========================================
function createReferenceWithTitle(refObject, params, titleBuilder) {
  // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
  const title = titleBuilder(params);

  // 2. 组合 refObject 和新 title
  const newObject = {
    ...refObject,
    title: title,
  };

  // 3. 返回新对象
  return newObject;
}

// =========================================
// Dynamic call description builders (internal)
// =========================================
function buildSearchXCallDescription(actualParams = {}) {
  const parts = [searchXBaseFuncDesc];

  if (actualParams.query) {
    parts.push(`for "${actualParams.query}"`);
  }

  const filters = [];
  const st = actualParams.start_time;
  const et = actualParams.end_time;
  if (st && et) {
    filters.push(`Time: ${st} to ${et}`);
  } else if (st) {
    filters.push(`Time from: ${st}`);
  } else if (et) {
    filters.push(`Time until: ${et}`);
  }

  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }

  return parts.join(' ').trim();
}

function buildSearchKnowledgeCallDescription(actualParams = {}) {
  const parts = [searchKnowledgeBaseFuncDesc];

  if (actualParams.query) {
    parts.push(`for "${actualParams.query}"`);
  }

  const filters = [];
  const st = actualParams.start_time;
  const et = actualParams.end_time;
  if (st && et) {
    filters.push(`Time: ${st} to ${et}`);
  } else if (st) {
    filters.push(`Time from: ${st}`);
  } else if (et) {
    filters.push(`Time until: ${et}`);
  }

  if (Array.isArray(actualParams.tier_filters) && actualParams.tier_filters.length > 0) {
    const tf = actualParams.tier_filters
      .map((f) => {
        const tier = f && (f.tier ?? f.Tier);
        const comp = f && f.comparator;
        if (tier != null && comp) return `${comp} Tier ${tier}`;
        if (tier != null) return `Tier ${tier}`;
        if (comp) return `${comp}`;
        return null;
      })
      .filter(Boolean);
    if (tf.length) {
      filters.push(`Tier filters: ${tf.join(' | ')}`);
    }
  }

  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }

  return parts.join(' ').trim();
}

function buildSearchRedditCallDescription(actualParams = {}) {
  const parts = [searchRedditBaseFuncDesc];

  if (actualParams.subreddit) {
    parts.push(`in r/${actualParams.subreddit}`);
  }

  const filters = [];
  if (Array.isArray(actualParams.keywords) && actualParams.keywords.length > 0) {
    const kws = actualParams.keywords.slice(0, 5).join(', ');
    filters.push(`Keywords: ${kws}`);
  }
  const st = actualParams.start_time;
  const et = actualParams.end_time;
  if (st && et) {
    filters.push(`Time: ${st} to ${et}`);
  } else if (st) {
    filters.push(`Time from: ${st}`);
  } else if (et) {
    filters.push(`Time until: ${et}`);
  }

  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }

  return parts.join(' ').trim();
}

function buildSearchBrowseCallDescription(actualParams = {}) {
  const parts = [searchBrowseBaseFuncDesc];

  if (actualParams.query) {
    parts.push(`for "${actualParams.query}"`);
  }

  const filters = [];
  const st = actualParams.start_time;
  const et = actualParams.end_time;
  if (st && et) {
    filters.push(`Time: ${st} to ${et}`);
  } else if (st) {
    filters.push(`Time from: ${st}`);
  } else if (et) {
    filters.push(`Time until: ${et}`);
  }
  if (actualParams.search_mode) {
    filters.push(`Mode: ${actualParams.search_mode}`);
  }

  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }

  return parts.join(' ').trim();
}

function buildSearchGoogleTrendingTopicCallDescription(actualParams = {}) {
  const parts = [searchGoogleTrendingTopicBaseFuncDesc];

  if (actualParams.geo) {
    parts.push(`in ${actualParams.geo}`);
  }

  const filters = [];
  if (actualParams.time) {
    filters.push(`Time: ${actualParams.time}`);
  }
  if (actualParams.category) {
    filters.push(`Category: ${actualParams.category}`);
  }

  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }

  return parts.join(' ').trim();
}

function buildGetDefiProtocolUserActivityCallDescription(actualParams = {}) {
  const parts = [defiProtocolUserActivityBaseFuncDesc];

  const protoId = actualParams.protocolId ?? actualParams.protocol_id;
  if (protoId != null) {
    parts.push(`for protocol ${protoId}`);
  }

  const filters = [];
  if (actualParams.type) {
    filters.push(`Type: ${actualParams.type}`);
  }
  const st = actualParams.start_time;
  const et = actualParams.end_time;
  if (st && et) {
    filters.push(`Time: ${st} to ${et}`);
  } else if (st) {
    filters.push(`Time from: ${st}`);
  } else if (et) {
    filters.push(`Time until: ${et}`);
  }

  if (filters.length > 0) {
    parts.push(`(${filters.join(', ')})`);
  }

  return parts.join(' ').trim();
}


function searchX(params) {
  useCredit('searchX', 1500);
  return sdkRelay('SearchX', params);
}

function searchKnowledge(params) {
  useCredit('searchKnowledge', 1500);
  
  const timestampToMDY = (timestamp) => {
    const date = new Date(timestamp);
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
  };
  
  const transformedParams = {
    ...params,
    start_time: params.start_time ? timestampToMDY(params.start_time) : undefined,
    end_time: params.end_time ? timestampToMDY(params.end_time) : undefined,
  };
  
  return sdkRelay('SearchKnowledge', transformedParams);
}

function searchBrowse(params) {
  useCredit('searchBrowse', 1500);
  
  const timestampToMDY = (timestamp) => {
    const date = new Date(timestamp);
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
  };
  
  const transformedParams = {
    ...params,
    start_time: params.start_time ? timestampToMDY(params.start_time) : undefined,
    end_time: params.end_time ? timestampToMDY(params.end_time) : undefined,
  };
  
  try {
    return sdkRelay('Search', transformedParams);
  } catch (error) {
    return {};
  }
}

function searchReddit(params) {
  useCredit('searchReddit', 1500);
  return sdkRelay('SearchReddit', params);
}


function searchGoogleTrendingTopic(params) {
  useCredit('getGoogleTrendingSearches', 350);

  const geo = params.geo || 'US';
  const time = params.time || 'past_24_hours';

  const baseUrl = 'https://www.searchapi.io/api/v1/search';

  const queryParams = [];
  queryParams.push(`engine=google_trends_trending_now`);
  queryParams.push(`geo=${encodeURIComponent(geo)}`);
  queryParams.push(`time=${encodeURIComponent(time)}`);
  queryParams.push(`api_key=${encodeURIComponent(key)}`);

  const url = `${baseUrl}?${queryParams.join('&')}`;

  const response = fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  return response;
}

function toMs(value) {
  if (value == null) {
    return null;
  }
  if (typeof value === 'number') {
    return value > 1e12 ? value : value * 1000;
  }
  if (typeof value === 'string') {
    const parsed = Date.parse(value);
    if (!Number.isNaN(parsed)) {
      return parsed;
    }
  }
  return null;
}

function pickSnapshotDate(params) {
  if (!params || typeof params !== 'object') {
    return Date.now();
  }
  const candidates = [params.end_time, params.end_publish_at, params.end_event_at, params.time, params.endTime, params.endDate, params.start_time, params.start_publish_at, params.start_event_at];
  for (const candidate of candidates) {
    const ms = toMs(candidate);
    if (ms != null) {
      return ms;
    }
  }
  return Date.now();
}

function ensureUniqueDates(items) {
  const used = new Set();
  return items.map((item) => {
    let { date } = item;
    if (date == null) {
      date = Date.now();
    }
    while (used.has(date)) {
      date += 1;
    }
    used.add(date);
    return { ...item, date };
  });
}

function coerceArray(value) {
  if (Array.isArray(value)) {
    return value;
  }
  if (value && typeof value === 'object') {
    if (Array.isArray(value.data)) {
      return value.data;
    }
    if (Array.isArray(value.results)) {
      return value.results;
    }
    if (Array.isArray(value.items)) {
      return value.items;
    }
  }
  return [];
}

/**
 * Nodified: X/Twitter search as a graph node
 */
function makeSearchXNode(params) {
  return {
    inputs: {
      search_x_raw: () => searchX(params),
    },
    outputs: {
      search_results: {
        name: 'search_x_results',
        description: 'X/Twitter search results grouped per request',
        fields: [
          { name: 'date', type: 'number', description: 'snapshot time ms' },
          { name: 'query', type: 'string', description: 'search query' },
          {
            name: 'results',
            type: 'array',
            description: 'matching posts',
            fields: [
              { name: 'title', type: 'string', description: 'post title' },
              { name: 'url', type: 'string', description: 'post URL' },
              { name: 'content', type: 'string', description: 'post content' },
              { name: 'author_username', type: 'string', description: 'author handle' },
            ],
          },
        ],
        ref: createReferenceWithTitle(searchXRef, params, buildSearchXCallDescription),
      },
    },
    run: (inputs) => {
      const results = coerceArray(inputs.search_x_raw).map((item) => ({
        title: item.title,
        url: item.url,
        content: item.content,
        author_username: item.author_username || item.authorUsername,
      }));
      return {
        search_results: [
          {
            date: pickSnapshotDate(params),
            query: params && typeof params.query === 'string' ? params.query : '',
            results,
          },
        ],
      };
    },
  };
}

/**
 * Nodified: Knowledge base search as a graph node
 */
function makeSearchKnowledgeNode(params) {
  return {
    inputs: {
      knowledge_raw: () => searchKnowledge(params),
    },
    outputs: {
      knowledge_results: {
        name: 'knowledge_results',
        description: 'search knowledge graph',
        fields: [
          { name: 'date', type: 'number', description: 'snapshot time ms' },
          { name: 'query', type: 'string', description: 'search query' },
          { name: 'summary', type: 'string', description: 'AI generated summary' },
          {
            name: 'citations',
            type: 'array',
            description: 'cited URLs',
            fields: [{ name: 'url', type: 'string', description: 'citation URL' }],
          },
          {
            name: 'search_results',
            type: 'array',
            description: 'raw search result entries',
            fields: [
              { name: 'title', type: 'string', description: 'source title' },
              { name: 'url', type: 'string', description: 'source URL' },
              { name: 'date', type: 'string', description: 'source publish date' },
              { name: 'snippet', type: 'string', description: 'content snippet' },
              { name: 'tier', type: 'number', description: 'Credibility tier of the source' },
            ],
          },
        ],
        ref: createReferenceWithTitle(searchKnowledgeRef, params, buildSearchKnowledgeCallDescription),
      },
    },
    run: (inputs) => {
      const raw = inputs.knowledge_raw || {};
      const summary = raw.summary || '';
      const citations = Array.isArray(raw.citations) ? raw.citations.map((url) => ({ url })) : [];
      const searchResults = coerceArray(raw.search_results || raw.results).map((item) => ({
        title: item.title,
        url: item.url,
        date: item.date,
        snippet: item.snippet,
      }));
      return {
        knowledge_results: [
          {
            date: pickSnapshotDate(params),
            query: params && typeof params.query === 'string' ? params.query : '',
            summary,
            citations,
            search_results: searchResults,
          },
        ],
      };
    },
  };
}

/**
 * Nodified: Real-time browse search as a graph node
 */
function makeSearchBrowseNode(params) {
  return {
    inputs: {
      browse_raw: () => searchBrowse(params),
    },
    outputs: {
      browse_results: {
        name: 'search_browse_results',
        description: 'Real-time browse search results grouped per request',
        fields: [
          { name: 'date', type: 'number', description: 'snapshot time ms' },
          { name: 'query', type: 'string', description: 'search query' },
          { name: 'summary', type: 'string', description: 'AI generated summary' },
          {
            name: 'citations',
            type: 'array',
            description: 'cited URLs',
            fields: [{ name: 'url', type: 'string', description: 'citation URL' }],
          },
          {
            name: 'search_results',
            type: 'array',
            description: 'raw search result entries',
            fields: [
              { name: 'title', type: 'string', description: 'source title' },
              { name: 'url', type: 'string', description: 'source URL' },
              { name: 'date', type: 'string', description: 'source publish date' },
              { name: 'snippet', type: 'string', description: 'content snippet' },
            ],
          },
        ],
        ref: createReferenceWithTitle(searchBrowseRef, params, buildSearchBrowseCallDescription),
      },
    },
    run: (inputs) => {
      const raw = inputs.browse_raw || {};
      const summary = raw.summary || raw.summarized_content || '';
      const citations = Array.isArray(raw.citations) ? raw.citations.map((url) => ({ url })) : [];
      const searchResults = coerceArray(raw.search_results || raw.results).map((item) => ({
        title: item.title,
        url: item.url,
        date: item.date,
        snippet: item.snippet,
      }));
      return {
        browse_results: [
          {
            date: pickSnapshotDate(params),
            query: params && typeof params.query === 'string' ? params.query : '',
            summary,
            citations,
            search_results: searchResults,
          },
        ],
      };
    },
  };
}

/**
 * Nodified: Reddit search as a graph node
 */
function makeSearchRedditNode(params) {
  return {
    inputs: {
      reddit_raw: () => searchReddit(params),
    },
    outputs: {
      reddit_posts: {
        name: 'reddit_posts',
        description: 'Reddit posts returned by the search',
        fields: [
          { name: 'date', type: 'number', description: 'post creation time ms' },
          { name: 'post_id', type: 'string', description: 'post identifier' },
          { name: 'title', type: 'string', description: 'post title' },
          { name: 'content', type: 'string', description: 'post body' },
          { name: 'author', type: 'string', description: 'author username' },
          { name: 'subreddit', type: 'string', description: 'subreddit name' },
          { name: 'score', type: 'number', description: 'post score' },
          { name: 'num_comments', type: 'number', description: 'number of comments' },
          { name: 'url', type: 'string', description: 'post URL' },
        ],
        ref: createReferenceWithTitle(searchRedditRef, params, buildSearchRedditCallDescription),
      },
    },
    run: (inputs) => {
      const posts = coerceArray(inputs.reddit_raw)
        .map((item) => {
          const createdMs = toMs(item.created_at || item.createdAt);
          if (createdMs == null) {
            return null;
          }
          return {
            date: createdMs,
            post_id: item.post_id || item.id,
            title: item.title,
            content: item.selftext,
            author: item.author,
            subreddit: item.subreddit,
            score: item.score,
            num_comments: item.num_comments,
            url: item.url,
          };
        })
        .filter(Boolean)
        .sort((a, b) => a.date - b.date);

      return {
        reddit_posts: ensureUniqueDates(posts),
      };
    },
  };
}


function makeGoogleTrendingSearchesNode(params) {
  const geo = (params && params.geo) || 'US';
  const timeRange = (params && params.time) || 'past_24_hours';
  const category = params ? params.category : undefined;

  return {
    inputs: {
      trends_raw: () => searchGoogleTrendingTopic(params),
    },
    outputs: {
      trending_searches: {
        name: 'google_trending_searches',
        description: 'Snapshot of Google trending searches for a region and time range.',
        fields: [
          { name: 'date', type: 'number', description: 'snapshot time ms' },
          { name: 'geo', type: 'string', description: 'geographic region' },
          { name: 'time_range', type: 'string', description: 'requested time window' },
          { name: 'category', type: 'string', description: 'category filter if provided' },
          {
            name: 'trends',
            type: 'array',
            description: 'trending search items in this snapshot',
            fields: [
              { name: 'position', type: 'number', description: 'ranking position' },
              { name: 'query', type: 'string', description: 'search query' },
              { name: 'search_volume', type: 'number', description: 'approximate volume' },
              { name: 'percentage_increase', type: 'number', description: 'increase percentage' },
              { name: 'location', type: 'string', description: 'geo of the item' },
              {
                name: 'categories',
                type: 'array',
                description: 'categories associated with the query',
                fields: [{ name: 'value', type: 'string', description: 'category name' }],
              },
              {
                name: 'keywords',
                type: 'array',
                description: 'related keywords',
                fields: [{ name: 'value', type: 'string', description: 'keyword' }],
              },
            ],
          },
        ],
        ref: createReferenceWithTitle(
          getGoogleTrendingSearchesRef,
          params,
          buildSearchGoogleTrendingTopicCallDescription
        ),
      },
    },
    run: (inputs) => {
      const raw = inputs.trends_raw || {};
      const items = Array.isArray(raw.trends) ? raw.trends : [];
      const snapshot = {
        date: Date.now(),
        geo: geo,
        time_range: timeRange,
        category: category,
        trends: items.map((t) => ({
          position: t.position,
          query: t.query,
          search_volume: t.search_volume,
          percentage_increase: t.percentage_increase,
          location: t.location,
          categories: Array.isArray(t.categories) ? t.categories.map((c) => ({ value: c })) : [],
          keywords: Array.isArray(t.keywords) ? t.keywords.map((k) => ({ value: k })) : [],
        })),
      };
      return { trending_searches: [snapshot] };
    },
  };
}

// Nodified: DeFi protocol user activity as a graph node
function makeDefiProtocolUserActivityNode(params) {
  const activityType = params && params.type ? params.type : 'users';
  return {
    inputs: {
      activity_raw: () => getDefiProtocolUserActivity(params),
    },
    outputs: {
      user_activity: {
        name: 'protocol_user_activity',
        description: 'Protocol user activity time series data.',
        fields: [
          { name: 'date', type: 'number', description: 'day start time ms (UTC)' },
          { name: 'protocol_id', type: 'number', description: 'protocol ID' },
          { name: 'activity_type', type: 'string', description: "one of: 'users' | 'txs' | 'gas' | 'newusers'" },
          { name: 'value', type: 'number', description: 'activity value (users count, tx count, gas cost, or new users)' },
        ],
        ref: createReferenceWithTitle(
          getDefiProtocolUserActivityRef,
          params,
          buildGetDefiProtocolUserActivityCallDescription
        ),
      },
    },
    run: (inputs) => {
      const raw = coerceArray(inputs.activity_raw);
      const protocolId = params && (params.protocolId || params.protocol_id);
      const typeVal = String(activityType);
      const series = raw
        .map((row) => {
          const d = toMs(row.date || row.timestamp);
          const val =
            row.value ??
            row.users ??
            row.txs ??
            row.gas ??
            row.newusers ??
            row.newUsers ??
            row.active_users ??
            row.activeWallets ??
            row.wallets;
          if (d == null || val == null) return null;
          return {
            date: d,
            protocol_id: protocolId != null ? Number(protocolId) : null,
            activity_type: typeVal,
            value: Number(val),
          };
        })
        .filter(Boolean)
        .sort((a, b) => a.date - b.date);

      return {
        user_activity: ensureUniqueDates(series),
      };
    },
  };
}


module.exports = {
    searchX,
    searchKnowledge,
    searchBrowse,
    searchReddit,
    searchGoogleTrendingTopic,
    makeSearchXNode,
    makeSearchKnowledgeNode,
    makeSearchBrowseNode,
    makeSearchRedditNode,
    makeGoogleTrendingSearchesNode,
    getRefs,
};