const { syncFetch: fetch } = require('net/http');
const { useCredit } = require('internal');
const { load } = require('@alva/secret');
const { sdkRelay } = require('sdkrelay');

const API_KEY = load('TRADING_ECONOMICS_KEY');
const BASE_URL = 'https://api.tradingeconomics.com';

function toMs(value) {
	if (value == null) {
		return null;
	}
	if (typeof value === 'number') {
		return value > 1e12 ? value : value * 1000;
	}
	if (typeof value === 'string') {
		const parsed = Date.parse(value);
		if (!Number.isNaN(parsed)) {
			return parsed;
		}
	}
	return null;
}

function ensureUniqueDates(items) {
	const used = new Set();
	return items.map((item) => {
		let { date } = item;
		if (date == null) {
			date = Date.now();
		}
		while (used.has(date)) {
			date += 1;
		}
		used.add(date);
		return { ...item, date };
	});
}

// refs (sourced from tool.json)
const getHistoricalEconomicIndicatorRef = {
  id: '@alva/data/economics/getHistoricalEconomicIndicator',
  module_name: '@alva/data/economics',
  module_display_name: 'Global Economic Indicators',
  sdk_name: 'getHistoricalEconomicIndicator',
  sdk_display_name: 'Historical Economic Indicators',
  source_name: 'Trading Economics',
  source: 'https://docs.tradingeconomics.com/indicators/historical/#by-country-indicator-and-date',
};

const getEconomicIndicatorsByIndicatorRef = {
  id: '@alva/data/economics/getEconomicIndicatorsByIndicator',
  module_name: '@alva/data/economics',
  module_display_name: 'Global Economic Indicators',
  sdk_name: 'getEconomicIndicatorsByIndicator',
  sdk_display_name: 'Economic Indicators Snapshot by Indicators',
  source_name: 'Trading Economics',
  source: 'https://docs.tradingeconomics.com/indicators/snapshot/#countries-by-indicator',
};

const getEconomicIndicatorsByCategoryRef = {
  id: '@alva/data/economics/getEconomicIndicatorsByCategory',
  module_name: '@alva/data/economics',
  module_display_name: 'Global Economic Indicators',
  sdk_name: 'getEconomicIndicatorsByCategory',
  sdk_display_name: 'Economic Indicators Snapshot by Country and Category',
  source_name: 'Trading Economics',
  source: 'https://docs.tradingeconomics.com/indicators/snapshot/#data-by-country-and-category-group',
};

// -----------------------------------------------------------------------------
// Internal base descriptions (summaries from doc) and dynamic description builders
// -----------------------------------------------------------------------------

// Helpers
function __normalizeToArray(v) {
  if (v == null) return [];
  return Array.isArray(v) ? v : [v];
}

function __joinList(v) {
  return __normalizeToArray(v)
    .map((x) => (x == null ? '' : String(x).trim()))
    .filter((x) => x.length > 0)
    .join(', ');
}

function __formatDateYYYYMMDD(v) {
  if (v == null) return '';
  const n = typeof v === 'string' ? Date.parse(v) : Number(v);
  if (!Number.isFinite(n)) return String(v);
  const d = new Date(n);
  if (Number.isNaN(d.getTime())) return String(v);
  return d.toISOString().slice(0, 10);
}

// 1) getHistoricalEconomicIndicator
const baseGetHistoricalEconomicIndicatorDesc = 'Fetch historical economic indicators';
function buildGetHistoricalEconomicIndicatorCallDescription(actualParams = {}) {
  const parts = [baseGetHistoricalEconomicIndicatorDesc];

  const countries = __joinList(actualParams.country);
  if (countries) parts.push(`for ${countries}`);

  const indicators = __joinList(actualParams.indicator);
  if (indicators) parts.push(`on ${indicators}`);

  const filters = [];
  const hasStart = actualParams.start_date != null;
  const hasEnd = actualParams.end_date != null;
  if (hasStart && hasEnd) {
    filters.push(`Time: ${__formatDateYYYYMMDD(actualParams.start_date)} to ${__formatDateYYYYMMDD(actualParams.end_date)}`);
  } else if (hasStart) {
    filters.push(`Time from: ${__formatDateYYYYMMDD(actualParams.start_date)}`);
  } else if (hasEnd) {
    filters.push(`Time until: ${__formatDateYYYYMMDD(actualParams.end_date)}`);
  }

  if (filters.length) parts.push(`(${filters.join(', ')})`);

  return parts.join(' ').trim();
}

// 2) getEconomicIndicatorsByIndicator
const baseGetEconomicIndicatorsByIndicatorDesc = 'Get economic indicator snapshots';
function buildGetEconomicIndicatorsByIndicatorCallDescription(actualParams = {}) {
  const parts = [baseGetEconomicIndicatorsByIndicatorDesc];

  const countries = __joinList(actualParams.country);
  if (countries) parts.push(`for ${countries}`);

  const indicators = __joinList(actualParams.indicators);
  if (indicators) parts.push(`on ${indicators}`);

  return parts.join(' ').trim();
}

// 3) getEconomicIndicatorsByCategory
const baseGetEconomicIndicatorsByCategoryDesc = 'Get economic indicator snapshots by category group';
function buildGetEconomicIndicatorsByCategoryCallDescription(actualParams = {}) {
  const parts = [baseGetEconomicIndicatorsByCategoryDesc];

  const countries = __joinList(actualParams.country);
  if (countries) parts.push(`for ${countries}`);

  const groups = __joinList(actualParams.category_group);
  if (groups) parts.push(`in ${groups}`);

  return parts.join(' ').trim();
}

function createReferenceWithTitle(refObject, params, titleBuilder) {
  // 1. 使用传入的 titleBuilder 函数和 params 来生成 title
  const title = titleBuilder(params);

  // 2. 组合 refObject 和新 title
  const newObject = {
    ...refObject,
    title: title
  };

  // 3. 返回新对象
  return newObject;
}

function getHistoricalEconomicIndicator(params) {
	useCredit('getHistoricalEconomicIndicator', 350);
	return sdkRelay('GetEconomicHistorical', params);
}

function getEconomicIndicatorsByIndicator(params) {
	useCredit('getEconomicIndicatorsByIndicator', 350);
	
	const countryArray = Array.isArray(params.country) ? params.country : [params.country];
	const indicatorArray = Array.isArray(params.indicators) ? params.indicators : [params.indicators];
	
	const encodedCountries = countryArray.map(c => encodeURIComponent(c)).join(',');
	const encodedIndicators = indicatorArray.map(i => encodeURIComponent(i)).join(',');
	
	const url = `${BASE_URL}/country/${encodedCountries}/${encodedIndicators}?c=${API_KEY}&f=json`;
	
	const response = fetch(url, {
		method: 'GET',
		headers: {
			'Content-Type': 'application/json',
		},
	});

	return response.json();
}

function getEconomicIndicatorsByCategory(params) {
	useCredit('getEconomicIndicatorsByCategory', 350);
	
	const countryArray = Array.isArray(params.country) ? params.country : [params.country];
	const categoryArray = Array.isArray(params.category_group) ? params.category_group : [params.category_group];
	
	const encodedCountries = countryArray.map(c => encodeURIComponent(c)).join(',');
	const encodedCategoryGroups = categoryArray.map(g => encodeURIComponent(g)).join(',');
	
	const url = `${BASE_URL}/country/${encodedCountries}?c=${API_KEY}&f=json&group=${encodedCategoryGroups}`;

	const response = fetch(url, {
		method: 'GET',
		headers: {
			'Content-Type': 'application/json',
		},
	});
	
	return response.json();
}

function makeHistoricalEconomicIndicatorNode(params) {
	return {
		inputs: {
			historical_raw: () => getHistoricalEconomicIndicator(params),
		},
		outputs: {
			historical_indicators: {
				name: 'historical_economic_indicators',
				description: 'Historical economic indicator data points',
				fields: [
					{ name: 'date', type: 'number', description: 'data point date/time in milliseconds (UTC)' },
					{ name: 'country', type: 'string', description: 'country/region name' },
					{ name: 'category', type: 'string', description: 'economic indicator name' },
					{ name: 'value', type: 'number', description: 'indicator value at this date' },
					{ name: 'frequency', type: 'string', description: 'data reporting frequency (e.g., Yearly, Quarterly, Monthly)' },
					{ name: 'last_update', type: 'number', description: 'last update time in milliseconds (UTC)' },
				],
				ref: createReferenceWithTitle(getHistoricalEconomicIndicatorRef, params, buildGetHistoricalEconomicIndicatorCallDescription),
			},
		},
		run: (inputs) => {
			const rawData = inputs.historical_raw;
			const dataPoints = rawData?.data_points ;
			
			const mapped = dataPoints
				.map((item) => {
					const dateMs = toMs(item.date_time);
					const lastUpdateMs = toMs(item.last_update);
					
					if (dateMs == null) {
						return null;
					}
					
					return {
						date: dateMs,
						country: item.country,
						category: item.category,
						value: item.value,
						frequency: item.frequency,
						last_update: lastUpdateMs,
					};
				})
				.filter(Boolean)
				.sort((a, b) => a.date - b.date);
			
			return {
				historical_indicators: ensureUniqueDates(mapped),
			};
		},
	};
}

function makeEconomicIndicatorsByIndicatorNode(params) {
	return {
		inputs: {
			indicators_raw: () => getEconomicIndicatorsByIndicator(params),
		},
		outputs: {
			indicator_snapshots: {
				name: 'economic_indicator_snapshots',
				description: 'Economic indicator snapshots by indicator',
				fields: [
					{ name: 'date', type: 'number', description: 'snapshot time in milliseconds' },
					{ name: 'country', type: 'string', description: 'country name' },
					{ name: 'category', type: 'string', description: 'economic indicator category name' },
					{ name: 'title', type: 'string', description: 'combined country and indicator title' },
					{ name: 'latest_value_date', type: 'number', description: 'latest value date in milliseconds (UTC)' },
					{ name: 'latest_value', type: 'number', description: 'latest published indicator value' },
					{ name: 'previous_value', type: 'number', description: 'previous published value' },
					{ name: 'previous_value_date', type: 'number', description: 'previous value date in milliseconds (UTC)' },
					{ name: 'source', type: 'string', description: 'data source organization name' },
					{ name: 'source_url', type: 'string', description: 'direct URL to the data source' },
					{ name: 'unit', type: 'string', description: 'measurement unit of the value' },
					{ name: 'url', type: 'string', description: 'Trading Economics indicator page URL' },
					{ name: 'category_group', type: 'string', description: 'broader category classification' },
					{ name: 'adjustment', type: 'string', description: 'data adjustment description' },
					{ name: 'frequency', type: 'string', description: 'data publication frequency' },
					{ name: 'historical_data_symbol', type: 'string', description: 'unique identifier for this data series' },
					{ name: 'create_date', type: 'number', description: 'date added to database in milliseconds (UTC)' },
					{ name: 'first_value_date', type: 'number', description: 'earliest historical value date in milliseconds (UTC)' },
				],
				ref: createReferenceWithTitle(getEconomicIndicatorsByIndicatorRef, params, buildGetEconomicIndicatorsByIndicatorCallDescription),
			},
		},
		run: (inputs) => {
			const rawData = inputs.indicators_raw;

			const mapped = rawData.map((item) => ({
				date: Date.now(),
				country: item.Country,
				category: item.Category,
				title: item.Title,
				latest_value_date: toMs(item.LatestValueDate),
				latest_value: item.LatestValue,
				previous_value: item.PreviousValue,
				previous_value_date: toMs(item.PreviousValueDate),
				source: item.Source,
				source_url: item.SourceURL,
				unit: item.Unit,
				url: item.URL,
				category_group: item.CategoryGroup,
				adjustment: item.Adjustment,
				frequency: item.Frequency,
				historical_data_symbol: item.HistoricalDataSymbol,
				create_date: toMs(item.CreateDate),
				first_value_date: toMs(item.FirstValueDate),
			}));
			
			return {
				indicator_snapshots: ensureUniqueDates(mapped),
			};
		},
	};
}

function makeEconomicIndicatorsByCategoryNode(params) {
	return {
		inputs: {
			category_raw: () => getEconomicIndicatorsByCategory(params),
		},
		outputs: {
			category_snapshots: {
				name: 'economic_category_snapshots',
				description: 'Economic indicator snapshots by country and category group',
				fields: [
					{ name: 'date', type: 'number', description: 'snapshot time in milliseconds' },
					{ name: 'country', type: 'string', description: 'country name' },
					{ name: 'category', type: 'string', description: 'economic indicator category name' },
					{ name: 'title', type: 'string', description: 'combined country and indicator title' },
					{ name: 'latest_value_date', type: 'number', description: 'latest value date in milliseconds (UTC)' },
					{ name: 'latest_value', type: 'number', description: 'latest published indicator value' },
					{ name: 'previous_value', type: 'number', description: 'previous published value' },
					{ name: 'previous_value_date', type: 'number', description: 'previous value date in milliseconds (UTC)' },
					{ name: 'source', type: 'string', description: 'data source organization name' },
					{ name: 'source_url', type: 'string', description: 'direct URL to the data source' },
					{ name: 'unit', type: 'string', description: 'measurement unit of the value' },
					{ name: 'url', type: 'string', description: 'Trading Economics indicator page URL' },
					{ name: 'category_group', type: 'string', description: 'broader category classification' },
					{ name: 'adjustment', type: 'string', description: 'data adjustment description' },
					{ name: 'frequency', type: 'string', description: 'data publication frequency' },
					{ name: 'historical_data_symbol', type: 'string', description: 'unique identifier for this data series' },
					{ name: 'create_date', type: 'number', description: 'date added to database in milliseconds (UTC)' },
					{ name: 'first_value_date', type: 'number', description: 'earliest historical value date in milliseconds (UTC)' },
				],
				ref: createReferenceWithTitle(getEconomicIndicatorsByCategoryRef, params, buildGetEconomicIndicatorsByCategoryCallDescription),
			},
		},
		run: (inputs) => {
			const rawData = inputs.category_raw;
			const mapped = rawData.map((item) => ({
				date: Date.now(),
				country: item.Country,
				category: item.Category,
				title: item.Title,
				latest_value_date: toMs(item.LatestValueDate),
				latest_value: item.LatestValue,
				previous_value: item.PreviousValue,
				previous_value_date: toMs(item.PreviousValueDate),
				source: item.Source,
				source_url: item.SourceURL,
				unit: item.Unit,
				url: item.URL,
				category_group: item.CategoryGroup,
				adjustment: item.Adjustment,
				frequency: item.Frequency,
				historical_data_symbol: item.HistoricalDataSymbol,
				create_date: toMs(item.CreateDate),
				first_value_date: toMs(item.FirstValueDate),
			}));
			
			return {
				category_snapshots: ensureUniqueDates(mapped),
			};
		},
	};
}

function getRefs() {
	return [
		getHistoricalEconomicIndicatorRef,
		getEconomicIndicatorsByIndicatorRef,
		getEconomicIndicatorsByCategoryRef,
	];
}

module.exports = {
	getHistoricalEconomicIndicator,
	getEconomicIndicatorsByIndicator,
	getEconomicIndicatorsByCategory,
	makeHistoricalEconomicIndicatorNode,
	makeEconomicIndicatorsByIndicatorNode,
	makeEconomicIndicatorsByCategoryNode,
	getRefs,
};
