function main() {
	const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
	const { jagentId } = require('env');
	const {
		makeHistoricalEconomicIndicatorNode,
		makeEconomicIndicatorsByIndicatorNode,
		makeEconomicIndicatorsByCategoryNode,
	} = require('@alva/data/economics:v1.0.0');

	// Simple delay function to avoid API rate limits
	function delay(ms) {
		const start = Date.now();
		while (Date.now() - start < ms) {
			// Busy wait
		}
	}

	// Build a graph and add nodes for ref testing (no run to avoid network calls)
	const g = new Graph(jagentId);
	g.addNode('historical_indicators', makeHistoricalEconomicIndicatorNode({
		countries: ['united states'],
		indicators: [
			'gdp',
			'gdp growth rate',
			'gdp annual growth rate',
			'industrial production',
			'capacity utilization',
			'consumer price index cpi',
			'producer prices',
			'inflation rate',
			'inflation expectations',
			'wage growth',
			'core inflation rate',
			'unemployment rate',
			'non farm payrolls',
			'labor force participation rate',
			'average hourly earnings',
			'productivity',
			'initial jobless claims',
			'interest rate',
			'government bond 10y',
			'money supply m1',
			'money supply m2',
			'consumer credit',
			'retail sales mom',
			'retail sales yoy',
			'consumer spending',
			'housing starts',
			'building permits',
			'home ownership rate',
			'consumer confidence'
		],
		start_time: 1751282292000,
		end_time: 1751887292000,
	}));

	g.addNode('indicators_by_indicator', makeEconomicIndicatorsByIndicatorNode({
		country: ['united states'],
		indicators: ['gdp', 'unemployment rate']
	}));

	g.addNode('indicators_by_category', makeEconomicIndicatorsByCategoryNode({
		country: ['united states'],
		category_group: 'gdp'
	}));
	g.run();

	function getRefsSafe(graph, nodeKey, primaryOutputKey, fallbackOutputName) {
		let refs = [];
		try {
			refs = graph.getRefsForOutput(nodeKey, primaryOutputKey) || [];
		} catch (e) {
			refs = [];
		}
		if (!refs || refs.length === 0) {
			try {
				refs = graph.getRefsForOutput(nodeKey, fallbackOutputName) || [];
			} catch (e) {
				refs = [];
			}
		}
		return refs;
	}

	function assertRef(actualRef, expected, ctx) {
		if (actualRef.id !== expected.id) throw new Error(`${ctx}: ref.id mismatch: ${actualRef.id} !== ${expected.id}`);
		if (actualRef.module_name !== expected.module_name) throw new Error(`${ctx}: ref.module_name mismatch: ${actualRef.module_name} !== ${expected.module_name}`);
		if (actualRef.module_display_name !== expected.module_display_name) throw new Error(`${ctx}: ref.module_display_name mismatch: ${actualRef.module_display_name} !== ${expected.module_display_name}`);
		if (actualRef.sdk_name !== expected.sdk_name) throw new Error(`${ctx}: ref.sdk_name mismatch: ${actualRef.sdk_name} !== ${expected.sdk_name}`);
		if (actualRef.sdk_display_name !== expected.sdk_display_name) throw new Error(`${ctx}: ref.sdk_display_name mismatch: ${actualRef.sdk_display_name} !== ${expected.sdk_display_name}`);
		if (actualRef.source_name !== expected.source_name) throw new Error(`${ctx}: ref.source_name mismatch: ${actualRef.source_name} !== ${expected.source_name}`);
		if (actualRef.source !== expected.source) throw new Error(`${ctx}: ref.source mismatch: ${actualRef.source} !== ${expected.source}`);
	}

	// Assert refs for historical economic indicators (use output key)
	const refsHist = getRefsSafe(g, 'historical_indicators', 'historical_indicators', 'historical_economic_indicators');
	if (refsHist.length > 0) {
		const ref = refsHist[0];
		const expected = {
			id: '@alva/data/economics/getHistoricalEconomicIndicator',
			module_name: '@alva/data/economics',
			module_display_name: 'Global Economic Indicators',
			sdk_name: 'getHistoricalEconomicIndicator',
			sdk_display_name: 'Historical Economic Indicators',
			source_name: 'Trading Economics',
			source: 'https://docs.tradingeconomics.com/indicators/historical/#by-country-indicator-and-date',
		};
		assertRef(ref, expected, 'historical_indicators');
	} else {
		// Fallback: directly inspect the node outputs definitions
		const node = makeHistoricalEconomicIndicatorNode({});
		const out = node.outputs && node.outputs.historical_indicators;
		if (!out || !out.ref) {
			throw new Error('Assertion failed: refs array is empty for historical_indicators.');
		}
		const expected = {
			id: '@alva/data/economics/getHistoricalEconomicIndicator',
			module_name: '@alva/data/economics',
			module_display_name: 'Global Economic Indicators',
			sdk_name: 'getHistoricalEconomicIndicator',
			sdk_display_name: 'Historical Economic Indicators',
			source_name: 'Trading Economics',
			source: 'https://docs.tradingeconomics.com/indicators/historical/#by-country-indicator-and-date',
		};
		assertRef(out.ref, expected, 'historical_indicators (fallback)');
	}

	// Assert refs for indicators by indicator (use output key)
	const refsInd = getRefsSafe(g, 'indicators_by_indicator', 'indicator_snapshots', 'economic_indicator_snapshots');
	if (refsInd.length > 0) {
		const ref = refsInd[0];
		const expected = {
			id: '@alva/data/economics/getEconomicIndicatorsByIndicator',
			module_name: '@alva/data/economics',
			module_display_name: 'Global Economic Indicators',
			sdk_name: 'getEconomicIndicatorsByIndicator',
			sdk_display_name: 'Economic Indicators Snapshot by Indicators',
			source_name: 'Trading Economics',
			source: 'https://docs.tradingeconomics.com/indicators/snapshot/#countries-by-indicator',
		};
		assertRef(ref, expected, 'indicators_by_indicator');
	} else {
		const node = makeEconomicIndicatorsByIndicatorNode({});
		const out = node.outputs && node.outputs.indicator_snapshots;
		if (!out || !out.ref) {
			throw new Error('Assertion failed: refs array is empty for indicators_by_indicator.');
		}
		const expected = {
			id: '@alva/data/economics/getEconomicIndicatorsByIndicator',
			module_name: '@alva/data/economics',
			module_display_name: 'Global Economic Indicators',
			sdk_name: 'getEconomicIndicatorsByIndicator',
			sdk_display_name: 'Economic Indicators Snapshot by Indicators',
			source_name: 'Trading Economics',
			source: 'https://docs.tradingeconomics.com/indicators/snapshot/#countries-by-indicator',
		};
		assertRef(out.ref, expected, 'indicators_by_indicator (fallback)');
	}

	// Assert refs for indicators by category (use output key)
	const refsCat = getRefsSafe(g, 'indicators_by_category', 'category_snapshots', 'economic_category_snapshots');
	if (refsCat.length > 0) {
		const ref = refsCat[0];
		const expected = {
			id: '@alva/data/economics/getEconomicIndicatorsByCategory',
			module_name: '@alva/data/economics',
			module_display_name: 'Global Economic Indicators',
			sdk_name: 'getEconomicIndicatorsByCategory',
			sdk_display_name: 'Economic Indicators Snapshot by Country and Category',
			source_name: 'Trading Economics',
			source: 'https://docs.tradingeconomics.com/indicators/snapshot/#data-by-country-and-category-group',
		};
		assertRef(ref, expected, 'indicators_by_category');
	} else {
		const node = makeEconomicIndicatorsByCategoryNode({});
		const out = node.outputs && node.outputs.category_snapshots;
		if (!out || !out.ref) {
			throw new Error('Assertion failed: refs array is empty for indicators_by_category.');
		}
		const expected = {
			id: '@alva/data/economics/getEconomicIndicatorsByCategory',
			module_name: '@alva/data/economics',
			module_display_name: 'Global Economic Indicators',
			sdk_name: 'getEconomicIndicatorsByCategory',
			sdk_display_name: 'Economic Indicators Snapshot by Country and Category',
			source_name: 'Trading Economics',
			source: 'https://docs.tradingeconomics.com/indicators/snapshot/#data-by-country-and-category-group',
		};
		assertRef(out.ref, expected, 'indicators_by_category (fallback)');
	}

	console.log('✅ Economics refs metadata tests passed');

	// Validate Historical Economic Indicator Node Output
	const historicalUri = new TimeSeriesUri(jagentId, 'historical_indicators', 'historical_economic_indicators', { last: '100' });
	const historicalSeries = new TimeSeries(historicalUri, g.store);
	historicalSeries.init();
	const historicalData = historicalSeries.data;

	if (historicalData.length > 0) {
		const record = historicalData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('historical_indicators: date must be a positive number (ms)');
		}
		if (typeof record.country !== 'string') {
			throw new Error('historical_indicators: country must be a string');
		}
		if (typeof record.category !== 'string') {
			throw new Error('historical_indicators: category must be a string');
		}
		if (typeof record.value !== 'number') {
			throw new Error('historical_indicators: value must be a number');
		}
		if (typeof record.frequency !== 'string') {
			throw new Error('historical_indicators: frequency must be a string');
		}
		if (typeof record.last_update !== 'number') {
			throw new Error('historical_indicators: last_update must be a number');
		}
		
		// Validate date uniqueness
		const dates = historicalData.map(d => d.date);
		const uniqueDates = new Set(dates);
		if (uniqueDates.size !== dates.length) {
			throw new Error('historical_indicators: date values are not unique');
		}
		
		console.log('✓ historical_indicators node output validated');
	}

	// Validate Economic Indicators by Indicator Node Output
	const indicatorUri = new TimeSeriesUri(jagentId, 'indicators_by_indicator', 'economic_indicator_snapshots', { last: '100' });
	const indicatorSeries = new TimeSeries(indicatorUri, g.store);
	indicatorSeries.init();
	const indicatorData = indicatorSeries.data;

	if (indicatorData.length > 0) {
		const record = indicatorData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('indicators_by_indicator: date must be a positive number (ms)');
		}
		if (typeof record.country !== 'string') {
			throw new Error('indicators_by_indicator: country must be a string');
		}
		if (typeof record.category !== 'string') {
			throw new Error('indicators_by_indicator: category must be a string');
		}
		if (typeof record.title !== 'string') {
			throw new Error('indicators_by_indicator: title must be a string');
		}
		if (typeof record.latest_value_date !== 'number') {
			throw new Error('indicators_by_indicator: latest_value_date must be a number');
		}
		if (typeof record.latest_value !== 'number') {
			throw new Error('indicators_by_indicator: latest_value must be a number');
		}
		if (typeof record.previous_value !== 'number') {
			throw new Error('indicators_by_indicator: previous_value must be a number');
		}
		if (typeof record.previous_value_date !== 'number') {
			throw new Error('indicators_by_indicator: previous_value_date must be a number');
		}
		if (typeof record.source !== 'string') {
			throw new Error('indicators_by_indicator: source must be a string');
		}
		if (typeof record.source_url !== 'string') {
			throw new Error('indicators_by_indicator: source_url must be a string');
		}
		if (typeof record.unit !== 'string') {
			throw new Error('indicators_by_indicator: unit must be a string');
		}
		if (typeof record.url !== 'string') {
			throw new Error('indicators_by_indicator: url must be a string');
		}
		if (typeof record.category_group !== 'string') {
			throw new Error('indicators_by_indicator: category_group must be a string');
		}
		if (typeof record.adjustment !== 'string') {
			throw new Error('indicators_by_indicator: adjustment must be a string');
		}
		if (typeof record.frequency !== 'string') {
			throw new Error('indicators_by_indicator: frequency must be a string');
		}
		if (typeof record.historical_data_symbol !== 'string') {
			throw new Error('indicators_by_indicator: historical_data_symbol must be a string');
		}
		if (typeof record.create_date !== 'number') {
			throw new Error('indicators_by_indicator: create_date must be a number');
		}
		if (typeof record.first_value_date !== 'number') {
			throw new Error('indicators_by_indicator: first_value_date must be a number');
		}
		
		// Validate date uniqueness
		const dates = indicatorData.map(d => d.date);
		const uniqueDates = new Set(dates);
		if (uniqueDates.size !== dates.length) {
			throw new Error('indicators_by_indicator: date values are not unique');
		}
		
		console.log('✓ indicators_by_indicator node output validated');
	}

	// Validate Economic Indicators by Category Node Output
	const categoryUri = new TimeSeriesUri(jagentId, 'indicators_by_category', 'economic_category_snapshots', { last: '100' });
	const categorySeries = new TimeSeries(categoryUri, g.store);
	categorySeries.init();
	const categoryData = categorySeries.data;

	if (categoryData.length > 0) {
		const record = categoryData[0];
		if (typeof record.date !== 'number' || record.date <= 0) {
			throw new Error('indicators_by_category: date must be a positive number (ms)');
		}
		if (typeof record.country !== 'string') {
			throw new Error('indicators_by_category: country must be a string');
		}
		if (typeof record.category !== 'string') {
			throw new Error('indicators_by_category: category must be a string');
		}
		if (typeof record.title !== 'string') {
			throw new Error('indicators_by_category: title must be a string');
		}
		if (typeof record.latest_value_date !== 'number') {
			throw new Error('indicators_by_category: latest_value_date must be a number');
		}
		if (typeof record.latest_value !== 'number') {
			throw new Error('indicators_by_category: latest_value must be a number');
		}
		if (typeof record.previous_value !== 'number') {
			throw new Error('indicators_by_category: previous_value must be a number');
		}
		if (typeof record.previous_value_date !== 'number') {
			throw new Error('indicators_by_category: previous_value_date must be a number');
		}
		if (typeof record.source !== 'string') {
			throw new Error('indicators_by_category: source must be a string');
		}
		if (typeof record.source_url !== 'string') {
			throw new Error('indicators_by_category: source_url must be a string');
		}
		if (typeof record.unit !== 'string') {
			throw new Error('indicators_by_category: unit must be a string');
		}
		if (typeof record.url !== 'string') {
			throw new Error('indicators_by_category: url must be a string');
		}
		if (typeof record.category_group !== 'string') {
			throw new Error('indicators_by_category: category_group must be a string');
		}
		if (typeof record.adjustment !== 'string') {
			throw new Error('indicators_by_category: adjustment must be a string');
		}
		if (typeof record.frequency !== 'string') {
			throw new Error('indicators_by_category: frequency must be a string');
		}
		if (typeof record.historical_data_symbol !== 'string') {
			throw new Error('indicators_by_category: historical_data_symbol must be a string');
		}
		if (typeof record.create_date !== 'number') {
			throw new Error('indicators_by_category: create_date must be a number');
		}
		if (typeof record.first_value_date !== 'number') {
			throw new Error('indicators_by_category: first_value_date must be a number');
		}
		
		// Validate date uniqueness
		const dates = categoryData.map(d => d.date);
		const uniqueDates = new Set(dates);
		if (uniqueDates.size !== dates.length) {
			throw new Error('indicators_by_category: date values are not unique');
		}
		
		console.log('✓ indicators_by_category node output validated');
	}

	console.log('✅ Economics make*Node tests passed');
	return 0;
}

main();