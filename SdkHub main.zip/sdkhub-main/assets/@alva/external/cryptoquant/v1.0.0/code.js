/**
 * @description
 * This file contains functions for fetching ETH exchange flow data from the CryptoQuant API.
 * Each function follows the provided code template style, using synchronous fetch requests.
 * * @dependencies
 * - @alva/secret: For securely loading API keys.
 * - net/http: For making HTTP requests.
 * * @setup
 * Please ensure your access token is configured through @alva/secret and named 'CRYPTOQUANT_ACCESS_TOKEN'.
 */

const { load } = require('@alva/secret');
const { syncFetch: fetch } = require('net/http');

// Load CryptoQuant access token from secure storage
const accessToken = load('CRYPTOQUANT_ACCESS_TOKEN');

/**
 * Converts Unix timestamp (in seconds) to the date string format required by CryptoQuant API.
 * @param {number} timestamp - Unix timestamp in seconds.
 * @param {string} window - Time window, supports "day" or "hour".
 * @returns {string} Formatted date string.
 */
function formatTimestampForCryptoQuant(timestamp, window = 'day') {
	// JavaScript Date needs milliseconds, so multiply timestamp by 1000
	const date = new Date(timestamp * 1000);

	// Use UTC time to avoid timezone issues
	const year = date.getUTCFullYear();
	const month = String(date.getUTCMonth() + 1).padStart(2, '0'); // Months start from 0, so +1
	const day = String(date.getUTCDate()).padStart(2, '0');

	// If window is 'hour', add hours, minutes, and seconds
	if (window === 'hour') {
		const hours = String(date.getUTCHours()).padStart(2, '0');
		const minutes = String(date.getUTCMinutes()).padStart(2, '0');
		const seconds = String(date.getUTCSeconds()).padStart(2, '0');
		return `${year}${month}${day}T${hours}${minutes}${seconds}`;
	}

	// Default to 'day' format
	return `${year}${month}${day}`;
}

/**
 * Generic request builder for creating and executing requests to the CryptoQuant API.
 * @param {string} baseUrl - Base URL for the API endpoint.
 * @param {object} params - Query parameters object.
 * @returns {object} - JSON data returned by the API.
 */
function cryptoQuantFetcher(baseUrl, params) {
	// Create a copy of the parameters object for modification, avoiding affecting the original object
	const processedParams = { ...params };

	// <<< --- Key modifications start here --- >>>

	if (processedParams.exchange && typeof processedParams.exchange === 'string') {
		processedParams.exchange = processedParams.exchange.toLowerCase();
	}

	// Get the time window parameter, default to 'day'
	const window = processedParams.window || 'day';

	// Check 'from' parameter, if it's a Unix timestamp (number), format it
	if (processedParams.from && typeof processedParams.from === 'number') {
		processedParams.from = formatTimestampForCryptoQuant(processedParams.from, window);
	}

	// Check 'to' parameter, if it's a Unix timestamp (number), format it
	if (processedParams.to && typeof processedParams.to === 'number') {
		processedParams.to = formatTimestampForCryptoQuant(processedParams.to, window);
	}

	// <<< --- Key modifications end here --- >>>

	const keyValuePairs = Object.keys(processedParams || {}).map((key) => {
		const value = processedParams[key];
		return encodeURIComponent(key) + '=' + encodeURIComponent(value);
	});

	const queryString = keyValuePairs.join('&');
	const fullUrl = queryString ? `${baseUrl}?${queryString}` : baseUrl;

	const fetchOptions = {
		method: 'GET',
		headers: {
			Authorization: `Bearer ${accessToken}`,
		},
	};

	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

function normalizeTimestampToSeconds(ts) {
	if (typeof ts !== 'number') {
		return ts; // 返回 null/undefined/etc.
	}

	if (ts > 9999999999) {
		return Math.floor(ts / 1000);
	}
	return ts;
}

// +++ =============================================== +++
// +++            New Common Response Processing Function                 +++
// +++ =============================================== +++
/**
 * [Common utility function] Normalizes CryptoQuant API response data.
 * - Converts `date` or `datetime` fields in `result.data` to `timestamp` (Unix seconds).
 * - Removes the `result.window` field.
 * @param {object} apiResponse - Raw API response object from `cryptoQuantFetcher`.
 * @returns {object} Processed and normalized API response object.
 */
function normalizeCryptoQuantResponse(apiResponse, apiParams) {
	if (typeof apiParams === 'undefined') {
		throw new Error(
			"normalizeCryptoQuantResponse requires 'apiParams' object to be explicitly passed."
		);
	}

	if (!apiResponse || !apiResponse.result || !Array.isArray(apiResponse.result.data)) {
		return apiResponse;
	}

	let normalizedData = apiResponse.result.data.map((item) => {
		const dateString = item.datetime || item.date;
		if (!dateString) return item;

		const timestamp = Math.floor(new Date(dateString).getTime() / 1000);
		const { date, datetime, ...rest } = item;
		return { timestamp, ...rest };
	});

	if (normalizedData.length > 0 && normalizedData[0].timestamp !== undefined) {
		normalizedData.sort((a, b) => a.timestamp - b.timestamp);
	}

	const { from, to } = apiParams;

	let fromTs = normalizeTimestampToSeconds(from);
	let toTs = normalizeTimestampToSeconds(to);

	if (fromTs || toTs) {
		if (fromTs && !toTs) {
			toTs = Math.floor(Date.now() / 1000);
		}
		if (fromTs) {
			normalizedData = normalizedData.filter(item => item.timestamp >= fromTs);
		}
		if (toTs) {
			normalizedData = normalizedData.filter(item => item.timestamp <= toTs);
		}
	}

	apiResponse.result.data = normalizedData;
	delete apiResponse.result.window;

	return apiResponse;
}

function toMs(value) {
	if (value == null) {
		return null;
	}
	if (typeof value === 'number') {
		return value > 1e12 ? value : value * 1000;
	}
	if (typeof value === 'string') {
		const parsed = Date.parse(value);
		if (!Number.isNaN(parsed)) {
			return parsed;
		}
	}
	return null;
}

function extractSeries(response) {
	const data = response?.result?.data;
	return Array.isArray(data) ? data : [];
}

function ensureUniqueDates(records) {
	const used = new Set();
	return records.map((record) => {
		let { date } = record;
		while (used.has(date)) {
			date += 1;
		}
		used.add(date);
		return { ...record, date };
	});
}

function buildCqNode(fetchFn, config) {
	const { outputKey, outputName, description, fields, ensureUnique = true, mapRecords } = config;
	return (params) => ({
		inputs: {
			raw: () => fetchFn(params),
		},
		outputs: {
			[outputKey]: {
				name: outputName,
				description,
				fields: [
					{
						name: 'date',
						type: 'number',
						description: 'timestamp ms',
					},
					...fields.map((field) => ({
						name: field.name,
						type: field.type || 'number',
						description: field.description,
					})),
				],
			},
		},
		run: (inputs) => {
			const series = (
				mapRecords
					? mapRecords(inputs.raw, params)
					: extractSeries(inputs.raw).map((item) => {
							const date = toMs(item.timestamp || item.datetime || item.date);
							if (date == null) {
								return null;
							}
							const record = { date };
							for (const field of fields) {
								const sourceKey = field.source || field.name;
								const value = field.transform ? field.transform(item[sourceKey], item, params) : item[sourceKey];
								record[field.name] = value == null ? null : value;
							}
							return record;
						})
			).filter(Boolean);
			return {
				[outputKey]: ensureUnique ? ensureUniqueDates(series) : series,
			};
		},
	});
}

function getCQExchangeReserve(params) {
	const { symbol, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (!apiParams.exchange) {
		throw new Error("The 'exchange' parameter is required.");
	}

	const supportedExchanges = [
		'binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'
	];
	const lowerCaseExchange = apiParams.exchange.toLowerCase();
	if(!supportedExchanges.includes(lowerCaseExchange)){
		throw new Error(`Unsupported exchange: '${apiParams.exchange}'. This function only supports ''binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'.`);
	}

	const supportedSymbols = ['btc', 'eth', 'xrp'];
	const lowerCaseSymbol = symbol.toLowerCase();

	// Add the extra validation for the symbol
	if (!supportedSymbols.includes(lowerCaseSymbol)) {
		throw new Error(`Unsupported symbol: '${symbol}'. This function only supports 'btc', 'eth', and 'xrp'.`);
	}
	// --- End of Validation Block ---

	// Automatically determine the flow type based on the symbol
	const flowType = lowerCaseSymbol === 'xrp' ? 'entity-flows' : 'exchange-flows';

	// Build the URL dynamically
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/${flowType}/reserve`;

	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQExchangeNetflow(params) {
	const { symbol, ...apiParams } = params;
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	const supportedExchanges = [
		'binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'
	];
	const lowerCaseExchange = apiParams.exchange.toLowerCase();
	if(!supportedExchanges.includes(lowerCaseExchange)){
		throw new Error(`Unsupported exchange: '${apiParams.exchange}'. This function only supports ''binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'.`);
	}
	const baseUrl = `https://api.cryptoquant.com/v1/${symbol.toLowerCase()}/exchange-flows/netflow`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQExchangeInflow(params) {
	const { symbol, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (!apiParams.exchange) {
		throw new Error("The 'exchange' parameter is required.");
	}

	const supportedExchanges = [
		'binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'
	];
	const lowerCaseExchange = apiParams.exchange.toLowerCase();
	if(!supportedExchanges.includes(lowerCaseExchange)){
		throw new Error(`Unsupported exchange: '${apiParams.exchange}'. This function only supports ''binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'.`);
	}

	const supportedSymbols = ['btc', 'eth', 'xrp'];
	const lowerCaseSymbol = symbol.toLowerCase();

	if (!supportedSymbols.includes(lowerCaseSymbol)) {
		throw new Error(`Unsupported symbol: '${symbol}'. This function only supports 'btc', 'eth', and 'xrp'.`);
	}
	// --- End of Validation Block ---

	// Automatically determine the flow type based on the symbol
	const flowType = lowerCaseSymbol === 'xrp' ? 'entity-flows' : 'exchange-flows';

	// Build the URL dynamically
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/${flowType}/inflow`;

	// Fetch the raw data and apply basic normalization
	const rawResponse = cryptoQuantFetcher(baseUrl, apiParams);
	const normalizedResponse = normalizeCryptoQuantResponse(rawResponse,apiParams);

	// Standardize the result data to ensure a consistent output structure
	if (normalizedResponse.result && normalizedResponse.result.data) {
		const mappedData = normalizedResponse.result.data.map((item) => {
			// The source field is 'inflow_total' for BTC/ETH and 'inflow' for XRP.
			// This line correctly assigns the value from whichever field is present.
			const totalInflow = item.inflow_total !== undefined ? item.inflow_total : item.inflow;

			return {
				timestamp: item.timestamp,
				inflow_total: totalInflow,
			};
		});

		normalizedResponse.result.data = mappedData;
	}

	return normalizedResponse;
}

function getCQExchangeOutflow(params) {
	const { symbol, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (!apiParams.exchange) {
		throw new Error("The 'exchange' parameter is required.");
	}

	const supportedExchanges = [
		'binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'
	];
	const lowerCaseExchange = apiParams.exchange.toLowerCase();
	if(!supportedExchanges.includes(lowerCaseExchange)){
		throw new Error(`Unsupported exchange: '${apiParams.exchange}'. This function only supports ''binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'.`);
	}

	const supportedSymbols = ['btc', 'eth', 'xrp'];
	const lowerCaseSymbol = symbol.toLowerCase();

	if (!supportedSymbols.includes(lowerCaseSymbol)) {
		throw new Error(`Unsupported symbol: '${symbol}'. This function only supports 'btc', 'eth', and 'xrp'.`);
	}
	// --- End of Validation Block ---

	// Automatically determine the flow type based on the symbol
	const flowType = lowerCaseSymbol === 'xrp' ? 'entity-flows' : 'exchange-flows';

	// Build the URL dynamically
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/${flowType}/outflow`;

	// Fetch the raw data and apply basic normalization
	const rawResponse = cryptoQuantFetcher(baseUrl, apiParams);
	const normalizedResponse = normalizeCryptoQuantResponse(rawResponse,apiParams);

	// Standardize the result data to ensure a consistent output structure
	if (normalizedResponse.result && normalizedResponse.result.data) {
		const mappedData = normalizedResponse.result.data.map((item) => {
			// The source field is 'outflow_total' for BTC/ETH and 'outflow' for XRP.
			// This assigns the value from whichever field is present to the standard 'outflow_total' key.
			const totalOutflow = item.outflow_total !== undefined ? item.outflow_total : item.outflow;

			return {
				timestamp: item.timestamp,
				outflow_total: totalOutflow,
			};
		});

		normalizedResponse.result.data = mappedData;
	}

	return normalizedResponse;
}

function getCQExchangeTransactionsCount(params) {
	const { symbol, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (!apiParams.exchange) {
		throw new Error("The 'exchange' parameter is required.");
	}

	const supportedExchanges = [
		'binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'
	];
	const lowerCaseExchange = apiParams.exchange.toLowerCase();
	if(!supportedExchanges.includes(lowerCaseExchange)){
		throw new Error(`Unsupported exchange: '${apiParams.exchange}'. This function only supports ''binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'.`);
	}

	const supportedSymbols = ['btc', 'eth', 'xrp'];
	const lowerCaseSymbol = symbol.toLowerCase();

	if (!supportedSymbols.includes(lowerCaseSymbol)) {
		throw new Error(`Unsupported symbol: '${symbol}'. This function only supports 'btc', 'eth', and 'xrp'.`);
	}
	// --- End of Validation Block ---

	// Automatically determine the flow type based on the symbol
	const flowType = lowerCaseSymbol === 'xrp' ? 'entity-flows' : 'exchange-flows';

	// Build the URL dynamically
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/${flowType}/transactions-count`;

	// Fetch the raw data and apply basic normalization
	const rawResponse = cryptoQuantFetcher(baseUrl, apiParams);
	const normalizedResponse = normalizeCryptoQuantResponse(rawResponse,apiParams);

	// Standardize the result data to ensure a consistent output structure
	if (normalizedResponse.result && normalizedResponse.result.data) {
		const mappedData = normalizedResponse.result.data.map((item) => {
			// Map 'deposit' to 'inflow' and 'withdraw' to 'outflow' for consistency
			const inflowCount = item.transactions_count_inflow !== undefined ? item.transactions_count_inflow : item.transactions_count_deposit;

			const outflowCount = item.transactions_count_outflow !== undefined ? item.transactions_count_outflow : item.transactions_count_withdraw;

			return {
				timestamp: item.timestamp,
				transactions_count_inflow: inflowCount,
				transactions_count_outflow: outflowCount,
			};
		});

		normalizedResponse.result.data = mappedData;
	}

	return normalizedResponse;
}

function getCQExchangeAddressesCount(params) {
	const { symbol, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (!apiParams.exchange) {
		throw new Error("The 'exchange' parameter is required.");
	}

	const supportedExchanges = [
		'binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'
	];
	const lowerCaseExchange = apiParams.exchange.toLowerCase();
	if(!supportedExchanges.includes(lowerCaseExchange)){
		throw new Error(`Unsupported exchange: '${apiParams.exchange}'. This function only supports ''binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'.`);
	}

	const supportedSymbols = ['btc', 'eth', 'xrp'];
	const lowerCaseSymbol = symbol.toLowerCase();

	if (!supportedSymbols.includes(lowerCaseSymbol)) {
		throw new Error(`Unsupported symbol: '${symbol}'. This function only supports 'btc', 'eth', and 'xrp'.`);
	}
	// --- End of Validation Block ---

	// Automatically determine the flow type based on the symbol
	const flowType = lowerCaseSymbol === 'xrp' ? 'entity-flows' : 'exchange-flows';

	// Build the URL dynamically
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/${flowType}/addresses-count`;

	// Fetch the raw data and apply basic normalization
	const rawResponse = cryptoQuantFetcher(baseUrl, apiParams);
	const normalizedResponse = normalizeCryptoQuantResponse(rawResponse,apiParams);

	// Standardize the result data to ensure a consistent output structure
	if (normalizedResponse.result && normalizedResponse.result.data) {
		const mappedData = normalizedResponse.result.data.map((item) => {
			// Map 'deposit' to 'inflow' and 'withdraw' to 'outflow' for consistency
			const inflowCount = item.addresses_count_inflow !== undefined ? item.addresses_count_inflow : item.addresses_count_deposit;

			const outflowCount = item.addresses_count_outflow !== undefined ? item.addresses_count_outflow : item.addresses_count_withdraw;

			return {
				timestamp: item.timestamp,
				addresses_count_inflow: inflowCount,
				addresses_count_outflow: outflowCount,
			};
		});

		normalizedResponse.result.data = mappedData;
	}

	return normalizedResponse;
}

function getCQTotalValueStaked(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (symbol.toLowerCase() !== 'eth2') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'eth2'.`);
	}

	// Validate window parameter if provided
	if (window) {
		const validWindows = ['day', 'hour', 'block'];
		if (!validWindows.includes(window)) {
			throw new Error(`Invalid window: '${window}'. This function only supports '${validWindows.join("', '")}'.`);
		}
		apiParams.window = window;
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = 'https://api.cryptoquant.com/v1/eth/eth2/total-value-staked';
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQStakingInflowTotal(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (symbol.toLowerCase() !== 'eth2') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'eth2'.`);
	}

	// Validate window parameter if provided
	if (window) {
		const validWindows = ['day', 'hour'];
		if (!validWindows.includes(window)) {
			throw new Error(`Invalid window: '${window}'. This function only supports '${validWindows.join("', '")}'.`);
		}
		apiParams.window = window;
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = 'https://api.cryptoquant.com/v1/eth/eth2/staking-inflow-total';
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQStakingTransactionCount(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (symbol.toLowerCase() !== 'eth2') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'eth2'.`);
	}

	// Validate window parameter if provided
	if (window) {
		const validWindows = ['day', 'hour'];
		if (!validWindows.includes(window)) {
			throw new Error(`Invalid window: '${window}'. This function only supports '${validWindows.join("', '")}'.`);
		}
		apiParams.window = window;
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = 'https://api.cryptoquant.com/v1/eth/eth2/staking-transaction-count';
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQStakingValidatorTotal(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (symbol.toLowerCase() !== 'eth2') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'eth2'.`);
	}

	// Validate window parameter if provided
	if (window) {
		const validWindows = ['day', 'hour'];
		if (!validWindows.includes(window)) {
			throw new Error(`Invalid window: '${window}'. This function only supports '${validWindows.join("', '")}'.`);
		}
		apiParams.window = window;
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = 'https://api.cryptoquant.com/v1/eth/eth2/staking-validator-total';
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQDepositorCountTotal(params) {
	const { symbol, window, limit } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (symbol.toLowerCase() !== 'eth2') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'eth2'.`);
	}

	// Validate window parameter if provided
	if (window && window !== 'day' && window !== 'hour') {
		throw new Error(`Invalid window: '${window}'. This function only supports 'day' and 'hour'.`);
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
	}
	// --- End of Validation Block ---

	const baseUrl = 'https://api.cryptoquant.com/v1/eth/eth2/depositor-count-total';
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, params),params);
}

function getCQDepositorCountNew(params) {
	const { symbol, window, limit } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (symbol.toLowerCase() !== 'eth2') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'eth2'.`);
	}

	// Validate window parameter if provided
	if (window && window !== 'day' && window !== 'hour') {
		throw new Error(`Invalid window: '${window}'. This function only supports 'day' and 'hour'.`);
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
	}
	// --- End of Validation Block ---

	const baseUrl = 'https://api.cryptoquant.com/v1/eth/eth2/depositor-count-new';
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, params),params);
}

function getCQNetworkContractsCount(params) {
	const { symbol, ...apiParams } = params;
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'eth') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'eth'.`);
	}
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-data/contracts-count`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),params);
}

function getCQNetworkBlockCount(params) {
	const { symbol, ...apiParams } = params;
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'eth') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'eth'.`);
	}
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-data/block-count`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),params);
}

function getCQNetworkGas(params) {
	const { symbol, ...apiParams } = params;
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'eth') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'eth'.`);
	}
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-data/gas`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),params);
}

function getCQNetworkBlockReward(params) {
	const { symbol, ...apiParams } = params;
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	const lowerCaseSymbol = symbol.toLowerCase();
	const supportedSymbols = ['btc', 'eth'];
	if (!supportedSymbols.includes(lowerCaseSymbol)) {
		throw new Error(`Unsupported symbol: '${symbol}'. This function supports 'btc' and 'eth'.`);
	}
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-data/blockreward`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),params);
}

function getCQExchangeInHouseFlow(params) {
	const { symbol, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (!apiParams.exchange) {
		throw new Error("The 'exchange' parameter is required.");
	}

	const supportedExchanges = [
		'binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'
	];
	const lowerCaseExchange = apiParams.exchange.toLowerCase();
	if(!supportedExchanges.includes(lowerCaseExchange)){
		throw new Error(`Unsupported exchange: '${apiParams.exchange}'. This function only supports ''binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'.`);
	}

	const lowerCaseSymbol = symbol.toLowerCase();

	// Add validation for the symbol
	if (lowerCaseSymbol !== 'btc') {
		throw new Error(`Invalid symbol: '${symbol}'. This function currently only supports 'btc'.`);
	}
	// --- End of Validation Block ---

	// Build the URL dynamically
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/exchange-flows/in-house-flow`;

	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),params);
}

function getCQMarketIndicatorSopr(params) {
	const { symbol, ...apiParams } = params;
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'btc') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'btc'.`);
	}
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/market-indicator/sopr`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQFlowIndicatorMpi(params) {
	const { symbol, ...apiParams } = params;
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'btc') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'btc'.`);
	}
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/flow-indicator/mpi`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQFlowIndicatorExchangeWhaleRatio(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (!apiParams.exchange) {
		throw new Error("The 'exchange' parameter is required.");
	}

	const supportedExchanges = [
		'binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'gate.io', 'gateio', 'htx', 'htx global', 'kucoin', 'okx', 'upbit'
	];
	const lowerCaseExchange = apiParams.exchange.toLowerCase();
	if (!supportedExchanges.includes(lowerCaseExchange)) {
		throw new Error(`Unsupported exchange: '${apiParams.exchange}'. This function only supports ${supportedExchanges.map(e => `'${e}'`).join(', ')}.`);
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'btc') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'btc'.`);
	}

	// Validate window parameter if provided
	if (window && window !== 'day' && window !== 'hour') {
		throw new Error(`Invalid window: '${window}'. This function only supports 'day' and 'hour'.`);
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/flow-indicator/exchange-whale-ratio`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQFlowIndicatorExchangeInflowAgeDistribution(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (!apiParams.exchange) {
		throw new Error("The 'exchange' parameter is required.");
	}

	const supportedExchanges = [
		'binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'gate.io', 'gateio', 'htx', 'htx global', 'kucoin', 'okx', 'upbit'
	];
	const lowerCaseExchange = apiParams.exchange.toLowerCase();
	if (!supportedExchanges.includes(lowerCaseExchange)) {
		throw new Error(`Unsupported exchange: '${apiParams.exchange}'. This function only supports ${supportedExchanges.map(e => `'${e}'`).join(', ')}.`);
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'btc') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'btc'.`);
	}

	// Validate window parameter if provided
	if (window && window !== 'day' && window !== 'hour') {
		throw new Error(`Invalid window: '${window}'. This function only supports 'day' and 'hour'.`);
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/flow-indicator/exchange-inflow-age-distribution`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQSupplySC(params) {
	const { token, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!token) {
		throw new Error("The 'token' parameter is required.");
	}

	const supportedTokens = [
		'all_token', 'usdt_eth', 'usdt_omni', 'usdp', 'usdc', 'tusd', 'dai', 'sai'
	];

	if (!supportedTokens.includes(token)) {
		throw new Error(`Unsupported token: '${token}'. This function only supports ${supportedTokens.map(t => `'${t}'`).join(', ')}.`);
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}

	// Validate timestamp ranges
	if (from !== undefined && from <= 0) {
		throw new Error(`Invalid timestamp: 'from' (${from}) must be a positive Unix timestamp.`);
	}
	if (to !== undefined && to <= 0) {
		throw new Error(`Invalid timestamp: 'to' (${to}) must be a positive Unix timestamp.`);
	}
	// --- End of Validation Block ---

	apiParams.token = token;
	const baseUrl = `https://api.cryptoquant.com/v1/stablecoin/network-data/supply`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQNetworkIndicatorStockToFlow(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'btc') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'btc'.`);
	}

	// Validate window parameter if provided
	if (window) {
		const validWindows = ['day', 'hour', 'block'];
		if (!validWindows.includes(window)) {
			throw new Error(`Invalid window: '${window}'. This function only supports '${validWindows.join("', '")}'.`);
		}
		apiParams.window = window;
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		// If both from and to are provided, both must be numbers
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			// If only one of them is provided, validate the individual parameter
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			// Only add the provided parameter
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-indicator/stock-to-flow`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQNetworkIndicatorNvt(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'btc') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'btc'.`);
	}

	// Validate window parameter if provided
	if (window) {
		const validWindows = ['day'];  // NVT only supports 'day' based on docs
		if (!validWindows.includes(window)) {
			throw new Error(`Invalid window: '${window}'. This function only supports '${validWindows.join("', '")}'.`);
		}
		apiParams.window = window;
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		// If both from and to are provided, both must be numbers
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			// If only one of them is provided, validate the individual parameter
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			// Only add the provided parameter
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-indicator/nvt`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQNetworkIndicatorPuellMultiple(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'btc') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'btc'.`);
	}

	// Validate window parameter if provided
	if (window) {
		const validWindows = ['day'];  // Puell Multiple only supports 'day' based on docs
		if (!validWindows.includes(window)) {
			throw new Error(`Invalid window: '${window}'. This function only supports '${validWindows.join("', '")}'.`);
		}
		apiParams.window = window;
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		// If both from and to are provided, both must be numbers
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			// If only one of them is provided, validate the individual parameter
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			// Only add the provided parameter
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-indicator/puell-multiple`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQNetworkIndicatorCdd(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'btc') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'btc'.`);
	}

	// Validate window parameter if provided
	if (window) {
		const validWindows = ['day'];  // CDD only supports 'day' based on docs
		if (!validWindows.includes(window)) {
			throw new Error(`Invalid window: '${window}'. This function only supports '${validWindows.join("', '")}'.`);
		}
		apiParams.window = window;
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		// If both from and to are provided, both must be numbers
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			// If only one of them is provided, validate the individual parameter
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			// Only add the provided parameter
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-indicator/cdd`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQNetworkIndicatorMca(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'btc') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'btc'.`);
	}

	// Validate window parameter if provided
	if (window) {
		const validWindows = ['day'];  // MCA only supports 'day' based on docs
		if (!validWindows.includes(window)) {
			throw new Error(`Invalid window: '${window}'. This function only supports '${validWindows.join("', '")}'.`);
		}
		apiParams.window = window;
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		// If both from and to are provided, both must be numbers
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			// If only one of them is provided, validate the individual parameter
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			// Only add the provided parameter
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-indicator/mca`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQNetworkIndicatorSca(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'btc') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'btc'.`);
	}

	// Validate window parameter if provided
	if (window) {
		const validWindows = ['day'];  // SCA only supports 'day' based on docs
		if (!validWindows.includes(window)) {
			throw new Error(`Invalid window: '${window}'. This function only supports '${validWindows.join("', '")}'.`);
		}
		apiParams.window = window;
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		// If both from and to are provided, both must be numbers
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			// If only one of them is provided, validate the individual parameter
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			// Only add the provided parameter
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-indicator/sca`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQNetworkIndicatorScaDistribution(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'btc') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'btc'.`);
	}

	// Validate window parameter if provided
	if (window) {
		const validWindows = ['day'];  // SCA Distribution only supports 'day' based on docs
		if (!validWindows.includes(window)) {
			throw new Error(`Invalid window: '${window}'. This function only supports '${validWindows.join("', '")}'.`);
		}
		apiParams.window = window;
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		// If both from and to are provided, both must be numbers
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			// If only one of them is provided, validate the individual parameter
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			// Only add the provided parameter
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-indicator/sca-distribution`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQNetworkIndicatorNupl(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'btc') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'btc'.`);
	}

	// Validate window parameter if provided
	if (window) {
		const validWindows = ['day'];  // NUPL only supports 'day' based on docs
		if (!validWindows.includes(window)) {
			throw new Error(`Invalid window: '${window}'. This function only supports '${validWindows.join("', '")}'.`);
		}
		apiParams.window = window;
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 10000) {  // NUPL has different max limit of 10000 based on docs
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 10000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		// If both from and to are provided, both must be numbers
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			// If only one of them is provided, validate the individual parameter
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			// Only add the provided parameter
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-indicator/nupl`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQNetworkIndicatorNrpl(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'btc') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'btc'.`);
	}

	// Validate window parameter if provided
	if (window) {
		const validWindows = ['day', 'hour'];  // NRPL supports 'day' and 'hour' based on docs
		if (!validWindows.includes(window)) {
			throw new Error(`Invalid window: '${window}'. This function only supports '${validWindows.join("', '")}'.`);
		}
		apiParams.window = window;
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
		apiParams.limit = limit;
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		// If both from and to are provided, both must be numbers
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			// If only one of them is provided, validate the individual parameter
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			// Only add the provided parameter
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-indicator/nrpl`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQExchangeShare(params) {
	const { symbol, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}
	if (!apiParams.exchange) {
		throw new Error("The 'exchange' parameter is required.");
	}

	const supportedExchanges = [
		'binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'
	];
	const lowerCaseExchange = apiParams.exchange.toLowerCase();
	if(!supportedExchanges.includes(lowerCaseExchange)){
		throw new Error(`Unsupported exchange: '${apiParams.exchange}'. This function only supports ''binance', 'bitfinex', 'bitget', 'bithumb', 'bitstamp',
		'bybit', 'kucoin', 'okx', 'upbit'.`);
	}

	const lowerCaseSymbol = symbol.toLowerCase();

	// Add validation for the symbol
	if (lowerCaseSymbol !== 'xrp') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'xrp'.`);
	}
	// --- End of Validation Block ---

	// Build the URL for the specific XRP entity flow endpoint
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/entity-flows/share`;

	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQWhaleMovements(params) {
	const { symbol, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const lowerCaseSymbol = symbol.toLowerCase();

	if (lowerCaseSymbol !== 'xrp') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'xrp'.`);
	}
	// --- End of Validation Block ---

	// Build the URL for the specific XRP entity flow endpoint
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/entity-flows/whale-movements`;

	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQNetworkTokensTransferred(params) {
	const { symbol, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const supportedSymbols = ['btc', 'eth', 'xrp'];
	const lowerCaseSymbol = symbol.toLowerCase();

	if (!supportedSymbols.includes(lowerCaseSymbol)) {
		throw new Error(`Unsupported symbol: '${symbol}'. This function only supports 'btc', 'eth', and 'xrp'.`);
	}
	// --- End of Validation Block ---

	// Build the URL dynamically
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-data/tokens-transferred`;

	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl, apiParams),apiParams);
}

function getCQDexVolume(params) {
	const { symbol, window, limit, from, to } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'xrp') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'xrp'.`);
	}

	// Validate window parameter if provided
	if (window && window !== 'day' && window !== 'hour') {
		throw new Error(`Invalid window: '${window}'. This function only supports 'day' and 'hour'.`);
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
	}

	// Validate time range if provided
	if (from !== undefined && to !== undefined) {
		if (typeof from !== 'number' || typeof to !== 'number') {
			throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
		}
		if (from >= to) {
			throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/dex-data/volume`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl,params),params);
}

function getCQDexTransactionsCount(params) {
	const { symbol, window, limit, from, to } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'xrp') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'xrp'.`);
	}

	// Validate window parameter if provided
	if (window && window !== 'day' && window !== 'hour') {
		throw new Error(`Invalid window: '${window}'. This function only supports 'day' and 'hour'.`);
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
	}

	// Validate time range if provided
	if (from !== undefined && to !== undefined) {
		if (typeof from !== 'number' || typeof to !== 'number') {
			throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
		}
		if (from >= to) {
			throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/dex-data/transactions-count`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl,params),params);
}

function getCQDexLiquidity(params) {
	const { symbol, window, limit, from, to } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'xrp') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'xrp'.`);
	}

	// Validate window parameter if provided
	if (window && window !== 'day' && window !== 'hour') {
		throw new Error(`Invalid window: '${window}'. This function only supports 'day' and 'hour'.`);
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
	}

	// Validate time range if provided
	if (from !== undefined && to !== undefined) {
		if (typeof from !== 'number' || typeof to !== 'number') {
			throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
		}
		if (from >= to) {
			throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/dex-data/liquidity`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl,params),params);
}

function getCQDexDexPrice(params) {
	const { symbol, window, limit, from, to } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const lowerCaseSymbol = symbol.toLowerCase();
	if (lowerCaseSymbol !== 'xrp') {
		throw new Error(`Unsupported symbol: '${symbol}'. This function currently only supports 'xrp'.`);
	}

	// Validate window parameter if provided
	if (window && window !== 'day' && window !== 'hour') {
		throw new Error(`Invalid window: '${window}'. This function only supports 'day' and 'hour'.`);
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
	}

	// Validate time range if provided
	if (from !== undefined && to !== undefined) {
		if (typeof from !== 'number' || typeof to !== 'number') {
			throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
		}
		if (from >= to) {
			throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
		}
	}
	// --- End of Validation Block ---

	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/dex-data/dex-price`;
	return normalizeCryptoQuantResponse(cryptoQuantFetcher(baseUrl,params),params);
}

function getCQNetworkAddressesCount(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const supportedSymbols = ['btc', 'xrp'];
	const lowerCaseSymbol = symbol.toLowerCase();
	if (!supportedSymbols.includes(lowerCaseSymbol)) {
		throw new Error(`Unsupported symbol: '${symbol}'. This function only supports 'btc' and 'xrp'.`);
	}

	// Validate window parameter if provided
	if (window && window !== 'day' && window !== 'hour') {
		throw new Error(`Invalid window: '${window}'. This function only supports 'day' and 'hour'.`);
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	// Dynamically build the URL based on the symbol
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-data/addresses-count`;

	// Fetch the data from the API
	const rawResponse = cryptoQuantFetcher(baseUrl, apiParams);
	const normalizedResponse = normalizeCryptoQuantResponse(rawResponse,apiParams);

	// If the symbol is XRP, map its unique field names to the standard ones
	// This ensures the function's output is consistent for any symbol
	if (symbol.toLowerCase() === 'xrp' && normalizedResponse.result && normalizedResponse.result.data) {
		const mappedData = normalizedResponse.result.data.map((item) => ({
			timestamp: item.timestamp,
			addresses_count_active: item.active_account,
			addresses_count_sender: item.sending_account,
			addresses_count_receiver: item.receiving_account,
		}));

		// Replace the original data with the new, standardized data
		normalizedResponse.result.data = mappedData;
	}

	return normalizedResponse;
}

function getCQNetworkTransactionsCount(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const supportedSymbols = ['btc', 'eth', 'xrp'];
	const lowerCaseSymbol = symbol.toLowerCase();
	if (!supportedSymbols.includes(lowerCaseSymbol)) {
		throw new Error(`Unsupported symbol: '${symbol}'. This function only supports 'btc', 'eth', and 'xrp'.`);
	}

	// Validate window parameter if provided
	if (window && window !== 'day' && window !== 'hour') {
		throw new Error(`Invalid window: '${window}'. This function only supports 'day' and 'hour'.`);
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	// Build the URL dynamically using the provided symbol
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-data/transactions-count`;

	// Fetch the data and get the base normalized response
	const rawResponse = cryptoQuantFetcher(baseUrl, apiParams);
	const normalizedResponse = normalizeCryptoQuantResponse(rawResponse,apiParams);

	// Standardize the data array to always use 'transactions_count_total'
	if (normalizedResponse.result && normalizedResponse.result.data) {
		const mappedData = normalizedResponse.result.data.map((item) => {
			// Check for the ETH field name first, otherwise fall back to the XRP field name.
			const totalCount = item.transactions_count_total !== undefined ? item.transactions_count_total : item.total_transactions_count;

			// Return a new object with the simple, standardized structure.
			return {
				timestamp: item.timestamp,
				transactions_count_total: totalCount,
			};
		});

		normalizedResponse.result.data = mappedData;
	}

	return normalizedResponse;
}

function getCQNetworkFees(params) {
	const { symbol, window, limit, from, to, ...apiParams } = params;

	// --- Validation Block ---
	if (!symbol) {
		throw new Error("The 'symbol' parameter is required.");
	}

	const supportedSymbols = ['btc', 'eth', 'xrp'];
	const lowerCaseSymbol = symbol.toLowerCase();
	if (!supportedSymbols.includes(lowerCaseSymbol)) {
		throw new Error(`Unsupported symbol: '${symbol}'. This function only supports 'btc', 'eth', and 'xrp'.`);
	}

	// Validate window parameter if provided
	if (window && window !== 'day' && window !== 'hour') {
		throw new Error(`Invalid window: '${window}'. This function only supports 'day' and 'hour'.`);
	}

	// Validate limit parameter if provided
	if (limit !== undefined) {
		if (typeof limit !== 'number' || !Number.isInteger(limit)) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be an integer.`);
		}
		if (limit < 2) {
			throw new Error(`Invalid limit: '${limit}'. Limit must be at least 2.`);
		}
		if (limit > 100000) {
			throw new Error(`Invalid limit: '${limit}'. Limit cannot exceed 100000.`);
		}
	}

	// Validate time range if provided
	if (from !== undefined || to !== undefined) {
		if (from !== undefined && to !== undefined) {
			if (typeof from !== 'number' || typeof to !== 'number') {
				throw new Error(`Invalid time range: 'from' and 'to' must be Unix timestamps (numbers).`);
			}
			if (from >= to) {
				throw new Error(`Invalid time range: 'from' (${from}) must be less than 'to' (${to}).`);
			}
			apiParams.from = from;
			apiParams.to = to;
		} else {
			if (from !== undefined && typeof from !== 'number') {
				throw new Error(`Invalid time range: 'from' must be a Unix timestamp (number).`);
			}
			if (to !== undefined && typeof to !== 'number') {
				throw new Error(`Invalid time range: 'to' must be a Unix timestamp (number).`);
			}
			if (from !== undefined) apiParams.from = from;
			if (to !== undefined) apiParams.to = to;
		}
	}
	// --- End of Validation Block ---

	// Build the URL dynamically using the provided symbol
	const baseUrl = `https://api.cryptoquant.com/v1/${lowerCaseSymbol}/network-data/fees`;

	// Fetch the data and get the base normalized response
	const rawResponse = cryptoQuantFetcher(baseUrl, apiParams);
	const normalizedResponse = normalizeCryptoQuantResponse(rawResponse,apiParams);

	// Map the response to the simple, standardized structure
	if (normalizedResponse.result && normalizedResponse.result.data) {
		const mappedData = normalizedResponse.result.data.map((item) => {
			// The XRP API uses 'total_fees', while the ETH API uses 'fees_total'.
			// This line checks for either field and assigns its value to the standard 'total_fees' key.
			const totalFeesValue = item.total_fees !== undefined ? item.total_fees : item.fees_total;

			return {
				timestamp: item.timestamp,
				total_fees: totalFeesValue,
			};
		});

		normalizedResponse.result.data = mappedData;
	}

	return normalizedResponse;
}
// Export all functions for calling in other modules
module.exports = {
	getCQWhaleMovements,
	getCQExchangeReserve,
	getCQExchangeNetflow,
	getCQExchangeInflow,
	getCQExchangeOutflow,
	getCQExchangeTransactionsCount,
	getCQExchangeAddressesCount,
	getCQExchangeInHouseFlow,
	getCQExchangeShare,
	getCQTotalValueStaked,
	getCQStakingInflowTotal,
	getCQStakingTransactionCount,
	getCQStakingValidatorTotal,
	getCQDepositorCountTotal,
	getCQDepositorCountNew,
	getCQNetworkAddressesCount,
	getCQNetworkTransactionsCount,
	getCQNetworkFees,
	getCQNetworkContractsCount,
	getCQNetworkBlockCount,
	getCQNetworkGas,
	getCQNetworkBlockReward,
	getCQNetworkTokensTransferred,
	getCQMarketIndicatorSopr,
	getCQFlowIndicatorMpi,
	getCQFlowIndicatorExchangeWhaleRatio,
	getCQFlowIndicatorExchangeInflowAgeDistribution,
	getCQNetworkIndicatorStockToFlow,
	getCQNetworkIndicatorNvt,
	getCQNetworkIndicatorPuellMultiple,
	getCQNetworkIndicatorCdd,
	getCQNetworkIndicatorMca,
	getCQNetworkIndicatorSca,
	getCQNetworkIndicatorScaDistribution,
	getCQNetworkIndicatorNupl,
	getCQNetworkIndicatorNrpl,
	getCQDexVolume,
	getCQDexTransactionsCount,
	getCQDexLiquidity,
	getCQDexDexPrice,
	getCQSupplySC,
};
