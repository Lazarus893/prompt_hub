const { syncFetch: fetch } = require('net/http');
const { load } = require('@alva/secret');
const key = load('CG-API-KEY');

const baseUrl = 'https://open-api-v4.coinglass.com';

function resolveCoinglass(endpoint, params) {
	const url = baseUrl + endpoint;
	const keyValuePairs = Object.keys(params || {}).map((key) => {
		const value = params[key];
		return encodeURIComponent(key) + '=' + encodeURIComponent(value);
	});
	const queryString = keyValuePairs.join('&');
	const fullUrl = queryString ? `${url}?${queryString}` : url;
	const fetchOptions = {
		method: 'GET',
		headers: {
			'CG-API-KEY': key,
			'Content-Type': 'application/json',
		},
	};
	const r = fetch(fullUrl, fetchOptions);
	return r.json()['data'];
}

function getFuturePrice(params) {
	if (params.start_time) {
		params.start_time = params.start_time * 1000;
	}
	if (params.end_time) {
		params.end_time = params.end_time * 1000;
	}
	return resolveCoinglass('/api/futures/price/history', params);
}

function getHyperliquidWhaleAlerts() {
	return resolveCoinglass('/api/hyperliquid/whale-alert');
}

function getHyperliquidWhalePositions() {
	return resolveCoinglass('/api/hyperliquid/whale-position');
}

function getMarginLongShort(params) {
	if (params.start_time) {
		params.start_time = params.start_time * 1000;
	}
	if (params.end_time) {
		params.end_time = params.end_time * 1000;
	}
	return resolveCoinglass('/api/bitfinex-margin-long-short', params);
}

function getBorrowInterestRateHistory(params) {
	if (params.start_time) {
		params.start_time = params.start_time * 1000;
	}
	if (params.end_time) {
		params.end_time = params.end_time * 1000;
	}
	return resolveCoinglass('/api/borrow-interest-rate/history', params);
}

function getBullMarketPeakIndicators() {
	return resolveCoinglass('/api/bull-market-peak-indicator');
}

function getCGExchangeAssets(params) {
	return resolveCoinglass('/api/exchange/assets', params);
}

function getFuturesBasisHistory(params) {
	if (params.start_time) {
		params.start_time = params.start_time * 1000;
	}
	if (params.end_time) {
		params.end_time = params.end_time * 1000;
	}
	return resolveCoinglass('/api/futures/basis/history', params);
}

function getWhaleIndexHistory(params) {
	if (params.start_time) {
		params.start_time = params.start_time * 1000;
	}
	if (params.end_time) {
		params.end_time = params.end_time * 1000;
	}
	return resolveCoinglass('/api/futures/whale-index/history', params);
}

function getAltcoinSeasonIndex() {
	return resolveCoinglass('/api/index/altcoin-season');
}

function getBitcoinReserveRisk() {
	return resolveCoinglass('/api/index/bitcoin-reserve-risk');
}

function getBitcoinDominance() {
	return resolveCoinglass('/api/index/bitcoin-dominance');
}

function getBitcoinRainbowChart() {
	return resolveCoinglass('/api/index/bitcoin/rainbow-chart');
}

function getCryptoFearAndGreedIndex() {
	return resolveCoinglass('/api/index/fear-greed-history');
}

function getBitcoinBubbleIndex() {
	return resolveCoinglass('/api/index/bitcoin/bubble-index');
}

function getBitcoinCorrelations() {
	return resolveCoinglass('/api/index/bitcoin-correlation');
}

function getCoinbasePremiumIndex(params) {
	if (params.start_time) {
		params.start_time = params.start_time * 1000;
	}
	if (params.end_time) {
		params.end_time = params.end_time * 1000;
	}
	return resolveCoinglass('/api/coinbase-premium-index',params);
}

function ensureSeconds(timestamp) {
	// 检查是否为有效数字
	if (typeof timestamp !== 'number' || !timestamp) {
		return timestamp;
	}

	const tsString = String(Math.floor(timestamp));

	if (tsString.length === 10) {
		return Math.floor(timestamp * 1000);
	}

	return timestamp;
}

function getCGOpenInterest(params) {
	if (params.start_time) {
		params.start_time = ensureSeconds(params.start_time);
	}

	if (params.end_time) {
		params.end_time = ensureSeconds(params.end_time);
	}

	// 调用 API
	return resolveCoinglass('/api/futures/open-interest/history', params);
}

function getCGFundingRate(params){
	if (params.start_time) {
		params.start_time = ensureSeconds(params.start_time);
	}

	if (params.end_time) {
		params.end_time = ensureSeconds(params.end_time);
	}
	return resolveCoinglass('/api/futures/funding-rate/history',params);
}

function getBitcoinProfitableDays() {
	return resolveCoinglass('/api/index/bitcoin/profitable-days');
}

function getCdriIndexHistory() {
	return resolveCoinglass('/api/futures/cdri-index/history');
}

module.exports = {
	getFuturePrice,
	getHyperliquidWhaleAlerts,
	getHyperliquidWhalePositions,
	getMarginLongShort,
	getBorrowInterestRateHistory,
	getBullMarketPeakIndicators,
	getCGExchangeAssets,
	getFuturesBasisHistory,
	getWhaleIndexHistory,
	getAltcoinSeasonIndex,
	getBitcoinReserveRisk,
	getBitcoinDominance,
	getBitcoinRainbowChart,
	getCryptoFearAndGreedIndex,
	getBitcoinBubbleIndex,
	getBitcoinCorrelations,
	getCoinbasePremiumIndex,
	getCGOpenInterest,
	getCGFundingRate,
	getBitcoinProfitableDays,
	getCdriIndexHistory
};
