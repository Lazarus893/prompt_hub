/**
 * @description
 * This file contains functions for fetching data from the DefiLlama API.
 * Each function follows the CryptoQuant code template style, using synchronous fetch requests.
 * 
 * @dependencies
 * - @alva/secret: For securely loading API keys.
 * - net/http: For making HTTP requests.
 * 
 * @setup
 * Please ensure your access token is configured through @alva/secret and named 'DFLM_KEY'.
 */

const { load } = require('@alva/secret');
const { syncFetch: fetch } = require('net/http');

// Load DefiLlama access token from secure storage
const accessToken = load('DFLM_KEY');

/**
 * Generic request builder for creating and executing requests to the DefiLlama API.
 * @param {string} baseUrl - Base URL for the API endpoint.
 * @param {object} params - Query parameters object.
 * @returns {object} - JSON data returned by the API.
 */
function defiLlamaFetcher(baseUrl, params) {
	const processedParams = { ...params };

	const keyValuePairs = Object.keys(processedParams || {}).map((key) => {
		const value = processedParams[key];
		return encodeURIComponent(key) + '=' + encodeURIComponent(value);
	});

	const queryString = keyValuePairs.join('&');
	const fullUrl = queryString ? `${baseUrl}?${queryString}` : baseUrl;

	const fetchOptions = {
		method: 'GET',
		headers: {
			'Content-Type': 'application/json',
		},
	};

	const r = fetch(fullUrl, fetchOptions);
	return r.json();
}

/**
 * Get DEX volume summary for a protocol
 * @param {object} params - Parameters object
 * @param {string} params.protocol - DEX protocol slug (required)
 * @returns {object} - DEX volume summary data
 */
function getDLDexVolumeSummary(params) {
	const { protocol } = params;

	if (!protocol) {
		throw new Error("The 'protocol' parameter is required.");
	}

	const baseUrl = `https://api.llama.fi/summary/dexs/${protocol}`;
	return defiLlamaFetcher(baseUrl, {});
}

/**
 * Get protocol user activity data
 * @param {object} params - Parameters object
 * @param {number} params.protocol_id - Protocol ID (required)
 * @param {string} params.type - Data type: 'users', 'txs', 'gas', or 'newusers' (required)
 * @returns {array} - Array of time series data points
 */
function getDLProtocolUserActivity(params = {}) {
	const { syncFetch: fetch } = require('net/http');

	const response = fetch(`https://pro-api.llama.fi/${accessToken}/api/userData/${params.type}/${params.protocol_id}`);
	
	return response.json();
}

/**
 * Get DeFi protocol fees and revenue data
 * @param {object} params - Parameters object
 * @param {string} params.protocol - Protocol slug (required)
 * @param {string} params.data_type - Data type: 'dailyFees', 'dailyRevenue', or 'dailyHoldersRevenue'
 * @returns {object} - Protocol fees and revenue data
 */
function getDLProtocolFinancials(params) {
	const { protocol } = params;

	if (!protocol) {
		throw new Error("The 'protocol' parameter is required.");
	}

	const baseUrl = `https://api.llama.fi/summary/fees/${protocol}`;
	return defiLlamaFetcher(baseUrl, {});
}

// Export all functions for calling in other modules
module.exports = {
	getDLDexVolumeSummary,
	getDLProtocolUserActivity,
	getDLProtocolFinancials
};
