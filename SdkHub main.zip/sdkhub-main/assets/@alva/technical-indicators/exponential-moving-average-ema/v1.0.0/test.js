function main() {
  const { ema } = require('@alva/technical-indicators/exponential-moving-average-ema:v1.0.0');

  // Generate a strictly increasing dataset
  const data = [];
  for (let i = 1; i <= 100; i++) {
    data.push(i);
  }

  // Test default parameters
  const emaDefault = ema(data);
  if (!Array.isArray(emaDefault)) {
    throw new Error('EMA default result is not an array');
  }
  if (emaDefault.length !== data.length) {
    throw new Error(`EMA default length expected ${data.length}, got ${emaDefault.length}`);
  }
  if (emaDefault.some((v) => typeof v !== 'number' || !isFinite(v))) {
    throw new Error('EMA default contains non-finite numbers');
  }
  // EMA over strictly increasing series should be non-decreasing
  for (let i = 1; i < emaDefault.length; i++) {
    if (emaDefault[i] < emaDefault[i - 1]) {
      throw new Error('EMA default should be non-decreasing for increasing input');
    }
  }

  // Test custom parameters
  const emaCustom = ema(data, { period: 2 });
  if (!Array.isArray(emaCustom)) {
    throw new Error('EMA custom result is not an array');
  }
  if (emaCustom.length !== data.length) {
    throw new Error(`EMA custom length expected ${data.length}, got ${emaCustom.length}`);
  }
  if (emaCustom.some((v) => typeof v !== 'number' || !isFinite(v))) {
    throw new Error('EMA custom contains non-finite numbers');
  }
  for (let i = 1; i < emaCustom.length; i++) {
    if (emaCustom[i] < emaCustom[i - 1]) {
      throw new Error('EMA custom should be non-decreasing for increasing input');
    }
  }

  // With smaller period, EMA should track price more closely on an uptrend
  const lastIdx = data.length - 1;
  if (!(emaCustom[lastIdx] >= emaDefault[lastIdx])) {
    throw new Error('EMA with smaller period should be closer to price than default (on uptrend)');
  }
  if (!(emaCustom[lastIdx] <= data[lastIdx])) {
    throw new Error('EMA should not exceed the last price on a monotonic uptrend');
  }

  console.log('✅ Exponential Moving Average (EMA) tests passed');
  return 0;
}
module.exports = main;
// Ensure the test runs regardless of how the runner executes this file
// (some runners import the file instead of running it as the main module)
main();
