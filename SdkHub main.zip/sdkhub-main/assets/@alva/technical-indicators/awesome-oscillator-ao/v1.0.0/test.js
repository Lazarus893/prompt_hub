function main() {
  const { ao } = require('@alva/technical-indicators/awesome-oscillator-ao:v1.0.0');

  // Test 1: Basic shape and length with ramping highs/lows
  const n = 100;
  const highs = Array.from({ length: n }, (_, i) => i + 2);
  const lows = Array.from({ length: n }, (_, i) => i);
  const resultDefault = ao(highs, lows);

  if (!Array.isArray(resultDefault)) {
    throw new Error('AO result should be an array');
  }
  if (resultDefault.length !== n) {
    throw new Error(`AO result length expected ${n}, got ${resultDefault.length}`);
  }
  if (!Number.isFinite(resultDefault[0]) || !Number.isFinite(resultDefault[n - 1])) {
    throw new Error('AO result should contain finite numbers at the boundaries');
  }

  // Test 2: Constant series should yield ~0 after warm-up
  const constHighs = Array.from({ length: n }, () => 10);
  const constLows = Array.from({ length: n }, () => 10);
  const fast = 5;
  const slow = 10; // keep small to minimize warm-up effects
  const resultConst = ao(constHighs, constLows, { fast, slow });

  if (resultConst.length !== n) {
    throw new Error('AO result (constant series) length mismatch');
  }
  const eps = 1e-10;
  for (let i = slow - 1; i < n; i++) {
    if (!Number.isFinite(resultConst[i])) {
      throw new Error(`AO result has non-finite value at index ${i}`);
    }
    if (Math.abs(resultConst[i]) > eps) {
      throw new Error(`AO result for constant series should be ~0 after warm-up. idx=${i}, got=${resultConst[i]}`);
    }
  }

  console.log('✅ Awesome Oscillator (AO) tests passed');
  return 0;
}

module.exports = { main };

// Ensure tests run even when the file is executed via a loader that uses require()
// Some runners import the file instead of executing it as the entry point.
// Call main() unconditionally to guarantee the tests run.
main();

