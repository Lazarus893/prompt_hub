function approxEqual(a, b, eps = 1e-9) {
  return Math.abs(a - b) <= eps;
}

function main() {
  const { vwma } = require('@alva/technical-indicators/volume-weighted-moving-average-vwma:v1.0.0');

  // Basic shape test with default parameters
  const closings = Array.from({ length: 100 }, (_, i) => i + 1); // 1..100
  const volumes = Array.from({ length: 100 }, (_, i) => (i % 5) + 1); // 1..5 repeating
  const resultDefault = vwma(closings, volumes);
  if (!Array.isArray(resultDefault)) {
    throw new Error('VWMA result should be an array');
  }
  if (resultDefault.length !== closings.length) {
    throw new Error(`VWMA length mismatch: expected ${closings.length}, got ${resultDefault.length}`);
  }

  // Period = 1 should equal the closings exactly
  const resultP1 = vwma(closings, volumes, { period: 1 });
  for (let i = 0; i < closings.length; i++) {
    if (!approxEqual(resultP1[i], closings[i])) {
      throw new Error(`VWMA period=1 mismatch at index ${i}: expected ${closings[i]}, got ${resultP1[i]}`);
    }
  }

  // With equal volumes, VWMA reduces to SMA over the window
  const c2 = [1, 2, 3, 4, 5, 6];
  const v2 = [1, 1, 1, 1, 1, 1];
  const r2 = vwma(c2, v2, { period: 3 });
  for (let i = 2; i < c2.length; i++) {
    const expected = (c2[i] + c2[i - 1] + c2[i - 2]) / 3;
    if (!approxEqual(r2[i], expected)) {
      throw new Error(`VWMA equal-volume SMA equivalence failed at index ${i}: expected ${expected}, got ${r2[i]}`);
    }
  }

  // Weighted volumes: check specific windows with period = 3
  const c3 = [1, 2, 3, 4, 5, 6];
  const v3 = [1, 2, 3, 4, 5, 6];
  const r3 = vwma(c3, v3, { period: 3 });
  // At index 4, window is indices 2..4: (3*3 + 4*4 + 5*5) / (3 + 4 + 5) = (9 + 16 + 25) / 12 = 50/12
  const expectedI4 = 50 / 12;
  if (!approxEqual(r3[4], expectedI4)) {
    throw new Error(`VWMA weighted check failed at index 4: expected ${expectedI4}, got ${r3[4]}`);
  }
  // At index 5, window is 3..5: (4*4 + 5*5 + 6*6) / (4 + 5 + 6) = (16 + 25 + 36) / 15 = 77/15
  const expectedI5 = 77 / 15;
  if (!approxEqual(r3[5], expectedI5)) {
    throw new Error(`VWMA weighted check failed at index 5: expected ${expectedI5}, got ${r3[5]}`);
  }

  console.log('✅ Volume Weighted Moving Average (VWMA) tests passed');
  return 0;
}

// Always run the test when this file is executed by the runner
main();

module.exports = { main };