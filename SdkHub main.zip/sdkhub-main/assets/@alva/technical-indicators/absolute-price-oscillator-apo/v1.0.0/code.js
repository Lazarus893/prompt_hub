const { indicators } = require('@alva/algorithm:v1.0.0');
module.exports = { apo: indicators.apo };
