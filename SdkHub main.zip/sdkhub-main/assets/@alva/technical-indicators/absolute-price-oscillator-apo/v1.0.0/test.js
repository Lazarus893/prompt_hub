function main() {
  const { apo } = require('@alva/technical-indicators/absolute-price-oscillator-apo:v1.0.0');

  // Test 1: Output length should match input length (default params)
  const constantData = Array.from({ length: 100 }, () => 10);
  const outputDefault = apo(constantData);
  if (!Array.isArray(outputDefault)) {
    throw new Error('apo should return an array');
  }
  if (outputDefault.length !== constantData.length) {
    throw new Error('apo output length mismatch for default params');
  }

  // Test 2: Constant series should yield ~0 values across the array (EMA difference on flat data)
  const EPS = 1e-9;
  for (let i = 0; i < outputDefault.length; i++) {
    if (Math.abs(outputDefault[i]) > EPS) {
      throw new Error(`apo on constant series should be near 0 at index ${i}, got ${outputDefault[i]}`);
    }
  }

  // Test 3: Custom parameters maintain the same invariant on constant data
  const outputCustom = apo(constantData, { fast: 2, slow: 5 });
  if (outputCustom.length !== constantData.length) {
    throw new Error('apo output length mismatch for custom params');
  }
  for (let i = 0; i < outputCustom.length; i++) {
    if (Math.abs(outputCustom[i]) > EPS) {
      throw new Error(`apo(custom) on constant series should be near 0 at index ${i}, got ${outputCustom[i]}`);
    }
  }

  // Test 4: Increasing series should result in a positive last APO value (fast EMA > slow EMA)
  const increasing = Array.from({ length: 200 }, (_, i) => i);
  const outputIncreasing = apo(increasing);
  if (outputIncreasing.length !== increasing.length) {
    throw new Error('apo output length mismatch on increasing series');
  }
  if (!(outputIncreasing[outputIncreasing.length - 1] > 0)) {
    throw new Error('apo last value expected to be positive for increasing series');
  }

  console.log('✅ Absolute Price Oscillator (APO) tests passed');
  return 0;
}
 
main();
