function main() {
  const { atr } = require('@alva/technical-indicators/average-true-range-atr:v1.0.0');

  // Generate deterministic synthetic OHLC data
  const len = 200;
  const highs = [];
  const lows = [];
  const closes = [];
  let price = 100;
  for (let i = 0; i < len; i++) {
    // deterministic pseudo move
    const step = (i % 10) - 5; // range [-5,4]
    price += step * 0.5;
    const low = price - 1 - (i % 3) * 0.2;
    const high = price + 1 + (i % 4) * 0.15;
    const close = price + ((i % 2 === 0) ? 0.25 : -0.15);
    lows.push(low);
    highs.push(high);
    closes.push(close);
  }

  // Default call
  const resDefault = atr(highs, lows, closes);
  if (!resDefault || !Array.isArray(resDefault.trLine) || !Array.isArray(resDefault.atrLine)) {
    throw new Error('ATR result should contain trLine and atrLine arrays');
  }
  if (resDefault.trLine.length !== len) {
    throw new Error(`trLine length expected ${len}, got ${resDefault.trLine.length}`);
  }
  if (resDefault.atrLine.length !== len) {
    throw new Error(`atrLine length expected ${len}, got ${resDefault.atrLine.length}`);
  }
  // Values should be non-negative
  const hasNegativeTR = resDefault.trLine.some(v => typeof v !== 'number' || v < 0 || Number.isNaN(v));
  if (hasNegativeTR) {
    throw new Error('trLine contains invalid/negative values');
  }
  const hasNegativeATR = resDefault.atrLine.some(v => typeof v !== 'number' || v < 0 || Number.isNaN(v));
  if (hasNegativeATR) {
    throw new Error('atrLine contains invalid/negative values');
  }

  // Custom period test
  const period = 9;
  const resCustom = atr(highs, lows, closes, { period });
  if (resCustom.trLine.length !== len || resCustom.atrLine.length !== len) {
    throw new Error('Custom period output lengths mismatch');
  }

  // Basic monotonicity check: ATR should respond to larger ranges.
  // Create a segment with artificially higher ranges and ensure ATR in that zone is on average higher
  const highs2 = highs.slice();
  const lows2 = lows.slice();
  const closes2 = closes.slice();
  for (let i = 50; i < 80; i++) {
    highs2[i] += 5; // widen range
    lows2[i] -= 5;
  }
  const resBump = atr(highs2, lows2, closes2, { period });
  const avg = (arr, s, e) => arr.slice(s, e).reduce((a, b) => a + b, 0) / (e - s);
  const baseAvg = avg(resCustom.atrLine, 50, 80);
  const bumpAvg = avg(resBump.atrLine, 50, 80);
  if (!(bumpAvg > baseAvg)) {
    throw new Error('ATR did not increase under widened ranges as expected');
  }

  console.log('✅ Average True Range (ATR) tests passed');
  return 0;
}

main();

module.exports = { main };
