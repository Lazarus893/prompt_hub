function main() {
  const { vpt } = require('@alva/technical-indicators/volume-price-trend-vpt:v1.0.0');

  // Test 1: Basic length and starting value
  const closes1 = [10, 10, 10, 10, 10];
  const vols1 = [100, 200, 300, 400, 500];
  const res1 = vpt(closes1, vols1);
  if (!Array.isArray(res1)) throw new Error('VPT should return an array');
  if (res1.length !== closes1.length) throw new Error('VPT length mismatch with input');
  if (res1[0] !== 0) throw new Error('VPT should start at 0');

  // Test 2: Known small dataset verification
  // Using formula: VPT[i] = VPT[i-1] + Vol[i] * (Close[i] - Close[i-1]) / Close[i-1]
  const closes2 = [100, 105, 102, 102, 110];
  const vols2 = [1000, 1500, 1200, 1000, 2000];
  const expected2 = [];
  let vptPrev = 0;
  expected2.push(vptPrev);
  for (let i = 1; i < closes2.length; i++) {
    const delta = (closes2[i] - closes2[i - 1]) / closes2[i - 1];
    vptPrev = vptPrev + vols2[i] * delta;
    expected2.push(vptPrev);
  }
  const res2 = vpt(closes2, vols2);
  const eps = 1e-9;
  if (res2.length !== expected2.length) throw new Error('VPT expected length mismatch');
  for (let i = 0; i < res2.length; i++) {
    if (Math.abs(res2[i] - expected2[i]) > eps) {
      throw new Error(`VPT value mismatch at index ${i}: got ${res2[i]}, expected ${expected2[i]}`);
    }
  }

  // Test 3: Monotonic behavior with steadily increasing price and positive volumes
  const closes3 = [];
  const vols3 = [];
  for (let i = 1; i <= 50; i++) {
    closes3.push(100 + i); // steadily increasing
    vols3.push(1000 + 10 * i);
  }
  const res3 = vpt(closes3, vols3);
  for (let i = 1; i < res3.length; i++) {
    if (!(res3[i] >= res3[i - 1])) {
      throw new Error('VPT should be non-decreasing for monotonically increasing prices with positive volumes');
    }
  }

  console.log('✅ Volume Price Trend (VPT) tests passed');
  return 0;
}

module.exports = { main };

// Ensure the test actually runs when invoked directly
if (require.main === module) {
  main();
}
