function main() {
  const { pvo } = require('@alva/technical-indicators/percentage-volume-oscillator-pvo:v1.0.0');

  const approxEqual = (a, b, eps = 1e-9) => Math.abs(a - b) <= eps;

  // Test 1: Basic length checks with sequential volumes
  const volumes = Array.from({ length: 200 }, (_, i) => i + 1); // avoid zeros
  const resultDefault = pvo(volumes);

  if (!resultDefault || !Array.isArray(resultDefault.pvoResult) || !Array.isArray(resultDefault.signal) || !Array.isArray(resultDefault.histogram)) {
    throw new Error('PVO result shape is invalid');
  }

  if (
    resultDefault.pvoResult.length !== volumes.length ||
    resultDefault.signal.length !== volumes.length ||
    resultDefault.histogram.length !== volumes.length
  ) {
    throw new Error('PVO arrays length mismatch with input');
  }

  // Test 2: Constant volumes should yield (approximately) zero PVO, zero signal, zero histogram
  const constVolumes = Array.from({ length: 150 }, () => 1000);
  const constRes = pvo(constVolumes);

  const lastIdxConst = constVolumes.length - 1;
  if (!approxEqual(constRes.pvoResult[lastIdxConst], 0)) {
    throw new Error('PVO of constant volumes should be approximately 0');
  }
  if (!approxEqual(constRes.signal[lastIdxConst], 0)) {
    throw new Error('Signal of constant volumes should be approximately 0');
  }
  if (!approxEqual(constRes.histogram[lastIdxConst], 0)) {
    throw new Error('Histogram of constant volumes should be approximately 0');
  }

  // Test 3: Custom parameters produce a different output than defaults on a trending series
  const customCfg = { fast: 6, slow: 13, signal: 7 };
  const resultCustom = pvo(volumes, customCfg);
  const lastIdx = volumes.length - 1;
  const lastDefault = resultDefault.pvoResult[lastIdx];
  const lastCustom = resultCustom.pvoResult[lastIdx];
  if (approxEqual(lastDefault, lastCustom)) {
    throw new Error('Custom configuration should change the PVO result');
  }

  console.log('✅ Percentage Volume Oscillator (PVO) tests passed');
  return 0;
}

// Ensure tests run in all environments by invoking main() unconditionally
main();
