function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

function isNumberOrNull(x) {
  return typeof x === 'number' || x === null || x === undefined;
}

function main() {
  const { macd } = require('@alva/technical-indicators/moving-average-convergence-divergence-macd:v1.0.0');

  // Test 1: default parameters with increasing data
  const data = Array.from({ length: 100 }, (_, i) => i + 1);
  const resDefault = macd(data);
  assert(resDefault && typeof resDefault === 'object', 'Result should be an object');
  assert(Array.isArray(resDefault.macdLine), 'macdLine should be an array');
  assert(Array.isArray(resDefault.signalLine), 'signalLine should be an array');
  assert(resDefault.macdLine.length === data.length, 'macdLine length should match input length');
  assert(resDefault.signalLine.length === data.length, 'signalLine length should match input length');
  // Ensure elements are numbers/null/undefined (depending on warmup behavior)
  for (let i = 0; i < data.length; i++) {
    assert(isNumberOrNull(resDefault.macdLine[i]), `macdLine[${i}] should be a number or null/undefined`);
    assert(isNumberOrNull(resDefault.signalLine[i]), `signalLine[${i}] should be a number or null/undefined`);
  }

  // Test 2: custom parameters
  const resCustom = macd(data, { fast: 14, slow: 28, signal: 7 });
  assert(Array.isArray(resCustom.macdLine), 'custom macdLine should be an array');
  assert(Array.isArray(resCustom.signalLine), 'custom signalLine should be an array');
  assert(resCustom.macdLine.length === data.length, 'custom macdLine length should match input length');
  assert(resCustom.signalLine.length === data.length, 'custom signalLine length should match input length');

  // Test 3: empty input
  const empty = [];
  const resEmpty = macd(empty);
  assert(Array.isArray(resEmpty.macdLine), 'empty macdLine should be an array');
  assert(Array.isArray(resEmpty.signalLine), 'empty signalLine should be an array');
  assert(resEmpty.macdLine.length === 0, 'macdLine length should be 0 for empty input');
  assert(resEmpty.signalLine.length === 0, 'signalLine length should be 0 for empty input');

  // Test 4: constant series should not produce NaNs
  const constant = Array.from({ length: 50 }, () => 100);
  const resConst = macd(constant);
  for (let i = 0; i < constant.length; i++) {
    const a = resConst.macdLine[i];
    const b = resConst.signalLine[i];
    assert(a === null || a === undefined || Number.isFinite(a), `macdLine[${i}] should be finite or null/undefined`);
    assert(b === null || b === undefined || Number.isFinite(b), `signalLine[${i}] should be finite or null/undefined`);
  }

  console.log('✅ Moving Average Convergence Divergence (MACD) tests passed');
  return 0;
}

// Always invoke main to ensure tests run under different runners/environments
main();

module.exports = { main };
