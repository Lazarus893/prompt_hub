function main() {
  const { nvi } = require('@alva/technical-indicators/negative-volume-index-nvi:v1.0.0');

  // Synthetic test data for NVI
  const closings = [100, 102, 101, 103, 106, 105];
  const volumes = [1000, 900, 1100, 1000, 1200, 1100];

  const resultDefault = nvi(closings, volumes);

  if (!Array.isArray(resultDefault)) {
    throw new Error('NVI should return an array');
  }
  if (resultDefault.length !== closings.length) {
    throw new Error(`NVI length mismatch: expected ${closings.length}, got ${resultDefault.length}`);
  }
  // Default start should be 1000 per documentation
  if (Math.abs(resultDefault[0] - 1000) > 1e-8) {
    throw new Error(`NVI default start value mismatch: expected 1000, got ${resultDefault[0]}`);
  }

  // Compute expected values based on the documented formula
  const expectedDefault = [];
  let prevNvi = 1000;
  expectedDefault.push(prevNvi);
  for (let i = 1; i < closings.length; i++) {
    if (volumes[i] > volumes[i - 1]) {
      // NVI stays the same if current volume > previous volume
      // prevNvi unchanged
    } else {
      // Otherwise, apply price change proportionally to previous NVI
      prevNvi = prevNvi + ((closings[i] - closings[i - 1]) / closings[i - 1]) * prevNvi;
    }
    expectedDefault.push(prevNvi);
  }

  // Compare with a small tolerance for floating point arithmetic
  for (let i = 0; i < resultDefault.length; i++) {
    const diff = Math.abs(resultDefault[i] - expectedDefault[i]);
    if (diff > 1e-6) {
      throw new Error(`NVI value mismatch at index ${i}: expected ${expectedDefault[i]}, got ${resultDefault[i]}`);
    }
  }

  // Test custom parameters
  const resultCustom = nvi(closings, volumes, { start: 500, period: 10 });
  if (Math.abs(resultCustom[0] - 500) > 1e-8) {
    throw new Error(`NVI custom start value mismatch: expected 500, got ${resultCustom[0]}`);
  }

  // Compute expected for custom start
  const expectedCustom = [];
  let prevNviCustom = 500;
  expectedCustom.push(prevNviCustom);
  for (let i = 1; i < closings.length; i++) {
    if (volumes[i] > volumes[i - 1]) {
      // prevNviCustom unchanged
    } else {
      prevNviCustom = prevNviCustom + ((closings[i] - closings[i - 1]) / closings[i - 1]) * prevNviCustom;
    }
    expectedCustom.push(prevNviCustom);
  }
  for (let i = 0; i < resultCustom.length; i++) {
    const diff = Math.abs(resultCustom[i] - expectedCustom[i]);
    if (diff > 1e-6) {
      throw new Error(`NVI custom value mismatch at index ${i}: expected ${expectedCustom[i]}, got ${resultCustom[i]}`);
    }
  }

  console.log('✅ Negative Volume Index (NVI) tests passed');
  return 0;
}

// Always invoke main to ensure tests run under different runners
main();

module.exports = main;
