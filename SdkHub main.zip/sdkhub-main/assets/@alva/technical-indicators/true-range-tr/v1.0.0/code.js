const { indicators } = require('@alva/algorithm:v1.0.0');
module.exports = { trueRange: indicators.trueRange };