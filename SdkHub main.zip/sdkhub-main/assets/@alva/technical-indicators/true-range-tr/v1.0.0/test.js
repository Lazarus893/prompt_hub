function main() {
  const { trueRange } = require('@alva/technical-indicators/true-range-tr:v1.0.0');

  // Construct simple, deterministic series
  const highs = [10, 12, 13, 15, 14, 16, 18, 17, 19, 20];
  const lows =  [ 8,  9, 11, 12, 12, 13, 15, 14, 16, 18];
  const closes=[ 9, 11, 12, 14, 13, 15, 17, 16, 18, 19];

  const tr = trueRange(highs, lows, closes);

  if (!Array.isArray(tr)) {
    throw new Error('trueRange should return an array');
  }
  if (tr.length !== highs.length) {
    throw new Error(`Expected TR length ${highs.length}, got ${tr.length}`);
  }

  // Manually compute expected TRs
  const expected = [];
  for (let i = 0; i < highs.length; i++) {
    const hl = highs[i] - lows[i];
    if (i === 0) {
      expected.push(hl);
    } else {
      const hPc = Math.abs(highs[i] - closes[i - 1]);
      const lPc = Math.abs(lows[i] - closes[i - 1]);
      expected.push(Math.max(hl, hPc, lPc));
    }
  }

  for (let i = 0; i < tr.length; i++) {
    if (Math.abs(tr[i] - expected[i]) > 1e-9) {
      throw new Error(`TR mismatch at index ${i}: got ${tr[i]}, expected ${expected[i]}`);
    }
  }

  console.log('✅ True Range (TR) tests passed');
  return 0;
}

module.exports = { main };
// Ensure the test actually runs when executed
main();