function main() {
  const { mmin } = require('@alva/technical-indicators/moving-min-mmin:v1.0.0');

  // Test 1: Default parameters should return an array with the same length as input
  const data1 = Array.from({ length: 100 }, (_, i) => i + 1);
  const result1 = mmin(data1);
  if (!Array.isArray(result1)) {
    throw new Error('MMIN default call did not return an array');
  }
  if (result1.length !== data1.length) {
    throw new Error('MMIN default result length mismatch');
  }

  // Test 2: With period = 1, the output should equal the input exactly
  const data2 = [5, 3, 8, 2, 7, 9, 1, 4];
  const result2 = mmin(data2, { period: 1 });
  for (let i = 0; i < data2.length; i++) {
    if (result2[i] !== data2[i]) {
      throw new Error(`MMIN period=1 mismatch at index ${i}: expected ${data2[i]}, got ${result2[i]}`);
    }
  }

  // Test 3: For a strictly decreasing series, moving min with any period >= 2 equals the input
  const data3 = [9, 8, 7, 6, 5, 4, 3, 2, 1];
  const result3 = mmin(data3, { period: 3 });
  for (let i = 0; i < data3.length; i++) {
    if (result3[i] !== data3[i]) {
      throw new Error(`MMIN decreasing sequence mismatch at index ${i}: expected ${data3[i]}, got ${result3[i]}`);
    }
  }

  // Test 4: Validate exact expected values for a handcrafted dataset and period
  const values = [4, 1, 7, 0, 5, 3, 6];
  const period = 3;
  const expected = [];
  for (let i = 0; i < values.length; i++) {
    const start = Math.max(0, i - period + 1);
    let min = Infinity;
    for (let j = start; j <= i; j++) {
      if (values[j] < min) min = values[j];
    }
    expected.push(min);
  }
  const result4 = mmin(values, { period });
  for (let i = 0; i < values.length; i++) {
    if (result4[i] !== expected[i]) {
      throw new Error(`MMIN expected mismatch at index ${i}: expected ${expected[i]}, got ${result4[i]}`);
    }
  }

  console.log('✅ Moving Min (MMIN) tests passed');
  return 0;
}

module.exports = main;
// Ensure the test actually runs when executed by the runner
main();
