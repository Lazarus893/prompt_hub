function main() {
  const { kc } = require('@alva/technical-indicators/keltner-channel-kc:v1.0.0');

  const N = 200;
  const highs = [];
  const lows = [];
  const closings = [];

  for (let i = 0; i < N; i++) {
    const base = 100 + i * 0.5 + 5 * Math.sin(i / 7);
    const highOffset = 1 + (i % 5) / 10; // deterministic offset
    const lowOffset = 1 + ((i + 2) % 7) / 10; // deterministic offset
    closings.push(base);
    highs.push(base + highOffset);
    lows.push(base - lowOffset);
  }

  const kcDefault = kc(highs, lows, closings);

  if (!kcDefault || typeof kcDefault !== 'object') {
    throw new Error('kc did not return an object');
  }

  const { middle, upper, lower } = kcDefault;

  if (!Array.isArray(middle) || !Array.isArray(upper) || !Array.isArray(lower)) {
    throw new Error('kc result does not contain middle, upper, lower arrays');
  }

  if (middle.length !== N || upper.length !== N || lower.length !== N) {
    throw new Error('kc arrays do not match input length');
  }

  // Ensure latest values are finite numbers
  const last = N - 1;
  if (!Number.isFinite(middle[last]) || !Number.isFinite(upper[last]) || !Number.isFinite(lower[last])) {
    throw new Error('kc latest values are not finite numbers');
  }

  // Validate band ordering where values are defined
  for (let i = 0; i < N; i++) {
    const m = middle[i];
    const u = upper[i];
    const l = lower[i];
    if (Number.isFinite(m) && Number.isFinite(u) && Number.isFinite(l)) {
      if (!(u >= m && m >= l)) {
        throw new Error(`kc band ordering violated at index ${i}: upper=${u}, middle=${m}, lower=${l}`);
      }
    }
  }

  // Test with custom period and ensure it still returns valid arrays
  const customPeriod = 14;
  const kcCustom = kc(highs, lows, closings, { period: customPeriod });

  if (!kcCustom || !Array.isArray(kcCustom.middle) || !Array.isArray(kcCustom.upper) || !Array.isArray(kcCustom.lower)) {
    throw new Error('kc custom result is invalid');
  }

  if (kcCustom.middle.length !== N || kcCustom.upper.length !== N || kcCustom.lower.length !== N) {
    throw new Error('kc custom arrays do not match input length');
  }

  // There should be at least one difference between default and custom period results at later indices
  let foundDifference = false;
  for (let i = 50; i < N; i++) {
    const mDef = middle[i];
    const mCus = kcCustom.middle[i];
    if (Number.isFinite(mDef) && Number.isFinite(mCus) && mDef !== mCus) {
      foundDifference = true;
      break;
    }
  }
  if (!foundDifference) {
    throw new Error('kc custom period did not produce different results from default at later indices');
  }

  console.log('✅ Keltner Channel (KC) tests passed');
  return 0;
}

// Always run the test when this file is executed, regardless of how it is invoked.
main();

module.exports = { main };
