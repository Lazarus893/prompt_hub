function isNumber(x) {
  return typeof x === 'number' && Number.isFinite(x);
}

function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

function main() {
  const { ab } = require('@alva/technical-indicators/acceleration-bands-ab:v1.0.0');

  // Test 1: basic shape and lengths with varying data
  const N = 100;
  const highs = [];
  const lows = [];
  const closings = [];
  for (let i = 0; i < N; i++) {
    lows.push(i);
    closings.push(i + 1);
    highs.push(i + 2);
  }

  const abDefault = ab(highs, lows, closings);
  assert(abDefault && abDefault.upper && abDefault.middle && abDefault.lower, 'AB result shape invalid');
  assert(Array.isArray(abDefault.upper) && Array.isArray(abDefault.middle) && Array.isArray(abDefault.lower), 'AB result fields must be arrays');
  assert(abDefault.upper.length === N, 'upper length is not ' + N);
  assert(abDefault.middle.length === N, 'middle length is not ' + N);
  assert(abDefault.lower.length === N, 'lower length is not ' + N);

  // Ensure ordering upper >= lower where values are numbers
  for (let i = 0; i < N; i++) {
    const u = abDefault.upper[i];
    const l = abDefault.lower[i];
    if (isNumber(u) && isNumber(l)) {
      assert(u >= l, `upper < lower at index ${i}`);
    }
  }

  // Test 2: custom config should change spread when multiplier increases
  const customConfig = { period: 10, multiplier: 6 };
  const abCustom = ab(highs, lows, closings, customConfig);
  assert(abCustom.upper.length === N && abCustom.lower.length === N, 'custom config output lengths mismatch');

  // Find an index where all values are numbers to compare spreads
  let comparableIndex = -1;
  for (let i = 0; i < N; i++) {
    const u0 = abDefault.upper[i];
    const l0 = abDefault.lower[i];
    const u1 = abCustom.upper[i];
    const l1 = abCustom.lower[i];
    if (isNumber(u0) && isNumber(l0) && isNumber(u1) && isNumber(l1)) {
      comparableIndex = i;
      // Expect larger spread for higher multiplier when highs > lows
      assert(u1 - l1 >= u0 - l0, `custom multiplier did not increase spread at index ${i}`);
      break;
    }
  }
  assert(comparableIndex !== -1, 'Could not find comparable numeric index for spread comparison');

  // Test 3: constant data should produce equal bands equal to the constant value (for computed indices)
  const M = 30;
  const constHighs = Array(M).fill(100);
  const constLows = Array(M).fill(100);
  const constClosings = Array(M).fill(100);
  const abConst = ab(constHighs, constLows, constClosings);
  assert(abConst.upper.length === M && abConst.middle.length === M && abConst.lower.length === M, 'constant data lengths mismatch');
  let numericCount = 0;
  for (let i = 0; i < M; i++) {
    const u = abConst.upper[i];
    const m = abConst.middle[i];
    const l = abConst.lower[i];
    if (isNumber(u) && isNumber(m) && isNumber(l)) {
      numericCount++;
      assert(u === 100 && m === 100 && l === 100, `bands not equal to 100 at index ${i}: (${u}, ${m}, ${l})`);
    }
  }
  assert(numericCount > 0, 'No numeric values produced for constant data');

  console.log('✅ Acceleration Bands (AB) tests passed');
  return 0;
}

// Always run main to ensure tests execute in all environments
main();
