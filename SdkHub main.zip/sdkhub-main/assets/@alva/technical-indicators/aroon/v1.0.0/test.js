function main() {
  const { aroon } = require('@alva/technical-indicators/aroon:v1.0.0');

  // Uptrend dataset: highs and lows strictly increasing
  const highsUp = [];
  const lowsUp = [];
  for (let i = 0; i < 100; i++) {
    lowsUp.push(i);
    highsUp.push(i + 1);
  }

  const resDefault = aroon(highsUp, lowsUp);
  if (!resDefault || !Array.isArray(resDefault.up) || !Array.isArray(resDefault.down)) {
    throw new Error('Aroon should return an object with up and down arrays');
  }
  if (resDefault.up.length !== 100 || resDefault.down.length !== 100) {
    throw new Error('Aroon output length mismatch for default params');
  }
  // Validate value ranges for the stable tail of the series
  for (let i = 50; i < 100; i++) {
    const u = resDefault.up[i];
    const d = resDefault.down[i];
    if (!Number.isFinite(u) || u < 0 || u > 100) {
      throw new Error('Aroon Up values should be finite and within [0, 100]');
    }
    if (!Number.isFinite(d) || d < 0 || d > 100) {
      throw new Error('Aroon Down values should be finite and within [0, 100]');
    }
  }
  if (resDefault.up[99] !== 100) {
    throw new Error('Aroon Up should be 100 at the end of a strong uptrend');
  }

  // Custom period test
  const resCustom = aroon(highsUp, lowsUp, { period: 14 });
  if (resCustom.up.length !== 100 || resCustom.down.length !== 100) {
    throw new Error('Aroon output length mismatch for custom period');
  }
  if (resCustom.up[99] !== 100) {
    throw new Error('Aroon Up (period 14) should be 100 at the end of a strong uptrend');
  }

  // Downtrend dataset: highs and lows strictly decreasing
  const highsDown = [];
  const lowsDown = [];
  for (let i = 0; i < 100; i++) {
    const base = 100 - i;
    highsDown.push(base);
    lowsDown.push(base - 1);
  }
  const resDown = aroon(highsDown, lowsDown, { period: 25 });
  if (resDown.up.length !== 100 || resDown.down.length !== 100) {
    throw new Error('Aroon output length mismatch for downtrend dataset');
  }
  if (resDown.down[99] !== 100) {
    throw new Error('Aroon Down should be 100 at the end of a strong downtrend');
  }

  console.log('✅ Aroon indicator tests passed');
  return 0;
}

// Always run tests when executed by the harness
main();
