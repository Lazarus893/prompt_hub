function main() {
  const { rma } = require('@alva/technical-indicators/rolling-moving-average-rma:v1.0.0');

  // Test 1: Basic constant input should yield the same constant output
  const size = 100;
  const constantValue = 10;
  const data = Array(size).fill(constantValue);

  const resultDefault = rma(data);
  if (!Array.isArray(resultDefault)) {
    throw new Error('rma should return an array');
  }
  if (resultDefault.length !== size) {
    throw new Error(`rma default length ${resultDefault.length} does not match input length ${size}`);
  }
  if (!resultDefault.every(v => Math.abs(v - constantValue) < 1e-12)) {
    throw new Error('rma default result should equal the constant input for all entries');
  }

  // Test 2: Custom period should still handle constant input correctly
  const period = 8;
  const resultCustom = rma(data, { period });
  if (!Array.isArray(resultCustom)) {
    throw new Error('rma (custom) should return an array');
  }
  if (resultCustom.length !== size) {
    throw new Error(`rma custom length ${resultCustom.length} does not match input length ${size}`);
  }
  if (!resultCustom.every(v => Math.abs(v - constantValue) < 1e-12)) {
    throw new Error('rma custom result should equal the constant input for all entries');
  }

  // Test 3: Empty input should yield empty output
  const resultEmpty = rma([]);
  if (!Array.isArray(resultEmpty)) {
    throw new Error('rma([]) should return an array');
  }
  if (resultEmpty.length !== 0) {
    throw new Error('rma([]) should return an empty array');
  }

  console.log('✅ Rolling Moving Average (RMA) tests passed');
  return 0;
}
module.exports = main;
main();
