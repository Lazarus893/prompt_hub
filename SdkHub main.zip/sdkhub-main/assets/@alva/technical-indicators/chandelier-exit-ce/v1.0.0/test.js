function main() {
  const { ce } = require('@alva/technical-indicators/chandelier-exit-ce:v1.0.0');

  const N = 100;
  const highs = [];
  const lows = [];
  const closings = [];

  for (let i = 0; i < N; i++) {
    const close = 100 + i * 0.5;
    const volatility = 1 + (i % 5) * 0.1;
    closings.push(close);
    highs.push(close + volatility);
    lows.push(close - volatility);
  }

  const ceDefault = ce(highs, lows, closings);
  if (!ceDefault || !Array.isArray(ceDefault.long) || !Array.isArray(ceDefault.short)) {
    throw new Error('Chandelier Exit: return value must be an object with long and short arrays');
  }
  if (ceDefault.long.length !== N) {
    throw new Error(`Chandelier Exit: long length expected ${N} but got ${ceDefault.long.length}`);
  }
  if (ceDefault.short.length !== N) {
    throw new Error(`Chandelier Exit: short length expected ${N} but got ${ceDefault.short.length}`);
  }

  const ceCustom = ce(highs, lows, closings, { period: 14 });
  if (!ceCustom || !Array.isArray(ceCustom.long) || !Array.isArray(ceCustom.short)) {
    throw new Error('Chandelier Exit (custom): return value must be an object with long and short arrays');
  }
  if (ceCustom.long.length !== N) {
    throw new Error(`Chandelier Exit (custom): long length expected ${N} but got ${ceCustom.long.length}`);
  }
  if (ceCustom.short.length !== N) {
    throw new Error(`Chandelier Exit (custom): short length expected ${N} but got ${ceCustom.short.length}`);
  }

  const sameLong = ceDefault.long.every((v, i) => v === ceCustom.long[i]);
  const sameShort = ceDefault.short.every((v, i) => v === ceCustom.short[i]);
  if (sameLong && sameShort) {
    throw new Error('Chandelier Exit: default and custom period results should differ for this dataset');
  }

  console.log('✅ Chandelier Exit (CE) tests passed');
  return 0;
}

// Always call main() so the test runs under different runners (including jagent)
main();
