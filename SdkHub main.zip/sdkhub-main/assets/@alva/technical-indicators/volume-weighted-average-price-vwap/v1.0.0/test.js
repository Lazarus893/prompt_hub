function nearlyEqual(a, b, eps = 1e-10) {
  return Math.abs(a - b) <= eps * Math.max(1, Math.abs(a), Math.abs(b));
}

function computeRollingVWAP(closings, volumes, period = 14) {
  const n = closings.length;
  const out = new Array(n);
  for (let i = 0; i < n; i++) {
    const start = Math.max(0, i - period + 1);
    let sumCV = 0;
    let sumV = 0;
    for (let j = start; j <= i; j++) {
      sumCV += closings[j] * volumes[j];
      sumV += volumes[j];
    }
    out[i] = sumV === 0 ? NaN : sumCV / sumV;
  }
  return out;
}

function main() {
  const { vwap } = require('@alva/technical-indicators/volume-weighted-average-price-vwap:v1.0.0');

  // Test 1: length and numerical correctness vs reference implementation (equal volumes)
  const N = 100;
  const period = 10;
  const closings1 = Array.from({ length: N }, (_, i) => i + 1); // 1..100
  const volumes1 = Array.from({ length: N }, () => 1); // equal weights
  const libResult1 = vwap(closings1, volumes1, { period });
  if (!Array.isArray(libResult1)) {
    throw new Error('vwap should return an array');
  }
  if (libResult1.length !== N) {
    throw new Error(`Expected vwap length ${N}, got ${libResult1.length}`);
  }
  const expected1 = computeRollingVWAP(closings1, volumes1, period);
  for (let i = 0; i < N; i++) {
    if (!nearlyEqual(libResult1[i], expected1[i])) {
      throw new Error(`VWAP mismatch at index ${i}: got ${libResult1[i]}, expected ${expected1[i]}`);
    }
  }

  // Test 2: constant price should yield constant VWAP regardless of volume distribution
  const M = 50;
  const constantPrice = 5;
  const closings2 = Array.from({ length: M }, () => constantPrice);
  const volumes2 = Array.from({ length: M }, (_, i) => (i % 7) + 1); // varying positive volumes
  const libResult2 = vwap(closings2, volumes2, { period: 7 });
  if (libResult2.length !== M) {
    throw new Error(`Expected vwap length ${M}, got ${libResult2.length}`);
  }
  for (let i = 0; i < M; i++) {
    if (!nearlyEqual(libResult2[i], constantPrice)) {
      throw new Error(`VWAP should equal constant price at index ${i}: got ${libResult2[i]}, expected ${constantPrice}`);
    }
  }

  console.log('✅ Volume Weighted Average Price (VWAP) tests passed');
  return 0;
}

main();

module.exports = { main };
