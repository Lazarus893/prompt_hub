function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

function isFiniteNumber(n) {
  return typeof n === 'number' && Number.isFinite(n);
}

function main() {
  const { rsi } = require('@alva/technical-indicators/relative-strength-index-rsi:v1.0.0');

  // Generate datasets
  const inc = Array.from({ length: 100 }, (_, i) => i + 1);
  const dec = Array.from({ length: 100 }, (_, i) => 100 - i);

  // Default period tests
  const rsiInc = rsi(inc);
  assert(Array.isArray(rsiInc), 'RSI result should be an array');
  assert(rsiInc.length === inc.length, 'RSI length should match input length for increasing data');
  assert(rsiInc.every(v => isFiniteNumber(v) && v >= 0 && v <= 100), 'All RSI values should be finite numbers within [0, 100]');
  assert(rsiInc[rsiInc.length - 1] > 50, 'RSI on increasing series should end above 50');

  const rsiDec = rsi(dec);
  assert(Array.isArray(rsiDec), 'RSI result should be an array');
  assert(rsiDec.length === dec.length, 'RSI length should match input length for decreasing data');
  assert(rsiDec.every(v => isFiniteNumber(v) && v >= 0 && v <= 100), 'All RSI values should be finite numbers within [0, 100]');
  assert(rsiDec[rsiDec.length - 1] < 50, 'RSI on decreasing series should end below 50');

  // Custom period tests
  const rsiIncP9 = rsi(inc, { period: 9 });
  assert(rsiIncP9.length === inc.length, 'RSI length with custom period should match input length');
  assert(rsiIncP9.every(v => isFiniteNumber(v) && v >= 0 && v <= 100), 'All RSI values (period 9) should be finite numbers within [0, 100]');
  // Note: Different periods may yield similar terminal values on monotonic series; primary check is bounds and length.

  console.log('✅ Relative Strength Index (RSI) tests passed');
  return 0;
}

// Always invoke main to ensure the test runs under all runners
main();

module.exports = { main };
