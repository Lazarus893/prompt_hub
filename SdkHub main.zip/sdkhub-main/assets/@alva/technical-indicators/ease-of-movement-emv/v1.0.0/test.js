function main() {
  const { emv } = require('@alva/technical-indicators/ease-of-movement-emv:v1.0.0');

  const len = 200;
  const highs = [];
  const lows = [];
  const volumes = [];
  let base = 100;

  for (let i = 0; i < len; i++) {
    const delta = Math.sin(i / 10) * 2 + (i % 5) * 0.5;
    const low = base + delta - 1;
    const high = base + delta + 1.5; // ensure high > low
    highs.push(high);
    lows.push(low);
    volumes.push(1000 + i * 10 + (i % 3) * 5); // ensure strictly positive volumes
    base += (i % 7 === 0 ? 0.2 : 0.05); // slight upward drift
  }

  const resultDefault = emv(highs, lows, volumes);
  if (!Array.isArray(resultDefault)) {
    throw new Error('EMV should return an array');
  }
  if (resultDefault.length !== len) {
    throw new Error(`EMV length mismatch: expected ${len}, got ${resultDefault.length}`);
  }

  const resultCustom = emv(highs, lows, volumes, { period: 20 });
  if (!Array.isArray(resultCustom) || resultCustom.length !== len) {
    throw new Error('EMV with custom period should return array of same length');
  }

  // Sanity: check that some mid-range values are finite numbers for both outputs
  for (let i = 30; i < len; i += Math.max(1, Math.floor(len / 10))) {
    const v1 = resultDefault[i];
    const v2 = resultCustom[i];
    if (typeof v1 !== 'number' || !Number.isFinite(v1)) {
      throw new Error(`EMV default value at index ${i} is not a finite number`);
    }
    if (typeof v2 !== 'number' || !Number.isFinite(v2)) {
      throw new Error(`EMV custom value at index ${i} is not a finite number`);
    }
  }

  console.log('✅ Ease of Movement (EMV) tests passed');
  return 0;
}

main();
