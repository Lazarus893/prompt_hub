function approxEqual(a, b, eps = 1e-6) {
  if (Number.isNaN(a) || Number.isNaN(b)) return false;
  return Math.abs(a - b) <= eps;
}

function main() {
  const { fi } = require('@alva/technical-indicators/force-index-fi:v1.0.0');

  // Test 1: Basic shape - result length matches inputs
  const closings1 = Array.from({ length: 100 }, (_, i) => i);
  const volumes1 = Array.from({ length: 100 }, () => 1000);
  const result1 = fi(closings1, volumes1);
  if (!Array.isArray(result1)) {
    throw new Error('fi should return an array');
  }
  if (result1.length !== closings1.length) {
    throw new Error('Force Index result length should equal input length');
  }
  if (!result1.every((v) => typeof v === 'number' && Number.isFinite(v))) {
    throw new Error('Force Index result should contain finite numbers');
  }

  // Test 2: With period=1, constant prices should yield zero FI after the first element
  const closings2 = Array.from({ length: 50 }, () => 42);
  const volumes2 = Array.from({ length: 50 }, (_, i) => i + 1);
  const result2 = fi(closings2, volumes2, { period: 1 });
  for (let i = 1; i < result2.length; i++) {
    if (!approxEqual(result2[i], 0, 1e-4)) {
      throw new Error('With period=1, Force Index should be ~0 for constant prices after the first element');
    }
  }

  // Test 3: With period = 1, increasing prices and constant volume produce constant positive FI after index 0
  const n = 20;
  const closings3 = Array.from({ length: n }, (_, i) => i);
  const volumes3 = Array.from({ length: n }, () => 10);
  const result3 = fi(closings3, volumes3, { period: 1 });
  for (let i = 1; i < n; i++) {
    if (!approxEqual(result3[i], 10)) {
      throw new Error('With period=1 and unit price increments, FI should be ~volume (10) after the first element');
    }
  }

  // Test 4: With period = 1, decreasing prices and constant volume produce constant negative FI after index 0
  const m = 20;
  const closings4 = Array.from({ length: m }, (_, i) => m - i);
  const volumes4 = Array.from({ length: m }, () => 5);
  const result4 = fi(closings4, volumes4, { period: 1 });
  for (let i = 1; i < m; i++) {
    if (!approxEqual(result4[i], -5)) {
      throw new Error('With period=1 and unit price decrements, FI should be ~-volume (-5) after the first element');
    }
  }

  // Test 5: Default period smoothing: after warm-up, sign should match direction bias
  const len = 60;
  const closings5 = Array.from({ length: len }, (_, i) => i * 1.0);
  const volumes5 = Array.from({ length: len }, () => 100);
  const result5 = fi(closings5, volumes5); // default period
  // After an initial warm-up, values should be non-negative for monotonic increase
  for (let i = 20; i < len; i++) {
    if (result5[i] < -1e-6) {
      throw new Error('With monotonically increasing prices, smoothed FI should be non-negative after warm-up');
    }
  }

  console.log('✅ Force Index (FI) tests passed');
  return 0;
}

const exitCode = main();
module.exports = exitCode;
