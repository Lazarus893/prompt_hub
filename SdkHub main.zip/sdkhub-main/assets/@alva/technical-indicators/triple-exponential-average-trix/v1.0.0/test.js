function main() {
  const { trix } = require('@alva/technical-indicators/triple-exponential-average-trix:v1.0.0');

  // generate sample data
  const data = [];
  for (let i = 0; i < 100; i++) {
    data.push(i + 1);
  }

  // Default parameters
  const trixDefault = trix(data);
  if (!Array.isArray(trixDefault)) {
    throw new Error('TRIX default output should be an array');
  }
  if (trixDefault.length !== data.length) {
    throw new Error('TRIX default length mismatch');
  }
  if (typeof trixDefault[trixDefault.length - 1] !== 'number') {
    throw new Error('TRIX default last value should be a number');
  }

  // Custom parameters
  const trixCustom = trix(data, { period: 9 });
  if (!Array.isArray(trixCustom)) {
    throw new Error('TRIX custom output should be an array');
  }
  if (trixCustom.length !== data.length) {
    throw new Error('TRIX custom length mismatch');
  }
  if (typeof trixCustom[trixCustom.length - 1] !== 'number') {
    throw new Error('TRIX custom last value should be a number');
  }

  // Expect different smoothing to produce different terminal values on a trending series
  if (trixCustom[trixCustom.length - 1] === trixDefault[trixDefault.length - 1]) {
    throw new Error('TRIX custom and default should differ for the last value');
  }

  console.log('✅ Triple Exponential Average (TRIX) tests passed');
  return 0;
}
main();