function almostEqual(a, b, eps = 1e-10) {
  return Math.abs(a - b) <= eps;
}

function main() {
  const { bop } = require('@alva/technical-indicators/balance-of-power-bop:v1.0.0');

  // Deterministic OHLC inputs with non-zero (high - low) to avoid division by zero
  const openings = [10, 12, 11, 13, 14];
  const highs = [12, 15, 13, 15, 16];
  const lows = [9, 11, 10, 12, 13];
  const closings = [11, 14, 12, 14, 15];

  const result = bop(openings, highs, lows, closings);

  if (!Array.isArray(result)) {
    throw new Error('BOP result should be an array');
  }
  if (result.length !== closings.length) {
    throw new Error(`BOP length mismatch: expected ${closings.length}, got ${result.length}`);
  }

  // Expected values using BOP = (Close - Open) / (High - Low)
  const expected = [
    (11 - 10) / (12 - 9), // 1/3
    (14 - 12) / (15 - 11), // 2/4 = 0.5
    (12 - 11) / (13 - 10), // 1/3
    (14 - 13) / (15 - 12), // 1/3
    (15 - 14) / (16 - 13), // 1/3
  ];

  for (let i = 0; i < expected.length; i++) {
    if (!almostEqual(result[i], expected[i])) {
      throw new Error(`BOP value mismatch at index ${i}: expected ${expected[i]}, got ${result[i]}`);
    }
    if (!(result[i] <= 1 && result[i] >= -1)) {
      throw new Error(`BOP value out of expected range [-1, 1] at index ${i}: ${result[i]}`);
    }
  }

  console.log('✅ Balance of Power (BOP) tests passed');
  return 0;
}

// Always run main to ensure the test executes under different runners
main();

module.exports = main;
