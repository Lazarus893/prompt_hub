function main() {
  const { tema } = require('@alva/technical-indicators/triple-exponential-moving-average-tema:v1.0.0');

  // Helper for floating point comparisons
  const approxEqual = (a, b, eps = 1e-6) => Math.abs(a - b) <= eps;

  // 1) Basic functionality and length check
  const data = Array.from({ length: 100 }, (_, i) => i);
  const temaDefault = tema(data);
  if (!Array.isArray(temaDefault)) {
    throw new Error('TEMA result should be an array');
  }
  if (temaDefault.length !== data.length) {
    throw new Error(`TEMA output length ${temaDefault.length} != input length ${data.length}`);
  }
  // Ensure all values are finite numbers
  for (let i = 0; i < temaDefault.length; i++) {
    if (!Number.isFinite(temaDefault[i])) {
      throw new Error(`TEMA output contains non-finite at index ${i}: ${temaDefault[i]}`);
    }
  }

  // 2) Constant series should stabilize to the constant value
  const constant = Array(100).fill(5);
  const temaConst = tema(constant);
  if (temaConst.length !== constant.length) {
    throw new Error('TEMA constant series: length mismatch');
  }
  // After some warm-up, values should be ~5
  for (let i = 20; i < temaConst.length; i++) {
    if (!approxEqual(temaConst[i], 5)) {
      throw new Error(`TEMA constant series deviates at index ${i}: ${temaConst[i]} != ~5`);
    }
  }

  // 3) Custom period should produce different smoothing than default on a step-change series
  const step = Array(50).fill(0).concat(Array(50).fill(100));
  const temaP2 = tema(step, { period: 2 });
  const temaP8 = tema(step, { period: 8 });
  if (temaP2.length !== step.length || temaP8.length !== step.length) {
    throw new Error('TEMA custom period: length mismatch');
  }
  // Compare a few indices after the step to ensure outputs differ
  const checkIndices = [50, 52, 55, 60];
  let foundDiff = false;
  for (const idx of checkIndices) {
    if (Math.abs(temaP2[idx] - temaP8[idx]) > 1e-6) {
      foundDiff = true;
      break;
    }
  }
  if (!foundDiff) {
    throw new Error('TEMA different periods should yield different smoothing near a step change');
  }

  // 4) Basic monotonic trend check: rising input should produce non-decreasing overall trend end vs start
  if (!(temaDefault[temaDefault.length - 1] >= temaDefault[0])) {
    throw new Error('TEMA on rising data should produce a non-decreasing overall trend');
  }

  // 5) Edge case: empty input should not throw and should return empty array
  const empty = tema([]);
  if (!Array.isArray(empty) || empty.length !== 0) {
    throw new Error('TEMA on empty input should return an empty array');
  }

  console.log('✅ Triple Exponential Moving Average (TEMA) tests passed');
  return 0;
}

// Ensure tests actually run in all environments
main();

module.exports = main;
