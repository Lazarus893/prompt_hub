function main() {
  const { roc } = require('@alva/technical-indicators/price-rate-of-change-roc:v1.0.0');

  // Test 1: Increasing series should yield positive ROC at the tail
  const incData = Array.from({ length: 100 }, (_, i) => i + 1);
  const incResult = roc(incData);
  if (!Array.isArray(incResult)) {
    throw new Error('ROC should return an array');
  }
  if (incResult.length !== incData.length) {
    throw new Error('ROC result length should match input length for increasing series');
  }
  const incTail = incResult[incResult.length - 1];
  if (!Number.isFinite(incTail) || !(incTail > 0)) {
    throw new Error('ROC tail value for increasing series should be a positive finite number');
  }

  // Test 2: Constant series should yield zero ROC where defined (tail should be 0)
  const constData = Array(100).fill(5);
  const constResult = roc(constData);
  if (constResult.length !== constData.length) {
    throw new Error('ROC result length should match input length for constant series');
  }
  const constTail = constResult[constResult.length - 1];
  if (constTail !== 0) {
    throw new Error('ROC tail value for constant series should be 0');
  }

  // Test 3: Custom period should still return same length and sensible values
  const constP4 = roc(constData, { period: 4 });
  if (constP4.length !== constData.length) {
    throw new Error('ROC (period=4) result length should match input length');
  }
  if (constP4[constP4.length - 1] !== 0) {
    throw new Error('ROC (period=4) tail value for constant series should be 0');
  }

  const incP10 = roc(incData, { period: 10 });
  if (incP10.length !== incData.length) {
    throw new Error('ROC (period=10) result length should match input length');
  }
  if (!Number.isFinite(incP10[incP10.length - 1]) || !(incP10[incP10.length - 1] > 0)) {
    throw new Error('ROC (period=10) tail value for increasing series should be positive and finite');
  }

  console.log('✅ Price Rate of Change (ROC) tests passed');
  return 0;
}

main();
