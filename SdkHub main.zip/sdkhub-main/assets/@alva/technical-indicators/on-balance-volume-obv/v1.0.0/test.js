function assert(condition, message) {
  if (!condition) {
    throw new Error(message || 'Assertion failed');
  }
}

function checkObvDeltas(closings, volumes, result) {
  for (let i = 1; i < closings.length; i++) {
    const delta = result[i] - result[i - 1];
    if (closings[i] > closings[i - 1]) {
      assert(
        delta === volumes[i],
        `Expected positive delta equal to volume at index ${i}, expected ${volumes[i]}, got ${delta}`
      );
    } else if (closings[i] < closings[i - 1]) {
      assert(
        delta === -volumes[i],
        `Expected negative delta equal to -volume at index ${i}, expected ${-volumes[i]}, got ${delta}`
      );
    } else {
      assert(delta === 0, `Expected zero delta at index ${i}, got ${delta}`);
    }
  }
}

function main() {
  const { obv } = require('@alva/technical-indicators/on-balance-volume-obv:v1.0.0');

  // Test 1: strictly increasing closings -> OBV should increase by volumes[i] each step
  const n = 100;
  const closingsInc = Array.from({ length: n }, (_, i) => i + 1);
  const volumesInc = Array.from({ length: n }, (_, i) => i + 1); // 1..n
  const resInc = obv(closingsInc, volumesInc);
  assert(Array.isArray(resInc), 'OBV result should be an array');
  assert(resInc.length === n, `OBV length should be ${n}`);
  checkObvDeltas(closingsInc, volumesInc, resInc);

  // Test 2: mixed movement with equals
  const closingsMixed = [10, 12, 11, 11, 15, 14, 14, 16, 13, 13, 14];
  const volumesMixed = [5, 20, 30, 40, 10, 15, 25, 35, 50, 60, 70];
  const resMixed = obv(closingsMixed, volumesMixed);
  assert(resMixed.length === closingsMixed.length, 'OBV length mismatch in mixed test');
  checkObvDeltas(closingsMixed, volumesMixed, resMixed);

  // Test 3: constant closings -> OBV should remain flat regardless of volumes
  const closingsConst = Array.from({ length: 20 }, () => 100);
  const volumesConst = Array.from({ length: 20 }, (_, i) => (i + 1) * 3);
  const resConst = obv(closingsConst, volumesConst);
  assert(resConst.length === closingsConst.length, 'OBV length mismatch in constant test');
  checkObvDeltas(closingsConst, volumesConst, resConst);

  console.log('✅ On-Balance Volume (OBV) tests passed');
  return 0;
}

// Ensure the test actually runs
main();
