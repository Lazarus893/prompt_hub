function main() {
  const { cfo } = require('@alva/technical-indicators/chande-forecast-oscillator-cfo:v1.0.0');

  // Build monotonically increasing closing prices starting from 1 to avoid division by zero
  const closings = Array.from({ length: 100 }, (_, i) => i + 1);

  // Default configuration test
  const resultDefault = cfo(closings);
  if (!Array.isArray(resultDefault)) {
    throw new Error('cfo should return an array');
  }
  if (resultDefault.length !== closings.length) {
    throw new Error(`cfo result length (${resultDefault.length}) does not match input length (${closings.length})`);
  }
  if (!Number.isFinite(resultDefault[resultDefault.length - 1])) {
    throw new Error('Last CFO value should be a finite number for default configuration');
  }

  // Custom period configuration test
  const period = 8;
  const resultCustom = cfo(closings, { period });
  if (!Array.isArray(resultCustom)) {
    throw new Error('cfo (custom) should return an array');
  }
  if (resultCustom.length !== closings.length) {
    throw new Error(`cfo (custom) result length (${resultCustom.length}) does not match input length (${closings.length})`);
  }
  if (!Number.isFinite(resultCustom[resultCustom.length - 1])) {
    throw new Error('Last CFO value should be a finite number for custom configuration');
  }

  console.log('✅ Chande Forecast Oscillator (CFO) tests passed');
  return 0;
}

module.exports = main;

if (require.main === module) {
  main();
}
