function isFiniteNumber(n) {
  return typeof n === 'number' && Number.isFinite(n);
}

function validateStructure(name, result, expectedLength) {
  if (!result || typeof result !== 'object') {
    throw new Error(name + ' result should be an object');
  }
  const { ppoResult, signal, histogram } = result;
  if (!Array.isArray(ppoResult)) throw new Error(name + ': ppoResult should be an array');
  if (!Array.isArray(signal)) throw new Error(name + ': signal should be an array');
  if (!Array.isArray(histogram)) throw new Error(name + ': histogram should be an array');

  if (ppoResult.length !== expectedLength) {
    throw new Error(name + ': ppoResult length is not ' + expectedLength);
  }
  if (signal.length !== expectedLength) {
    throw new Error(name + ': signal length is not ' + expectedLength);
  }
  if (histogram.length !== expectedLength) {
    throw new Error(name + ': histogram length is not ' + expectedLength);
  }

  // Validate histogram ≈ ppoResult - signal for indices with finite numbers
  let validated = 0;
  for (let i = 0; i < expectedLength; i++) {
    const p = ppoResult[i];
    const s = signal[i];
    const h = histogram[i];
    if (isFiniteNumber(p) && isFiniteNumber(s) && isFiniteNumber(h)) {
      const diff = Math.abs(h - (p - s));
      if (diff > 1e-6) {
        throw new Error(name + ': histogram at index ' + i + ' is not equal to ppoResult - signal');
      }
      validated++;
    }
  }
  if (validated === 0) {
    throw new Error(name + ': no finite values to validate relationship (ppoResult - signal = histogram)');
  }
}

function main() {
  const { ppo } = require('@alva/technical-indicators/percentage-price-oscillator-ppo:v1.0.0');

  // Build deterministic input data
  const data = [];
  for (let i = 0; i < 200; i++) {
    // mildly trending prices with small oscillation
    data.push(100 + i * 0.5 + Math.sin(i / 5) * 2);
  }

  const defaultResult = ppo(data);
  validateStructure('Default PPO', defaultResult, data.length);

  const customConfig = { fast: 6, slow: 13, signal: 7 };
  const customResult = ppo(data, customConfig);
  validateStructure('Custom PPO', customResult, data.length);

  // Ensure custom parameters produce a different series (at least at some indices)
  let differenceCount = 0;
  for (let i = 0; i < data.length; i++) {
    const a = defaultResult.ppoResult[i];
    const b = customResult.ppoResult[i];
    if (isFiniteNumber(a) && isFiniteNumber(b) && Math.abs(a - b) > 1e-12) {
      differenceCount++;
      break;
    }
  }
  if (differenceCount === 0) {
    throw new Error('Custom PPO parameters did not change the result compared to defaults');
  }

  console.log('✅ Percentage Price Oscillator (PPO) tests passed');
  return 0;
}

// Always run the test when this file is executed or required by the runner
main();

module.exports = { main };
