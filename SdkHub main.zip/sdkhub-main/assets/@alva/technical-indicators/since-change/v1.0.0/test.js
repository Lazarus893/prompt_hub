function main() {
  const { since } = require('@alva/technical-indicators/since-change:v1.0.0');

  const assertArrayEqual = (actual, expected, message) => {
    const a = JSON.stringify(actual);
    const e = JSON.stringify(expected);
    if (a !== e) {
      throw new Error(`${message}\nExpected: ${e}\nActual:   ${a}`);
    }
  };

  // Test 1: single element
  assertArrayEqual(since([5]), [0], 'since([5]) should be [0]');

  // Test 2: all equal values
  assertArrayEqual(since([1, 1, 1, 1]), [0, 1, 2, 3], 'since with repeating identical values failed');

  // Test 3: all different values
  assertArrayEqual(since([1, 2, 3, 4]), [0, 0, 0, 0], 'since with all different values failed');

  // Test 4: example from documentation
  assertArrayEqual(since([1, 2, 2, 3, 4, 4, 4]), [0, 0, 1, 0, 0, 1, 2], 'since example from documentation failed');

  // Test 5: patterned data (runs of 10)
  const data = Array.from({ length: 100 }, (_, i) => Math.floor(i / 10));
  const expected = [];
  for (let i = 0; i < data.length; i++) {
    if (i === 0 || data[i] !== data[i - 1]) {
      expected.push(0);
    } else {
      expected.push(expected[i - 1] + 1);
    }
  }
  const result = since(data);
  if (result.length !== data.length) {
    throw new Error('Output length must match input length');
  }
  assertArrayEqual(result, expected, 'since failed on patterned data');

  console.log('✅ Since Change tests passed');
  return 0;
}

// Always run the tests when this file is executed or required by the runner
main();
