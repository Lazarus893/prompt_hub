'use strict';

function approxEqual(a, b, eps = 1e-9) {
  return Math.abs(a - b) <= eps;
}

function isNumber(x) {
  return typeof x === 'number' && Number.isFinite(x);
}

function main() {
  const { willr } = require('@alva/technical-indicators/williams-r-willr:v1.0.0');

  const N = 100;

  // Dataset 1: Ascending highs/lows, closes equal to highs -> expect %R near 0 (overbought)
  const highs1 = [];
  const lows1 = [];
  const closes1 = [];
  for (let i = 0; i < N; i++) {
    const low = i;
    const high = i + 10;
    highs1.push(high);
    lows1.push(low);
    // Close equals highest high of the window when series is strictly increasing
    closes1.push(high);
  }
  const result1 = willr(highs1, lows1, closes1, { period: 14 });
  if (!Array.isArray(result1)) throw new Error('Result 1 is not an array');
  if (result1.length !== N) throw new Error('Result 1 length mismatch');
  // Last value should be exactly 0
  const last1 = result1[result1.length - 1];
  if (!isNumber(last1)) throw new Error('Result 1 last value is not a number');
  if (!approxEqual(last1, 0)) throw new Error(`Expected last value to be 0, got ${last1}`);
  // All numeric values should be within [-100, 0]
  for (const v of result1) {
    if (isNumber(v) && (v < -100 || v > 0)) {
      throw new Error(`Value out of range [-100, 0]: ${v}`);
    }
  }

  // Dataset 2: Constant range with close at the lowest low -> expect -100 across
  const highs2 = new Array(N).fill(100);
  const lows2 = new Array(N).fill(0);
  const closes2 = new Array(N).fill(0);
  const result2 = willr(highs2, lows2, closes2); // default period
  if (!Array.isArray(result2)) throw new Error('Result 2 is not an array');
  if (result2.length !== N) throw new Error('Result 2 length mismatch');
  for (const v of result2) {
    if (!isNumber(v)) continue; // skip non-numeric placeholders if any
    if (!approxEqual(v, -100)) {
      throw new Error(`Expected -100, got ${v}`);
    }
  }

  // Dataset 3: Same as dataset 2 but with custom period to ensure config works
  const period = 5;
  const result3 = willr(highs2, lows2, closes2, { period });
  if (!Array.isArray(result3)) throw new Error('Result 3 is not an array');
  if (result3.length !== N) throw new Error('Result 3 length mismatch');
  const last3 = result3[result3.length - 1];
  if (!isNumber(last3) || !approxEqual(last3, -100)) {
    throw new Error(`With custom period=${period}, expected last value -100, got ${last3}`);
  }

  console.log('✅ Williams R (WILLR) tests passed');
  return 0;
}

main();

module.exports = { main };