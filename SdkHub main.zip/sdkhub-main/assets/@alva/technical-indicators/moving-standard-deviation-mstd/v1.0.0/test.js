function main() {
  const { mstd } = require('@alva/technical-indicators/moving-standard-deviation-mstd:v1.0.0');

  // Test 1: Basic functionality with default parameters
  const data = [];
  for (let i = 0; i < 100; i++) {
    data.push(i);
  }
  const resultDefault = mstd(data);
  if (!Array.isArray(resultDefault)) {
    throw new Error('mstd should return an array');
  }
  if (resultDefault.length !== data.length) {
    throw new Error('Result length should match input length for default config');
  }
  for (let i = 0; i < resultDefault.length; i++) {
    const v = resultDefault[i];
    if (!Number.isFinite(v)) {
      throw new Error(`Non-finite value at index ${i} for default config`);
    }
    if (v < 0) {
      throw new Error(`Negative standard deviation at index ${i} for default config`);
    }
  }

  // Test 2: Custom period parameter
  const resultPeriod2 = mstd(data, { period: 2 });
  if (!Array.isArray(resultPeriod2)) {
    throw new Error('mstd with custom period should return an array');
  }
  if (resultPeriod2.length !== data.length) {
    throw new Error('Result length should match input length for custom period');
  }
  for (let i = 0; i < resultPeriod2.length; i++) {
    const v = resultPeriod2[i];
    if (!Number.isFinite(v)) {
      throw new Error(`Non-finite value at index ${i} for period=2`);
    }
    if (v < 0) {
      throw new Error(`Negative standard deviation at index ${i} for period=2`);
    }
  }

  // Test 3: Constant series should yield zeros (std dev = 0)
  const constant = new Array(50).fill(5);
  const resultConstant = mstd(constant);
  if (resultConstant.length !== constant.length) {
    throw new Error('Constant series result length mismatch');
  }
  for (let i = 0; i < resultConstant.length; i++) {
    if (Math.abs(resultConstant[i]) > 1e-12) {
      throw new Error(`Expected zero std dev for constant series at index ${i}, got ${resultConstant[i]}`);
    }
  }

  console.log('✅ Moving Standard Deviation (MSTD) tests passed');
  return 0;
}

module.exports = main;
// Ensure the test actually runs
main();
