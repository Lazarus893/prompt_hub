function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function arraysEqual(a, b) {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}

function approxArraysEqual(a, b, eps = 1e-9) {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (Math.abs(a[i] - b[i]) > eps) return false;
  }
  return true;
}

function range(n) {
  return Array.from({ length: n }, (_, i) => i + 1);
}

function prefixSums(values) {
  const out = [];
  let acc = 0;
  for (const v of values) {
    acc += v;
    out.push(acc);
  }
  return out;
}

function main() {
  const { msum } = require('@alva/technical-indicators/moving-sum-msum:v1.0.0');

  // Data setup
  const values = range(10); // [1..10]

  // Default period (expected 4)
  const expectedDefault = [1, 3, 6, 10, 14, 18, 22, 26, 30, 34];
  const outDefault = msum(values);
  assert(Array.isArray(outDefault), 'msum should return an array');
  assert(outDefault.length === values.length, 'output length should match input length');
  assert(arraysEqual(outDefault, expectedDefault), 'default period moving sum is incorrect');

  // Custom period 7
  const expectedP7 = [1, 3, 6, 10, 15, 21, 28, 35, 42, 49];
  const outP7 = msum(values, { period: 7 });
  assert(arraysEqual(outP7, expectedP7), 'period 7 moving sum is incorrect');

  // Period 1 should equal the original values
  const outP1 = msum(values, { period: 1 });
  assert(arraysEqual(outP1, values), 'period 1 should equal the original values');

  // Period larger than input length: should equal prefix sums
  const outLarge = msum(values, { period: 20 });
  assert(arraysEqual(outLarge, prefixSums(values)), 'period > length should produce prefix sums');

  // Empty input
  const outEmpty = msum([], { period: 5 });
  assert(Array.isArray(outEmpty) && outEmpty.length === 0, 'empty input should return empty array');

  // Non-mutation of input
  const original = values.slice();
  msum(values, { period: 4 });
  assert(arraysEqual(values, original), 'msum should not mutate the input array');

  // Floating numbers with tolerance
  const floatVals = [0.1, 0.2, 0.3, 0.4, 0.5];
  const floatOut = msum(floatVals, { period: 3 });
  const expectedFloat = [0.1, 0.3, 0.6, 0.9, 1.2];
  assert(approxArraysEqual(floatOut, expectedFloat, 1e-12), 'floating number moving sum incorrect');

  console.log('✅ Moving Sum (MSUM) tests passed');
  return 0;
}

// Always run the test when this file is executed or required by the runner
main();
