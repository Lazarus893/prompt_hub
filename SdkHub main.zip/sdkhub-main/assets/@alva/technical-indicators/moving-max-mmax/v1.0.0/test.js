function computeExpected(values, period) {
  const out = [];
  for (let i = 0; i < values.length; i++) {
    const start = Math.max(0, i - period + 1);
    let max = -Infinity;
    for (let j = start; j <= i; j++) {
      if (values[j] > max) max = values[j];
    }
    out.push(max === -Infinity ? undefined : max);
  }
  return out;
}

function assertArrayEqual(actual, expected, message) {
  if (actual.length !== expected.length) {
    throw new Error(`${message} (length mismatch: ${actual.length} !== ${expected.length})`);
  }
  for (let i = 0; i < actual.length; i++) {
    const a = actual[i];
    const e = expected[i];
    if (!(Number.isFinite(a) && Number.isFinite(e) && a === e)) {
      throw new Error(`${message} (index ${i}: ${a} !== ${e})`);
    }
  }
}

function main() {
  const { mmax } = require('@alva/technical-indicators/moving-max-mmax:v1.0.0');

  // Increasing sequence - default period (4)
  {
    const values = Array.from({ length: 20 }, (_, i) => i + 1);
    const result = mmax(values);
    const expected = computeExpected(values, 4);
    assertArrayEqual(result, expected, 'MMAX increasing sequence with default period failed');
  }

  // Custom period (8)
  {
    const values = Array.from({ length: 25 }, (_, i) => Math.floor(10 * Math.sin(i / 3)) + i);
    const result = mmax(values, { period: 8 });
    const expected = computeExpected(values, 8);
    assertArrayEqual(result, expected, 'MMAX custom period (8) failed');
  }

  // Constant sequence
  {
    const values = Array(15).fill(7);
    const result = mmax(values, { period: 5 });
    const expected = computeExpected(values, 5);
    assertArrayEqual(result, expected, 'MMAX constant sequence failed');
  }

  // Decreasing sequence
  {
    const values = Array.from({ length: 10 }, (_, i) => 10 - i);
    const result = mmax(values, { period: 3 });
    const expected = computeExpected(values, 3);
    assertArrayEqual(result, expected, 'MMAX decreasing sequence failed');
  }

  // Negative values and mix
  {
    const values = [-5, -2, -3, -1, -4, -6, -1, -8];
    const result = mmax(values, { period: 2 });
    const expected = computeExpected(values, 2);
    assertArrayEqual(result, expected, 'MMAX negative values mix failed');
  }

  // Empty input
  {
    const values = [];
    const result = mmax(values);
    if (!Array.isArray(result) || result.length !== 0) {
      throw new Error('MMAX empty input should return empty array');
    }
  }

  // Single element
  {
    const values = [42];
    const result = mmax(values, { period: 10 });
    const expected = computeExpected(values, 10);
    assertArrayEqual(result, expected, 'MMAX single element failed');
  }

  console.log('✅ Moving Max (MMAX) tests passed');
  return 0;
}

module.exports = main;

main();

