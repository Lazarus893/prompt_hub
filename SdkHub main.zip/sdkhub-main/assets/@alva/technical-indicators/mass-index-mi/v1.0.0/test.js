function main() {
  const { mi } = require('@alva/technical-indicators/mass-index-mi:v1.0.0');

  // Generate synthetic highs and lows where highs > lows
  const highs = [];
  const lows = [];
  for (let i = 0; i < 100; i++) {
    const low = i + (i % 3) * 0.1; // small oscillation
    const high = low + 2 + (i % 5) * 0.05; // ensure high > low with variation
    lows.push(low);
    highs.push(high);
  }

  const miDefault = mi(highs, lows);
  if (!Array.isArray(miDefault)) {
    throw new Error('MI result should be an array');
  }
  if (miDefault.length !== highs.length) {
    throw new Error(`MI length mismatch: expected ${highs.length}, got ${miDefault.length}`);
  }
  const lastDefault = miDefault[miDefault.length - 1];
  if (!Number.isFinite(lastDefault)) {
    throw new Error('Last MI (default params) should be a finite number');
  }

  // Custom parameters should still return proper array and typically yield different values
  const miCustom = mi(highs, lows, { emaPeriod: 5, miPeriod: 17 });
  if (!Array.isArray(miCustom)) {
    throw new Error('Custom MI result should be an array');
  }
  if (miCustom.length !== highs.length) {
    throw new Error(`Custom MI length mismatch: expected ${highs.length}, got ${miCustom.length}`);
  }
  const lastCustom = miCustom[miCustom.length - 1];
  if (!Number.isFinite(lastCustom)) {
    throw new Error('Last MI (custom params) should be a finite number');
  }
  if (lastCustom === lastDefault) {
    throw new Error('Custom parameters should affect the MI value (last value matched default)');
  }

  console.log('✅ Mass Index (MI) tests passed');
  return 0;
}

module.exports = main;
main();
