function approxEqual(a, b, eps = 1e-9) {
  return Math.abs(a - b) <= eps;
}

function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

function main() {
  const { dema } = require('@alva/technical-indicators/double-exponential-moving-average-dema:v1.0.0');

  // Test 1: Basic length and numeric output using default period
  const data = Array.from({ length: 100 }, (_, i) => i);
  const resultDefault = dema(data);
  assert(Array.isArray(resultDefault), 'DEMA should return an array');
  assert(resultDefault.length === data.length, 'Result length should match input length');
  assert(Number.isFinite(resultDefault[resultDefault.length - 1]), 'Last DEMA value should be a finite number');

  // Test 2: Period = 1 should reproduce the input exactly
  const resultP1 = dema(data, { period: 1 });
  assert(resultP1.length === data.length, 'Period 1: length should match input');
  for (let i = 0; i < data.length; i++) {
    assert(resultP1[i] === data[i], `Period 1: value mismatch at index ${i}`);
  }

  // Test 3: Constant series should remain constant (especially towards the end)
  const constant = 42;
  const constSeries = Array.from({ length: 120 }, () => constant);
  const constResult = dema(constSeries, { period: 12 });
  assert(constResult.length === constSeries.length, 'Constant series: length should match');
  // Check last 10 values are (approximately) equal to the constant
  for (let i = constResult.length - 10; i < constResult.length; i++) {
    assert(approxEqual(constResult[i], constant, 1e-9), `Constant series: value not constant at index ${i}`);
  }

  // Test 4: Smaller period tracks input more closely than larger period
  const trendingThenSpike = Array.from({ length: 60 }, (_, i) => i);
  trendingThenSpike[trendingThenSpike.length - 1] = 200; // spike at the end
  const resFast = dema(trendingThenSpike, { period: 3 });
  const resSlow = dema(trendingThenSpike, { period: 30 });
  const last = trendingThenSpike[trendingThenSpike.length - 1];
  const errFast = Math.abs(resFast[resFast.length - 1] - last);
  const errSlow = Math.abs(resSlow[resSlow.length - 1] - last);
  assert(errFast <= errSlow, 'Smaller period should be closer to the latest price than larger period');

  console.log('✅ Double Exponential Moving Average (DEMA) tests passed');
  return 0;
}

module.exports = { main };

// Ensure the test actually runs when executed
main();

