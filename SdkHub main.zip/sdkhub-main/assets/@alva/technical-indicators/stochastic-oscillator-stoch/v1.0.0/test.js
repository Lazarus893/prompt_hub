function main() {
  const { stoch } = require('@alva/technical-indicators/stochastic-oscillator-stoch:v1.0.0');

  const highs = [];
  const lows = [];
  const closings = [];
  for (let i = 0; i < 100; i++) {
    // Construct a simple monotonically increasing series
    const close = i;
    const high = close + 5;
    const low = close - 5;
    highs.push(high);
    lows.push(low);
    closings.push(close);
  }

  // Default parameters
  const stochDefault = stoch(highs, lows, closings);
  if (!stochDefault || !Array.isArray(stochDefault.k) || !Array.isArray(stochDefault.d)) {
    throw new Error('stoch() should return an object with k and d arrays');
  }
  if (stochDefault.k.length !== closings.length) {
    throw new Error('k length is not equal to input length for default params');
  }
  if (stochDefault.d.length !== closings.length) {
    throw new Error('d length is not equal to input length for default params');
  }

  // Custom parameters
  const stochCustom = stoch(highs, lows, closings, { kPeriod: 12, dPeriod: 2 });
  if (!stochCustom || !Array.isArray(stochCustom.k) || !Array.isArray(stochCustom.d)) {
    throw new Error('stoch() with custom params should return an object with k and d arrays');
  }
  if (stochCustom.k.length !== closings.length) {
    throw new Error('k length is not equal to input length for custom params');
  }
  if (stochCustom.d.length !== closings.length) {
    throw new Error('d length is not equal to input length for custom params');
  }

  console.log('✅ Stochastic Oscillator (STOCH) tests passed');
  return 0;
}

module.exports = { main };

// Ensure the test runs when executed directly
if (require.main === module) {
  main();
}
