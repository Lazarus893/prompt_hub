function main() {
  const { ui } = require('@alva/technical-indicators/ulcer-index-ui:v1.0.0');

  const mkArray = (n, fn) => Array.from({ length: n }, (_, i) => fn(i));

  // Flat series should yield 0 UI (no drawdown)
  const flat = mkArray(100, () => 100);
  const outFlat = ui(flat);
  if (!Array.isArray(outFlat)) {
    throw new Error('ui() should return an array');
  }
  if (outFlat.length !== flat.length) {
    throw new Error('Ulcer Index length mismatch for flat series (default config)');
  }
  const lastFlat = outFlat[outFlat.length - 1];
  if (typeof lastFlat !== 'number' || Number.isNaN(lastFlat)) {
    throw new Error('Ulcer Index last value for flat series should be a number');
  }
  if (lastFlat !== 0) {
    throw new Error('Ulcer Index last value for flat series should be 0');
  }
  for (const v of outFlat) {
    if (v == null) continue; // allow leading nulls if any
    if (typeof v !== 'number' || Number.isNaN(v)) {
      throw new Error('Ulcer Index contains non-number values');
    }
    if (v < 0) {
      throw new Error('Ulcer Index should not contain negative values');
    }
  }

  // Monotonically increasing series should also yield 0 at the end (no drawdowns)
  const inc = mkArray(100, (i) => i + 1);
  const outInc = ui(inc, { period: 14 });
  if (outInc.length !== inc.length) {
    throw new Error('Ulcer Index length mismatch for increasing series');
  }
  const lastInc = outInc[outInc.length - 1];
  if (typeof lastInc !== 'number' || Number.isNaN(lastInc)) {
    throw new Error('Ulcer Index last value for increasing series should be a number');
  }
  if (lastInc !== 0) {
    throw new Error('Ulcer Index last value for increasing series should be 0');
  }

  // Monotonically decreasing series should yield a positive value at the end (drawdowns present)
  const dec = mkArray(100, (i) => 100 - i);
  const outDec = ui(dec, { period: 8 });
  if (outDec.length !== dec.length) {
    throw new Error('Ulcer Index length mismatch for decreasing series');
  }
  const lastDec = outDec[outDec.length - 1];
  if (typeof lastDec !== 'number' || Number.isNaN(lastDec)) {
    throw new Error('Ulcer Index last value for decreasing series should be a number');
  }
  if (lastDec <= 0) {
    throw new Error('Ulcer Index last value for decreasing series should be positive');
  }

  console.log('✅ Ulcer Index (UI) tests passed');
  return 0;
}

// Always run the test when this file is executed or required by a runner
main();

module.exports = main;
