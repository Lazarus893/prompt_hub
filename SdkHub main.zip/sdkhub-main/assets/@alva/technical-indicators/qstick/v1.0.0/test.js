function main() {
  const { qstick } = require('@alva/technical-indicators/qstick:v1.0.0');

  // Helper for approximate comparisons
  const approxEqual = (a, b, eps = 1e-9) => Math.abs(a - b) <= eps;

  // Test 1: default parameters with constant difference
  const N = 100;
  const openings1 = Array(N).fill(0);
  const closings1 = Array(N).fill(5);
  const resDefault = qstick(openings1, closings1);
  if (!resDefault || resDefault.length !== N) {
    throw new Error('Qstick default: result length mismatch');
  }
  if (!approxEqual(resDefault[N - 1], 5)) {
    throw new Error(`Qstick default: expected last value ~ 5, got ${resDefault[N - 1]}`);
  }

  // Test 2: period = 1 should equal (closing - opening) point-wise
  const openings2 = Array.from({ length: N }, (_, i) => i);
  const closings2 = Array.from({ length: N }, (_, i) => i + 1);
  const resP1 = qstick(openings2, closings2, { period: 1 });
  if (!resP1 || resP1.length !== N) {
    throw new Error('Qstick period=1: result length mismatch');
  }
  for (let i = 0; i < N; i++) {
    const expected = closings2[i] - openings2[i];
    if (!approxEqual(resP1[i], expected)) {
      throw new Error(`Qstick period=1: mismatch at index ${i}, expected ${expected}, got ${resP1[i]}`);
    }
  }

  console.log('✅ Qstick tests passed');
  return 0;
}

main();