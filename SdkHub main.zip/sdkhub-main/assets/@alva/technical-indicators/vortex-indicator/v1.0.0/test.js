function main() {
  const { vortex } = require('@alva/technical-indicators/vortex-indicator:v1.0.0');

  // Build synthetic OHLC arrays with consistent relationships: high >= low, low <= close <= high
  const highs = [];
  const lows = [];
  const closings = [];
  const n = 100;
  for (let i = 0; i < n; i++) {
    const base = 50 + Math.sin(i / 5) * 10 + i * 0.1; // trending with oscillation
    const range = 2 + (i % 5) * 0.5; // varying range
    const low = base - range;
    const high = base + range;
    const close = low + (high - low) * 0.6; // somewhere in the upper portion
    highs.push(high);
    lows.push(low);
    closings.push(close);
  }

  // Default parameters (period should default to 14)
  const viDefault = vortex(highs, lows, closings);
  if (!viDefault || !Array.isArray(viDefault.plus) || !Array.isArray(viDefault.minus)) {
    throw new Error('vortex() must return an object with plus and minus arrays');
  }
  if (viDefault.plus.length !== n || viDefault.minus.length !== n) {
    throw new Error('plus/minus length must equal input length');
  }

  // Spot check that after the period window results are finite non-negative numbers
  const startCheck = 20; // beyond common default period of 14
  for (let i = startCheck; i < n; i++) {
    const p = viDefault.plus[i];
    const m = viDefault.minus[i];
    if (!(Number.isFinite(p) && Number.isFinite(m) && p >= 0 && m >= 0)) {
      throw new Error('plus/minus values should be finite non-negative numbers after warm-up period');
    }
  }

  // Custom period
  const period = 9;
  const viCustom = vortex(highs, lows, closings, { period });
  if (viCustom.plus.length !== n || viCustom.minus.length !== n) {
    throw new Error('plus/minus length (custom period) must equal input length');
  }

  console.log('✅ Vortex Indicator tests passed');
  return 0;
}

module.exports = main;
main();
