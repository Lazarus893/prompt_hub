function main() {
  const { ad } = require('@alva/technical-indicators/accumulation-distribution-a-d:v1.0.0');

  // Test 1: Length and zero accumulation when MFM is zero each period
  const highs1 = [];
  const lows1 = [];
  const closings1 = [];
  const volumes1 = [];
  for (let i = 0; i < 100; i++) {
    // High - Low = 2, Close - Low = 1, High - Close = 1 => MFM = 0 => MFV = 0
    lows1.push(i);
    highs1.push(i + 2);
    closings1.push(i + 1);
    volumes1.push(100);
  }
  const adResult1 = ad(highs1, lows1, closings1, volumes1);
  if (!Array.isArray(adResult1)) {
    throw new Error('A/D result is not an array');
  }
  if (adResult1.length !== 100) {
    throw new Error('A/D length mismatch for Test 1');
  }
  for (let i = 0; i < adResult1.length; i++) {
    if (adResult1[i] !== 0) {
      throw new Error('A/D expected all zeros for Test 1');
    }
  }

  // Test 2: Strictly positive accumulation when Close == High (MFM = 1)
  const highs2 = [10, 11, 12, 13, 14];
  const lows2 = [8, 9, 10, 11, 12];
  const closings2 = [10, 11, 12, 13, 14]; // equal to highs
  const volumes2 = [10, 10, 10, 10, 10];
  const adResult2 = ad(highs2, lows2, closings2, volumes2);
  const expected2 = [10, 20, 30, 40, 50];
  if (adResult2.length !== expected2.length) {
    throw new Error('A/D length mismatch for Test 2');
  }
  for (let i = 0; i < expected2.length; i++) {
    if (adResult2[i] !== expected2[i]) {
      throw new Error(`A/D incorrect at index ${i} for Test 2: got ${adResult2[i]}, expected ${expected2[i]}`);
    }
  }

  // Test 3: Strictly negative accumulation when Close == Low (MFM = -1)
  const highs3 = [10, 11, 12, 13, 14];
  const lows3 = [8, 9, 10, 11, 12];
  const closings3 = [8, 9, 10, 11, 12]; // equal to lows
  const volumes3 = [10, 10, 10, 10, 10];
  const adResult3 = ad(highs3, lows3, closings3, volumes3);
  const expected3 = [-10, -20, -30, -40, -50];
  if (adResult3.length !== expected3.length) {
    throw new Error('A/D length mismatch for Test 3');
  }
  for (let i = 0; i < expected3.length; i++) {
    if (adResult3[i] !== expected3[i]) {
      throw new Error(`A/D incorrect at index ${i} for Test 3: got ${adResult3[i]}, expected ${expected3[i]}`);
    }
  }

  console.log('✅ Accumulation/Distribution (A/D) tests passed');
  return 0;
}

main();
