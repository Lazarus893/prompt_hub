function main() {
  const { psar } = require('@alva/technical-indicators/parabolic-sar:v1.0.0');

  // Build synthetic upward-trending OHLC data
  const N = 200;
  const highs = [];
  const lows = [];
  const closings = [];
  for (let i = 0; i < N; i++) {
    const c = i + 1; // closing price
    const h = c + 1; // high >= close
    const l = c - 1; // low <= close
    highs.push(h);
    lows.push(l);
    closings.push(c);
  }

  // Default configuration test
  const out1 = psar(highs, lows, closings);
  if (!out1 || typeof out1 !== 'object') {
    throw new Error('psar() must return an object');
  }
  const { trends, psarResult } = out1;
  if (!Array.isArray(trends) || trends.length !== N) {
    throw new Error('trends must be an array of length ' + N);
  }
  if (!Array.isArray(psarResult) || psarResult.length !== N) {
    throw new Error('psarResult must be an array of length ' + N);
  }
  if (!psarResult.every((v) => typeof v === 'number' && Number.isFinite(v))) {
    throw new Error('psarResult must contain only finite numbers');
  }

  // Custom configuration test
  const custom = { step: 0.01, max: 0.2 };
  const out2 = psar(highs, lows, closings, custom);
  if (!out2 || typeof out2 !== 'object') {
    throw new Error('psar(custom) must return an object');
  }
  const { trends: trends2, psarResult: psarResult2 } = out2;
  if (!Array.isArray(trends2) || trends2.length !== N) {
    throw new Error('custom trends must be an array of length ' + N);
  }
  if (!Array.isArray(psarResult2) || psarResult2.length !== N) {
    throw new Error('custom psarResult must be an array of length ' + N);
  }
  if (!psarResult2.every((v) => typeof v === 'number' && Number.isFinite(v))) {
    throw new Error('custom psarResult must contain only finite numbers');
  }

  // Downward-trending data sanity check
  const highsD = [];
  const lowsD = [];
  const closingsD = [];
  for (let i = 0; i < N; i++) {
    const c = N - i; // decreasing close
    highsD.push(c + 1);
    lowsD.push(c - 1);
    closingsD.push(c);
  }
  const out3 = psar(highsD, lowsD, closingsD);
  if (!out3 || typeof out3 !== 'object') {
    throw new Error('psar(downward) must return an object');
  }
  const { trends: trendsDown, psarResult: psarDown } = out3;
  if (!Array.isArray(trendsDown) || trendsDown.length !== N) {
    throw new Error('downward trends must be an array of length ' + N);
  }
  if (!Array.isArray(psarDown) || psarDown.length !== N) {
    throw new Error('downward psarResult must be an array of length ' + N);
  }
  if (!psarDown.every((v) => typeof v === 'number' && Number.isFinite(v))) {
    throw new Error('downward psarResult must contain only finite numbers');
  }

  console.log('✅ Parabolic SAR tests passed');
  return 0;
}

// Execute immediately in the jagent runner environment
main();
