function assert(condition, message) {
  if (!condition) {
    throw new Error(message || 'Assertion failed');
  }
}

function main() {
  const { dc } = require('@alva/technical-indicators/donchian-channel-dc:v1.0.0');

  // Test 1: Basic structure and lengths with default parameters
  const data = [];
  for (let i = 0; i < 100; i++) {
    data.push(i);
  }

  const result = dc(data);
  assert(result && typeof result === 'object', 'dc should return an object');
  assert(Array.isArray(result.upper), 'result.upper should be an array');
  assert(Array.isArray(result.middle), 'result.middle should be an array');
  assert(Array.isArray(result.lower), 'result.lower should be an array');
  assert(result.upper.length === 100, 'upper length is not 100');
  assert(result.middle.length === 100, 'middle length is not 100');
  assert(result.lower.length === 100, 'lower length is not 100');

  // Invariant checks when values are finite
  for (let i = 0; i < 100; i++) {
    const u = result.upper[i];
    const m = result.middle[i];
    const l = result.lower[i];
    if (Number.isFinite(u) && Number.isFinite(m) && Number.isFinite(l)) {
      assert(u >= l, `upper < lower at index ${i}`);
      const mid = (u + l) / 2;
      const eps = 1e-9;
      assert(Math.abs(m - mid) <= eps, `middle is not average of upper and lower at index ${i}`);
    }
  }

  // Test 2: Custom period
  const custom = dc(data, { period: 8 });
  assert(custom.upper.length === 100, 'custom upper length is not 100');
  assert(custom.middle.length === 100, 'custom middle length is not 100');
  assert(custom.lower.length === 100, 'custom lower length is not 100');

  for (let i = 0; i < 100; i++) {
    const u = custom.upper[i];
    const m = custom.middle[i];
    const l = custom.lower[i];
    if (Number.isFinite(u) && Number.isFinite(m) && Number.isFinite(l)) {
      assert(u >= l, `custom: upper < lower at index ${i}`);
      const mid = (u + l) / 2;
      const eps = 1e-9;
      assert(Math.abs(m - mid) <= eps, `custom: middle is not average at index ${i}`);
    }
  }

  // Test 3: Constant series should have equal bands (where defined)
  const constant = Array(50).fill(5);
  const cRes = dc(constant, { period: 5 });
  assert(cRes.upper.length === 50, 'constant upper length is not 50');
  assert(cRes.middle.length === 50, 'constant middle length is not 50');
  assert(cRes.lower.length === 50, 'constant lower length is not 50');
  for (let i = 0; i < 50; i++) {
    const u = cRes.upper[i];
    const m = cRes.middle[i];
    const l = cRes.lower[i];
    if (Number.isFinite(u) && Number.isFinite(m) && Number.isFinite(l)) {
      assert(u === 5 && l === 5 && m === 5, `constant series bands not equal 5 at index ${i}`);
    }
  }

  console.log('✅ Donchian Channel (DC) tests passed');
  return 0;
}

main();
