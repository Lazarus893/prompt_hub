function approxEqual(a, b, eps = 1e-9) {
  if (a == null || b == null) return false;
  return Math.abs(a - b) <= eps;
}

function expectedMidpointValue(t, window) {
  // Given highs[i] = i + 1 and lows[i] = i
  // Tenkan/Kijun/SSB raw = (max(highs last window) + min(lows last window)) / 2
  // = ((t + 1) + (t - window + 1)) / 2 = t - window/2 + 1
  return t - window / 2 + 1;
}

function verifyIchimoku(highs, lows, closings, params, label) {
  const { ichimokuCloud } = require('@alva/technical-indicators/ichimoku-cloud:v1.0.0');
  const res = ichimokuCloud(highs, lows, closings, params);

  const short = (params && params.short) || 9;
  const medium = (params && params.medium) || 26;
  const long = (params && params.long) || 52;
  const closeShift = (params && params.close) || 26;
  const N = highs.length;

  const { tenkan, kijun, ssa, ssb, laggingSpan } = res;
  if (!Array.isArray(tenkan) || !Array.isArray(kijun) || !Array.isArray(ssa) || !Array.isArray(ssb) || !Array.isArray(laggingSpan)) {
    throw new Error(`[${label}] Output should contain arrays tenkan, kijun, ssa, ssb, laggingSpan`);
  }

  // Expect forward-shifted spans to be extended by medium periods
  if (ssa.length !== N + medium) {
    throw new Error(`[${label}] ssa length expected ${N + medium}, got ${ssa.length}`);
  }
  if (ssb.length !== N + medium) {
    throw new Error(`[${label}] ssb length expected ${N + medium}, got ${ssb.length}`);
  }

  // Relationships validation on safe indices (away from warmup zones and respecting forward/backward shifts)
  const start = Math.max(long - 1, 5);
  const end = Math.min(N - medium - 1, N - 5);
  for (let t = start; t <= end; t += Math.max(5, Math.floor((end - start) / 5) || 1)) {
    // Tenkan and Kijun raw values at t
    const expTenkan = expectedMidpointValue(t, short);
    const expKijun = expectedMidpointValue(t, medium);
    const expSSBraw = expectedMidpointValue(t, long);
    const expSSAraw = (expTenkan + expKijun) / 2;

    const outIndex = t + medium; // forward shift

    // Tenkan/Kijun should align at index t (either exact or allow nulls before warmup)
    if (tenkan[t] != null && !approxEqual(tenkan[t], expTenkan)) {
      throw new Error(`[${label}] tenkan[${t}] expected ~${expTenkan}, got ${tenkan[t]}`);
    }
    if (kijun[t] != null && !approxEqual(kijun[t], expKijun)) {
      throw new Error(`[${label}] kijun[${t}] expected ~${expKijun}, got ${kijun[t]}`);
    }

    // SSA/SSB shifted forward by medium periods
    if (ssa[outIndex] != null && !approxEqual(ssa[outIndex], expSSAraw)) {
      throw new Error(`[${label}] ssa[${outIndex}] expected ~${expSSAraw}, got ${ssa[outIndex]}`);
    }
    if (ssb[outIndex] != null && !approxEqual(ssb[outIndex], expSSBraw)) {
      throw new Error(`[${label}] ssb[${outIndex}] expected ~${expSSBraw}, got ${ssb[outIndex]}`);
    }
  }

  // Chikou (laggingSpan) is closing shifted backward by `close` periods:
  // laggingSpan[j] should align with closings[j + closeShift] for valid range
  const maxJ = Math.min(laggingSpan.length - 1, N - closeShift - 1);
  for (let j = 0; j <= maxJ; j += Math.max(5, Math.floor(maxJ / 5) || 1)) {
    const expectedClose = closings[j + closeShift];
    if (laggingSpan[j] != null && !approxEqual(laggingSpan[j], expectedClose)) {
      throw new Error(`[${label}] laggingSpan[${j}] expected ~${expectedClose}, got ${laggingSpan[j]}`);
    }
  }
}

function main() {
  const highs = [];
  const lows = [];
  const closings = [];
  const N = 300;
  for (let i = 0; i < N; i++) {
    lows.push(i);
    highs.push(i + 1);
    closings.push(i + 0.5);
  }

  // Default params
  verifyIchimoku(highs, lows, closings, undefined, 'default');

  // Custom params
  verifyIchimoku(highs, lows, closings, { short: 14, medium: 30, long: 50, close: 10 }, 'custom');

  console.log('✅ Ichimoku Cloud tests passed');
  return 0;
}

main();
