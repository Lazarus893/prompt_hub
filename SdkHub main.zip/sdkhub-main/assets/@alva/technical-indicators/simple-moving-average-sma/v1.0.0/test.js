function main() {
  const { sma } = require('@alva/technical-indicators/simple-moving-average-sma:v1.0.0');

  // Generate a simple increasing dataset 0..99
  const data = Array.from({ length: 100 }, (_, i) => i);

  // Helper for approximate comparison
  const approxEqual = (a, b, eps = 1e-9) => Number.isFinite(a) && Number.isFinite(b) && Math.abs(a - b) <= eps;

  // Test 1: Default parameters (period=2)
  const resDefault = sma(data);
  if (!Array.isArray(resDefault)) {
    throw new Error('SMA should return an array');
  }
  if (resDefault.length !== data.length) {
    throw new Error('SMA result length should match input length');
  }
  // Last value must be the average of the last 2 values: (98 + 99) / 2 = 98.5
  if (!approxEqual(resDefault[resDefault.length - 1], (98 + 99) / 2)) {
    throw new Error('SMA default period last value is incorrect');
  }

  // Test 2: Custom period = 4
  const resP4 = sma(data, { period: 4 });
  if (resP4.length !== data.length) {
    throw new Error('SMA period=4 result length should match input length');
  }
  // Last value must be the average of the last 4 values: (96+97+98+99)/4 = 97.5
  if (!approxEqual(resP4[resP4.length - 1], (96 + 97 + 98 + 99) / 4)) {
    throw new Error('SMA period=4 last value is incorrect');
  }

  // Test 3: period = 1 should mirror the original series for the last element
  const resP1 = sma(data, { period: 1 });
  if (resP1.length !== data.length) {
    throw new Error('SMA period=1 result length should match input length');
  }
  if (!approxEqual(resP1[resP1.length - 1], data[data.length - 1])) {
    throw new Error('SMA period=1 last value should equal the last input value');
  }

  // Sanity check: for increasing series and period>=1, SMA should be non-decreasing
  if (!(resP4[50] <= resP4[70] && resP4[70] <= resP4[90])) {
    throw new Error('SMA period=4 should be non-decreasing on increasing data');
  }

  console.log('✅ Simple Moving Average (SMA) tests passed');
  return 0;
}

// Always invoke main to ensure the test actually runs when executed
main();

module.exports = main;
