function main() {
  const { kdj } = require('@alva/technical-indicators/random-index-kdj:v1.0.0');

  // Generate synthetic OHLC data
  const highs = [];
  const lows = [];
  const closings = [];
  for (let i = 0; i < 100; i++) {
    const low = i;
    const high = i + 2;
    const close = i + 1;
    lows.push(low);
    highs.push(high);
    closings.push(close);
  }

  const resultDefault = kdj(highs, lows, closings);
  if (!resultDefault || !Array.isArray(resultDefault.k) || !Array.isArray(resultDefault.d) || !Array.isArray(resultDefault.j)) {
    throw new Error('kdj should return an object with k, d, j arrays');
  }
  if (resultDefault.k.length !== highs.length) {
    throw new Error('k length mismatch');
  }
  if (resultDefault.d.length !== highs.length) {
    throw new Error('d length mismatch');
  }
  if (resultDefault.j.length !== highs.length) {
    throw new Error('j length mismatch');
  }

  const anyNonNumber = (arr) => arr.some(v => typeof v !== 'number' || Number.isNaN(v));
  if (anyNonNumber(resultDefault.k) || anyNonNumber(resultDefault.d) || anyNonNumber(resultDefault.j)) {
    throw new Error('K/D/J contain non-number values');
  }

  // Test with custom parameters
  const customConfig = { rPeriod: 8, kPeriod: 4, dPeriod: 6 };
  const resultCustom = kdj(highs, lows, closings, customConfig);
  if (resultCustom.k.length !== highs.length || resultCustom.d.length !== highs.length || resultCustom.j.length !== highs.length) {
    throw new Error('Custom config lengths mismatch');
  }

  // Ensure custom config changes at least one output series
  const differs = (a, b) => a.some((v, idx) => v !== b[idx]);
  if (!differs(resultDefault.k, resultCustom.k) && !differs(resultDefault.d, resultCustom.d) && !differs(resultDefault.j, resultCustom.j)) {
    throw new Error('Custom config did not change output');
  }

  console.log('✅ Random Index (KDJ) tests passed');
  return 0;
}

main();
