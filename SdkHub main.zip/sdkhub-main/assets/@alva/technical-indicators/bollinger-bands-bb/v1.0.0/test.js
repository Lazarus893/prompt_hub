function main() {
  const { bb } = require('@alva/technical-indicators/bollinger-bands-bb:v1.0.0');

  // Test 1: Basic usage with increasing data
  const data = Array.from({ length: 100 }, (_, i) => i + 1);
  const result = bb(data);

  if (!result || !Array.isArray(result.upper) || !Array.isArray(result.middle) || !Array.isArray(result.lower)) {
    throw new Error('bb should return an object with upper, middle, lower arrays');
  }
  if (result.upper.length !== data.length) throw new Error('upper length mismatch');
  if (result.middle.length !== data.length) throw new Error('middle length mismatch');
  if (result.lower.length !== data.length) throw new Error('lower length mismatch');

  for (let i = 0; i < data.length; i++) {
    const u = result.upper[i];
    const m = result.middle[i];
    const l = result.lower[i];
    // Skip undefined or NaN values in the warmup period
    if (u == null || m == null || l == null) continue;
    if (Number.isNaN(u) || Number.isNaN(m) || Number.isNaN(l)) continue;
    if (!(u >= m && m >= l)) {
      throw new Error(`Bands order invalid at index ${i}: upper=${u}, middle=${m}, lower=${l}`);
    }
  }

  // Test 2: Constant dataset should yield upper == middle == lower after warmup
  const constant = Array.from({ length: 60 }, () => 42);
  const period = 14;
  const resConst = bb(constant, { period });
  for (let i = 0; i < constant.length; i++) {
    const u = resConst.upper[i];
    const m = resConst.middle[i];
    const l = resConst.lower[i];
    if (u == null || m == null || l == null) continue; // warmup
    if (u !== m || m !== l) {
      throw new Error(`Constant data should have equal bands at index ${i}: upper=${u}, middle=${m}, lower=${l}`);
    }
  }

  console.log('✅ Bollinger Bands (BB) tests passed');
  return 0;
}

// Always invoke main() to ensure the test runs even if the runner requires this file instead of executing it directly.
module.exports = main;
main();
