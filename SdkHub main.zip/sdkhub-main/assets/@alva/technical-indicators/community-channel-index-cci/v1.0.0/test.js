function main() {
  const { cci } = require('@alva/technical-indicators/community-channel-index-cci:v1.0.0');

  const highs = [];
  const lows = [];
  const closings = [];
  for (let i = 0; i < 100; i++) {
    closings.push(i);
    highs.push(i + 1);
    lows.push(i - 1);
  }

  const cciDefault = cci(highs, lows, closings);
  if (!Array.isArray(cciDefault)) {
    throw new Error('CCI result should be an array');
  }
  if (cciDefault.length !== 100) {
    throw new Error('CCI default length is not 100');
  }

  const cciCustom = cci(highs, lows, closings, { period: 50 });
  if (cciCustom.length !== 100) {
    throw new Error('CCI custom length is not 100');
  }

  console.log('✅ Community Channel Index (CCI) tests passed');
  return 0;
}

main();
