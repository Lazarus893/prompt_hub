function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

function isFiniteNumber(n) {
  return typeof n === 'number' && Number.isFinite(n);
}

function numbersBetween(arr, min, max) {
  return arr.every((v) => isFiniteNumber(v) && v >= min && v <= max);
}

function main() {
  const { mfi } = require('@alva/technical-indicators/money-flow-index-mfi:v1.0.0');

  // Generate synthetic OHLCV data
  const len = 120;
  const highs = [];
  const lows = [];
  const closings = [];
  const volumes = [];
  let price = 100;
  for (let i = 0; i < len; i++) {
    // Simulate some random walk for price and volume
    const change = Math.sin(i / 7) * 0.5 + (i % 5 === 0 ? 1 : -0.3);
    price = Math.max(1, price + change);
    const high = price + Math.random() * 2 + 0.5;
    const low = Math.max(0.1, price - (Math.random() * 2 + 0.5));
    const close = Math.min(high, Math.max(low, price + (Math.random() - 0.5)));
    const volume = 1000 + Math.floor(Math.random() * 500);

    highs.push(high);
    lows.push(low);
    closings.push(close);
    volumes.push(volume);
  }

  // Default MFI
  const mfiDefault = mfi(highs, lows, closings, volumes);
  assert(Array.isArray(mfiDefault), 'mfi should return an array');
  assert(mfiDefault.length === len, 'mfi length should equal input length');
  assert(numbersBetween(mfiDefault, 0, 100), 'all MFI values must be between 0 and 100');

  // Custom period should still return same length and values within range
  const period = 10;
  const customCfg = { period };
  const mfiCustom = mfi(highs, lows, closings, volumes, customCfg);
  assert(mfiCustom.length === len, 'custom period mfi length mismatch');
  assert(numbersBetween(mfiCustom, 0, 100), 'custom MFI values must be between 0 and 100');

  // Changing period should generally change values (not necessarily all positions)
  const diffCount = mfiCustom.filter((v, i) => v !== mfiDefault[i]).length;
  assert(diffCount > 0, 'custom period should affect MFI values');

  // Edge case: very short arrays
  const shortHighs = [2, 3, 4];
  const shortLows = [1, 2, 3];
  const shortCloses = [1.5, 2.5, 3.5];
  const shortVolumes = [100, 200, 300];
  const short = mfi(shortHighs, shortLows, shortCloses, shortVolumes, { period: 2 });
  assert(short.length === 3, 'short input length should be preserved');
  assert(numbersBetween(short, 0, 100), 'short input MFI should be within range');

  console.log('✅ Money Flow Index (MFI) tests passed');
  return 0;
}

module.exports = { main };

main();
