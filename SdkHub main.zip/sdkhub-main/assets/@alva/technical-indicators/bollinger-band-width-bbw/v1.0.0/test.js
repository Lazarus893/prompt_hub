function main() {
  const { bbw } = require('@alva/technical-indicators/bollinger-band-width-bbw:v1.0.0');
  const { bb } = require('@alva/technical-indicators/bollinger-bands-bb:v1.0.0');

  // Build a simple linearly increasing dataset
  const closings = Array.from({ length: 200 }, (_, i) => i + 1);

  // First compute Bollinger Bands as input to BBW
  const bbResult = bb(closings, { period: 20 });

  // Default BBW
  const resultDefault = bbw(bbResult);
  if (!resultDefault || !Array.isArray(resultDefault.width)) {
    throw new Error('BBW default: width should be an array');
  }
  if (resultDefault.width.length !== closings.length) {
    throw new Error('BBW default: width length mismatch');
  }

  // Custom params
  const resultCustom = bbw(bbResult, { period: 50, emaPeriod: 10 });
  if (!resultCustom || !Array.isArray(resultCustom.widthEma)) {
    throw new Error('BBW custom: widthEma should be an array');
  }
  if (resultCustom.widthEma.length !== closings.length) {
    throw new Error('BBW custom: widthEma length mismatch');
  }

  // Basic sanity: width values should be non-negative
  const hasNegative = resultDefault.width.some((v) => typeof v === 'number' && v < 0);
  if (hasNegative) {
    throw new Error('BBW default: width should not contain negative values');
  }

  console.log('✅ Bollinger Band Width (BBW) tests passed');
  return 0;
}

module.exports = { main };

// Ensure the test actually runs when executed directly
if (require.main === module) {
  main();
}
