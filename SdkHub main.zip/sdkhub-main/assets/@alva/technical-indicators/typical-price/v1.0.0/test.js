function main() {
  const { typicalPrice } = require('@alva/technical-indicators/typical-price:v1.0.0');

  // Test 1: Basic functionality with 100 points
  const highs = [];
  const lows = [];
  const closings = [];
  for (let i = 0; i < 100; i++) {
    lows.push(i);        // L = i
    closings.push(i + 1); // C = i + 1
    highs.push(i + 2);    // H = i + 2
  }
  const tp = typicalPrice(highs, lows, closings);
  if (!Array.isArray(tp)) {
    throw new Error('typicalPrice should return an array');
  }
  if (tp.length !== 100) {
    throw new Error('typicalPrice length is not 100');
  }
  // Expected: ((H + L + C) / 3) = ((i+2) + i + (i+1)) / 3 = (3i + 3)/3 = i + 1
  for (let i = 0; i < 100; i++) {
    const expected = i + 1;
    if (Math.abs(tp[i] - expected) > 1e-12) {
      throw new Error(`typicalPrice value mismatch at index ${i}: expected ${expected}, got ${tp[i]}`);
    }
  }

  // Test 2: Empty input arrays
  const empty = typicalPrice([], [], []);
  if (!Array.isArray(empty) || empty.length !== 0) {
    throw new Error('typicalPrice should return an empty array for empty inputs');
  }

  // Test 3: Known small sample
  const h2 = [10, 13, 16];
  const l2 = [7, 10, 13];
  const c2 = [8, 12, 14];
  // Expected: [(10+7+8)/3, (13+10+12)/3, (16+13+14)/3] => [25/3, 35/3, 43/3]
  const expected2 = [25 / 3, 35 / 3, 43 / 3];
  const tp2 = typicalPrice(h2, l2, c2);
  if (tp2.length !== expected2.length) {
    throw new Error('typicalPrice small sample length mismatch');
  }
  for (let i = 0; i < expected2.length; i++) {
    if (Math.abs(tp2[i] - expected2[i]) > 1e-12) {
      throw new Error(`typicalPrice small sample mismatch at index ${i}: expected ${expected2[i]}, got ${tp2[i]}`);
    }
  }

  console.log('✅ Typical Price tests passed');
  return 0;
}

main();
