function main() {
  const { trima } = require('@alva/technical-indicators/triangular-moving-average-trima:v1.0.0');

  // Test 1: Constant series should yield the same constant (for all non-null outputs)
  const constant = Array(100).fill(5);
  const resultDefault = trima(constant);
  if (!Array.isArray(resultDefault)) {
    throw new Error('TRIMA did not return an array for default parameters');
  }
  if (resultDefault.length !== constant.length) {
    throw new Error('TRIMA result length mismatch for default parameters');
  }
  const nonNullDefault = resultDefault.filter(v => v !== null && v !== undefined);
  if (nonNullDefault.length === 0) {
    throw new Error('TRIMA produced no non-null values for default parameters');
  }
  if (!nonNullDefault.every(v => Math.abs(v - 5) < 1e-9)) {
    throw new Error('TRIMA non-null values should equal the constant input (default parameters)');
  }

  // Test 2: Custom period with constant input
  const constant10 = Array(50).fill(10);
  const resultP9 = trima(constant10, { period: 9 });
  if (!Array.isArray(resultP9)) {
    throw new Error('TRIMA did not return an array for period 9');
  }
  if (resultP9.length !== constant10.length) {
    throw new Error('TRIMA result length mismatch for period 9');
  }
  const nonNullP9 = resultP9.filter(v => v !== null && v !== undefined);
  if (nonNullP9.length === 0) {
    throw new Error('TRIMA produced no non-null values for period 9');
  }
  if (!nonNullP9.every(v => Math.abs(v - 10) < 1e-9)) {
    throw new Error('TRIMA non-null values should equal the constant input (period 9)');
  }

  // Test 3: Monotonicity on increasing sequence (non-null outputs should be non-decreasing)
  const increasing = Array.from({ length: 30 }, (_, i) => i);
  const resultInc = trima(increasing, { period: 4 });
  if (resultInc.length !== increasing.length) {
    throw new Error('TRIMA result length mismatch on increasing input');
  }
  for (let i = 1; i < resultInc.length; i++) {
    if (resultInc[i] != null && resultInc[i - 1] != null && resultInc[i] < resultInc[i - 1]) {
      throw new Error('TRIMA should be non-decreasing for an increasing input sequence');
    }
  }

  console.log('✅ Triangular Moving Average (TRIMA) tests passed');
  return 0;
}

if (require.main === module) {
  main();
} else {
  module.exports = main;
}
