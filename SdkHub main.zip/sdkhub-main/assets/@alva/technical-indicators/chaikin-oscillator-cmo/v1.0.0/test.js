function main() {
  const { cmo } = require('@alva/technical-indicators/chaikin-oscillator-cmo:v1.0.0');

  // Generate synthetic OHLCV data
  const len = 200;
  const highs = [];
  const lows = [];
  const closes = [];
  const volumes = [];
  let price = 100;
  for (let i = 0; i < len; i++) {
    // simple deterministic walk for prices
    const delta = Math.sin(i / 10) + (i % 5 === 0 ? 2 : -1);
    price = Math.max(1, price + delta);
    const high = price + 1 + (i % 3);
    const low = Math.max(0.1, price - 1 - (i % 2));
    const close = price + (i % 2 === 0 ? 0.3 : -0.2);
    const volume = 1000 + (i * 7) % 300;
    highs.push(high);
    lows.push(low);
    closes.push(close);
    volumes.push(volume);
  }

  // Default config
  const resDefault = cmo(highs, lows, closes, volumes);
  if (!resDefault || !Array.isArray(resDefault.adResult) || !Array.isArray(resDefault.cmoResult)) {
    throw new Error('CMO did not return expected structure');
  }
  if (resDefault.adResult.length !== len) {
    throw new Error(`adResult length mismatch: ${resDefault.adResult.length} !== ${len}`);
  }
  if (resDefault.cmoResult.length !== len) {
    throw new Error(`cmoResult length mismatch: ${resDefault.cmoResult.length} !== ${len}`);
  }

  // Basic sanity: values should be finite numbers or nulls at initial periods depending on implementation
  const hasFiniteCMO = resDefault.cmoResult.some(v => typeof v === 'number' && Number.isFinite(v));
  if (!hasFiniteCMO) {
    throw new Error('cmoResult has no finite numbers');
  }

  // Custom config
  const cfg = { fast: 2, slow: 5 };
  const resCustom = cmo(highs, lows, closes, volumes, cfg);
  if (resCustom.cmoResult.length !== len) {
    throw new Error('Custom cmoResult length mismatch');
  }

  // Ensure custom config changes result in some difference compared to default
  const diffCount = resCustom.cmoResult.reduce((acc, v, i) => acc + (v !== resDefault.cmoResult[i] ? 1 : 0), 0);
  if (diffCount < Math.floor(len * 0.2)) {
    throw new Error('Custom parameters did not meaningfully change the CMO output');
  }

  console.log('✅ Chaikin Oscillator (CMO) tests passed');
  return 0;
}

module.exports = { main };

// Ensure the test actually runs
main();
