function main() {
  const { po } = require('@alva/technical-indicators/projection-oscillator-po:v1.0.0');

  const N = 200;
  const highs = [];
  const lows = [];
  const closings = [];
  for (let i = 0; i < N; i++) {
    const base = 100 + Math.sin(i / 10) * 5 + i * 0.05;
    const close = base;
    const high = close + 0.5 + (i % 5) * 0.1;
    const low = close - 0.5 - (i % 5) * 0.1;
    highs.push(high);
    lows.push(low);
    closings.push(close);
  }

  // Default parameters
  const resultDefault = po(highs, lows, closings);
  if (!resultDefault || !Array.isArray(resultDefault.poResult) || !Array.isArray(resultDefault.spoResult)) {
    throw new Error('PO did not return expected structure { poResult, spoResult }');
  }
  if (resultDefault.poResult.length !== N) {
    throw new Error(`poResult length is not ${N}`);
  }
  if (resultDefault.spoResult.length !== N) {
    throw new Error(`spoResult length is not ${N}`);
  }
  const hasNumberDefault = resultDefault.poResult.some(v => typeof v === 'number') && resultDefault.spoResult.some(v => typeof v === 'number');
  if (!hasNumberDefault) {
    throw new Error('Expected numeric values in PO outputs for default parameters');
  }

  // Custom parameters
  const resultCustom = po(highs, lows, closings, { period: 9, smooth: 2 });
  if (!resultCustom || !Array.isArray(resultCustom.poResult) || !Array.isArray(resultCustom.spoResult)) {
    throw new Error('PO (custom) did not return expected structure { poResult, spoResult }');
  }
  if (resultCustom.poResult.length !== N) {
    throw new Error(`poResult (custom) length is not ${N}`);
  }
  if (resultCustom.spoResult.length !== N) {
    throw new Error(`spoResult (custom) length is not ${N}`);
  }
  const hasNumberCustom = resultCustom.poResult.some(v => typeof v === 'number') && resultCustom.spoResult.some(v => typeof v === 'number');
  if (!hasNumberCustom) {
    throw new Error('Expected numeric values in PO outputs for custom parameters');
  }

  console.log('✅ Projection Oscillator (PO) tests passed');
  return 0;
}

// Always run main to ensure the test actually executes under the jagent runner
main();

module.exports = { main };

