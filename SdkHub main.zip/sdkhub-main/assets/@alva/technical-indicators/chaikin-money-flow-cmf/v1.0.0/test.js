function main() {
  const { cmf } = require('@alva/technical-indicators/chaikin-money-flow-cmf:v1.0.0');

  // Synthetic dataset with reasonable OHLC and volume values
  const highs = [];
  const lows = [];
  const closings = [];
  const volumes = [];
  for (let i = 0; i < 100; i++) {
    const low = i;
    const high = i + 3; // ensure high > low
    const close = low + (high - low) * 0.6; // close within [low, high]
    const vol = 1000 + (i % 10) * 50; // varying volume
    lows.push(low);
    highs.push(high);
    closings.push(close);
    volumes.push(vol);
  }

  // Default configuration
  const cmfDefault = cmf(highs, lows, closings, volumes);
  if (!Array.isArray(cmfDefault) || cmfDefault.length !== 100) {
    throw new Error('CMF length with default config is not 100');
  }
  for (let i = 0; i < cmfDefault.length; i++) {
    const v = cmfDefault[i];
    if (typeof v !== 'number' || !Number.isFinite(v)) {
      throw new Error('CMF contains non-finite value at index ' + i);
    }
    if (v < -1 - 1e-9 || v > 1 + 1e-9) {
      throw new Error('CMF value out of expected range [-1, 1] at index ' + i + ': ' + v);
    }
  }

  // Custom configuration (period)
  const cmfCustom = cmf(highs, lows, closings, volumes, { period: 14 });
  if (!Array.isArray(cmfCustom) || cmfCustom.length !== 100) {
    throw new Error('CMF length with custom config is not 100');
  }

  // Deterministic bullish dataset: close == high -> CMF should be 1 across the series
  const highs2 = [];
  const lows2 = [];
  const closings2 = [];
  const volumes2 = [];
  for (let i = 0; i < 60; i++) {
    const low = 10 + i;
    const high = low + 5; // ensure high > low
    const close = high; // maximum bullish pressure
    const vol = 100 + i;
    lows2.push(low);
    highs2.push(high);
    closings2.push(close);
    volumes2.push(vol);
  }
  const cmfBull = cmf(highs2, lows2, closings2, volumes2, { period: 20 });
  if (!Array.isArray(cmfBull) || cmfBull.length !== 60) {
    throw new Error('CMF length on bullish dataset is not 60');
  }
  for (let i = 0; i < cmfBull.length; i++) {
    const v = cmfBull[i];
    if (Math.abs(v - 1) > 1e-6) {
      throw new Error('CMF should be ~1 when close == high at index ' + i + ': ' + v);
    }
  }

  console.log('✅ Chaikin Money Flow (CMF) tests passed');
  return 0;
}

main();

module.exports = main;
