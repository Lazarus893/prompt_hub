const { sdkRelay } = require('sdkrelay');
const { useCredit } = require('internal');
const { userId } = require('env');

function llmGenerate(params) {
	useCredit('llmGenerate', 20000);
	return sdkRelay('LLMGenerate', params);
}

function llmAsk(params) {
	useCredit('llmAsk', 20000);
	return sdkRelay('LLMAsk', { ...params, user_id: userId });
}

module.exports = {
	llmGenerate,
	llmAsk,
};
