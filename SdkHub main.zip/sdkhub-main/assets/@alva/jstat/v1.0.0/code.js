// Return jstat module from algorithm sdk

const { jStat } = require('@alva/algorithm:v1.0.0');
module.exports = { jStat };
