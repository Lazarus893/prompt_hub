function main() {
	const { jStat } = require('@alva/jstat');
	const data = [1, 2, 3, 4, 5];
	const mean = jStat.mean(data);
	console.log('Mean:', mean);
	console.log('✅ jStat tests passed');
	return 0;
}

main();
