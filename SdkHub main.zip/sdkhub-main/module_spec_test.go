package sdkhub

import (
	"testing"

	"github.com/stretchr/testify/suite"
)

type ModuleSpecTestSuite struct {
	suite.Suite
}

func TestModuleSpecTestSuite(t *testing.T) {
	suite.Run(t, new(ModuleSpecTestSuite))
}

func (suite *ModuleSpecTestSuite) TestParseModuleSpec() {
	for _, tc := range []struct {
		name        string
		module      string
		expected    *ModuleSpec
		expectError bool
	}{
		{
			name:   "system module",
			module: "net/http",
			expected: &ModuleSpec{
				ModuleName: "net/http",
				Version:    "1.0.0",
				IsSystem:   true,
			},
			expectError: false,
		},
		{
			name:   "simple system module",
			module: "store",
			expected: &ModuleSpec{
				ModuleName: "store",
				Version:    "1.0.0",
				IsSystem:   true,
			},
			expectError: false,
		},
		{
			name:   "alva direct module",
			module: "@alva/llm",
			expected: &ModuleSpec{
				Org:        "alva",
				Namespaces: []string{},
				ModuleName: "llm",
				Version:    "1.0.0",
				IsSystem:   false,
			},
			expectError: false,
		},
		{
			name:   "alva module with version",
			module: "@alva/algorithm:2.1.0",
			expected: &ModuleSpec{
				Org:        "alva",
				Namespaces: []string{},
				ModuleName: "algorithm",
				Version:    "2.1.0",
				IsSystem:   false,
			},
			expectError: false,
		},
		{
			name:   "alva data module",
			module: "@alva/data/crypto/meme",
			expected: &ModuleSpec{
				Org:        "alva",
				Namespaces: []string{"data", "crypto"},
				ModuleName: "meme",
				Version:    "1.0.0",
				IsSystem:   false,
			},
			expectError: false,
		},
		{
			name:   "alva data module with version",
			module: "@alva/data/crypto/meme:1.2.3",
			expected: &ModuleSpec{
				Org:        "alva",
				Namespaces: []string{"data", "crypto"},
				ModuleName: "meme",
				Version:    "1.2.3",
				IsSystem:   false,
			},
			expectError: false,
		},
		{
			name:        "invalid version format",
			module:      "@alva/llm:1.0",
			expectError: true,
		},
		{
			name:        "invalid org name",
			module:      "@123alva/llm",
			expectError: true,
		},
		{
			name:        "invalid module name",
			module:      "@alva/123test",
			expectError: true,
		},
		{
			name:        "too many colons",
			module:      "@alva/llm:1.0.0:extra",
			expectError: true,
		},
		{
			name:        "missing module name",
			module:      "@alva/",
			expectError: true,
		},
	} {
		suite.Run(tc.name, func() {
			result, err := ParseModuleSpec(tc.module)

			if tc.expectError {
				suite.Error(err)
				return
			}

			suite.NoError(err)
			suite.NotNil(result)

			suite.Equal(tc.expected.Org, result.Org)
			suite.Equal(tc.expected.ModuleName, result.ModuleName)
			suite.Equal(tc.expected.Version, result.Version)
			suite.Equal(tc.expected.IsSystem, result.IsSystem)
			suite.Equal(tc.expected.Namespaces, result.Namespaces)
		})
	}
}

func (suite *ModuleSpecTestSuite) TestModuleSpecStructure() {
	spec := &ModuleSpec{
		Org:        "alva",
		Namespaces: []string{"data", "crypto"},
		ModuleName: "meme",
		Version:    "1.0.0",
		IsSystem:   false,
	}

	suite.Equal("alva", spec.Org)
	suite.Equal([]string{"data", "crypto"}, spec.Namespaces)
	suite.Equal("meme", spec.ModuleName)
	suite.Equal("1.0.0", spec.Version)
	suite.False(spec.IsSystem)
}

func (suite *ModuleSpecTestSuite) TestModuleSpecFullName() {
	for _, tc := range []struct {
		name     string
		spec     *ModuleSpec
		expected string
	}{
		{
			name: "system module",
			spec: &ModuleSpec{
				ModuleName: "net/http",
				IsSystem:   true,
			},
			expected: "net/http",
		},
		{
			name: "system module simple",
			spec: &ModuleSpec{
				ModuleName: "store",
				IsSystem:   true,
			},
			expected: "store",
		},
		{
			name: "alva module without namespaces",
			spec: &ModuleSpec{
				Org:        "alva",
				Namespaces: []string{},
				ModuleName: "llm",
				Version:    "1.0.0",
				IsSystem:   false,
			},
			expected: "@alva/llm",
		},
		{
			name: "alva module with single namespace",
			spec: &ModuleSpec{
				Org:        "alva",
				Namespaces: []string{"data"},
				ModuleName: "crypto",
				Version:    "1.0.0",
				IsSystem:   false,
			},
			expected: "@alva/data/crypto",
		},
		{
			name: "alva module with multiple namespaces",
			spec: &ModuleSpec{
				Org:        "alva",
				Namespaces: []string{"data", "crypto"},
				ModuleName: "meme",
				Version:    "1.0.0",
				IsSystem:   false,
			},
			expected: "@alva/data/crypto/meme",
		},
		{
			name: "alva module with deep nesting",
			spec: &ModuleSpec{
				Org:        "alva",
				Namespaces: []string{"data", "crypto", "defi", "pools"},
				ModuleName: "uniswap",
				Version:    "2.1.0",
				IsSystem:   false,
			},
			expected: "@alva/data/crypto/defi/pools/uniswap",
		},
		{
			name: "third party module",
			spec: &ModuleSpec{
				Org:        "space-id",
				Namespaces: []string{"data"},
				ModuleName: "domains",
				Version:    "1.0.0",
				IsSystem:   false,
			},
			expected: "@space-id/data/domains",
		},
		{
			name: "third party module without namespaces",
			spec: &ModuleSpec{
				Org:        "ethereum",
				Namespaces: []string{},
				ModuleName: "web3",
				Version:    "1.0.0",
				IsSystem:   false,
			},
			expected: "@ethereum/web3",
		},
	} {
		suite.Run(tc.name, func() {
			result := tc.spec.FullName()
			suite.Equal(tc.expected, result)
		})
	}
}

func (suite *ModuleSpecTestSuite) TestModuleSpecFullNameWithVersion() {
	for _, tc := range []struct {
		name     string
		spec     *ModuleSpec
		expected string
	}{
		{
			name: "system module",
			spec: &ModuleSpec{
				ModuleName: "net/http",
				Version:    "1.0.0",
				IsSystem:   true,
			},
			expected: "net/http:v1.0.0",
		},
		{
			name: "system module simple",
			spec: &ModuleSpec{
				ModuleName: "store",
				Version:    "1.0.0",
				IsSystem:   true,
			},
			expected: "store:v1.0.0",
		},
		{
			name: "alva module without namespaces",
			spec: &ModuleSpec{
				Org:        "alva",
				Namespaces: []string{},
				ModuleName: "llm",
				Version:    "1.0.0",
				IsSystem:   false,
			},
			expected: "@alva/llm:v1.0.0",
		},
		{
			name: "alva module with single namespace",
			spec: &ModuleSpec{
				Org:        "alva",
				Namespaces: []string{"data"},
				ModuleName: "crypto",
				Version:    "1.0.0",
				IsSystem:   false,
			},
			expected: "@alva/data/crypto:v1.0.0",
		},
		{
			name: "alva module with multiple namespaces",
			spec: &ModuleSpec{
				Org:        "alva",
				Namespaces: []string{"data", "crypto"},
				ModuleName: "meme",
				Version:    "1.0.0",
				IsSystem:   false,
			},
			expected: "@alva/data/crypto/meme:v1.0.0",
		},
		{
			name: "alva module with deep nesting",
			spec: &ModuleSpec{
				Org:        "alva",
				Namespaces: []string{"data", "crypto", "defi", "pools"},
				ModuleName: "uniswap",
				Version:    "2.1.0",
				IsSystem:   false,
			},
			expected: "@alva/data/crypto/defi/pools/uniswap:v2.1.0",
		},
		{
			name: "third party module",
			spec: &ModuleSpec{
				Org:        "space-id",
				Namespaces: []string{"data"},
				ModuleName: "domains",
				Version:    "1.0.0",
				IsSystem:   false,
			},
			expected: "@space-id/data/domains:v1.0.0",
		},
		{
			name: "third party module without namespaces",
			spec: &ModuleSpec{
				Org:        "ethereum",
				Namespaces: []string{},
				ModuleName: "web3",
				Version:    "1.0.0",
				IsSystem:   false,
			},
			expected: "@ethereum/web3:v1.0.0",
		},
	} {
		suite.Run(tc.name, func() {
			result := tc.spec.FullNameWithVersion()
			suite.Equal(tc.expected, result)
		})
	}
}
