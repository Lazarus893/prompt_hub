package sdkhub

import (
	"fmt"
	"path"
	"regexp"
	"strings"
)

// Precompiled regex patterns for better performance
var (
	versionRegex = regexp.MustCompile(`^\d+\.\d+\.\d+$`)
	nameRegex    = regexp.MustCompile(`^[a-z][a-z0-9-]*$`)
)

const (
	DefaultVersion = "1.0.0"
)

// ModuleSpec represents a parsed module specification
type ModuleSpec struct {
	Org        string   // e.g., "alva" (without @)
	Namespaces []string // e.g., ["data", "crypto"]
	ModuleName string   // e.g., "meme"
	Version    string   // e.g., "1.0.0"
	IsSystem   bool     // true for system modules like "net/http"
}

// FullName constructs the full module name without version for version-ignored module lookup
func (spec *ModuleSpec) FullName() string {
	if spec.IsSystem {
		return spec.ModuleName
	}

	return path.Join("@"+spec.Org, strings.Join(spec.Namespaces, "/"), spec.ModuleName)
}

// FullNameWithVersion constructs the versioned full module name, e.g. "@alva/data/crypto/meme:v1.0.0"
// NOTE: semver's v-prefix is included in the version.
func (spec *ModuleSpec) FullNameWithVersion() string {
	return fmt.Sprintf("%s:v%s", spec.FullName(), spec.Version)
}

// ParseModuleSpec parses a module string according to the new module format:
// @org/[namespace]*/module_name:version
// Examples:
// - @alva/data/crypto/meme:1.0.0
// - @alva/data/crypto/meme:v1.0.0
// - @alva/llm:1.0.0
// - net/http (system module)
// - store (system module)
func ParseModuleSpec(module string) (*ModuleSpec, error) {
	// System modules don't have @ prefix
	// Currently we don't have any system modules that is > 1.0.0, so we just use 1.0.0 and skip version validation.
	if !strings.HasPrefix(module, "@") {
		return &ModuleSpec{
			ModuleName: module,
			Version:    DefaultVersion,
			IsSystem:   true,
		}, nil
	}

	// Split by : to separate version
	parts := strings.Split(module, ":")
	var moduleWithoutVersion string
	var version string

	if len(parts) == 1 {
		moduleWithoutVersion = parts[0]
		version = DefaultVersion
	} else if len(parts) == 2 {
		moduleWithoutVersion = parts[0]
		version = strings.TrimPrefix(parts[1], "v") // remove v prefix for robustness
		// Validate version format (basic semver: x.y.z)
		if !versionRegex.MatchString(version) {
			return nil, fmt.Errorf("invalid version format: %s, expected semver format like 1.0.0", version)
		}
	} else {
		return nil, fmt.Errorf("invalid module format: %s, too many ':' separators", module)
	}

	// Remove @ prefix and split by /
	moduleWithoutVersion = strings.TrimPrefix(moduleWithoutVersion, "@")
	segments := strings.Split(moduleWithoutVersion, "/")

	if len(segments) < 2 {
		return nil, fmt.Errorf(
			"invalid module format: %s, expected @org/[namespace]*/module_name",
			module,
		)
	}

	org := segments[0]
	moduleName := segments[len(segments)-1]
	namespaces := segments[1 : len(segments)-1]

	// Validate org name (must start with letter, contain only lowercase letters, numbers, and -)
	if !nameRegex.MatchString(org) {
		return nil, fmt.Errorf(
			"invalid org name: %s, must start with letter and contain only lowercase letters, numbers, and - ",
			org,
		)
	}

	// Validate module name (same rules as org)
	if !nameRegex.MatchString(moduleName) {
		return nil, fmt.Errorf(
			"invalid module name: %s, must start with letter and contain only lowercase letters, numbers, and - ",
			moduleName,
		)
	}

	// Validate namespace/category names
	for _, ns := range namespaces {
		if !nameRegex.MatchString(ns) {
			return nil, fmt.Errorf(
				"invalid namespace: %s, must start with letter and contain only lowercase letters, numbers, and - ",
				ns,
			)
		}
	}

	return &ModuleSpec{
		Org:        org,
		Namespaces: namespaces,
		ModuleName: moduleName,
		Version:    version,
		IsSystem:   false,
	}, nil
}
