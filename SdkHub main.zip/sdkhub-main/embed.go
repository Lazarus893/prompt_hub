package sdkhub

import "embed"

// sdkFS embeds all SDK files so we can ship them inside the binary.
// When a directory is named, all files in that tree are embedded.
//
//go:embed assets/@alva assets/@arrays
var sdkFS embed.FS
