package sdkhub

import (
	"os"
	"path/filepath"
	"testing"
)

func TestCheckNodifiedCoverage_NoMissing(t *testing.T) {
	dir := t.TempDir()
	moduleDir := filepath.Join(dir, "@alva", "data", "sample", "v1.0.0")
	if err := os.MkdirAll(moduleDir, 0o755); err != nil {
		t.Fatalf("creating module directory: %v", err)
	}

	code := `function getFoo() {}
function makeFooNode() {}
module.exports = {
  getFoo,
  makeFooNode,
};`

	if err := os.WriteFile(filepath.Join(moduleDir, "code.js"), []byte(code), 0o644); err != nil {
		t.Fatalf("writing code.js: %v", err)
	}

	missing, err := CheckNodifiedCoverage(dir)
	if err != nil {
		t.Fatalf("check returned error: %v", err)
	}
	if len(missing) != 0 {
		t.Fatalf("expected no missing entries, got %d", len(missing))
	}
}

func TestCheckNodifiedCoverage_ReportsMissing(t *testing.T) {
	dir := t.TempDir()
	moduleDir := filepath.Join(dir, "@alva", "data", "sample", "v1.0.0")
	if err := os.MkdirAll(moduleDir, 0o755); err != nil {
		t.Fatalf("creating module directory: %v", err)
	}

	code := `function getFoo() {}
module.exports = {
  getFoo,
};`

	if err := os.WriteFile(filepath.Join(moduleDir, "code.js"), []byte(code), 0o644); err != nil {
		t.Fatalf("writing code.js: %v", err)
	}

	missing, err := CheckNodifiedCoverage(dir)
	if err != nil {
		t.Fatalf("check returned error: %v", err)
	}
	if len(missing) != 1 {
		t.Fatalf("expected one missing entry, got %d", len(missing))
	}
	entry := missing[0]
	if entry.Original != "getFoo" || entry.Expected != "makeFooNode" {
		t.Fatalf("unexpected missing entry: %+v", entry)
	}
}

func TestCheckNodifiedCoverage_AllowsFactoryDefinitions(t *testing.T) {
	dir := t.TempDir()
	moduleDir := filepath.Join(dir, "@alva", "data", "sample", "v1.0.0")
	if err := os.MkdirAll(moduleDir, 0o755); err != nil {
		t.Fatalf("creating module directory: %v", err)
	}

	code := `function getFoo() {}
const factories = [
  { factoryName: "makeFooNode", source: getFoo }
];
const nodes = Object.fromEntries(factories.map((item) => [item.factoryName, () => ({})]));
module.exports = {
  getFoo,
  ...nodes,
};`

	if err := os.WriteFile(filepath.Join(moduleDir, "code.js"), []byte(code), 0o644); err != nil {
		t.Fatalf("writing code.js: %v", err)
	}

	missing, err := CheckNodifiedCoverage(dir)
	if err != nil {
		t.Fatalf("check returned error: %v", err)
	}
	if len(missing) != 0 {
		t.Fatalf("expected no missing entries, got %d", len(missing))
	}
}
