package sdkhub

import (
	"context"
	"encoding/xml"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
)

// MockSDKUpdater is a mock implementation of SDKUpdater interface
type MockSDKUpdater struct {
	mock.Mock
}

func (m *MockSDKUpdater) UpdateSDK(
	ctx context.Context,
	name string,
	doc string,
	code string,
	isPublic bool,
) error {
	args := m.Called(ctx, name, doc, code, isPublic)
	return args.Error(0)
}

func TestSDKHub_GetModule(t *testing.T) {
	hub := &SDKHub{
		modules: map[string]*SDK{
			"existing-sdk": {
				name: "existing-sdk",
				doc:  "test doc",
				code: "test code",
			},
		},
	}

	tests := []struct {
		name       string
		moduleName string
		wantSDK    bool
		wantErr    bool
		errMsg     string
	}{
		{
			name:       "existing module",
			moduleName: "existing-sdk",
			wantSDK:    true,
			wantErr:    false,
		},
		{
			name:       "non-existing module",
			moduleName: "non-existing-sdk",
			wantSDK:    false,
			wantErr:    true,
			errMsg:     "module non-existing-sdk not found",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			sdk, err := hub.GetModule(tt.moduleName)
			if tt.wantErr {
				assert.Error(t, err)
				assert.Contains(t, err.Error(), tt.errMsg)
				assert.Nil(t, sdk)
			} else {
				assert.NoError(t, err)
				if tt.wantSDK {
					assert.NotNil(t, sdk)
					assert.Equal(t, tt.moduleName, sdk.Name())
				}
			}
		})
	}
}

func TestSDKHub_GenerateMarkdownDocs(t *testing.T) {
	hub := &SDKHub{
		modules: map[string]*SDK{
			"@sdk1/foo:v1.0.0": {
				name: "@sdk1/foo:v1.0.0",
				doc:  "SDK 1 documentation",
				code: "sdk1 code",
			},
			"@sdk2/bar:v1.0.0": {
				name: "@sdk2/bar:v1.0.0",
				doc:  "SDK 2 documentation",
				code: "sdk2 code",
			},
		},
	}

	tests := []struct {
		name     string
		sdkIds   []string
		expected string
		wantErr  bool
		errMsg   string
	}{
		{
			name:     "empty list",
			sdkIds:   []string{},
			expected: "## SDK Docs\n\n",
		},
		{
			name:     "single SDK with version specified",
			sdkIds:   []string{"@sdk1/foo:v1.0.0"},
			expected: "## SDK Docs\n\n<sdk \"id\" = @sdk1/foo:v1.0.0>\n```javascript\nSDK 1 documentation\n```\n</sdk>\n\n\n\nYou Must only choose from the sdks: foo->@sdk1/foo:v1.0.0",
		},
		{
			name:     "multiple SDKs with version specified",
			sdkIds:   []string{"@sdk1/foo:v1.0.0", "@sdk2/bar:v1.0.0"},
			expected: "## SDK Docs\n\n<sdk \"id\" = @sdk1/foo:v1.0.0>\n```javascript\nSDK 1 documentation\n```\n</sdk>\n\n<sdk \"id\" = @sdk2/bar:v1.0.0>\n```javascript\nSDK 2 documentation\n```\n</sdk>\n\n\n\nYou Must only choose from the sdks: foo->@sdk1/foo:v1.0.0, bar->@sdk2/bar:v1.0.0",
		},
		{
			name:     "with non-existing SDK (fallback to fuzzy search)",
			sdkIds:   []string{"@sdk1/foo:v1.0.0", "non-existing", "@sdk2/bar:v1.0.0"},
			expected: "## SDK Docs\n\n<sdk \"id\" = @sdk1/foo:v1.0.0>\n```javascript\nSDK 1 documentation\n```\n</sdk>\n\n<sdk \"id\" = @sdk1/foo:v1.0.0>\n```javascript\nSDK 1 documentation\n```\n</sdk>\n\n<sdk \"id\" = @sdk2/bar:v1.0.0>\n```javascript\nSDK 2 documentation\n```\n</sdk>\n\n\n\nYou Must only choose from the sdks: foo->@sdk1/foo:v1.0.0, foo->@sdk1/foo:v1.0.0, bar->@sdk2/bar:v1.0.0",
			wantErr:  false,
		},
		{
			name:     "with empty SDK ID",
			sdkIds:   []string{"@sdk1/foo:v1.0.0", "", "@sdk2/bar:v1.0.0"},
			expected: "## SDK Docs\n\n<sdk \"id\" = @sdk1/foo:v1.0.0>\n```javascript\nSDK 1 documentation\n```\n</sdk>\n\n<sdk \"id\" = @sdk2/bar:v1.0.0>\n```javascript\nSDK 2 documentation\n```\n</sdk>\n\n\n\nYou Must only choose from the sdks: foo->@sdk1/foo:v1.0.0, bar->@sdk2/bar:v1.0.0",
		},
		{
			name:     "with version-specified SDK ID (mixed)",
			sdkIds:   []string{"@sdk1/foo", "@sdk2/bar:v1.0.0"},
			expected: "## SDK Docs\n\n<sdk \"id\" = @sdk1/foo:v1.0.0>\n```javascript\nSDK 1 documentation\n```\n</sdk>\n\n<sdk \"id\" = @sdk2/bar:v1.0.0>\n```javascript\nSDK 2 documentation\n```\n</sdk>\n\n\n\nYou Must only choose from the sdks: foo->@sdk1/foo:v1.0.0, bar->@sdk2/bar:v1.0.0",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result, err := hub.GenerateMarkdownDocs(tt.sdkIds)
			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" && err != nil {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
				assert.Equal(t, tt.expected, result)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.expected, result)
			}
		})
	}
}

func TestSDKHub_buildXMLDoc(t *testing.T) {
	hub := &SDKHub{
		modules: map[string]*SDK{
			"sdk1": {
				name: "sdk1",
				doc:  "SDK 1 documentation",
				code: "sdk1 code",
			},
			"sdk2": {
				name: "sdk2",
				doc:  "SDK 2 documentation",
				code: "sdk2 code",
			},
		},
	}

	err := hub.buildXMLDoc()
	assert.NoError(t, err)
	assert.NotEmpty(t, hub.xmlDoc)

	// Verify XML structure
	var xmlDoc XMLDoc
	err = xml.Unmarshal([]byte(strings.TrimPrefix(hub.xmlDoc, xml.Header)), &xmlDoc)
	assert.NoError(t, err)
	assert.Equal(t, "sdkhub", xmlDoc.XMLName.Local)
	assert.Len(t, xmlDoc.Docs, 2)

	// Check that both SDKs are included (order might vary due to map iteration)
	sdkIds := make(map[string]bool)
	for _, doc := range xmlDoc.Docs {
		sdkIds[doc.ID] = true
		switch doc.ID {
		case "sdk1":
			assert.Equal(t, "SDK 1 documentation", doc.Content)
		case "sdk2":
			assert.Equal(t, "SDK 2 documentation", doc.Content)
		}
	}
	assert.True(t, sdkIds["sdk1"])
	assert.True(t, sdkIds["sdk2"])
}

func TestSDKHub_GetXMLDoc(t *testing.T) {
	hub := &SDKHub{
		xmlDoc: "test xml content",
	}

	assert.Equal(t, "test xml content", hub.GetXMLDoc())
}

func TestWalk(t *testing.T) {
	// Test walk function over embedded SDK files
	sdkNames, err := walk(sdkFS)
	assert.NoError(t, err)
	assert.NotEmpty(t, sdkNames)

	// Verify that known SDK directories are found
	foundSDKs := make(map[string]bool)
	for _, name := range sdkNames {
		foundSDKs[name] = true
	}

	// Check for some known SDKs based on the project structure (version dirs moved)
	expectedSDKs := []string{
		"assets/@arrays/data/stock/company/income/v1.0.0",
		"assets/@arrays/crypto/defi/screener/v1.0.0",
	}

	for _, expectedSDK := range expectedSDKs {
		assert.True(
			t,
			foundSDKs[expectedSDK],
			"Expected SDK %s not found in walk results",
			expectedSDK,
		)
	}

	noDocSDKs := map[string]bool{
		"assets/@alva/external/coinglass/v1.0.0":   true,
		"assets/@alva/external/cryptoquant/v1.0.0": true,
		"assets/@alva/external/defillama/v1.0.0":   true,
	}

	// Verify that each found SDK has the required files in embed FS
	for _, sdkName := range sdkNames {
		if !noDocSDKs[sdkName] {
			_, err := fs.Stat(sdkFS, sdkName+"/doc")
			assert.NoError(t, err, "doc file should exist for SDK %s", sdkName)
			_, err = fs.Stat(sdkFS, sdkName+"/doc_nodified")
			assert.NoError(t, err, "doc_nodified file should exist for SDK %s", sdkName)
		}
		_, err := fs.Stat(sdkFS, sdkName+"/code.js")
		assert.NoError(t, err, "code.js file should exist for SDK %s", sdkName)
	}
}

func TestNewSDKHub_WithRealSDKs(t *testing.T) {
	hub, err := NewSDKHub(context.Background(), false, "")
	assert.NoError(t, err)
	assert.NotNil(t, hub)
	assert.NotEmpty(t, hub.modules)

	// Verify that some known SDKs are loaded (names translated back from assets/*)
	expectedSDKs := map[string]SDK{
		"@arrays/data/stock/company/income:v1.0.0": {
			name: "@arrays/data/stock/company/income:v1.0.0",
			doc:  "Retrieves income statements for a specific company and period, with optional pagination",
			code: "function getCompanyIncomeStatements(params) {",
		},
		"@arrays/crypto/defi/screener:v1.0.0": {
			name: "@arrays/crypto/defi/screener:v1.0.0",
			doc:  "Retrieves a filtered list of DeFi liquidity pools",
			code: "function getDeFiPoolsList(params)",
		},
		"@arrays/crypto/crypto-holdings:v1.0.0": {
			name: "@arrays/crypto/crypto-holdings:v1.0.0",
			doc:  "Public Company Crypto Holdings",
			code: "getCryptoHoldingsData(",
		},
	}

	for _, expectedSDK := range expectedSDKs {
		sdk, err := hub.GetModule(expectedSDK.name)
		assert.NoError(t, err, "Should be able to get SDK %s", expectedSDK)
		assert.NotNil(t, sdk)
		assert.Equal(t, expectedSDK.name, sdk.Name())
		assert.Contains(t, sdk.Doc(), expectedSDK.doc)
		assert.Contains(t, sdk.Code(), expectedSDK.code)
	}

	// Test XML documentation generation
	assert.NotEmpty(t, hub.GetXMLDoc())

	// Verify XML is valid
	var xmlDoc XMLDoc
	err = xml.Unmarshal([]byte(strings.TrimPrefix(hub.GetXMLDoc(), xml.Header)), &xmlDoc)
	assert.NoError(t, err)
	assert.Equal(t, "sdkhub", xmlDoc.XMLName.Local)
	assert.NotEmpty(t, xmlDoc.Docs)

	// Test markdown generation
	list := make([]string, 0, len(expectedSDKs))
	for _, expectedSDK := range expectedSDKs {
		list = append(list, expectedSDK.name)
	}
	markdown, err := hub.GenerateMarkdownDocs(list)
	assert.NoError(t, err)
	assert.Contains(t, markdown, "## SDK Docs")
	for _, expectedSDK := range expectedSDKs {
		assert.Contains(t, markdown, expectedSDK.name)
	}
}

func TestNewSDKHub_LoadTestsFlag(t *testing.T) {
	const moduleName = "@alva/jstat:v1.0.0"

	hubWithoutTests, err := NewSDKHub(context.Background(), false, "")
	assert.NoError(t, err)
	sdk, err := hubWithoutTests.GetModule(moduleName)
	assert.NoError(t, err)
	assert.Empty(t, sdk.Test())

	hubWithTests, err := NewSDKHub(context.Background(), true, "")
	assert.NoError(t, err)
	sdkWithTest, err := hubWithTests.GetModule(moduleName)
	assert.NoError(t, err)
	assert.NotEmpty(t, sdkWithTest.Test())
	assert.Contains(t, sdkWithTest.Test(), "jStat tests passed")
}

func TestSDKHub_Update_Success(t *testing.T) {
	mockCli := new(MockSDKUpdater)
	// Allow any number of UpdateSDK calls with correct arg types
	mockCli.On("UpdateSDK", mock.Anything, mock.Anything, mock.Anything, mock.Anything, true).
		Return(nil).
		Maybe()

	hub, err := NewSDKHub(context.Background(), false, "")
	assert.NoError(t, err)
	assert.NotNil(t, hub)

	err = hub.Update(mockCli)
	assert.NoError(t, err)
	mockCli.AssertExpectations(t)
}

func TestSDKHub_Update_Error(t *testing.T) {
	mockCli := new(MockSDKUpdater)
	// Cause first UpdateSDK call to fail
	mockCli.On("UpdateSDK", mock.Anything, mock.Anything, mock.Anything, mock.Anything, true).
		Return(fmt.Errorf("update failed")).
		Once()
	// Remaining calls (if any) succeed
	mockCli.On("UpdateSDK", mock.Anything, mock.Anything, mock.Anything, mock.Anything, true).
		Return(nil).
		Maybe()

	hub, err := NewSDKHub(context.Background(), false, "")
	assert.NoError(t, err)
	assert.NotNil(t, hub)

	err = hub.Update(mockCli)
	assert.Error(t, err)
}

func TestXMLDocEntry(t *testing.T) {
	// Test XML marshaling/unmarshaling of XMLDocEntry
	entry := XMLDocEntry{
		ID:      "test-sdk",
		Content: "test content with <special> characters & symbols",
	}

	xmlData, err := xml.Marshal(entry)
	assert.NoError(t, err)
	assert.Contains(t, string(xmlData), "test-sdk")
	assert.Contains(t, string(xmlData), "test content with <special> characters & symbols")

	// Test unmarshaling
	var unmarshaledEntry XMLDocEntry
	err = xml.Unmarshal(xmlData, &unmarshaledEntry)
	assert.NoError(t, err)
	assert.Equal(t, entry.ID, unmarshaledEntry.ID)
	assert.Equal(t, entry.Content, unmarshaledEntry.Content)
}

func TestXMLDoc(t *testing.T) {
	// Test complete XMLDoc marshaling/unmarshaling
	doc := XMLDoc{
		Docs: []XMLDocEntry{
			{ID: "sdk1", Content: "SDK 1 content"},
			{ID: "sdk2", Content: "SDK 2 content"},
		},
	}

	xmlData, err := xml.MarshalIndent(doc, "", "  ")
	assert.NoError(t, err)

	fullXML := xml.Header + string(xmlData)
	assert.Contains(t, fullXML, `<?xml version="1.0" encoding="UTF-8"?>`)
	assert.Contains(t, fullXML, `<sdkhub>`)
	assert.Contains(t, fullXML, `<doc id="sdk1">`)
	assert.Contains(t, fullXML, `<doc id="sdk2">`)

	// Test unmarshaling
	var unmarshaledDoc XMLDoc
	err = xml.Unmarshal([]byte(strings.TrimPrefix(fullXML, xml.Header)), &unmarshaledDoc)
	assert.NoError(t, err)
	assert.Equal(t, "sdkhub", unmarshaledDoc.XMLName.Local)
	assert.Len(t, unmarshaledDoc.Docs, 2)
}

func TestSDKHub_GetModule_Success(t *testing.T) {
	hub, err := NewSDKHub(context.Background(), false, "")
	assert.NoError(t, err)
	assert.NotNil(t, hub)

	// get module with fully qualified name
	sdk, err := hub.GetModule("@alva/data/crypto/market:v1.0.0")
	assert.NoError(t, err)
	assert.NotNil(t, sdk)
	assert.Equal(t, "@alva/data/crypto/market:v1.0.0", sdk.Name())

	// get module with version-ignored name
	sdk, err = hub.GetModuleWithDefaultVersion("@alva/data/crypto/market")
	assert.NoError(t, err)
	assert.NotNil(t, sdk)
	assert.Equal(t, "@alva/data/crypto/market:v1.0.0", sdk.Name())
}

func TestSDKHub_RealDataExists(t *testing.T) {
	hub, err := NewSDKHub(context.Background(), false, "")
	assert.NoError(t, err)
	assert.NotNil(t, hub)

	sdk, err := hub.GetModule("@alva/data/crypto/market:v1.0.0")
	assert.NoError(t, err)
	assert.NotNil(t, sdk)
	assert.Equal(t, "@alva/data/crypto/market:v1.0.0", sdk.Name())
	assert.Contains(t, sdk.Doc(), "market")
	assert.Contains(t, sdk.Code(), "function")

	// use default version
	sdk, err = hub.GetModuleWithDefaultVersion("@alva/data/crypto/market")
	assert.NoError(t, err)
	assert.NotNil(t, sdk)
	assert.Equal(t, "@alva/data/crypto/market:v1.0.0", sdk.Name())
	assert.Contains(t, sdk.Doc(), "market")
	assert.Contains(t, sdk.Code(), "function")
}

func TestSDKHub_GetModulesByDiv(t *testing.T) {
	// Create a test hub with known modules
	hub := &SDKHub{
		modules: map[string]*SDK{
			"@sdk1/foo:v1.0.0": {
				name: "@sdk1/foo:v1.0.0",
				doc:  "Short doc 1",
				code: "code1",
			},
			"@sdk2/bar:v1.0.0": {
				name: "@sdk2/bar:v1.0.0",
				doc:  "Short doc 2",
				code: "code2",
			},
			"@sdk3/baz:v1.0.0": {
				name: "@sdk3/baz:v1.0.0",
				doc:  strings.Repeat("Long documentation content ", 100),
				code: "code3",
			},
		},
	}

	// Calculate max module bytes for the test hub
	hub.calculateMaxModuleBytes()

	tests := []struct {
		name         string
		divMaxBytes  int
		wantDivCount int
		validateFunc func(t *testing.T, divisions []string)
	}{
		{
			name:         "empty hub",
			divMaxBytes:  1000,
			wantDivCount: 0,
			validateFunc: func(t *testing.T, divisions []string) {
				hub := &SDKHub{modules: map[string]*SDK{}}
				count, divs, err := hub.GetModulesByDiv(1000)
				assert.Error(t, err)
				assert.Contains(t, err.Error(), "no modules found")
				assert.Equal(t, 0, count)
				assert.Empty(t, divs)
			},
		},
		{
			name:         "max bytes too small",
			divMaxBytes:  1000,
			wantDivCount: 0,
			validateFunc: func(t *testing.T, divisions []string) {
				// Will error because 1000 < moduleMaxBytes (30000)
				assert.Nil(t, divisions)
			},
		},
		{
			name:         "all modules fit in one division",
			divMaxBytes:  50000,
			wantDivCount: 1,
			validateFunc: func(t *testing.T, divisions []string) {
				assert.Len(t, divisions, 1)
				// Check that all modules are in the division
				assert.Contains(t, divisions[0], "@sdk1/foo:v1.0.0")
				assert.Contains(t, divisions[0], "@sdk2/bar:v1.0.0")
				assert.Contains(t, divisions[0], "@sdk3/baz:v1.0.0")
				assert.Contains(t, divisions[0], "```javascript")
				assert.Contains(t, divisions[0], "<sdk \"id\" =")
				assert.Contains(t, divisions[0], "</sdk>")
				assert.Contains(t, divisions[0], MDDocSeparator)
				// Check for the SDK summary at the end
				assert.Contains(t, divisions[0], "You Must only choose from the sdks:")
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if tt.name == "empty hub" {
				tt.validateFunc(t, nil)
				return
			}

			count, divisions, err := hub.GetModulesByDiv(tt.divMaxBytes)

			// Check for expected errors
			if tt.divMaxBytes <= 0 {
				assert.Error(t, err)
				assert.Contains(t, err.Error(), "must be positive")
				return
			}

			// Check if divMaxBytes is less than the hub's maxModuleBytes
			if tt.divMaxBytes < hub.GetMaxModuleBytes() {
				assert.Error(t, err)
				assert.Contains(t, err.Error(), "must be at least")
				return
			}

			assert.NoError(t, err)

			if tt.wantDivCount > 0 {
				assert.Greater(t, count, 0, "Should have at least one division")
			} else {
				assert.Equal(t, tt.wantDivCount, count)
			}

			if tt.validateFunc != nil {
				tt.validateFunc(t, divisions)
			}
		})
	}
}

func TestSDKHub_MaxModuleBytes(t *testing.T) {
	// Test that maxModuleBytes is calculated correctly
	hub := &SDKHub{
		modules: map[string]*SDK{
			"@small/module:v1.0.0": {
				name: "@small/module:v1.0.0",
				doc:  "Small doc",
				code: "code",
			},
			"@large/module:v1.0.0": {
				name: "@large/module:v1.0.0",
				doc:  strings.Repeat("Very large documentation ", 500),
				code: "code",
			},
		},
	}

	hub.calculateMaxModuleBytes()

	// The large module should determine the max bytes
	assert.Greater(t, hub.GetMaxModuleBytes(), 10000, "Max module bytes should be significant")

	// Verify that GetModulesByDiv respects this
	_, _, err := hub.GetModulesByDiv(100) // Much smaller than any real module
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "must be at least")

	// Should work with a value >= maxModuleBytes
	count, divisions, err := hub.GetModulesByDiv(hub.GetMaxModuleBytes())
	assert.NoError(t, err)
	assert.Greater(t, count, 0)
	assert.NotEmpty(t, divisions)
}

func TestSDKHub_GetModulesByDiv_RealData(t *testing.T) {
	// Test with real SDK data
	hub, err := NewSDKHub(context.Background(), false, "")
	assert.NoError(t, err)
	assert.NotNil(t, hub)

	// Log the actual max module bytes for debugging
	t.Logf("Actual max module bytes: %d", hub.GetMaxModuleBytes())

	// Use the actual max module bytes from the hub
	count, divisions, err := hub.GetModulesByDiv(hub.GetMaxModuleBytes())
	assert.NoError(t, err)
	assert.Greater(t, count, 0, "Should have at least one division")

	// Verify each division has the expected content
	for i, div := range divisions {
		assert.NotEmpty(t, div, "Division %d should not be empty", i)

		assert.Contains(t, div, "<sdk \"id\" =", "Division %d should contain SDK tags", i)
		assert.Contains(t, div, "```javascript", "Division %d should contain code blocks", i)
		assert.Contains(
			t,
			div,
			"You Must only choose from the sdks:",
			"Division %d should contain SDK summary",
			i,
		)

		assert.False(t, strings.HasPrefix(div, MDDocSeparator),
			"First module in division %d should not start with separator", i)
	}

	// Test with double the max module size
	doubleSize := hub.GetMaxModuleBytes() * 2
	count2, divisions2, err2 := hub.GetModulesByDiv(doubleSize)
	assert.NoError(t, err2)
	assert.LessOrEqual(t, count2, count, "Larger max bytes should create fewer divisions")

	for i, div := range divisions2 {
		assert.NotEmpty(t, div, "Large division %d should not be empty", i)
	}

	// Test with size below maxModuleBytes - should error
	smallSize := hub.GetMaxModuleBytes() - 100
	_, _, err3 := hub.GetModulesByDiv(smallSize)
	assert.Error(t, err3)
	assert.Contains(t, err3.Error(), "must be at least")
}

func TestSDKHub_NoDocSDK(t *testing.T) {
	// Create a hub with both SDKs with docs and without docs
	hub := &SDKHub{
		modules: map[string]*SDK{
			// SDK with documentation
			"@sdk1/with-doc:v1.0.0": {
				name: "@sdk1/with-doc:v1.0.0",
				doc:  "This SDK has documentation",
				code: "function withDoc() { return 'has doc'; }",
			},
			// SDK without documentation (empty doc)
			"@sdk2/no-doc:v1.0.0": {
				name: "@sdk2/no-doc:v1.0.0",
				doc:  "", // Empty doc
				code: "function noDoc() { return 'no doc'; }",
			},
		},
	}

	// Test 1: SDK without doc can be retrieved via GetModule
	t.Run("GetModule_NoDocSDK", func(t *testing.T) {
		sdk, err := hub.GetModule("@sdk2/no-doc:v1.0.0")
		assert.NoError(t, err)
		assert.NotNil(t, sdk)
		assert.Equal(t, "@sdk2/no-doc:v1.0.0", sdk.Name())
		assert.Equal(t, "", sdk.Doc()) // Doc should be empty
		assert.Equal(t, "function noDoc() { return 'no doc'; }", sdk.Code())
	})
	// Test 2: Test with real SDK hub to verify the overall behavior works correctly
	t.Run("RealSDKHubBehavior", func(t *testing.T) {
		// Test with real SDK hub to verify the overall behavior
		realHub, err := NewSDKHub(context.Background(), false, "")
		assert.NoError(t, err)
		assert.NotNil(t, realHub)

		// Verify that all SDKs can be accessed (even those with empty docs)
		for sdkName := range realHub.modules {
			sdk, err := realHub.GetModule(sdkName)
			assert.NoError(t, err, "Should be able to get SDK %s", sdkName)
			assert.NotNil(t, sdk)
			assert.Equal(t, sdkName, sdk.Name())
			assert.NotEmpty(t, sdk.Code(), "SDK %s should have code", sdkName)
			// Doc can be empty or non-empty - both are valid
		}

		// Generate markdown docs for all SDKs
		allSDKIds := make([]string, 0, len(realHub.modules))
		for sdkName := range realHub.modules {
			allSDKIds = append(allSDKIds, sdkName)
		}

		markdown, err := realHub.GenerateMarkdownDocs(allSDKIds)
		assert.NoError(t, err)

		// Count SDKs with empty vs non-empty docs
		excludedCount := 0
		includedCount := 0
		sdksWithEmptyDoc := []string{}

		for _, sdkName := range allSDKIds {
			sdk, err := realHub.GetModule(sdkName)
			assert.NoError(t, err, "Should be able to get SDK %s", sdkName)

			if sdk.Doc() == "" {
				excludedCount++
				sdksWithEmptyDoc = append(sdksWithEmptyDoc, sdkName)
			} else {
				includedCount++
			}
		}

		// Verify that at least some SDKs were processed
		assert.Equal(t, 125, len(allSDKIds), "Should have some SDKs in the hub")
		assert.Equal(t, 122, includedCount)
		assert.Equal(t, 3, excludedCount)

		// The core functionality test: verify that GenerateMarkdownDocs excludes SDKs with empty docs
		// by checking that it returns fewer SDKs than the total number of modules
		// (since some modules have empty docs and should be excluded)
		docCount := strings.Count(markdown, "<sdk \"id\" =")
		assert.Equal(
			t,
			includedCount,
			docCount,
			"Should have excluded",
		)

		// Similarly, verify XML documentation excludes SDKs with empty docs
		xmlDoc := realHub.GetXMLDoc()
		assert.NotEmpty(t, xmlDoc)
		xmlSdkCount := strings.Count(xmlDoc, `<doc id="`)
		assert.Equal(t, includedCount, xmlSdkCount, "Should have included")

		// Verify that our mock test behavior is consistent: SDKs with empty docs can be accessed
		// but are excluded from generated documentation
		for i := 0; i < excludedCount; i++ {
			sdkName := sdksWithEmptyDoc[i]
			sdk, err := realHub.GetModule(sdkName)
			assert.NoError(t, err)
			assert.Equal(t, "", sdk.Doc())
			assert.NotEmpty(t, sdk.Code())
		}
	})
}

func TestDocAndDocNodifiedConcatenation(t *testing.T) {
	// Use a real module known to have both doc and doc_nodified
	hub, err := NewSDKHub(context.Background(), false, "")
	assert.NoError(t, err)
	assert.NotNil(t, hub)

	sdk, err := hub.GetModule("@alva/data/crypto/market:v1.0.0")
	assert.NoError(t, err)
	assert.NotNil(t, sdk)

	d1, err := sdkFS.ReadFile("assets/@alva/data/crypto/market/v1.0.0/doc")
	assert.NoError(t, err)
	d2, err := sdkFS.ReadFile("assets/@alva/data/crypto/market/v1.0.0/doc_nodified")
	assert.NoError(t, err)

	expected := strings.TrimSpace(string(d1)) + "\n\n" + strings.TrimSpace(string(d2))
	assert.Equal(t, expected, sdk.Doc())
}

func TestNewSDKHub_WithLocalPathOverride(t *testing.T) {
	// Create a temporary local hub directory with assets structure
	tempDir := t.TempDir()

	// Build minimal module: assets/@local/data/example/foo/v1.0.0
	modDir := filepath.Join(
		tempDir,
		"assets",
		"@local",
		"data",
		"example",
		"foo",
		"v1.0.0",
	)
	require.NoError(t, os.MkdirAll(modDir, 0o755))

	// Write required files: code.js, optional doc, doc_nodified, and test.js
	code := "function foo(params) { return 'ok'; }"
	require.NoError(t, os.WriteFile(filepath.Join(modDir, "code.js"), []byte(code+"\n"), 0o644))
	require.NoError(t, os.WriteFile(filepath.Join(modDir, "doc"), []byte("Doc A\n"), 0o644))
	require.NoError(
		t,
		os.WriteFile(filepath.Join(modDir, "doc_nodified"), []byte("Doc B\n"), 0o644),
	)
	require.NoError(
		t,
		os.WriteFile(filepath.Join(modDir, "test.js"), []byte("// no-op test\n"), 0o644),
	)

	// Initialize hub with local path
	hub, err := NewSDKHub(context.Background(), true, tempDir)
	assert.NoError(t, err)
	assert.NotNil(t, hub)

	// Expect the module name to be translated to versioned full name
	sdk, err := hub.GetModule("@local/data/example/foo:v1.0.0")
	assert.NoError(t, err)
	assert.NotNil(t, sdk)
	assert.Equal(t, "@local/data/example/foo:v1.0.0", sdk.Name())
	assert.Equal(t, strings.TrimSpace(code), sdk.Code())
	// doc should be concatenation of doc + doc_nodified
	assert.Equal(t, "Doc A\n\nDoc B", strings.TrimSpace(sdk.Doc()))
	assert.Contains(t, sdk.Test(), "no-op test")
}

// buildTestHub constructs a small in-memory hub and its inverted index
func buildTestHub() *SDKHub {
	mods := map[string]*SDK{
		"@foo/data/alpha:v1.0.0": {name: "@foo/data/alpha:v1.0.0", doc: "docA", code: "codeA"},
		"@foo/data/beta:v1.0.0":  {name: "@foo/data/beta:v1.0.0", doc: "docB", code: "codeB"},
		"@bar/ai/alpha:v1.0.0":   {name: "@bar/ai/alpha:v1.0.0", doc: "docC", code: "codeC"},
	}

	h := &SDKHub{modules: mods}
	_ = h.buildInvertedIndex()
	return h
}

func TestGetModuleFuzzy_ScoringAndBounds(t *testing.T) {
	h := buildTestHub()

	// Query with overlapping terms: org=foo, namespaces include data, module alpha
	results, err := h.GetModuleFuzzy("@foo/data/alpha", 2)
	assert.NoError(t, err)
	assert.Len(t, results, 2)
	// alpha under foo should rank first over alpha under bar
	assert.Equal(t, "@foo/data/alpha:v1.0.0", results[0].Name())

	// Clamp topN
	res2, err := h.GetModuleFuzzy("@foo/data/alpha", 10)
	assert.NoError(t, err)
	assert.Len(t, res2, 3)
}

func TestGetModuleFuzzy_TieBreakByName(t *testing.T) {
	// Construct hub with same score candidates and verify name tiebreak
	mods := map[string]*SDK{
		"@o/x/a:v1.0.0": {name: "@o/x/a:v1.0.0", doc: "d", code: "c"},
		"@o/x/b:v1.0.0": {name: "@o/x/b:v1.0.0", doc: "d", code: "c"},
	}
	h := &SDKHub{modules: mods}
	_ = h.buildInvertedIndex()

	res, err := h.GetModuleFuzzy("@o/x/a", 2)
	assert.NoError(t, err)
	assert.Len(t, res, 2)
	// Scores equal, so alphabetical by name asc
	assert.Equal(t, "@o/x/a:v1.0.0", res[0].Name())
	assert.Equal(t, "@o/x/b:v1.0.0", res[1].Name())
}

func TestGetModuleFuzzy_NoMatchesFallback(t *testing.T) {
	h := buildTestHub()
	res, err := h.GetModuleFuzzy("@unknown/org/thing:1.0.0", 2)
	assert.NoError(t, err)
	assert.Len(t, res, 2)
	// Fallback returns sorted Modules() by name; verify determinism
	all := h.Modules()
	assert.Equal(t, all[0].Name(), res[0].Name())
	assert.Equal(t, all[1].Name(), res[1].Name())
}

func TestGetModuleFuzzy_RealHub_Sanity(t *testing.T) {
	// Ensure the function works on real data and does not panic
	realHub, err := NewSDKHub(context.Background(), false, "")
	assert.NoError(t, err)
	assert.NotNil(t, realHub)

	res, err := realHub.GetModuleFuzzy("@alva/data/crypto/market", 3)
	assert.NoError(t, err)
	assert.GreaterOrEqual(t, len(res), 1)
}

// buildTestHubFive constructs a hub with 5 modules to test extra-namespace queries
func buildTestHubFive() *SDKHub {
	mods := map[string]*SDK{
		"@org/data/a:v1.0.0":     {name: "@org/data/a:v1.0.0", doc: "d", code: "c"},
		"@org/data/b:v1.0.0":     {name: "@org/data/b:v1.0.0", doc: "d", code: "c"},
		"@org/etl/a:v1.0.0":      {name: "@org/etl/a:v1.0.0", doc: "d", code: "c"},
		"@org/ml/feature:v1.0.0": {name: "@org/ml/feature:v1.0.0", doc: "d", code: "c"},
		"@other/data/c:v1.0.0":   {name: "@other/data/c:v1.0.0", doc: "d", code: "c"},
	}

	h := &SDKHub{modules: mods}
	_ = h.buildInvertedIndex()
	return h
}

func TestGetModuleFuzzy_ExtraNamespaceComponent(t *testing.T) {
	h := buildTestHubFive()

	// Human-readable scenario:
	// - Five modules exist:
	//   @org/data/a, @org/data/b, @org/etl/a, @org/ml/feature, @other/data/c
	// - The user intends "@org/data/a" but adds an extra namespace "etl"
	//   (borrowed from another module's namespace) -> query: @org/data/etl/a
	// - Scoring uses presence + IDF. The extra namespace boosts "@org/etl/a"
	//   so it should rank above "@org/data/a", but both should be in top results.

	res, err := h.GetModuleFuzzy("@org/data/etl/a", 3)
	assert.NoError(t, err)
	assert.GreaterOrEqual(t, len(res), 2)

	// The module containing the added namespace component (etl) should rank first
	assert.Equal(t, "@org/etl/a:v1.0.0", res[0].Name())
	// The originally intended path without the extra namespace should still be next
	assert.Equal(t, "@org/data/a:v1.0.0", res[1].Name())
}

func TestGetModuleFuzzy_RealModules(t *testing.T) {
	// Create a hub with real module examples
	modules := map[string]*SDK{
		"@alva/data/social/x:v1.0.0": {
			name: "@alva/data/social/x:v1.0.0",
			doc:  "social x",
			code: "",
		},
		"@alva/data/stock/company/kpi:v1.0.0": {
			name: "@alva/data/stock/company/kpi:v1.0.0",
			doc:  "kpi",
			code: "",
		},
		"@alva/llm:v1.0.0": {
			name: "@alva/llm:v1.0.0",
			doc:  "llm",
			code: "",
		},
		"@alva/technical-indicators:v1.0.0": {
			name: "@alva/technical-indicators:v1.0.0",
			doc:  "indicators",
			code: "",
		},
		"@arrays/data/stock/company/balance:v1.0.0": {
			name: "@arrays/data/stock/company/balance:v1.0.0",
			doc:  "balance",
			code: "",
		},
		"@arrays/data/stock/company/income:v1.0.0": {
			name: "@arrays/data/stock/company/income:v1.0.0",
			doc:  "income",
			code: "",
		},
		"@arrays/data/stock/spot/ohlcv:v1.0.0": {
			name: "@arrays/data/stock/spot/ohlcv:v1.0.0",
			doc:  "ohlcv",
			code: "",
		},
		"@arrays/data/etf/holdings:v1.0.0": {
			name: "@arrays/data/etf/holdings:v1.0.0",
			doc:  "etf holdings",
			code: "",
		},
		"@arrays/stock/screener:v1.0.0": {
			name: "@arrays/stock/screener:v1.0.0",
			doc:  "screener",
			code: "",
		},
		"@arrays/data/stock/economic/calendar:v1.0.0": {
			name: "@arrays/data/stock/economic/calendar:v1.0.0",
			doc:  "calendar",
			code: "",
		},
		"@arrays/data/stock/institution/holdings:v1.0.0": {
			name: "@arrays/data/stock/institution/holdings:v1.0.0",
			doc:  "inst holdings",
			code: "",
		},
		"@arrays/data/stock/macro/forex-historical:v1.0.0": {
			name: "@arrays/data/stock/macro/forex-historical:v1.0.0",
			doc:  "forex",
			code: "",
		},
		"@arrays/data/stock/person/senator-trading:v1.0.0": {
			name: "@arrays/data/stock/person/senator-trading:v1.0.0",
			doc:  "senator",
			code: "",
		},
		"@alva/external/defillama:v1.0.0": {
			name: "@alva/external/defillama:v1.0.0",
			doc:  "defillama",
			code: "",
		},
		"@arrays/crypto/screener:v1.0.0": {
			name: "@arrays/crypto/screener:v1.0.0",
			doc:  "crypto screener",
			code: "",
		},
	}

	h := &SDKHub{modules: modules}
	err := h.buildInvertedIndex()
	require.NoError(t, err)

	tests := []struct {
		name          string
		query         string
		topN          int
		expectedFirst string   // Expected first result
		expectedInTop []string // Should be in top results (any order after first)
		description   string
	}{
		// Test 1: Missing namespace level (common error: stock/ instead of data/stock/)
		{
			name:          "missing_data_namespace",
			query:         "@arrays/stock/company/balance",
			topN:          3,
			expectedFirst: "@arrays/data/stock/company/balance:v1.0.0",
			expectedInTop: []string{
				"@arrays/data/stock/company/income:v1.0.0",
			},
			description: "User forgets 'data' namespace, should still find stock/company modules",
		},

		// Test 2: Wrong org name (alva vs arrays)
		{
			name:          "wrong_org_name",
			query:         "@alva/data/stock/company/balance",
			topN:          3, // Increase topN to see more results
			expectedFirst: "@arrays/data/stock/company/balance:v1.0.0",
			expectedInTop: []string{
				"@arrays/data/stock/company/income:v1.0.0",
			},
			description: "User uses wrong org (alva instead of arrays), should find arrays modules",
		},

		// Test 3: Extra namespace level added
		{
			name:          "extra_namespace_level",
			query:         "@arrays/data/stock/spot/market/ohlcv",
			topN:          2,
			expectedFirst: "@arrays/data/stock/spot/ohlcv:v1.0.0",
			expectedInTop: []string{},
			description:   "User adds extra 'market' namespace that doesn't exist",
		},

		// Test 4: Simple module name (no namespaces)
		{
			name:          "simple_module",
			query:         "@alva/llm",
			topN:          1,
			expectedFirst: "@alva/llm:v1.0.0",
			expectedInTop: []string{},
			description:   "Direct match for simple module without namespaces",
		},

		// Test 5: Partial path - just module name
		{
			name:  "partial_path_screener",
			query: "screener",
			topN:  3,
			expectedInTop: []string{
				"@arrays/stock/screener:v1.0.0",
				"@arrays/crypto/screener:v1.0.0",
			},
			description: "Just module name 'screener' should find all screener modules",
		},

		// Test 6: Mixed up namespace order
		{
			name:          "mixed_namespace_order",
			query:         "@arrays/stock/data/company/income",
			topN:          2,
			expectedFirst: "@arrays/data/stock/company/income:v1.0.0",
			expectedInTop: []string{
				"@arrays/data/stock/company/balance:v1.0.0",
			},
			description: "User swaps 'data' and 'stock' order",
		},

		// Test 7: Missing org prefix
		{
			name:          "missing_org",
			query:         "data/stock/economic/calendar",
			topN:          1,
			expectedFirst: "@arrays/data/stock/economic/calendar:v1.0.0",
			expectedInTop: []string{},
			description:   "Query without @ prefix and org name",
		},

		// Test 8: Multiple matching terms
		{
			name:          "multiple_matches",
			query:         "@arrays/data/stock/institution/holdings",
			topN:          2,
			expectedFirst: "@arrays/data/stock/institution/holdings:v1.0.0",
			expectedInTop: []string{
				"@arrays/data/etf/holdings:v1.0.0", // Also has 'holdings' and 'data'
			},
			description: "Multiple modules share common terms",
		},

		// Test 9: Hyphenated module names
		{
			name:          "hyphenated_name",
			query:         "@arrays/data/stock/person/senator-trading",
			topN:          1,
			expectedFirst: "@arrays/data/stock/person/senator-trading:v1.0.0",
			expectedInTop: []string{},
			description:   "Module with hyphenated name",
		},

		// Test 10: Wrong namespace but correct module name
		{
			name:          "wrong_namespace_correct_module",
			query:         "@alva/data/crypto/defillama",
			topN:          1,
			expectedFirst: "@alva/external/defillama:v1.0.0",
			expectedInTop: []string{},
			description:   "User guesses wrong namespace path but has correct module name",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			results, err := h.GetModuleFuzzy(tt.query, tt.topN)
			assert.NoError(t, err)
			assert.NotEmpty(t, results, "Should return results for query: %s", tt.query)

			// Check first result if specified
			if tt.expectedFirst != "" {
				require.GreaterOrEqual(t, len(results), 1)
				assert.Equal(
					t,
					tt.expectedFirst,
					results[0].Name(),
					"First result mismatch for query '%s'. Description: %s",
					tt.query,
					tt.description,
				)
			}

			// Check that expected modules are in top results
			resultNames := make(map[string]bool)
			for _, sdk := range results {
				resultNames[sdk.Name()] = true
			}

			for _, expected := range tt.expectedInTop {
				assert.True(t, resultNames[expected],
					"Expected '%s' in top %d results for query '%s'. Got: %v. Description: %s",
					expected, tt.topN, tt.query, getNames(results), tt.description)
			}
		})
	}
}

// Test when terms don't match any modules
func TestGetModuleFuzzy_NoMatches(t *testing.T) {
	modules := map[string]*SDK{
		"@alva/llm:v1.0.0": {
			name: "@alva/llm:v1.0.0",
			doc:  "llm",
			code: "",
		},
		"@arrays/data/stock/company/balance:v1.0.0": {
			name: "@arrays/data/stock/company/balance:v1.0.0",
			doc:  "balance",
			code: "",
		},
	}

	h := &SDKHub{modules: modules}
	err := h.buildInvertedIndex()
	require.NoError(t, err)

	// Query with completely unrelated terms
	results, err := h.GetModuleFuzzy("@unknown/xyz/abc/def", 2)
	assert.NoError(t, err)
	assert.Len(t, results, 2, "Should fallback to returning all modules sorted by name")

	// Verify fallback returns modules sorted by name
	assert.Equal(t, "@alva/llm:v1.0.0", results[0].Name())
	assert.Equal(t, "@arrays/data/stock/company/balance:v1.0.0", results[1].Name())
}

// Test scoring with overlapping terms
func TestGetModuleFuzzy_Scoring(t *testing.T) {
	modules := map[string]*SDK{
		"@alva/data/stock/company/kpi:v1.0.0": {
			name: "@alva/data/stock/company/kpi:v1.0.0",
			doc:  "kpi",
			code: "",
		},
		"@arrays/data/stock/company/balance:v1.0.0": {
			name: "@arrays/data/stock/company/balance:v1.0.0",
			doc:  "balance",
			code: "",
		},
		"@arrays/stock/screener:v1.0.0": {
			name: "@arrays/stock/screener:v1.0.0",
			doc:  "screener",
			code: "",
		},
		"@alva/llm:v1.0.0": {
			name: "@alva/llm:v1.0.0",
			doc:  "llm",
			code: "",
		},
	}

	h := &SDKHub{modules: modules}
	err := h.buildInvertedIndex()
	require.NoError(t, err)

	// Query with terms that match multiple modules
	results, err := h.GetModuleFuzzy("@alva/data/stock/company/balance", 3)
	assert.NoError(t, err)
	assert.GreaterOrEqual(t, len(results), 2)

	// Both stock/company modules should rank high due to shared terms
	resultNames := getNames(results[:2])
	assert.Contains(t, resultNames, "@alva/data/stock/company/kpi:v1.0.0")
	assert.Contains(t, resultNames, "@arrays/data/stock/company/balance:v1.0.0")
}

// Helper function to get names from SDK slice
func getNames(sdks []*SDK) []string {
	names := make([]string, len(sdks))
	for i, sdk := range sdks {
		names[i] = sdk.Name()
	}
	return names
}

// TestIsDisabledByDefault tests the isDisabledByDefault function
func TestIsDisabledByDefault(t *testing.T) {
	tests := []struct {
		name       string
		moduleName string
		expected   bool
	}{
		{
			name:       "test utils module - disabled",
			moduleName: "@test/utils:v1.0.0",
			expected:   true,
		},
		{
			name:       "test utils with namespace - disabled",
			moduleName: "@test/helpers/foo:v1.0.0",
			expected:   true,
		},
		{
			name:       "arrays internal module - disabled",
			moduleName: "@arrays/internal/helpers:v1.0.0",
			expected:   true,
		},
		{
			name:       "arrays internal with deeper path - disabled",
			moduleName: "@arrays/internal/data/stock:v1.0.0",
			expected:   true,
		},
		{
			name:       "regular alva module - not disabled",
			moduleName: "@alva/data/crypto/market:v1.0.0",
			expected:   false,
		},
		{
			name:       "regular arrays module - not disabled",
			moduleName: "@arrays/data/stock/company/income:v1.0.0",
			expected:   false,
		},
		{
			name:       "arrays crypto module - not disabled",
			moduleName: "@arrays/crypto/screener:v1.0.0",
			expected:   false,
		},
		{
			name:       "alva llm module - not disabled",
			moduleName: "@alva/llm:v1.0.0",
			expected:   false,
		},
		{
			name:       "edge case: test in name but not prefix",
			moduleName: "@alva/test-data:v1.0.0",
			expected:   false,
		},
		{
			name:       "edge case: internal in name but not arrays/internal prefix",
			moduleName: "@alva/internal-tools:v1.0.0",
			expected:   false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := isDisabledByDefault(tt.moduleName)
			assert.Equal(t, tt.expected, result,
				"isDisabledByDefault(%q) = %v, want %v",
				tt.moduleName, result, tt.expected)
		})
	}
}

// TestShouldIncludeModule tests the shouldIncludeModule function
func TestShouldIncludeModule(t *testing.T) {
	tests := []struct {
		name       string
		moduleName string
		buildFlags []string
		expected   bool
	}{
		// Regular modules - always included regardless of flags
		{
			name:       "regular module without flags",
			moduleName: "@alva/data/crypto/market:v1.0.0",
			buildFlags: []string{},
			expected:   true,
		},
		{
			name:       "regular module with flags",
			moduleName: "@arrays/data/stock/company/income:v1.0.0",
			buildFlags: []string{BuildFlagIncludeTestUtils},
			expected:   true,
		},

		// Test utils modules
		{
			name:       "test utils without flag - excluded",
			moduleName: "@test/utils:v1.0.0",
			buildFlags: []string{},
			expected:   false,
		},
		{
			name:       "test utils with correct flag - included",
			moduleName: "@test/utils:v1.0.0",
			buildFlags: []string{BuildFlagIncludeTestUtils},
			expected:   true,
		},
		{
			name:       "test utils with wrong flag - excluded",
			moduleName: "@test/utils:v1.0.0",
			buildFlags: []string{BuildFlagIncludeArraysInternal},
			expected:   false,
		},
		{
			name:       "test utils nested path with flag - included",
			moduleName: "@test/helpers/mock:v1.0.0",
			buildFlags: []string{BuildFlagIncludeTestUtils},
			expected:   true,
		},

		// Arrays internal modules
		{
			name:       "arrays internal without flag - excluded",
			moduleName: "@arrays/internal/helpers:v1.0.0",
			buildFlags: []string{},
			expected:   false,
		},
		{
			name:       "arrays internal with correct flag - included",
			moduleName: "@arrays/internal/helpers:v1.0.0",
			buildFlags: []string{BuildFlagIncludeArraysInternal},
			expected:   true,
		},
		{
			name:       "arrays internal with wrong flag - excluded",
			moduleName: "@arrays/internal/helpers:v1.0.0",
			buildFlags: []string{BuildFlagIncludeTestUtils},
			expected:   false,
		},
		{
			name:       "arrays internal nested path with flag - included",
			moduleName: "@arrays/internal/data/stock/helpers:v1.0.0",
			buildFlags: []string{BuildFlagIncludeArraysInternal},
			expected:   true,
		},

		// Multiple flags
		{
			name:       "test utils with multiple flags - included",
			moduleName: "@test/utils:v1.0.0",
			buildFlags: []string{BuildFlagIncludeArraysInternal, BuildFlagIncludeTestUtils},
			expected:   true,
		},
		{
			name:       "arrays internal with multiple flags - included",
			moduleName: "@arrays/internal/helpers:v1.0.0",
			buildFlags: []string{BuildFlagIncludeArraysInternal, BuildFlagIncludeTestUtils},
			expected:   true,
		},

		// Unknown/invalid flags
		{
			name:       "disabled module with unknown flag - excluded",
			moduleName: "@test/utils:v1.0.0",
			buildFlags: []string{"--unknown-flag"},
			expected:   false,
		},
		{
			name:       "regular module with unknown flag - included",
			moduleName: "@alva/llm:v1.0.0",
			buildFlags: []string{"--unknown-flag"},
			expected:   true,
		},

		// Edge cases
		{
			name:       "empty module name",
			moduleName: "",
			buildFlags: []string{},
			expected:   true, // Not disabled by default
		},
		{
			name:       "module similar to disabled prefix but not exact",
			moduleName: "@testing/module:v1.0.0",
			buildFlags: []string{},
			expected:   true, // @testing/ is not @test/
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := shouldIncludeModule(tt.moduleName, tt.buildFlags)
			assert.Equal(t, tt.expected, result,
				"shouldIncludeModule(%q, %v) = %v, want %v",
				tt.moduleName, tt.buildFlags, result, tt.expected)
		})
	}
}

// TestNewSDKHub_WithBuildFlags tests NewSDKHub with build flags
func TestNewSDKHub_WithBuildFlags(t *testing.T) {
	// Create a temporary local hub directory with test modules
	tempDir := t.TempDir()

	// Helper to create a module
	createModule := func(path, doc, code string) {
		modDir := filepath.Join(tempDir, "assets", path)
		require.NoError(t, os.MkdirAll(modDir, 0o755))
		require.NoError(t, os.WriteFile(filepath.Join(modDir, "code.js"), []byte(code), 0o644))
		if doc != "" {
			// Both doc and doc_nodified must exist together
			require.NoError(t, os.WriteFile(filepath.Join(modDir, "doc"), []byte(doc), 0o644))
			require.NoError(
				t,
				os.WriteFile(filepath.Join(modDir, "doc_nodified"), []byte(doc+" nodified"), 0o644),
			)
		}
	}

	// Create test modules
	createModule("@alva/data/example/v1.0.0", "Regular alva doc", "function alva() {}")
	createModule("@arrays/data/stock/test/v1.0.0", "Regular arrays doc", "function arrays() {}")
	createModule("@test/utils/v1.0.0", "Test utils doc", "function testUtils() {}")
	createModule("@test/helpers/mock/v1.0.0", "Test helpers doc", "function testHelpers() {}")
	createModule(
		"@arrays/internal/helper/v1.0.0",
		"Arrays internal doc",
		"function arraysInternal() {}",
	)

	tests := []struct {
		name               string
		buildFlags         []string
		expectedModules    []string
		notExpectedModules []string
		description        string
	}{
		{
			name:       "no build flags - only regular modules",
			buildFlags: []string{},
			expectedModules: []string{
				"@alva/data/example:v1.0.0",
				"@arrays/data/stock/test:v1.0.0",
			},
			notExpectedModules: []string{
				"@test/utils:v1.0.0",
				"@test/helpers/mock:v1.0.0",
				"@arrays/internal/helper:v1.0.0",
			},
			description: "Without flags, should only load regular modules",
		},
		{
			name:       "include test utils flag",
			buildFlags: []string{BuildFlagIncludeTestUtils},
			expectedModules: []string{
				"@alva/data/example:v1.0.0",
				"@arrays/data/stock/test:v1.0.0",
				"@test/utils:v1.0.0",
				"@test/helpers/mock:v1.0.0",
			},
			notExpectedModules: []string{
				"@arrays/internal/helper:v1.0.0",
			},
			description: "With test utils flag, should include @test/ modules",
		},
		{
			name:       "include arrays internal flag",
			buildFlags: []string{BuildFlagIncludeArraysInternal},
			expectedModules: []string{
				"@alva/data/example:v1.0.0",
				"@arrays/data/stock/test:v1.0.0",
				"@arrays/internal/helper:v1.0.0",
			},
			notExpectedModules: []string{
				"@test/utils:v1.0.0",
				"@test/helpers/mock:v1.0.0",
			},
			description: "With arrays internal flag, should include @arrays/internal/ modules",
		},
		{
			name: "both flags - include all",
			buildFlags: []string{
				BuildFlagIncludeTestUtils,
				BuildFlagIncludeArraysInternal,
			},
			expectedModules: []string{
				"@alva/data/example:v1.0.0",
				"@arrays/data/stock/test:v1.0.0",
				"@test/utils:v1.0.0",
				"@test/helpers/mock:v1.0.0",
				"@arrays/internal/helper:v1.0.0",
			},
			notExpectedModules: []string{},
			description:        "With both flags, should include all modules",
		},
		{
			name:       "unknown flag - only regular modules",
			buildFlags: []string{"--unknown-flag"},
			expectedModules: []string{
				"@alva/data/example:v1.0.0",
				"@arrays/data/stock/test:v1.0.0",
			},
			notExpectedModules: []string{
				"@test/utils:v1.0.0",
				"@test/helpers/mock:v1.0.0",
				"@arrays/internal/helper:v1.0.0",
			},
			description: "Unknown flags should be ignored, behaving like no flags",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			hub, err := NewSDKHub(context.Background(), false, tempDir, tt.buildFlags...)
			assert.NoError(t, err)
			assert.NotNil(t, hub)

			// Check that expected modules are present
			for _, moduleName := range tt.expectedModules {
				sdk, err := hub.GetModule(moduleName)
				assert.NoError(t, err,
					"Expected module %s to be loaded. %s",
					moduleName, tt.description)
				assert.NotNil(t, sdk,
					"Expected module %s to be loaded. %s",
					moduleName, tt.description)
				assert.Equal(t, moduleName, sdk.Name())
			}

			// Check that not expected modules are absent
			for _, moduleName := range tt.notExpectedModules {
				sdk, err := hub.GetModule(moduleName)
				assert.Error(t, err,
					"Expected module %s NOT to be loaded. %s",
					moduleName, tt.description)
				assert.Nil(t, sdk,
					"Expected module %s NOT to be loaded. %s",
					moduleName, tt.description)
			}

			// Verify total module count
			expectedCount := len(tt.expectedModules)
			actualCount := len(hub.modules)
			assert.Equal(t, expectedCount, actualCount,
				"Expected %d modules, got %d. %s",
				expectedCount, actualCount, tt.description)
		})
	}
}

// TestNewSDKHub_RealData_WithBuildFlags tests build flags with real embedded data
func TestNewSDKHub_RealData_WithBuildFlags(t *testing.T) {
	// Test with real embedded data to ensure no @test/ or @arrays/internal/ modules exist
	// and that build flags work correctly if such modules are added in the future

	tests := []struct {
		name        string
		buildFlags  []string
		description string
	}{
		{
			name:        "no flags",
			buildFlags:  []string{},
			description: "Default hub without any build flags",
		},
		{
			name:        "with test utils flag",
			buildFlags:  []string{BuildFlagIncludeTestUtils},
			description: "Hub with test utils enabled",
		},
		{
			name:        "with arrays internal flag",
			buildFlags:  []string{BuildFlagIncludeArraysInternal},
			description: "Hub with arrays internal enabled",
		},
		{
			name: "with both flags",
			buildFlags: []string{
				BuildFlagIncludeTestUtils,
				BuildFlagIncludeArraysInternal,
			},
			description: "Hub with both flags enabled",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			hub, err := NewSDKHub(context.Background(), false, "", tt.buildFlags...)
			assert.NoError(t, err, tt.description)
			assert.NotNil(t, hub, tt.description)
			assert.NotEmpty(t, hub.modules, tt.description)

			// Count modules by prefix
			regularCount := 0
			testUtilsCount := 0
			arraysInternalCount := 0

			for moduleName := range hub.modules {
				if strings.HasPrefix(moduleName, testUtilsPrefix) {
					testUtilsCount++
				} else if strings.HasPrefix(moduleName, arraysInternalPrefix) {
					arraysInternalCount++
				} else {
					regularCount++
				}
			}

			// Verify counts based on flags
			assert.Greater(t, regularCount, 0, "Should always have regular modules")

			// Check that disabled modules are only present with correct flags
			hasTestUtilsFlag := false
			hasArraysInternalFlag := false
			for _, flag := range tt.buildFlags {
				if flag == BuildFlagIncludeTestUtils {
					hasTestUtilsFlag = true
				}
				if flag == BuildFlagIncludeArraysInternal {
					hasArraysInternalFlag = true
				}
			}

			if !hasTestUtilsFlag {
				assert.Equal(t, 0, testUtilsCount,
					"Should not have @test/ modules without %s flag",
					BuildFlagIncludeTestUtils)
			}

			if !hasArraysInternalFlag {
				assert.Equal(t, 0, arraysInternalCount,
					"Should not have @arrays/internal/ modules without %s flag",
					BuildFlagIncludeArraysInternal)
			}

			// Test that the hub is functional
			assert.NotEmpty(t, hub.GetXMLDoc())

			// Verify inverted index was built
			assert.NotNil(t, hub.invertedIndex)
		})
	}
}

// TestBuildFlagConstants tests that build flag constants are properly defined
func TestBuildFlagConstants(t *testing.T) {
	tests := []struct {
		name     string
		flag     string
		prefixes []string
	}{
		{
			name:     "arrays internal flag",
			flag:     BuildFlagIncludeArraysInternal,
			prefixes: []string{arraysInternalPrefix},
		},
		{
			name:     "test utils flag",
			flag:     BuildFlagIncludeTestUtils,
			prefixes: []string{testUtilsPrefix},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Check that flag is defined and not empty
			assert.NotEmpty(t, tt.flag, "Build flag should not be empty")
			assert.True(t, strings.HasPrefix(tt.flag, "--"), "Build flag should start with --")

			// Check that flag is mapped in buildFlagToPrefixes
			prefixes, exists := buildFlagToPrefixes[tt.flag]
			assert.True(t, exists, "Flag %s should exist in buildFlagToPrefixes", tt.flag)
			assert.Equal(
				t,
				tt.prefixes,
				prefixes,
				"Flag %s should map to correct prefixes",
				tt.flag,
			)

			// Check that all prefixes are in disabledByDefaultPrefixes
			for _, prefix := range prefixes {
				found := false
				for _, disabledPrefix := range disabledByDefaultPrefixes {
					if prefix == disabledPrefix {
						found = true
						break
					}
				}
				assert.True(t, found, "Prefix %s should be in disabledByDefaultPrefixes", prefix)
			}
		})
	}
}

// TestModulePrefixConsistency tests that prefix constants are consistent
func TestModulePrefixConsistency(t *testing.T) {
	// Verify that all flag prefixes are in disabled list
	for flag, prefixes := range buildFlagToPrefixes {
		for _, prefix := range prefixes {
			found := false
			for _, disabledPrefix := range disabledByDefaultPrefixes {
				if prefix == disabledPrefix {
					found = true
					break
				}
			}
			assert.True(t, found,
				"Flag %s prefix %s should be in disabledByDefaultPrefixes",
				flag, prefix)
		}
	}
}
