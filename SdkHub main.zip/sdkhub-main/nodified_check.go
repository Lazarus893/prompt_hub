package sdkhub

import (
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"unicode"
	"unicode/utf8"
)

// NodifiedMissing records an exported function without a corresponding nodified factory.
type NodifiedMissing struct {
	Module   string
	Original string
	Expected string
}

// CheckNodifiedCoverage walks the assets tree and reports exported SDK functions
// that are missing their nodified counterparts as defined in gen-nodified-sdk.md.
func CheckNodifiedCoverage(assetsRoot string) ([]NodifiedMissing, error) {
	info, err := os.Stat(assetsRoot)
	if err != nil {
		return nil, fmt.Errorf("checking assets root: %w", err)
	}
	if !info.IsDir() {
		return nil, fmt.Errorf("assets root is not a directory: %s", assetsRoot)
	}

	var missing []NodifiedMissing

	walkErr := filepath.WalkDir(assetsRoot, func(path string, d fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if d.IsDir() {
			return nil
		}
		if d.Name() != "code.js" {
			return nil
		}

		rel, err := filepath.Rel(assetsRoot, path)
		if err != nil {
			return fmt.Errorf("computing relative path for %s: %w", path, err)
		}

		fileMissing, err := checkCodeFileForNodified(path, rel)
		if err != nil {
			return fmt.Errorf("checking nodified coverage for %s: %w", rel, err)
		}

		missing = append(missing, fileMissing...)

		return nil
	})

	if walkErr != nil {
		return nil, walkErr
	}

	return missing, nil
}

type exportEntryKind int

const (
	exportEntryName exportEntryKind = iota
	exportEntrySpread
)

type exportEntry struct {
	Name string
	Kind exportEntryKind
}

func checkCodeFileForNodified(path, relative string) ([]NodifiedMissing, error) {
	contents, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}

	source := string(contents)

	if strings.Contains(source, "module.exports = require") {
		// Re-exported module, nothing to check locally.
		return nil, nil
	}

	block, ok := extractModuleExportsBlock(source)
	if !ok {
		return nil, nil
	}

	entries := parseExportEntries(block)
	exported := make(map[string]struct{})
	var originals []string

	for _, entry := range entries {
		if entry.Kind == exportEntrySpread {
			continue
		}
		if entry.Name == "" {
			continue
		}
		exported[entry.Name] = struct{}{}
		if isOriginalExport(entry.Name) {
			originals = append(originals, entry.Name)
		}
	}

	if len(originals) == 0 {
		return nil, nil
	}

	var missing []NodifiedMissing //nolint:prealloc
	for _, original := range originals {
		expected := expectedNodeFactoryName(original)
		if _, ok := exported[expected]; ok {
			continue
		}
		if containsIdentifier(source, expected) {
			continue
		}
		missing = append(missing, NodifiedMissing{
			Module:   filepath.ToSlash(relative),
			Original: original,
			Expected: expected,
		})
	}

	return missing, nil
}

func extractModuleExportsBlock(source string) (string, bool) {
	idx := strings.Index(source, "module.exports")
	if idx == -1 {
		return "", false
	}

	braceIdx := strings.Index(source[idx:], "{")
	if braceIdx == -1 {
		return "", false
	}

	start := idx + braceIdx
	depth := 0
	inString := false
	var stringChar rune

	for i := start; i < len(source); i++ {
		ch := rune(source[i])

		if inString {
			if ch == '\\' {
				i++
				continue
			}
			if ch == stringChar {
				inString = false
			}
			continue
		}

		switch ch {
		case '\'', '"', '`':
			inString = true
			stringChar = ch
		case '{':
			if depth == 0 {
				start = i + 1
			}
			depth++
		case '}':
			depth--
			if depth == 0 {
				return source[start:i], true
			}
			if depth < 0 {
				return "", false
			}
		}
	}

	return "", false
}

func parseExportEntries(block string) []exportEntry {
	var entries []exportEntry //nolint:prealloc

	cleaned := removeComments(block)
	fragments := strings.Split(cleaned, ",")
	for _, fragment := range fragments {
		item := strings.TrimSpace(fragment)
		if item == "" {
			continue
		}
		if strings.HasPrefix(item, "...") {
			name := strings.TrimSpace(item[3:])
			entries = append(entries, exportEntry{Name: name, Kind: exportEntrySpread})
			continue
		}

		if colon := strings.Index(item, ":"); colon != -1 {
			item = strings.TrimSpace(item[:colon])
		}

		item = strings.Trim(item, "'\"")
		if item == "" {
			continue
		}

		entries = append(entries, exportEntry{Name: item, Kind: exportEntryName})
	}

	return entries
}

func removeComments(input string) string {
	lineComment := regexp.MustCompile(`(?m)//.*$`)
	blockComment := regexp.MustCompile(`(?s)/\*.*?\*/`)
	withoutLine := lineComment.ReplaceAllString(input, "")
	return blockComment.ReplaceAllString(withoutLine, "")
}

func isOriginalExport(name string) bool {
	if name == "" {
		return false
	}
	if strings.HasPrefix(name, "make") {
		return false
	}
	r, _ := utf8DecodeRuneInString(name)
	return unicode.IsLower(r)
}

func expectedNodeFactoryName(original string) string {
	if strings.HasPrefix(original, "get") {
		rest := original[3:]
		if rest != "" {
			r, _ := utf8DecodeRuneInString(rest)
			if unicode.IsUpper(r) {
				return "make" + rest + "Node"
			}
		}
	}
	r, size := utf8DecodeRuneInString(original)
	if size <= 0 {
		return "make" + original + "Node"
	}
	upper := string(unicode.ToUpper(r)) + original[size:]
	return "make" + upper + "Node"
}

func containsIdentifier(source, ident string) bool {
	if ident == "" {
		return false
	}
	idx := strings.Index(source, ident)
	for idx != -1 {
		before := rune(0)
		after := rune(0)
		if idx > 0 {
			before = rune(source[idx-1])
		}
		if idx+len(ident) < len(source) {
			after = rune(source[idx+len(ident)])
		}
		if !isIdentifierChar(before) && !isIdentifierChar(after) {
			return true
		}
		next := strings.Index(source[idx+len(ident):], ident)
		if next == -1 {
			break
		}
		idx += len(ident) + next
	}
	return false
}

func utf8DecodeRuneInString(s string) (rune, int) {
	if s == "" {
		return rune(0), 0
	}
	r, size := utf8.DecodeRuneInString(s)
	if r == utf8.RuneError && size == 0 {
		return rune(0), 0
	}
	return r, size
}

func isIdentifierChar(ch rune) bool {
	if ch == '_' {
		return true
	}
	return unicode.IsLetter(ch) || unicode.IsDigit(ch)
}
