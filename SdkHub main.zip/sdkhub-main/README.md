# SDK Hub

SDK Hub is a centralized registry and management system for internal SDKs used across the Alva AI platform. It provides a unified interface for accessing various data sources, algorithms, and services through standardized JavaScript modules.

NOTE: a module's fully qualified name is like `@org/[namespace]*/module_name:version`, e.g. `@alva/data/crypto/meme:v1.0.0`.

The first part is the org name which must be prefixed with `@`, the second part is a list of namespaces, the third part is the module name, and after the `:` is the version part. It must be semver format like `v1.0.0`, that the `v` prefix is required.

The code and the documentation are stored in the directory structure like `assets/@org/[namespace]*/module_name/version`.

## Adding New SDKs

Follow these steps to add a new SDK:

1. **Create Directory Structure**

    ```
    assets/@org/[namespace]*/module_name/version/
    ├── code.js    # JavaScript implementation
    └── doc        # API documentation
    ```

2. **Add JavaScript Implementation**
   Create `code.js` with your SDK's JavaScript functions and modules。
   Create `doc` file with JSDoc-formatted documentation。

3. **Run the test**

```bash
go test ./...
```

## File Structure

```
sdkhub/
├── assets/@alva/           # Alva namespace SDKs (embedded)
└── assets/@arrays/         # Arrays namespace SDKs (embedded)
```

## Module Visibility

SDK Hub supports three levels of module visibility:

### 1. Disabled Modules

Modules with specific prefixes that are **disabled by default** and only loaded when explicitly enabled via build flags:

- `@test/*` - Test utilities (enable with `--include-test-utils`)
- `@arrays/internal/*` - Internal arrays modules (enable with `--include-arrays-internal`)

When not enabled, these modules are not loaded at all—they effectively don't exist in the hub.

**Example:**
```go
// Load hub without test modules (default)
hub, _ := sdkhub.NewSDKHub(ctx, false, "")

// Load hub with test utilities enabled
hub, _ := sdkhub.NewSDKHub(ctx, false, "", BuildFlagIncludeTestUtils)
```

### 2. Private Modules

Modules with only `code.js` (and optionally `test.js`) but **no `doc` file**:

- ✅ Can be imported and used by other modules
- ❌ Won't appear in documentation (XML/Markdown)
- ❌ LLMs will never know about them

Use this for internal implementation details or helper modules that shouldn't be exposed to LLM-based code generation.

**Directory structure:**
```
assets/@org/namespace/private-module/v1.0.0/
├── code.js    # Implementation
└── test.js    # Optional tests
```

### 3. Public Modules

Modules with **both documentation and code**:

- ✅ Can be imported and used by other modules
- ✅ Appear in generated documentation
- ✅ Discoverable by LLMs

**Directory structure:**
```
assets/@org/namespace/public-module/v1.0.0/
├── code.js        # Implementation
├── doc            # API documentation (JSDoc format)
├── doc_nodified   # Nodified version documentation
└── test.js        # Optional tests
```

**Note:** Both `doc` and `doc_nodified` must exist together, or both must be absent. Having only one will cause an error during hub initialization.

## SDK Tester

```bash
go run cmd/sdk_tester/main.go --mock ./local.json
```
