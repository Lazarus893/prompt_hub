package sdkhub

import "encoding/xml"

// XMLDoc represents the root XML document containing all SDK documentation
type XMLDoc struct {
	XMLName xml.Name      `xml:"sdkhub"`
	Docs    []XMLDocEntry `xml:"doc"`
}

// XMLDocEntry represents a single SDK documentation entry
type XMLDocEntry struct {
	ID      string `xml:"id,attr"`
	Content string `xml:",cdata"`
}
