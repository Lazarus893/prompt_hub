## Nodified SDK

SDKs in most cases will be used in a computation graph context. See below docs for detailed spec of the node context.

### The Prompt of using Graph Framework & SDKs to solve the user's request

=========== start of the prompt doc ===============

<how-to-code>

# Runtime & Module Model

- The runtime is a **custom V8-based VM**. `globalThis` exposes exactly and only the following functions:
    - `log(...args)` — non-blocking, ring-buffered; safe to call frequently.
    - `require(specifier)` — custom module loader (not npm).
    - NOTE: this is a custom runtime, only functions listed here are available.
- **Require grammar:** `@org/path/to/sdkName:semver`, e.g. `@alva/foo/bar/pkg:v1.0.0`
  Modules are **singletons per run** (idempotent `require`). You should only require the same module once.
- SDKs (including any fetch-like functions) are **synchronous** unless otherwise specified. Use only SDKs listed in `module_docs` for this context.

# Built-in Modules & Guidelines

## Graph Framework (Dataflow for AI-driven analytics) — `@alva/graph:v1.0.0`

This framework exposes a graph runtime for composing data analysis pipelines as nodes connected by time-series dependencies.

The core API consists of:

- `TimeSeriesUri`: declarative handle for a stored time series
- `TimeSeries`: data view over a `TimeSeriesUri`
- `Node`: a node in the graph with inputs, outputs, and a `run(inputs)` function that updates output time series algorithmically based on inputs.
- `Graph`: container of `Node`s; orchestrates execution order of nodes.

Note: this library is JavaScript; examples below use TypeScript-style annotations to convey intent and prevent common mistakes.

### Concepts

#### Basic concepts

##### JagentId

JagentId is a unique identifier for an agent. Each graph is associated with a single `jagentId`, obtained by importing the `env` module.

```js
const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');
const graph = new Graph(jagentId);
```

##### NodeId & OutputName

`nodeId` and `outputName` must be valid JS identifiers without `$` and cannot be reserved keywords. Valid characters: letters, digits, `_`; identifiers cannot start with a digit.

#### TimeSeriesUri

`TimeSeriesUri` names a specific output time series in the graph using the following schema:

```ts
new TimeSeriesUri(jagentId: string, nodeId: string, outputName: string, params?: { last?: string; before?: string })
```

- `params` support:
    - `last`: positive integer as a string; preload the latest N records
    - `before`: positive integer as a string; epoch ms, only valid when `last` is also provided

Common mistakes:

- Using `before` without `last` → error
- Non-integer/<=0 values for `last` or `before` → error
- Invalid identifiers (e.g., `node-1` or `$foo`) → error

### TimeSeries

`TimeSeries` provides read-only access to a `TimeSeriesUri`.

Key points:

- `timeSeries.init()` must be called before `more()`. The graph calls `init()` for you when wiring inputs before calling `run(inputs)`.
- Data contract: `timeSeries.data` is date-descending (newest first). Index `0` is the newest record.
- `init(preloadLast?: number)`: optional preload argument. In graph execution, `init` is called without arguments; to preload, use `TimeSeriesUri({ last: 'N' })`. If `last` is not provided, the `TimeSeries` initializes with empty data. You can still call `more()` to load data, but this is not recommended.
- `more(limit: number)`: loads older records (before the current oldest) and appends them to `data`.

#### Node and Graph

##### Node

Each node is defined by:

```ts
// For computed/dynamic values (not stored time series)
type LambdaSource = () => unknown;

// For output fields
export type TypeField = {
	name: string;
	type: 'number' | 'string' | 'boolean' | 'object' | 'array';
	description?: string;
	fields?: TypeField[]; // for object/array
};

interface NodeConfig {
	inputs?: Record<string, LambdaSource | TimeSeriesUri>; // functions or TimeSeriesUri
	outputs?: Record<
		string,
		{
			name: string;
			description: string;
			fields: TypeField[];
		}
	>;
	run(inputs: Record<string, TimeSeries | unknown>): Record<string, TsRecord[]> | void | undefined | null;
}
```

##### Node Inputs

Inputs specifies the data that the node will use to compute its outputs. Input sources can be either functions or `TimeSeriesUri`s. Do not construct or read TimeSeries inside input lambdas. Input lambdas must only fetch external SDK data and return it raw. If your node needs upstream graph data, declare a TimeSeriesUri input and read it from inputs in run(). Reading the store in a lambda bypasses dependency scheduling and may run before producers, causing empty data or races.

- Input functions are evaluated before `run()` and their return values are passed directly (not wrapped).
- `TimeSeriesUri` inputs are materialized to `TimeSeries` instances with `init()` automatically called.

**SDK data retrieval (required pattern)**

- All external data fetching via SDKs/APIs must happen in input lambdas. Place the raw SDK results into inputs and transform them in `run`.
- The node `run(inputs)` must be a pure transformation. Data fetching calls should be made in input lambdas. Data transformation or computation are allowed in `run`, e.g., compute MACD from prices, use llmGenerate to summarize text, etc.

Example pattern:

```javascript
const { someAPI } = require('@alva/foo/bar/sdk:v1.0.0');

// inputs of a node
inputs: {
	// Replace the comment with your SDK call; return structured data only
	prices_from_sdk: () => {
		return someAPI.fetchPrices('Ticker', 'Interval');
	};
}
// Later in run(inputs):
run: (inputs) => ({
	price: inputs.prices_from_sdk.map((r) => ({
		date: r.date_ms,
		price: r.close,
	})),
});
```

**TimeSeriesUri inputs**

```javascript
inputs: {
  recentPrices: new TimeSeriesUri(jagentId, 'ingest_prices', 'prices', { last: '300' }),
  olderSlice:   new TimeSeriesUri(jagentId, 'ingest_prices', 'prices', { last: '200', before: '1694563200000' })
}
```

You can only reference data from other nodes in the same graph. Input dependencies must not be circular.

When defining inputs, carefully consider how much data you need to fetch:

- Fetch sufficient history for indicators and moving statistics:
    - e.g., SMA(N) → fetch at least `N` extra points beyond the requested output window (+10–20% buffer).
    - RSI(14) → at least 14 warm-up periods (+buffer).
    - Volatility/standard deviation → ensure adequate sample size.
- For comparative metrics **within a single series** (e.g., YoY for the same instrument), fetch the additional period(s) needed.
- It is acceptable to fetch more data than needed and handle any excess in the `run` function.

##### Node Outputs Declaration

- Each node declares outputs; each output is a **time-series array** with a strict schema.
- The **first field** of every output is `date` (`number`, Unix epoch **ms**).
  **Contract:** within a single output array, **no two records may share the same `date`**.
- Nullable fields use a **two-field representation**: `*_value` and `*_present` (`boolean`). Use only when “present vs. missing” matters.
- Provide a clear description for each **output** and each **field**. Names must be descriptive and meaningful.
- If the field name is self-explanatory, you can skip the description, e.g. `close_price`, `high_price`, etc.
- When multiple domain events occur at the same timestamp (e.g., top-N at close, batch alerts), emit a single record for that `date` and put the events in a nested array field. Do not create multiple records with the same `date`.
- When emitting multiple items that conceptually belong to the same snapshot (e.g., LLM-extracted bullets), use one record with a nested array field. Do not emit multiple rows sharing the same date.

**Good example: Grouping simultaneous events into a nested array (avoid duplicate dates)**

Some events inherently happen at the same time, you must group them into a nested array instead. In this example, the node
output is a daily snapshot of the top 50 traded companies, using data at the market close time of the day. Companies are ordered by trading volume and stored in the nested array. This avoids emitting 50 separate records with the same `date`.

```javascript
outputs: {
  top50_traded_companies: {
    name: 'top50_traded_companies, daily',
    description: 'Top 50 traded companies (one record per day, unique by time).',
    fields: [
      { name: 'date', type: 'number', description: 'market close time of the day' },
      { name: 'total_trading_volume', type: 'number', description: 'total trading volume of the day' },
      {
        name: 'top50',
        type: 'array',
        description: 'companies ordered by trading volume',
        fields: [
          { name: 'company_name', type: 'string', description: 'name of the company' },
          { name: 'trading_volume', type: 'number', description: 'trading volume of the company' },
          { name: 'price_change_percentage', type: 'number', description: 'price change percentage of the company' },
        ],
      },
    ],
  },
}
// an example run function matches the output declaration above
run: (inputs) => {
  // assume inputs.stocks = [{ date, company_name, trading_volume, open_price, close_price }, ...], fetched from a SDK
  // It contains trading information of all companies for the past month.
  const grouped = {};
  for (const r of inputs.stocks) {
    const day = new Date(r.date).toISOString().slice(0, 10);
    if (!grouped[day]) grouped[day] = [];
    grouped[day].push(r);
  }

  const out = Object.entries(grouped).map(([day, arr]) => {
    const top50 = arr
      .sort((a, b) => b.trading_volume - a.trading_volume)
      .slice(0, 50)
      .map(t => ({
        company_name: t.company_name,
        trading_volume: t.trading_volume,
        price_change_percentage: ((t.close_price - t.open_price) / t.open_price) * 100,
      }));
    const totalVol = top50.reduce((s, x) => s + x.trading_volume, 0);
    return {
      date: new Date(day).getTime(),
      total_trading_volume: totalVol,
      top50
    };
  });
  return { top50_traded_companies: out };
}
```

**Bad example: Emitting multiple records with the same date**

```javascript
// ❌ Negative example: mapping an array to rows while assigning the SAME date
outputs: {
  insights: {
    name: 'insights',
    description: 'insights from search and analyzed by LLM',
    fields: [
      { name: 'date', type: 'number', description: 'date of the insights' },
      { name: 'foo', type: 'string', description: 'foo' },
      { name: 'links', type: 'array', description: 'links', fields: [{ name: 'url', type: 'string', description: 'url' }] },
      // ... other fields
    ]
  }
},
run: (inputs) => {
  return {
    industry_insights: inputs.insights.map(i => ({
      date: Date.now(), // ❌ same timestamp for every row → duplicate date error
      foo: i.foo,
      links: i.links.map(l => ({ url: l.url })),
      // ... other fields
    }))
  };
}
```

To turn the above into a good example, you can emit a single record with a nested array field:

```javascript
outputs: {
  insights: {
    name: 'insights',
    description: 'insights from search and analyzed by LLM',
    fields: [
      { name: 'date', type: 'number', description: 'date of the insights' },
      {
        name: 'insights',
        type: 'array',
        description: 'insights from LLM',
        fields: [
          { name: 'foo', type: 'string', description: 'foo' },
          { name: 'bar', type: 'number', description: 'bar' },
          { name: 'links', type: 'array', description: 'links', fields: [{ name: 'url', type: 'string', description: 'url' }] }, // deep nested array
        ],
      },
      // ... other fields
    ],
  },
},
run: (inputs: any) => {
  return {
    industry_insights: [
      {
        date: Date.now(), // only 1 record in the array
        insights: inputs.insights.map((i) => ({ // pack all insights found today into a nested array
          foo: i.foo,
          links: i.links.map(l => ({ url: l.url })), // okay to have deep nested array
        })),
      },
    ],
  };
}
```

**Good example: Emitting a single record with a nested array field**

<node-outputs-design-rules>

**Date Uniqueness (mandatory)**

- Within any single output array returned by a node, **every `date` is unique**.
- **Do not** assign one “run timestamp” to multiple records. When you find using a single "run timestamp" is necessary (e.g., summarizing many events at one moment), you must emit one record for that `date` and group the events into a nested array field (see example above).

**Collision Avoidance by Design**

If multiple domain events would otherwise share the same millisecond:

- **Redesign outputs** so collisions cannot occur in any one output (e.g., split by entity, instrument, event type, or aggregation level). If the events are inherently simultaneous for a single output, use a nested array field to hold them in a single record at that `date`.
- **Do not** micro-shift timestamps (e.g., `date + i`) to “make them unique”.
- **Do not** encode tie-breakers in `date`. Keep `date` a true time key.
- **Never** use `Date.now()` to generate per-record dates; derive per **Date Derivation Order** above.
- If you detect potential collisions during construction, **restructure** the outputs (split or aggregate upstream) so that each output still emits **one record per `date`**. For inherently simultaneous events, aggregate them into a nested array field.

**Date Derivation Order (deterministic only)**

When defining each record’s `date`, use this order and stop at the first that applies:

1. **Upstream source date** (convert seconds → ms if needed; never alter it).
2. **Domain clock** via `Date.UTC(...)` (e.g., bar start, day start, market open).

**Separation & Comparisons**

- Keep each entity/instrument in its **own output**.
- For cross-entity comparisons, compute per-series summaries independently, then optionally emit a **single one-record** comparison series (derived fields only).

**Correct patterns**

```javascript
// Separate outputs per entity
return {
	aapl_prices: aapl.map((d) => ({
		date: d.date,
		close_value: d.close,
		close_present: true,
	})),
	googl_prices: googl.map((d) => ({
		date: d.date,
		close_value: d.close,
		close_present: true,
	})),
};

// Comparison as one-record series (derived metrics only)
return {
	aapl_stats: [{ date: runTs, mean: 150.2, min: 148.0, max: 152.0 }],
	googl_stats: [{ date: runTs, mean: 2805.1, min: 2789.0, max: 2820.0 }],
	comparison: [{ date: runTs, mean_diff: 150.2 - 2805.1 }],
};
```

<node-outputs-anti-patterns>
* Zipping unrelated series by index → ❌
* Interleaving multiple entities in one output (causes duplicate `date`) → ❌
* Micro-shifting times (`date + i`) to dodge collisions → ❌
* Using index-as-date when real timestamps exist just to avoid collisions → ❌
* Emitting multiple records with the exact same `date` for simultaneous events → ❌ (Use a nested array field in a single record instead.)
</node-outputs-anti-patterns>

</node-outputs-design-rules>

##### Node Run Function

The `run(inputs)` function computes outputs **purely** from its inputs and returns an object mapping **declared** output names to time-series arrays.

<node-run-function-contract>

- **Pure & deterministic:** No side effects, no I/O, no global mutation.
- **Transform inputs only:** Fetch all external data in input lambdas; `run` must only transform provided inputs.
- **Declared-only:** Return **only** keys defined in `outputs`. Return `undefined`/`null` to append nothing.
- **Time semantics:** Every record includes `date` as a **number (ms epoch, UTC)**. Compute dates per the **Date Derivation Order**. Do **not** use `Date.now()` to create per-record dates.
- **Uniqueness (mandatory):** Within each returned output array, **every `date` must be unique**. If your logic would create collisions, **redesign outputs** (split by entity/type/level) rather than altering timestamps.
- No `try/catch` inside `run`. On fatal conditions, **throw** an `Error` (the graph handles it).

<node-run-function-minimal-template>
```ts
run: (inputs) => {
  // 1) derive data deterministically from inputs
  const out = /* build array of { date: ms, ...fields } using Date Derivation Order */;

// 2) return declared outputs only
return { outputName: out };
}

````

</node-run-function-minimal-template>

</node-run-function-contract>

##### Graph

`Graph` manages nodes and execution:

```ts
const g = new Graph(jagentId);
g.addNode('nodeId', config);
g.run(); // executes in topological order; nodes may run in parallel where applicable
````

- Nodes execute in dependency order and may run in parallel when applicable.
- Note: the `jagentId` must match the one from the `env` module.

### Quick start

#### Two-node pipeline

```javascript
const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');
const { getPrice } = require('@alva/foo/bar/sdk:v1.0.0');

const g = new Graph(jagentId);

g.addNode('ingest_prices', {
	inputs: {
		// (Just an example) Fetch via SDK here and return an array like: [{ date_ms: number, close: number, low: number, high: number ... }, ...]
		fetched_prices: () => getPrice('BTC-USD', '4h', { limit: 100 }),
	},
	outputs: {
		price: {
			name: 'btc price daily close price',
			description: 'btc price daily close price, aggregated from 4h price',
			fields: [
				{
					name: 'date',
					type: 'number',
					description: 'ms since epoch (UTC), end of trade time of the day',
				},
				{ name: 'close_price', type: 'number', description: '' }, // you can skip description if the name is self-explanatory
			],
		},
	},
	run: (inputs) => {
		// Just Example: group by day (UTC) and pick the last price as "close"
		const daily = {};
		for (const p of inputs.fetched_prices) {
			const day = new Date(p.date_ms).toISOString().slice(0, 10); // YYYY-MM-DD
			daily[day] = p; // overwrite -> keeps last price of the day
		}

		return {
			price: Object.entries(daily).map(([day, p]) => ({
				date: new Date(day).getTime(),
				close_price: p.close,
			})),
		};
	},
});

g.addNode('consumer', {
	inputs: {
		close_price: new TimeSeriesUri(jagentId, 'ingest_prices', 'price', {
			last: '100',
		}),
	},
	outputs: {
		doubled_price: {
			name: 'doubled_price',
			description: 'derived price by doubling the price',
			fields: [
				{
					name: 'date',
					type: 'number',
					description: 'the timestamp of date of derived price',
				},
				{
					name: 'doubled_price',
					type: 'number',
					description: 'the close price of btc of that day multiplied by 2',
				},
			],
		},
	},
	run: (inputs) => {
		const derivedPrice = inputs.close_price.data.map((record) => ({
			date: record.date,
			doubled_price: record.close_price * 2,
		}));
		return { doubled_price: derivedPrice };
	},
});

g.run();
```

### Data rules and validations (important)

- **Record order when appending**: The store expects records in strict date-ascending order. The graph framework sorts your returned array ascending before append and rejects duplicate dates with a detailed error. Ensure each `date` is unique per output.
- **Record order when reading**: `TimeSeries.data` is date-descending (newest first). Use index `0` for the latest record.
- **Windowing with `last`/`before`**:
    - `last=N`: preload latest N records
    - `last=N, before=T`: preload the N records strictly before timestamp `T`
    - `before` without `last` → error
- **Inputs must be functions or `TimeSeriesUri`**. Passing raw arrays/objects as inputs is invalid; wrap them: `inputs: { feed: () => myArray }`.
- **Outputs must be declared**: Returning an output key not present in `outputs` throws. Returning `undefined/null` appends nothing.
- **TypeDoc must be JSON-serializable**: `outputs[...].fields[*].type` can be any JSON-serializable value. The entire TypeDoc is serialized with `JSON.stringify`.
- **Identifier rules**: `nodeId` and `outputName` follow `^[A-Za-z_][A-Za-z0-9_]*$`, cannot be JS reserved words, and `$` is not allowed. `jagentId` allows dashes but must start alphanumeric.
- **Cross-agent dependencies**: A `TimeSeriesUri` referencing a different `jagentId` does not create a scheduling dependency. The current runtime executes nodes within one agent; cross-agent reads may still succeed if the store serves data, but order is not coordinated.

## llmGenerate — `@alva/stg/llm:v1.0.0`

When to use:

- When you need to extract structured information from text (e.g., news, social posts, search results) and you need the extracted data as input for further algorithmic analysis.

See the example below for how to use this module. You define the return value schema by specifying it in the `system_message`.
Batch multiple texts in one call to save tokens.

- **Always include the source link from upstream data in your output.**

```javascript
const { llmGenerate } = require('@alva/stg/llm:v1.0.0');

// Example:
const extracted = llmGenerate({
	system_message:
		'Extract social sentiment from the following text. Return structured data in JSON: { entity: string, sentiment: string }, where entity is the entity mentioned in the text and sentiment is one of the following: positive, negative, neutral.',
	user_message: `News: ${text1}\n${text2}\n${text3}`,
});

JSON.parse(extracted).forEach((item) => {
	if (item.sentiment === 'positive') {
		log(`${item.entity} is positive`);
	}
});
```

## External modules

- Only use modules explicitly documented in `module_docs`.
- Do not infer parameters or shapes. Follow docs exactly.

Note on data integrity:

- **Never fabricate/mock data anywhere in this document or your code.** Examples should illustrate structure and flow without inventing records. Use SDK-derived inputs!

---

# Coding Guidelines

<time-policy>
- **All timestamps are Unix epoch milliseconds (`number`) end-to-end.**, except for SDKs that require seconds.
- Outputs and all `TimeSeries` records **must** use ms.
- **Use `Date.UTC()` for all time conversions.**
- **Convert all user time expressions exactly via `Date.UTC()`.**
- Helpers (optional):
  ```javascript
  function utcMs(y, m0, d, hh=0, mm=0, ss=0, ms=0) { return Date.UTC(y, m0, d, hh, mm, ss, ms); }
  function toSec(ms) { return Math.floor(ms / 1000); } // only if an SDK requires seconds
  ```
- `TimeSeriesUri` parameters (strings):
  - `last`: e.g., `'500'` (count of most recent records)
  - `before`: **ms epoch** as string, exclusive boundary, e.g., `'1694563200000'`
  - If `before` present, `last` is required.
-

**Legacy seconds conversion example (for interop only):**

> Use when interacting with older APIs that require **seconds**. Keep ms end-to-end in your graph outputs.

```javascript
// Date.UTC uses 0-indexed month; convert to SECONDS for legacy APIs:
const startSec = Math.floor(Date.UTC(2025, 5, 1, 0, 0, 0) / 1000); // June 1, 2025
const endSec = Math.floor(Date.UTC(2025, 5, 8, 0, 0, 0) / 1000); // June 8, 2025
// Current time window in seconds (legacy interop):
const nowSec = Math.floor(Date.now() / 1000);
const weekSec = nowSec + 7 * 24 * 3600;
```

</time-policy>

<defensive-programming>
- **Error boundaries:** Both lambda input functions and node `run` function must be clean (no try–catch). If something throws, the graph framework will catch it safely in the VM.
- **Avoid try-catch:** In general, you should not use try-catch blocks unless the error is not fatal and task can continue even if the error occurs. When you must fail, fail noisily and as soon as possible.
- Log key steps sparingly but meaningfully:
  ```javascript
  log('normalize_prices', { count: arr.length });
  ```
</defensive-programming>

<data-source-policy>
- **NEVER** invent/mock production data.
- **Priority:** 1) SDKs from `module_docs`; 2) text from search or context as *secondary* evidence (extracted them via `llmGenerate`) only if those data are unavailable in the SDKs.
</data-source-policy>

---

# Code Structure & Guidelines

Always use the graph framework to code. Below is a good example structure to follow:

## Main return value (result processing and summary)

- Use the return value of the main function to present a structured meaningful result that satisfies the user's request and help your team understand the result.
- Always return a JSON object that includes `data_brief`, a structured digest bridging raw data and narrative summary.
- `data_brief` must contain:
    - `metric_name` (string): clear name of the computed metric
    - `validation` (object): integrity checks with pass/fail results
    - `conclusion` (object): computable summary suitable for the dataset (time-series or otherwise)
- The `conclusion` schema is flexible. Example (illustrative only): stats, trend, highlights. Adapt fields to the task so conclusions are computable and semantically useful. **The conclusion must directly address the `data_requirement`** and include fields that specifically answer the questions or metrics requested to ensure the output is directly actionable for the user's needs.
- Keep the main return object compact (target < 2000 bytes). Do not inline large arrays; heavy data belongs in node outputs.
- Note again that other agents can read outputs of nodes in the graph, so you do not need to repeat them in the main return value.
- Derive conclusions from actual code execution results; never assume or fabricate.
- You may include additional fields (e.g., `summary`) alongside `data_brief` as helpful narrative, but `data_brief` is required.

```javascript
const { Graph, TimeSeries, TimeSeriesUri } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');

const graph = new Graph(jagentId);

graph.addNode('foo', ...); // add foo node here
graph.addNode('bar', ...); // add bar node here

function buildDataBrief(fooData, barData) {
  // Construct the required structured digest derived from actual results
  const metricName = 'foo_records_and_bar_records';
  const validation = {
    // ... validation check result fields
  };
  const conclusion = {
    // ... conclusion fields
  };
  return { metric_name: metricName, validation, conclusion };
}

function main() {
  graph.run();
  const foo = new TimeSeries(new TimeSeriesUri(jagentId, 'some_node', 'some_output', { last: '100' }), graph.store);
  foo.init();
  const bar = new TimeSeries(new TimeSeriesUri(jagentId, 'bar', 'bar_output', { last: '100' }), graph.store);
  bar.init();

  return {
    data_brief: buildDataBrief(foo.data, bar.data),
    // More Optional fields for other agents..., e.g. summary
    summary: `foo records: ${foo.data.length}`,
  };
}

main();
```

## Principles

You design everything as a dataflow of small, focused nodes. Each node does one thing well, and downstream nodes consume upstream outputs via `TimeSeriesUri`.

- **Typical pipeline shape**
    - **Ingest nodes**: Call SDKs, log input params, normalize to a clean schema.
    - **Transform/feature nodes**: Read prior series, compute derived metrics/features.
    - **Summarize/compare nodes**: Produce the final result of the user's request.
    - **Reporting/main**: After `graph.run()`, materialize the needed series and assemble the main output object.

- **Wiring inputs**
    - Use a small lambda for config/constants or direct SDK calls that don’t require historical context.
    - Use `TimeSeriesUri` when you depend on historical data produced by other nodes. Choose a `last` window that covers your computation horizon plus warm-up & buffer.

- **Designing outputs**
    - Keep outputs narrowly scoped and stable. Prefer adding a new output over breaking an existing one.
    - Name outputs and fields descriptively so other agents can consume them without guessing.

- **Execution and consumption pattern**
    1. Create the graph with the current `jagentId`.
    2. Add nodes with clear inputs/outputs.
    3. Run the graph.
    4. Materialize specific series to construct your main return value.

- **LLM usage pattern**
    - When aggregating text (e.g., news), concatenate inputs thoughtfully and call `llmGenerate` once to obtain a structured or summarized field for your output series. Batch to reduce latency/cost.

- **Performance and ergonomics**
    - Avoid wide outputs; favor multiple focused outputs.
    - Log meaningful milestones (inputs size, records processed), not every loop iteration.
    - Reuse the single graph instance per run; don’t `require` modules repeatedly.

</how-to-code>

=========== end of the prompt doc ===============

We want you to write a new "nodified" SDK for each of the existing SDK that

For example, for getOHLCV function, the new "nodified" SDK should be like this:

Assuming the original SDK can be used like this:

```javascript
const { getOHLCV } = require('@alva/data/crypto/market:v1.0.0');

const ohlcv = getOHLCV({
	symbol: 'BTC',
	time_start: Math.floor(Date.UTC(2025, 7, 12, 0, 0, 0) / 1000),
	time_end: Math.floor(Date.UTC(2025, 7, 14, 0, 0, 0) / 1000),
	interval: '1d',
});
```

The new "nodified" SDK should be able to be used like this:

```javascript
const { makeOHLCVNode } = require('@alva/data/crypto/market:v1.0.0');
g.addNode(
	'node_name',
	makeOHLCVNode({
		symbol: 'BTC',
		time_start: Math.floor(Date.UTC(2025, 7, 12, 0, 0, 0) / 1000),
		time_end: Math.floor(Date.UTC(2025, 7, 14, 0, 0, 0) / 1000),
		interval: '1d',
	})
);
```

with detailed documentation explaining the parameters and the output typedoc of the node.

```javascript
const { makeOHLCVNode } = require('@alva/data/crypto/market:v1.0.0');

/**
 * @function makeOHLCVNode
 * @param {object} params - The parameters for the OHLCV node.
 * @param {string} params.symbol - The symbol of the cryptocurrency.
 * @param {number} params.time_start - The start time of the OHLCV data.
 * @param {number} params.time_end - The end time of the OHLCV data.
 * @param {string} params.interval - The interval of the OHLCV data.
 * @returns {object} The OHLCV node.
 *
 * The output typedoc of the node is (following the rules of the graph framework):
 * outputs: {
 *   ohlcv: {
 *     name: 'ohlcv',
 *     description: 'OHLCV data',
 *     fields: [
 *       { name: 'date', type: 'number', description: 'ms since epoch (UTC), beginning of the interval' },
 *       { name: 'open', type: 'number', description: 'open price of the interval' },
 *       { name: 'high', type: 'number', description: 'high price of the interval' },
 *       { name: 'low', type: 'number', description: 'low price of the interval' },
 *       { name: 'close', type: 'number', description: 'close price of the interval' },
 *       { name: 'volume', type: 'number', description: 'volume of the interval' },
 *       ],
 *     },
 * }
 */
function makeOHLCVNode(params) {
	return {
		symbol: params.symbol,
		time_start: params.time_start,
		time_end: params.time_end,
		interval: params.interval,
	};
}
```

the implementation of the node should be like this:

```javascript
const { getPrice } = require('@alva/data/crypto/market:v1.0.0');

function makeOHLCVNode(params) { // NOTE: exactly the same parameter as the original SDK
  return {
    inputs: {
      // Fetch raw OHLCV from the SDK. Do not transform here.
      ohlcv_raw: () =>
        getPrice(params),
    ;,
    outputs: {
      ohlcv: {
        name: 'ohlcv',
        description: 'OHLCV data for ' + params.symbol + ' at ' + params.interval + ' interval',
        fields: [
          { name: 'date', type: 'number', description: 'ms since epoch (UTC), beginning of the interval' },
          { name: 'open', type: 'number', description: 'open price of the interval' },
          { name: 'high', type: 'number', description: 'high price of the interval' },
          { name: 'low', type: 'number', description: 'low price of the interval' },
          { name: 'close', type: 'number', description: 'close price of the interval' },
          { name: 'volume', type: 'number', description: 'volume of the interval' },
        ],
      },
    },
    run: (inputs) => {
      // map the inputs.ohlcv_raw to the to a object following the typedoc of the node
      return {
        ohlcv: inputs.ohlcv_raw.map(r => ({
          date: r.date,
          open: r.open,
          high: r.high,
          low: r.low,
          close: r.close,
          volume: r.volume,
        })),
      };
    },
  };
}
```

### How to determine the output & its typedoc of the node

Because all output array must be a time-series array, when the response naturally reflects a time-series array, the output should use date wisely.

For example, the response of the getExchangeAnnouncements (array of ExchangeAnnouncement) naturally reflects a time-series.
So instead of having 1 big record in the time-series array, packing all ExchangeAnnouncement into 1 record (not good), we should have one record per ExchangeAnnouncement, and use the published_at as the date.

Note that due to in the real world, even not very likely, the date of different ExchangeAnnouncement may be the same. In this case, we just add little time shift (like 1 ms) to make them different.

The original doc:

```javascript
/**
 * Get official announcements from cryptocurrency exchanges
 * @function getExchangeAnnouncements
 * @param {Object} params - Parameters for announcement query
 * @param {string} [params.exchange] - The exact name of the exchange to filter by, select from Binance, Binance Alpha, okx, upbit
 * @param {number} [params.start_time] - Start time as Unix timestamp in milliseconds for filtering announcements
 * @param {number} [params.end_time] - End time as Unix timestamp in milliseconds for filtering announcements
 * @param {number} [params.limit=50] - Maximum number of announcements to return
 * @param {string} [params.category] - Category filter (e.g., "listing", "delisting", "maintenance", "new_feature")
 * @returns {Array<ExchangeAnnouncement>} Array of exchange announcements
 *
 * @typedef {Object} ExchangeAnnouncement
 * @property {string} exchange_name - Name of the exchange
 * @property {string} symbol - Related symbol (if applicable)
 * @property {string} url - Direct URL to the announcement
 * @property {string} title - Announcement title
 * @property {string} content - Full announcement content/description
 * @property {number} published_at - Publication timestamp in seconds
 * @property {Array<ListedPair>} [listed_pairs] - Array of trading pairs if announcement is about new listings
 *
 * @typedef {Object} ListedPair
 * @property {string} trading_pair - Trading pair symbol (e.g., "BTC/USDT", "ETH/BTC")
 * @property {number} listed_at - Listing timestamp in seconds
 *
 * @example
 * const { getExchangeAnnouncements } = require("@alva/data/crypto/exchange");
 *
 * // Get all recent announcements from Binance
 * const announcements = getExchangeAnnouncements({
 *   exchange: "Binance",
 *   start_time: Date.now() - 7 * 24 * 60 * 60 * 1000, // Last 7 days
 *   end_time: Date.now(),
 *   limit: 20
 * });
 *
 * for (const announcement of announcements) {
 *   log(`Exchange: ${announcement.exchange_name}`);
 *   log(`Title: ${announcement.title}`);
 *   log(`URL: ${announcement.url}`);
 *   log(`Published: ${new Date(announcement.published_at * 1000).toLocaleString()}`);
 *
 *   if (announcement.listed_pairs && announcement.listed_pairs.length > 0) {
 *     log("New listings:");
 *     for (const pair of announcement.listed_pairs) {
 *       log(`  - ${pair.trading_pair} (listed at: ${new Date(pair.listed_at * 1000).toLocaleString()})`);
 *     }
 *   }
 * }
 *
 * // Get listing announcements from all exchanges
 * const listingAnnouncements = getExchangeAnnouncements({
 *   category: "listing",
 *   start_time: Date.now() - 24 * 60 * 60 * 1000, // Last 24 hours
 *   end_time: Date.now(),
 *   limit: 10
 * });
 *
 * log(`Found ${listingAnnouncements.length} listing announcements`);
 */
```

The good makeExchangeAnnouncementsNode should be like this: (carefully following the comments in the code, they are telling you the good practice to follow)

```javascript
function makeExchangeAnnouncementsNode(params) {
	return {
		inputs: {
			announcements_raw: () => getExchangeAnnouncements(params),
		},
		outputs: {
			announcements: {
				name: 'exchange_announcements',
				description: 'Official Exchange Announcements',
				fields: [
					{ name: 'date', type: 'number', description: 'publication time ms' }, // place them in 1 line is preferred
					{ name: 'exchange_name', type: 'string' }, // when the field name is self-explanatory, skip the description
					{ name: 'symbol', type: 'string', description: 'related symbol if applicable' },
					{ name: 'url', type: 'string', description: 'announcement URL' },
					{ name: 'title', type: 'string', description: 'announcement title' },
					{ name: 'content', type: 'string', description: 'announcement content/description' },
					{
						name: 'listed_pairs', // for nested array, use multiple lines is preferred
						type: 'array',
						description: 'pairs listed in this announcement (if any)',
						fields: [
							{ name: 'trading_pair', type: 'string', description: 'pair symbol, e.g., BTC/USDT' }, // even in nested array, if the field is not object or array, use single line is preferred
							{ name: 'listed_at', type: 'number', description: 'listing time ms' },
						],
					},
				],
			},
		},
		run: (inputs) => {
			const arr = inputs.announcements_raw || [];
			// if duplicate by published_at, add 1 ms to the later one
			// sort by published_at, ascending
			arr.sort((a, b) => a.published_at - b.published_at);
			for (let i = 0; i < arr.length - 1; i++) {
				// minor hack: if duplicate by published_at, add 1 ms to the later one
				if (arr[i].published_at === arr[i + 1]?.published_at) {
					arr[i + 1].published_at += 1;
				}
			}
			return {
				announcements: arr.map((a) => ({
					date: a.published_at * 1000, // be careful with unit conversion. If original sdk uses seconds, convert to ms here
					exchange_name: a.exchange_name,
					symbol: a.symbol,
					url: a.url,
					title: a.title,
					content: a.content,
					listed_pairs: Array.isArray(a.listed_pairs)
						? a.listed_pairs.map((lp) => ({
								trading_pair: lp.trading_pair,
								listed_at: lp.listed_at != null ? lp.listed_at * 1000 : undefined,
							}))
						: [],
				})),
			};
		},
	};
}
```

The good doc_nodified should be like this: Note that you don't have to repeat the parameter doc, because the parameter is is exactly the same as the original SDK.

You must include exactly the same typedoc of the node in the doc_nodified, as the typedoc is the contract between the node and the graph framework.

The example should be succinct. You don't have to write boilerplate code like const { Graph } = require('@alva/graph:v1.0.0'); const { jagentId } = require('env');

It should be just like

const { makeExchangeAnnouncementsNode } = require('@alva/data/crypto/exchange:v1.0.0');
const g = new Graph(jagentId);
g.addNode('exchange_ann', makeExchangeAnnouncementsNode(...)); // params is the same as the original sdk

```javascript
/**
 * @function makeExchangeAnnouncementsNode
 * @example
 * const { makeExchangeAnnouncementsNode } = require('@alva/data/crypto/exchange:v1.0.0');
 * g.addNode('exchange_ann', makeExchangeAnnouncementsNode(params)); // params is the same as the original sdk
 * ${makeExchangeAnnouncementsNode_typedoc} // insert actual output typedoc of the node, write them here.
 */
```

The good test.js should be like this:

```javascript
const { Graph } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');
const { makeExchangeAnnouncementsNode } = require('@alva/data/crypto/exchange');
const g = new Graph(jagentId);
g.addNode(
	'exchange_ann',
	makeExchangeAnnouncementsNode({
		exchange: 'Binance',
		start_time: Date.now() - 7 * 24 * 60 * 60 * 1000,
		end_time: Date.now(),
		limit: 5,
	})
);
g.run();
// as long as no throw, it is considered passed
return 0;
```

## Another good example:

### Doc

```javascript
/**
 * Get historical price data (OHLCV) for cryptocurrencies
 * @function getPrice
 * @param {Object} params - Parameters for price data query
 * @param {string} params.symbol - The cryptocurrency symbol (e.g., "BTC", "ETH")"
 * @param {number} params.time_start - Start time as Unix timestamp in seconds
 * @param {number} params.time_end - End time as Unix timestamp in seconds
 * @param {string} params.interval - Time interval (e.g., "1m", "5m", "15m", "1h", "4h", "1d")
 * @returns {Array<PriceCandle>} Array of OHLCV price candles
 *
 * @typedef {Object} PriceCandle
 * @property {number} time_open - Opening time as Unix timestamp in seconds
 * @property {number} time_close - Closing time as Unix timestamp in seconds
 * @property {string} time_period_start - Period start time in ISO 8601 format
 * @property {string} time_period_end - Period end time in ISO 8601 format
 * @property {number} price_open - Opening price
 * @property {number} price_close - Closing price
 * @property {number} price_low - Lowest price
 * @property {number} price_high - Highest price
 * @property {number} trades_count - Number of trades in the period
 * @property {number} volume_traded - Trading volume
 */
```

### Code for nodified SDK

The following is a good example:

1. it does not hide any error! Don't check data, just let it throw if data is not expected.
2. skip description if the field name is self-explanatory.

```javascript
function makePriceNode(params) {
	return {
		inputs: {
			price_raw: () => getPrice(params),
		},
		outputs: {
			ohlcv: {
				name: 'ohlcv',
				description: 'Historic OHLCV price data',
				fields: [
					{
						name: 'date',
						type: 'number',
						description: 'interval start time ms since epoch',
					},
					{ name: 'open', type: 'number' }, // skip description if the field name is self-explanatory
					{ name: 'high', type: 'number' },
					{ name: 'low', type: 'number' },
					{
						name: 'close',
						type: 'number',
					},
					{
						name: 'volume_traded',
						type: 'number',
					},
					{
						name: 'trades_count',
						type: 'number',
					},
				],
			},
		},
		run: (inputs) => {
			return {
				ohlcv: inputs.price_raw.map((item) => {
					return {
						date: toMs(item.time_open),
						open: item.price_open,
						high: item.price_high,
						low: item.price_low,
						close: item.price_close,
						volume_traded: item.volume_traded,
						trades_count: item.trades_count,
					};
				}),
			};
		},
	};
}

NOTE: DO NOT add null check for date or any other field. Just let it throw if data is wrong.
```

### Doc_nodified

```javascript
/**
 * @function makePriceNode
 * @example
 * const { makePriceNode } = require('@alva/data/crypto/market:v1.0.0');
 * g.addNode('xxx_price', makePriceNode(params)); // params is the same as the original sdk
 * ${makePriceNode_typedoc} // insert actual output typedoc of the node, llm you should write them here.
 */
```

### Test.js for nodified SDK

```javascript
const { Graph } = require('@alva/graph:v1.0.0');
const { jagentId } = require('env');
const { makePriceNode } = require('@alva/data/crypto/market:v1.0.0');
const g = new Graph(jagentId);
g.addNode('xxx_price', makePriceNode(params));
g.run();
// as long as no throw, it is considered passed
return 0;
```

## Workflow

1. Generate new make{SDKName}Node function for each exported function in the original SDK. If existing make{SDKName}Node function, review its implementation carefully, and make sure it is correct. If not good rewrite it.
2. Write the doc_nodified file to include function doc of new make{SDKName}Node function. NOTE: don't repeat the parameter doc, because the parameter is is exactly the same as the original SDK. Learn from good examples.
3. Write the test.js file to add test cases for the new make{SDKName}Node function. Following above good examples.

Common errors:

- Event time vs. snapshot time:
    - Symptom: Unnecessarily Using API call time or run timestamp as `date` instead of the event's own timestamp.
    - Fix: If an event has a stable, domain timestamp that does not change with API call/snapshot time, use that as the record `date` (ms epoch). Convert seconds → ms where needed; prefer deterministic construction via `Date.UTC(...)`.
- Missing mandatory time-series fields:
    - Symptom: Output records lack `date`, or `date` is not the first field, or `date` is not in milliseconds.
    - Fix: Every output record must include `date` (number, ms epoch, UTC) as the first field. All other fields must follow the declared typedoc.
- Duplicate `date` values within one output:
    - Symptom: The API response may be an array of events, but multiple records share the same `date` (e.g., several events occur the same day).
    - Fix: Do not micro-shift timestamps to avoid collisions. Either (1) group simultaneous events into a single record with a nested array field, (preferred, unless micro-shifting is unavoidable because of nesting too deep (more than 3 levels)) or (2) split outputs by entity/type/level so each output maintains unique `date`s.
- Using `Date.now()` for per-record timestamps:
    - Symptom: Assigning the same run timestamp to many rows.
    - Fix: Derive each record’s `date` from source data or domain clocks only. `Date.now()` is acceptable only for a single, derived summary record when no per-event time exists.
- Returning a snapshot instead of a true time series:
    - Symptom: Packing many time-stamped items into one record when each item has its own timestamp (or, conversely, emitting many rows that share one snapshot time).
    - Fix: If items have their own timestamps, emit one record per item with that timestamp. If items are simultaneous by design, emit a single record with a nested array field. This is just like group event by date.
- Time unit mistakes (seconds vs. milliseconds):
    - Symptom: Returning `date` in seconds; forgetting to convert nested timestamps.
    - Fix: All graph outputs use milliseconds. Convert any seconds from SDKs to ms consistently, including nested fields.
- Declared outputs mismatch:
    - Symptom: Returning keys not declared in `outputs`, missing required fields, or wrong field types.
    - Fix: Return only declared outputs. Ensure each field matches the typedoc name and type. Update the typedoc if schema evolves.

