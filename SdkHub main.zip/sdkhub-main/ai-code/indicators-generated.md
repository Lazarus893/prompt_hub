### Awesome Oscillator (AO)

The Awesome Oscillator (AO) calculates momentum using the difference between two simple moving averages of median prices based on high and low prices. The formula used is:

```
Median Price = ((Low + High) / 2)
AO = 5-Period SMA - 34-Period SMA.
```

This indicator helps traders identify trends and potential reversals.

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const highs = [...]; // an array of high prices
const lows = [...]; // an array of low prices
const aoDefault = indicators.ao(highs, lows);
// The default parameters are fast: 5 and slow: 34.
// Use the return value to make a decision. The AO value can indicate momentum.
if (aoDefault[i] > 0) {
  // ... long/buy signal
} else {
  // ... short/sell signal
}
```

// Example 2: Using custom parameters
```javascript
const aoCustom = indicators.ao(highs, lows, { fast: 2, slow: 20 });
// The custom parameters specified a short period of 2 and a long period of 20.
// Use the return value similarly to identify trading opportunities.
if (aoCustom[i] > 0) {
  // ... action for positive oscillator indicating bullish momentum
} else {
  // ... action for negative or zero oscillator
}
```

### Function Return Structure
The `ao` function returns an array of numbers representing the calculated Awesome Oscillator values, which can be used to inform trading decisions based on momentum changes.

---

### Chaikin Oscillator (CMO)

The Chaikin Oscillator (CMO) measures the momentum of the Accumulation/Distribution (A/D) line using the Moving Average Convergence Divergence (MACD) formula. It is calculated as the difference between fast and slow periods of the Exponential Moving Average (EMA) of the A/D values.

#### Function Return Structure
The `cmo` function returns an object containing:
- `adResult`: an array of A/D values.
- `cmoResult`: an array representing the Chaikin oscillator values.

```javascript
// Example 1: Using default parameters
const highs = [...]; // an array of high prices
const lows = [...];  // an array of low prices
const closings = [...]; // an array of closing prices
const volumes = [...]; // an array of volumes

const cmoDefault = indicators.cmo(highs, lows, closings, volumes);
// The default parameters are fast: 3, slow: 10
console.log(cmoDefault.adResult); // Array of A/D values
console.log(cmoDefault.cmoResult); // Array of CMO values

// Use the return value to make a decision
if (cmoDefault.cmoResult[i] > 0) {
  // bullish signal
} else {
  // bearish signal
}

// Example 2: Using custom parameters
const customConfig = { fast: 2, slow: 5 };
const cmoCustom = indicators.cmo(highs, lows, closings, volumes, customConfig);
// Custom parameters used: fast: 2, slow: 5
console.log(cmoCustom.adResult); // Array of A/D values as per custom config
console.log(cmoCustom.cmoResult); // Array of CMO values as per custom config

// Use the return value to make a decision
if (cmoCustom.cmoResult[i] > 0) {
  // bullish signal
} else {
  // bearish signal
}
```

This documentation provides a succinct overview of how to use the Chaikin Oscillator, along with default and custom parameter examples to guide users in implementing this indicator effectively.

---

### Ichimoku Cloud

The **Ichimoku Cloud** calculates a versatile indicator that defines support and resistance, identifies trend direction, gauges momentum, and provides trading signals.

This indicator returns an object containing five key components: 
- `tenkan`: Tenkan-sen (Conversion Line)
- `kijun`: Kijun-sen (Base Line)
- `ssa`: Senkou Span A (Leading Span A)
- `ssb`: Senkou Span B (Leading Span B)
- `laggingSpan`: Chikou Span (Lagging Span)

#### Example 1: Using Default Parameters

```javascript
const highs = [...]; // an array of high prices
const lows = [...];  // an array of low prices
const closings = [...]; // an array of closing prices

// Using default parameters: short=9, medium=26, long=52, close=26
const ichimokuDefault = indicators.ichimokuCloud(highs, lows, closings);
// You can access the results as follows:
console.log(ichimokuDefault.tenkan);       // Tenkan-sen values
console.log(ichimokuDefault.kijun);        // Kijun-sen values
console.log(ichimokuDefault.ssa);          // Senkou Span A
console.log(ichimokuDefault.ssb);          // Senkou Span B
console.log(ichimokuDefault.laggingSpan);  // Lagging Span (Chikou Span)
```

#### Example 2: Using Custom Parameters

```javascript
const highs = [...]; // an array of high prices
const lows = [...];  // an array of low prices
const closings = [...]; // an array of closing prices

// Custom parameters: short=14, medium=30, long=50, close=10
const ichimokuCustom = indicators.ichimokuCloud(highs, lows, closings, {
  short: 14,
  medium: 30,
  long: 50,
  close: 10,
});

// Access the results similar to the default example
console.log(ichimokuCustom.tenkan);       // Tenkan-sen values based on custom parameters
console.log(ichimokuCustom.kijun);        // Kijun-sen values based on custom parameters
console.log(ichimokuCustom.ssa);          // Senkou Span A based on custom parameters
console.log(ichimokuCustom.ssb);          // Senkou Span B based on custom parameters
console.log(ichimokuCustom.laggingSpan);  // Lagging Span based on custom parameters
```

### Note:
The default configuration for the Ichimoku Cloud is:
- `short`: 9
- `medium`: 26
- `long`: 52
- `close`: 26

When using custom parameters, any of these properties can be modified to suit your analysis requirements.

---

### Percentage Price Oscillator (PPO)

The Percentage Price Oscillator (PPO) is a momentum oscillator that indicates the ups and downs based on price movements. A breakout is confirmed when the PPO is positive. 

#### Default Parameters
The default configuration for the PPO is:
- **Fast period:** 12
- **Slow period:** 26
- **Signal period:** 9

```javascript
const prices = [...]; // an array of price values
const ppoDefault = indicators.ppo(prices); // Using default parameters

// Using the return value to make a decision
if (ppoDefault.ppoResult[i] > 0) {
  // The market is in a bullish condition
} else {
  // The market is in a bearish condition
}
```

#### Custom Parameters
You can customize the parameters if needed. For example, using a fast period of 6, a slow period of 13, and a signal period of 7:

```javascript
const prices = [...]; // an array of price values
const customConfig = { fast: 6, slow: 13, signal: 7 };
const ppoCustom = indicators.ppo(prices, customConfig); // Using custom parameters

// Using the return value to make a decision
if (ppoCustom.ppoResult[i] > 0) {
  // The market is in a bullish condition
} else {
  // The market is in a bearish condition
}
```

#### Return Structure
Both the default and custom configurations will return an object containing:
- `ppoResult`: An array of PPO values.
- `signal`: An array of signal values derived from the PPO.
- `histogram`: An array representing the difference between `ppoResult` and `signal`.

Example of accessing PPO results:

```javascript
console.log(ppoCustom.ppoResult); // Array of PPO values
console.log(ppoCustom.signal);     // Array of signal values
console.log(ppoCustom.histogram);  // Array of histogram values
```

This documentation section provides an overview of how to utilize the Percentage Price Oscillator, demonstrating practical usage and the expected output structure for enhanced decision-making in trading strategies.

---

### Percentage Volume Oscillator (PVO)

The **Percentage Volume Oscillator (PVO)** is a momentum oscillator for volume that indicates the ups and downs based on volume changes. A breakout is confirmed when PVO is positive. It is calculated using the formula:

```
PVO = ((EMA(fastPeriod, volumes) - EMA(slowPeriod, volumes)) / EMA(longPeriod, volumes)) * 100
Signal = EMA(9, PVO)
Histogram = PVO - Signal
```

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const volumes = [...]; // an array of volume values
const pvoDefault = indicators.pvo(volumes);
// pvoDefault includes pvoResult, signal, and histogram
console.log(pvoDefault.pvoResult); // array of PVO results
console.log(pvoDefault.signal);     // array of Signal values
console.log(pvoDefault.histogram);  // array of Histogram values

// Example decision making based on PVO
if (pvoDefault.pvoResult[i] > 0) {
  // ... long/buy signal
} else {
  // ... short/sell signal
}
```
*Default parameters used are fast: 12, slow: 26, and signal: 9.*

// Example 2: Using custom parameters
```javascript
const customPvoConfig = { fast: 6, slow: 13, signal: 7 };
const pvoCustom = indicators.pvo(volumes, customPvoConfig);
// pvoCustom includes pvoResult, signal, and histogram with custom settings
console.log(pvoCustom.pvoResult); // array of PVO results with custom settings
console.log(pvoCustom.signal);     // array of Signal values with custom settings
console.log(pvoCustom.histogram);  // array of Histogram values with custom settings

// Use pvoCustom results for trading decisions
if (pvoCustom.pvoResult[i] > 0) {
  // ... action for positive volume oscillator
} else {
  // ... action for negative or zero volume oscillator
}
```
*In this example, custom parameters used are fast: 6, slow: 13, and signal: 7.*

---

### Price Rate of Change (ROC)

The **Price Rate of Change (ROC)** is a momentum indicator that measures the percentage change in price over a specified period. It helps in identifying the strength of a trend. The default period for the ROC calculation is 3.

#### Usage Examples:

```javascript
const values = [...]; // an array of closing prices

// Example 1: Using default parameters
const rocDefault = indicators.roc(values);
// Default parameter period is 3
// The return value is an array of ROC values.
console.log(rocDefault); // Output will show ROC values for the input

// Example 2: Using custom parameters
const rocCustom = indicators.roc(values, { period: 4 });
// The return value will reflect the ROC based on the defined period
console.log(rocCustom); // Output will show ROC values calculated with a period of 4
```

In both examples, the resulting arrays contain ROC values that indicate the momentum of the price changes:
- When the value is above 0, it indicates a positive momentum (uptrend).
- When the value is below 0, it indicates a negative momentum (downtrend).

---

### Relative Strength Index (RSI)

The **Relative Strength Index (RSI)** is a momentum indicator that measures the magnitude of recent price changes to evaluate overbought and oversold conditions using a given window period.

#### Usage Examples

// Example 1: Using default parameters
```javascript
const closings = [...]; // an array of closing prices
const rsiDefault = indicators.rsi(closings);
// Use the return value to assess market conditions.
if (rsiDefault[i] > 70) {
  // ... overbought condition, consider selling or shorting
} else if (rsiDefault[i] < 30) {
  // ... oversold condition, consider buying
}
```
*Default period parameter is 14.*

// Example 2: Using custom parameters
```javascript
const rsiCustom = indicators.rsi(closings, { period: 9 });
// Same as above, use the return value to assess market conditions.
if (rsiCustom[i] > 70) {
  // ... overbought condition, consider selling or shorting
} else if (rsiCustom[i] < 30) {
  // ... oversold condition, consider buying
}
```
*In this example, the period parameter is set to 9.* 

### Return Structure

The **RSI** function returns an array of calculated RSI values based on the provided closing prices and the specified or default period. Each element corresponds to the RSI value for the respective closing price, reflecting the momentum and potential overbought/oversold states.

---

### Stochastic Oscillator (STOCH)

The [stochasticOscillator](./stochasticOscillator.ts) function calculates a momentum indicator that shows the location of the closing price relative to the high-low range over a specified number of periods.

```javascript
// Example 1: Using default parameters
const highs = [...]; // an array of high prices
const lows = [...];  // an array of low prices
const closings = [...]; // an array of closing prices

const stochDefault = indicators.stoch(highs, lows, closings);
// The default parameters are { kPeriod: 14, dPeriod: 3 }
console.log(stochDefault.k); // the %K values
console.log(stochDefault.d); // the %D values

// You can use the return values to interpret trading signals.
// For example, if the %K crosses above the %D, it can signal a buying opportunity.
if (stochDefault.k[i] > stochDefault.d[i]) {
  // ... potential buy signal
} else {
  // ... potential sell signal
}

// Example 2: Using custom parameters
const stochCustom = indicators.stoch(highs, lows, closings, { kPeriod: 12, dPeriod: 2 });
// Custom parameters modify the look-back periods for the calculations.
console.log(stochCustom.k); // the %K values with custom periods
console.log(stochCustom.d); // the %D values with custom periods

// Similar to the default case, you can use the custom result to make trading decisions.
if (stochCustom.k[i] > stochCustom.d[i]) {
  // ... potential buy signal
} else {
  // ... potential sell signal
}
```

### Return Structure

The function returns an object containing two arrays:
- **k**: The %K values computed from the closing, high, and low prices.
- **d**: The %D values representing the smoothed version of the %K values.

Both values can be used for momentum analysis and to identify potential buy or sell signals in trading strategies.

---

### Williams R (WILLR)

The **Williams R (WILLR)** function calculates the Williams R based on low, high, and closing prices. This momentum indicator measures overbought and oversold levels, moving between 0 and -100. Buy signals are indicated when the value is -80 and below, while sell signals are indicated when it is -20 and above.

```javascript
import { willr } from 'indicatorts';

// Example 1: Using default parameters
const highs = [...];     // An array of high prices
const lows = [...];      // An array of low prices
const closings = [...];  // An array of closing prices

const willrDefault = willr(highs, lows, closings);
// Use the return value for trading decisions
if (willrDefault[i] < -80) {
  // ... long/buy signal
} else if (willrDefault[i] > -20) {
  // ... short/sell signal
}

// Example 2: Using custom parameters
const customConfig = { period: 40 }; // Custom period for calculation
const willrCustom = willr(highs, lows, closings, customConfig);
// Same as above, use the return value for trading decisions
if (willrCustom[i] < -80) {
  // ... long/buy signal
} else if (willrCustom[i] > -20) {
  // ... short/sell signal
}
```

### Return Structure
The output of the `willr` function is an array of numerical values representing the Williams R indicator over the provided periods. Each value corresponds to the respective period's assessment of market conditions.

---

### Absolute Price Oscillator (APO)

The Absolute Price Oscillator (APO) calculates the difference between two exponential moving averages (EMAs). A positive value indicates an upward trend, while a negative value signals a downward trend. The default parameters for the APO are:
- **fast:** 14
- **slow:** 30

#### Usage Examples:

```javascript
// Example 1: Using default parameters
const values = [...]; // an array of numbers
const apoDefault = indicators.apo(values); // Using default configuration
// The return value is an array of APO values. Choose strategy based on these values.
if (apoDefault[i] > 0) {
  // ... long/buy signal
} else {
  // ... short/sell signal
}

// Example 2: Using custom parameters
const apoCustom = indicators.apo(values, { fast: 2, slow: 5 }); // Custom fast and slow periods
// The return value is still an array of APO values.
if (apoCustom[i] > 0) {
  // ... action for positive APO
} else {
  // ... action for negative or zero APO
}
```

In this setup, `apoDefault` and `apoCustom` hold the computed values of the APO indicator based on the provided values array. You can apply different strategies based on whether these values are positive or negative.

---

### Aroon

The [Aroon](https://github.com/cinar/indicatorts) function is a technical indicator used to identify trend changes in a stock's price and the strength of that trend. It consists of two lines, Aroon Up and Aroon Down. When Aroon Up is above Aroon Down, it signifies a bullish trend, and when Aroon Down is above Aroon Up, it signifies a bearish trend.

Aroon's calculations are as follows:

```
Aroon Up = ((Period - Days Since Last Period High) / Period) * 100
Aroon Down = ((Period - Days Since Last Period Low) / Period) * 100
```

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const highs = [...]; // an array of highs
const lows = [...];  // an array of lows
const aroonDefault = indicators.aroon(highs, lows);
// The result includes two arrays: aroonDefault.up and aroonDefault.down
if (aroonDefault.up[i] > aroonDefault.down[i]) {
  // ... long/buy signal
} else {
  // ... short/sell signal
}
```
- **Default Parameters:** The default period is set to 25.

```javascript
// Example 2: Using custom parameters
const aroonCustom = indicators.aroon(highs, lows, { period: 14 });
// The result includes two arrays: aroonCustom.up and aroonCustom.down
if (aroonCustom.up[i] > aroonCustom.down[i]) {
  // ... long/buy signal
} else {
  // ... short/sell signal
}
```
- **Custom Parameters:** When the `period` is set to 14, the calculations are adjusted accordingly.

Both examples return an object containing `up` and `down` arrays, which indicate the strength of the trends over the provided periods.

---

### Balance of Power (BOP)

The **Balance of Power (BOP)** function calculates the strength of buying and selling pressure. A positive value indicates an upward trend, while a negative value indicates a downward trend. A zero value indicates a balance between buyers and sellers.

The BOP is calculated using the formula:

```
BOP = (Closing - Opening) / (High - Low)
```

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const openings = [...]; // an array of opening prices
const highs = [...]; // an array of high prices
const lows = [...]; // an array of low prices
const closings = [...]; // an array of closing prices

const bopDefault = indicators.bop(openings, highs, lows, closings);
// Positive values indicate buying pressure, while negative values suggest selling pressure.
if (bopDefault[i] > 0) {
  // ... long/buy signal
} else if (bopDefault[i] < 0) {
  // ... short/sell signal
} else {
  // ... neutral market
}
```

// Example 2: Using custom parameters (if supported)
Currently, BOP does not have customizable parameters; it uses fixed inputs based on the formula mentioned above. Therefore, this example is omitted.

This self-contained section provides a clear understanding of how to utilize the Balance of Power indicator, with example code illustrating its application using default inputs.

---

### Chande Forecast Oscillator (CFO)

The Chande Forecast Oscillator calculates the percentage difference between the closing price and the n-period linear regression forecasted price. When the oscillator is above zero, it indicates that the forecast price is greater than the closing price, and when it's below zero, it indicates the opposite.

#### Formula
```
R = Linreg(Closing)
CFO = ((Closing - R) / Closing) * 100
```

#### Usage Examples

// Example 1: Using default parameters
```javascript
import { cfo } from 'indicatorts';

const closings = [...]; // an array of closing prices
const cfoDefault = cfo(closings);
// cfoDefault will provide the CFO values for the given closings
// Interpretation: If cfoDefault[i] > 0, it suggests a bullish trend.
// If cfoDefault[i] < 0, it indicates a bearish trend.
if (cfoDefault[i] > 0) {
  // ... long/buy signal
} else {
  // ... short/sell signal
}
```

// Example 2: Using custom parameters
```javascript
import { mcfo } from 'indicatorts';

const closings = [...]; // an array of closing prices
const customConfig = { period: 8 }; // custom period for moving CFO
const cfoCustom = mcfo(closings, customConfig);
// cfoCustom will provide the moving CFO values based on the custom period
// Interpretation: Positive values indicate predicted upward movement, while negative values indicate downward.
if (cfoCustom[i] > 0) {
  // ... action for positive CFO
} else {
  // ... action for negative CFO
}
```

### Summary 
The Chande Forecast Oscillator is a useful tool for identifying potential market trends based on historical price data. Users can easily implement it with either default settings or customize the period to fit their trading strategy.

---

### Community Channel Index (CCI)

The Community Channel Index (CCI) is a momentum-based oscillator that helps determine when an investment vehicle is reaching a condition of being overbought or oversold. The CCI uses the typical price and its moving average to calculate trading signals.

#### Formula
```
Moving Average = Sma(Period, Typical Price)
Mean Deviation = Sma(Period, Abs(Typical Price - Moving Average))
CMI = (Typical Price - Moving Average) / (0.015 * Mean Deviation)
```

#### Usage Examples

// Example 1: Using default parameters
```javascript
const highs = [...];  // An array of high prices
const lows = [...];   // An array of low prices
const closings = [...]; // An array of closing prices

const cciDefault = indicators.cci(highs, lows, closings);
// The default parameter is period = 20
// Result may be used similarly in trading decisions
if (cciDefault[i] > 100) {
  // ... indicates overbought condition
} else if (cciDefault[i] < -100) {
  // ... indicates oversold condition
} else {
  // ... neutral market condition
}
```

// Example 2: Using custom parameters
```javascript
const cciCustom = indicators.cci(highs, lows, closings, { period: 50 });
// Custom period parameter set to 50
// Analyze the return value for trading signals
if (cciCustom[i] > 100) {
  // ... indicates overbought condition
} else if (cciCustom[i] < -100) {
  // ... indicates oversold condition
} else {
  // ... neutral market condition
}
```

The CCI function returns an array of CCI values based on the provided highs, lows, and closing prices. Users can employ these values to make informed trading decisions based on overbought or oversold conditions detected by the CCI.

---

### Double Exponential Moving Average (DEMA)

The **Double Exponential Moving Average (DEMA)** is a technical indicator designed to reduce noise in price data and provide a clearer view of trends by utilizing two exponential moving averages (EMAs). It is calculated using the following formula:

```
DEMA = (2 * EMA(values)) - EMA(EMA(values))
```

#### Usage Examples

// Example 1: Using default parameters
```javascript
const values = [...]; // an array of numbers representing price data
const resultDefault = indicators.dema(values); // Uses default period of 12
// Result example structure: [...]; // Array of DEMA values
```
In this example, the DEMA function is called without any configuration object, which defaults the period to 12.

```javascript
if (resultDefault[i] > previousValue) {
  // ... possible action for an uptrend
} else {
  // ... possible action for a downtrend
}
```

// Example 2: Using custom parameters
```javascript
const values = [...]; // an array of numbers representing price data
const customConfig = { period: 28 }; // Custom period for calculation
const resultCustom = indicators.dema(values, customConfig);
// Result example structure: [...]; // Array of DEMA values with custom period
```
In this example, the DEMA function is called with a custom period of 28.

```javascript
if (resultCustom[i] > previousValue) {
  // ... potential action for uptrend signal
} else {
  // ... potential action for downtrend signal
}
```

With these examples, you can effectively use the DEMA function to analyze trends in your data based on both default and custom configurations.

---

### Exponential Moving Average (EMA)

The **Exponential Moving Average (EMA)** is a trend-following technical indicator that gives more weight to recent prices, making it more responsive to new information compared to a Simple Moving Average (SMA). This indicator is configurable through an optional parameter that sets the period for the moving average.

**Default Parameter:**
- period: 12

```javascript
// Example 1: Using default parameters
const values = [...]; // an array of closing prices
const emaDefault = indicators.ema(values);
// The result is an array of EMA values calculated with the default period (12).

// Using the return value to make a decision
if (emaDefault[i] > emaDefault[i - 1]) {
  // ... signal for potential price increase (uptrend)
} else {
  // ... signal for potential price decrease (downtrend)
}


// Example 2: Using custom parameters
const customConfig = { period: 2 }; // Setting the period to 2
const emaCustom = indicators.ema(values, customConfig);
// The result is an array of EMA values calculated with the specified period.

if (emaCustom[i] > emaCustom[i - 1]) {
  // ... signal for potential price increase (uptrend)
} else {
  // ... signal for potential price decrease (downtrend)
}
```

The `ema` function returns an array of EMA values corresponding to the input `values`. You can derive trading signals from changes in the EMA trend. For example, if the current EMA value is greater than the previous EMA value, it may indicate an upward price movement, warranting a potential buy signal.

---

### Mass Index (MI)

The **Mass Index (MI)** uses the high-low range to identify trend reversals based on range expansions. A high MI value may indicate a potential trend reversal, while a low value suggests the continuation of the current trend.

**Formula:**
```
Single EMA = EMA(9, Highs - Lows)
Double EMA = EMA(9, Single EMA)
Ratio = Single EMA / Double EMA
MI = Sum(25, Ratio)
```

#### Usage Examples

// Example 1: Using default parameters
```javascript
const highs = [...]; // an array of high prices
const lows = [...]; // an array of low prices
const miDefault = indicators.mi(highs, lows);
// Here, the default parameters are:
// - emaPeriod: 9
// - miPeriod: 25

// Use the return value to interpret the MI
if (miDefault[i] > someThreshold) {
  // ... potential trend reversal detected
} else {
  // ... trend likely to continue
}
```

// Example 2: Using custom parameters
```javascript
const highs = [...]; // an array of high prices
const lows = [...]; // an array of low prices
const miCustom = indicators.mi(highs, lows, { emaPeriod: 5, miPeriod: 17 });
// Here, custom parameters are:
// - emaPeriod: 5
// - miPeriod: 17

// Use the return value to interpret the MI
if (miCustom[i] > someThreshold) {
  // ... potential trend reversal detected
} else {
  // ... trend likely to continue
}
```

**Return Structure Example:**
Both `miDefault` and `miCustom` will return an array of MI values corresponding to the input high and low prices, providing insight into potential trend reversals throughout the specified periods. These values can be analyzed to make informed trading decisions based on threshold conditions.

---

### Moving Average Convergence Divergence (MACD)

The **Moving Average Convergence Divergence (MACD)** is a trend-following momentum indicator that displays the relationship between two moving averages of a security’s price. It can help identify potential buy or sell signals based on crossovers between the MACD line and the signal line.

#### Default Parameters

The default parameters for the MACD are:
- Fast EMA period: 12
- Slow EMA period: 26
- Signal EMA period: 9

```javascript
// Example 1: Using default parameters
const closings = [...]; // an array of closing prices
const macdDefault = indicators.macd(closings);
// Use the return value to make a decision. Positive MACD suggests potential buying opportunity.
if (macdDefault.macdLine[i] > macdDefault.signalLine[i]) {
  // ... buy signal
} else {
  // ... sell signal
}
```

#### Custom Parameters

You can customize the periods to better fit your trading strategy. For example, to use a fast EMA period of 14, a slow EMA period of 28, and a signal period of 7:

```javascript
// Example 2: Using custom parameters
const macdCustom = indicators.macd(closings, { fast: 14, slow: 28, signal: 7 });
// Decision making based on the MACD and Signal line crossovers.
if (macdCustom.macdLine[i] > macdCustom.signalLine[i]) {
  // ... buy signal
} else {
  // ... sell signal
}
```

The function returns an object containing:
- `macdLine`: The calculated MACD values.
- `signalLine`: The calculated signal line values.

Using these values, traders can analyze momentum and identify potential buy/sell opportunities based on the behavior of the MACD relative to the signal line.

---

### Moving Max (MMAX)

The `mmax` function calculates the moving maximum for a given period. It returns an array of the maximum values found within the specified window of input values.

**Default Parameters:**
- `period: 4` (default value for the moving period).

```javascript
const values = [...]; // an array of numbers
const mmaxDefault = indicators.mmax(values); // Uses the default period of 4
// Result will reflect the maximum of the last 4 values at each index
console.log(mmaxDefault); // Example output: [... calculated moving max values ...]

// Use the return value to make decisions, e.g., identifying resistance levels.
if (mmaxDefault[i] > someThreshold) {
  // ... potential resistance identified
} else {
  // ... no significant resistance
}
```

**Custom Parameters:**
You can also specify a custom period. For example, if you want to find the moving maximum over the last 8 values:

```javascript
const mmaxCustom = indicators.mmax(values, { period: 8 }); // Custom period of 8
// Result will reflect the maximum of the last 8 values at each index
console.log(mmaxCustom); // Example output: [... calculated moving max values with custom period ...]

// Use the return value to make different strategy decisions.
if (mmaxCustom[i] > someOtherThreshold) {
  // ... trigger a sell signal or other action
} else {
  // ... consider other possibilities based on price travel
}
``` 

This concise setup allows you to easily adapt the Moving Max indicator for varying strategies and analysis based on your specific trading needs.

---

### Moving Min (MMIN)

The **Moving Min (MMIN)** function calculates the minimum value within a given moving period. This indicator can help identify the lowest prices over a specified timeframe.

#### Example 1: Using Default Parameters

```javascript
const values = [...]; // an array of numbers
const mminDefault = indicators.mmin(values); // Default period is 4

// The result is an array of minimum values for each period.
console.log(mminDefault); // Example output: [...]

// Use the return value to make a decision regarding price movements.
if (mminDefault[i] < someThreshold) {
  // ... this indicates a possible trend change or panic selling
}
```

#### Example 2: Using Custom Parameters

```javascript
const values = [...]; // an array of numbers
const mminCustom = indicators.mmin(values, { period: 8 }); // Custom period of 8

// The result will reflect the minimum values over the last 8 periods.
console.log(mminCustom); // Example output: [...]

// Use the return value for additional analysis.
if (mminCustom[i] < someThreshold) {
  // ... give a signal about potential buying opportunity if minimum is low
}
```

### Return Structure
The function returns an array of minimum values, where each element corresponds to the minimum over the specified period as you iterate through the input values. For example, if your input array has ten elements, and you use a period of 4, the output will also have ten elements, where the minimum values are calculated based on the last 4 periods.

---

### Moving Sum (MSUM)

The `movingSum` function calculates the moving sum of a given array of numbers over a specified period. If no configuration is provided, it defaults to a period of 4.

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const values = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const msumDefault = indicators.msum(values); // Default period is 4
// Resulting array example: [1, 3, 6, 10, 14, 18, ...]
// Use the return value for analysis or decision making
console.log(msumDefault);
```

// Example 2: Using custom parameters
```javascript
const msumCustom = indicators.msum(values, { period: 7 });
// Resulting array example: [1, 3, 6, 10, 15, 21, 28, 35, ...]
// Similar to before, utilize this return value to make decisions
console.log(msumCustom);
```

In both examples, `msum` returns an array where each element corresponds to the moving sum of the last `period` elements up to that point in the input array. The first few elements in the result may not represent complete moving sums until enough values are present.

---

### Parabolic SAR

The **Parabolic SAR** (Stop and Reverse) is a common technical indicator used to identify trends and to act as a trailing stop for trades. It provides signals regarding the direction of the price trends and potential reversals.

#### Function Signature
```javascript
function psar(highs, lows, closings, config = {});
```
- **highs**: an array of high prices.
- **lows**: an array of low prices.
- **closings**: an array of closing prices.
- **config**: an optional configuration object that can define parameters like step and max.

**Default Configuration**:
- `step`: 0.02
- `max`: 0.2

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const highs = [...]; // an array of high prices
const lows = [...]; // an array of low prices
const closings = [...]; // an array of closing prices

const { trends, psarResult } = indicators.psar(highs, lows, closings);
// Using the return value to interpret trends.
// Example: Act on the trend result.
if (trends[i] === 'RISING') {
  // ... indicate a potential buy or hold action.
} else {
  // ... indicate a potential sell action.
}
```

// Example 2: Using custom parameters
```javascript
const customConfig = { step: 0.01, max: 0.3 };
const { trends, psarResultCustom } = indicators.psar(highs, lows, closings, customConfig);
// Using the custom return value to interpret trends.
if (trends[i] === 'RISING') {
  // ... indicate a potential buy or hold action based on custom settings.
} else {
  // ... indicate a potential sell action based on custom settings.
}
```

#### Return Structure:
The function returns an object containing:
- `trends`: an array indicating the trend for each point (e.g., 'RISING' or 'FALLING').
- `psarResult`: an array of values representing the Parabolic SAR calculated for each price point.

Example of `psarResult`:
```javascript
const psarResult = [3836.86, 3836.86, 3836.86, 3822.91, ...]; // calculated SAR values
``` 

This concise documentation provides the essential details for working with the Parabolic SAR indicator while allowing users to quickly grasp how to leverage its functionality in their trading strategies.

---

### Qstick

The **Qstick** indicator calculates the ratio of recent up and down bars. It is utilized to analyze buying and selling pressure within financial markets. The Qstick value is derived from the following formula:

```
QS = Sma(Closing - Opening)
```

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const openings = [...]; // array of opening values
const closings = [...]; // array of closing values

const qstickDefault = indicators.qstick(openings, closings);
// The default parameter period is set to 14.
console.log(qstickDefault); // Use the Qstick values for trading decisions
```

// Example 2: Using custom parameters
```javascript
const qstickCustom = indicators.qstick(openings, closings, { period: 9 });
// Here, we specify a custom period of 9 for the calculation.
console.log(qstickCustom); // Use the Qstick values for trading decisions
```

### Return Structure

The **Qstick** function returns an array of Qstick values based on the input opening and closing values. Each element of the array corresponds to the Qstick value calculated for each bar in the input data. The values can be interpreted in the context of market trends. For instance, consistent negative values may indicate bearish pressure, while positive values can suggest bullish momentum.

---

### Random Index (KDJ)

The **KDJ** (Random Index) is a momentum indicator used to analyze price trends. It consists of three lines: K, D, and J. The K and D lines help determine overbought or oversold conditions, while the J line indicates divergence from the K and D lines.

The KDJ is calculated as follows:

1. Calculate the **RSV** (Raw Stochastic Value):
   ```
   RSV = ((Closing - Min(Low, rPeriod)) / (Max(High, rPeriod) - Min(Low, rPeriod))) * 100
   ```
2. Calculate the **K** value:
   ```
   K = Sma(RSV, kPeriod)
   ```
3. Calculate the **D** value:
   ```
   D = Sma(K, dPeriod)
   ```
4. Calculate the **J** value:
   ```
   J = (3 * K) - (2 * D)
   ```

**Default Parameters:** The default configuration is `{ rPeriod: 9, kPeriod: 3, dPeriod: 3 }`.

```javascript
// Example 1: Using default parameters
const highs = [...];  // array of high values
const lows = [...];   // array of low values
const closings = [...]; // array of closing values

const kdjDefault = indicators.kdj(highs, lows, closings); // uses default config
console.log(kdjDefault.k); // K line values
console.log(kdjDefault.d); // D line values
console.log(kdjDefault.j); // J line values

// Use the return value for trading decisions.
// The interpretation may differ based on your strategy.
if (kdjDefault.k[i] > 80) {
  // Potentially overbought condition
} else if (kdjDefault.k[i] < 20) {
  // Potentially oversold condition
}

// Example 2: Using custom parameters
const customConfig = { rPeriod: 8, kPeriod: 4, dPeriod: 6 };
const kdjCustom = indicators.kdj(highs, lows, closings, customConfig);
console.log(kdjCustom.k);
console.log(kdjCustom.d);
console.log(kdjCustom.j);

// Similar trading signals can be derived from the custom result.
if (kdjCustom.k[i] > 80) {
  // Action for potential overbought condition
} else if (kdjCustom.k[i] < 20) {
  // Action for potential oversold condition
}
```

With the KDJ indicator, traders can identify potential entry and exit points based on the crossover of the K and D lines or the levels of the J line.

---

### Rolling Moving Average (RMA)

The **Rolling Moving Average (RMA)** is a technical indicator used to smooth out price data by creating a constantly updated average price. It calculates the average of a defined number of periods, which helps in identifying trends over time.

#### Usage Examples

// Example 1: Using default parameters
```javascript
const values = [...]; // array of numbers representing price data
const rmaDefault = indicators.rma(values);
// The default configuration is { period: 4 }. 
// Use the return value to make a decision about price trends.
if (rmaDefault[i] > someThreshold) {
  // ... action for upward trend
} else {
  // ... action for downward trend
}
```

// Example 2: Using custom parameters
```javascript
const values = [...]; // array of numbers representing price data
const rmaCustom = indicators.rma(values, { period: 8 });
// Here, custom parameter specifies a period of 8.
if (rmaCustom[i] > someThreshold) {
  // ... action for upward trend
} else {
  // ... action for downward trend
}
```

In the examples, `values` is an array of price data over time. The RMA function processes this data to generate a new array of RMA values, making it easier to observe the trend direction in market activities. The user can adjust the period parameter for a more tailored analysis based on their trading strategy.

---

### Simple Moving Average (SMA)

The **Simple Moving Average (SMA)** calculates the average value of a specified period in a sequence of numbers and is widely used in trend analysis within financial markets.

**Default Parameters:** The default period is set to 2.

```javascript
// Example 1: Using default parameters
const values = [...]; // an array of numbers (e.g., closing prices)
const smaDefault = indicators.sma(values);
// Use the return value to make decisions, for example:
if (smaDefault[i] > smaDefault[i - 1]) {
  // ... bullish signal
} else {
  // ... bearish signal
}

// Example 2: Using custom parameters
const customConfig = { period: 4 }; // setting period to 4
const smaCustom = indicators.sma(values, customConfig);
// Again, use the return value to guide your trading strategy
if (smaCustom[i] > smaCustom[i - 1]) {
  // ... bullish signal for custom SMA
} else {
  // ... bearish signal for custom SMA
}
```

In these examples, `smaDefault` and `smaCustom` will return an array of SMA values corresponding to the input array `values`, allowing you to analyze trends based on the calculated averages over the specified periods.

---

### Since Change

The `since` function provides a count of how many values have remained unchanged since the last change in a given array of values. This can be particularly useful for identifying periods of stability in a time series.

```javascript
// Example 1: Using default parameters
const values = [...]; // an array of numbers
const sinceChangeDefault = indicators.since(values);
// The result is an array of counts that represent how many consecutive times each value has appeared since the last different value.
// Use the return value for analysis.
console.log(sinceChangeDefault); // Logs: [...], where each element is the count since the last change

// Example 2: Using custom parameters
// The 'since' function does not require any custom parameters as it defaults to simply the array of values.
const sinceChangeCustom = indicators.since(values);
// same as above, use the return value to make decisions based on the patterns observed.
console.log(sinceChangeCustom); // Logs: [...], with counts based on the provided values
```

### Function Return Structure Explained

The return value from the `since` function is an array where each index corresponds to the input values. Each element in this output array represents the number of consecutive occurrences of the corresponding value from the input array since the last change. For example:

- If the input array is `[1, 2, 2, 3, 4, 4, 4]`, the output will be `[0, 0, 1, 0, 0, 1, 2]`.
- This means that `2` appeared consecutively once after the initial occurrence and `4` appeared consecutively twice after its first occurrence.

This succinctly summarizes how the `since` function operates and how to implement it effectively within your projects.

---

### Triangular Moving Average (TRIMA)

The **Triangular Moving Average (TRIMA)** is a weighted moving average that gives more weight to the middle values. It is useful for reducing volatility and improving trend detection.

#### Default Parameters
The default configuration for TRIMA is a *period of 4*.

```javascript
const values = [...]; // an array of numbers representing historical price data

// Example 1: Using default parameters
const trimaDefault = indicators.trima(values);
// The result will be calculated using a default period of 4
console.log(trimaDefault); // Use the resulting array for your analysis

// Decision making can vary based on how you interpret the TRIMA values.
if (trimaDefault[i] > trimaDefault[i - 1]) {
  // ... bullish indication or trend continuation
} else {
  // ... bearish indication or trend reversal
}
```

#### Custom Parameters
You can customize the calculation period by passing a configuration object. For example, to use a period of 9:

```javascript
// Example 2: Using custom parameters
const trimaCustom = indicators.trima(values, { period: 9 });
// The result will be calculated using the specified period of 9
console.log(trimaCustom); // Use the resulting array for your analysis

// Again, your analysis may depend on the relationship of current vs previous values.
if (trimaCustom[i] > trimaCustom[i - 1]) {
  // ... bullish indication or trend continuation
} else {
  // ... bearish indication or trend reversal
}
```

### Return Structure
The `trima` function returns an array of numerical values representing the Triangular Moving Average. Each value corresponds to the average price calculated over the specified window period, adjusted according to the formula mentioned. Use this output to identify trends or reversals in the price action.

---

### Triple Exponential Average (TRIX)

The [trix](./tripleExponentialAverage.ts) function calculates the Triple Exponential Average (TRIX), which is an oscillator used to identify oversold and overbought markets, and can also be used as a momentum indicator. The TRIX oscillates around a zero line.

The formula for TRIX is:
```
EMA1 = EMA(period, values)
EMA2 = EMA(period, EMA1)
EMA3 = EMA(period, EMA2)
TRIX = (EMA3 - Previous EMA3) / Previous EMA3
```

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const values = [...]; // an array of numbers representing price data
const trixDefault = indicators.trix(values);
// The default configuration uses a period of 4
console.log(trixDefault); // Use this output for further analysis
// Decision based on TRIX value
if (trixDefault[i] > 0) {
  // ... bullish signal
} else if (trixDefault[i] < 0) {
  // ... bearish signal
}
```

// Example 2: Using custom parameters
```javascript
const trixCustom = indicators.trix(values, { period: 9 });
// Custom period set to 9 for more sensitivity
console.log(trixCustom); // Use this output for further analysis
// Decision based on custom TRIX value
if (trixCustom[i] > 0) {
  // ... bullish signal
} else if (trixCustom[i] < 0) {
  // ... bearish signal
}
```

In these examples, the returned value arrays (`trixDefault` and `trixCustom`) provide the calculated TRIX values based on the input price data, allowing you to ascertain potential market trends based on the TRIX indicator.

---

### Triple Exponential Moving Average (TEMA)

The **Triple Exponential Moving Average (TEMA)** is a technical indicator designed to smooth out price data, allowing traders to identify trends more easily without the lag associated with traditional moving averages. 

**Formula:**
```
TEMA = (3 * EMA1) - (3 * EMA2) + EMA3
EMA1 = EMA(values)
EMA2 = EMA(EMA1)
EMA3 = EMA(EMA2)
```

#### Usage Examples:

```javascript
// Example 1: Using default parameters
const values = [...]; // an array of numbers representing price data
const temaDefault = indicators.tema(values);
// The default parameters: { period: 2 }
console.log(temaDefault); // Returns the TEMA values using the default period

// Decision based on TEMA values
if (temaDefault[i] > temaDefault[i - 1]) {
  // ... signal for bullish trend
} else {
  // ... signal for bearish trend
}

// Example 2: Using custom parameters
const temaCustom = indicators.tema(values, { period: 4 });
// Custom parameters: { period: 4 }
console.log(temaCustom); // Returns the TEMA values using a custom period

// Decision based on custom TEMA values
if (temaCustom[i] > temaCustom[i - 1]) {
  // ... signal for bullish trend
} else {
  // ... signal for bearish trend
}
```

### Summary

- The TEMA function can be used without any parameters, where it defaults to a period of 2.
- Users can customize the period by passing an options object.
- The returned array contains TEMA values that can be used to inform trading decisions based on trend detection.

---

### Typical Price

The `typicalPrice` function approximates the average price for a given period and can serve as a filter in moving average systems. It computes the typical price using the formula:

```
Typical Price = (High + Low + Closing) / 3
```

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const highs = [...];   // an array of high prices
const lows = [...];    // an array of low prices
const closings = [...]; // an array of closing prices

const typicalPrices = indicators.typicalPrice(highs, lows, closings);
// The result is an array of typical price values computed from the inputs.
// Make trading decisions based on the values:
if (typicalPrices[i] > threshold) {
  // ... bullish signal suggested by typical price
} else {
  // ... bearish signal suggested by typical price
}
```

// Example 2: Using custom parameters (if applicable)
```javascript
const highs = [...];   // an array of high prices
const lows = [...];    // an array of low prices
const closings = [...]; // an array of closing prices

// Typical price does not support custom parameters.
const typicalPricesCustom = indicators.typicalPrice(highs, lows, closings);
// Make trading decisions similar to the default example.
if (typicalPricesCustom[i] > threshold) {
  // ... bullish signal
} else {
  // ... bearish signal
}
```

### Return Structure
- The `typicalPrice` function will return an array of computed typical price values, which can be utilized to make trading decisions.
- Example structure of the return value: `[1400.83, 1402.52, 1402.49, 1402.43, 1404.85]`. Each entry in the array corresponds to the computed typical price for each period.

---

### Volume Weighted Moving Average (VWMA)

The **Volume Weighted Moving Average (VWMA)** is a technical indicator that averages price data with an emphasis on volume, meaning areas with higher volume will have a greater influence on the average. It is calculated using the formula:

```
VWMA = Sum(Price * Volume) / Sum(Volume) for a given Period.
```

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const closings = [...]; // an array of closing prices
const volumes = [...]; // an array of corresponding volumes
const vwmaDefault = indicators.vwma(closings, volumes);
// The default configuration uses a period of 20.

console.log(vwmaDefault);
// Use the return value for trading decisions, for instance:
if (vwmaDefault[i] > closings[i]) {
  // ... bullish signal
} else {
  // ... bearish signal
}
```

// Example 2: Using custom parameters
```javascript
const vwmaCustom = indicators.vwma(closings, volumes, { period: 3 });
// Here we explicitly set the period for the VWMA calculation.

console.log(vwmaCustom);
// Similar to above, you can make decisions based on the custom indicator output:
if (vwmaCustom[i] > closings[i]) {
  // ... action for bullish trend
} else {
  // ... action for bearish trend
}
```

In both examples, the VWMA returns an array of calculated moving averages over the specified period, which can be used to gauge market trends based on volume-weighted prices. The value comparisons (e.g., with current closing prices) help in making trading decisions based on potential bullish or bearish signals.

---

### Vortex Indicator

The Vortex Indicator provides two oscillators that capture positive and negative trend movement. A bullish signal is indicated when the positive trend indicator crosses above the negative trend indicator, while a bearish signal occurs when the negative trend crosses above the positive trend.

#### Formulae:
- +VM = Abs(Current High - Prior Low)
- -VM = Abs(Current Low - Prior High)
- +VM14 = 14-Period Sum of +VM
- -VM14 = 14-Period Sum of -VM
- TR = Max((High - Low), Abs(High - Previous Closing), Abs(Low - Previous Closing))
- TR14 = 14-Period Sum of TR
- +VI14 = +VM14 / TR14
- -VI14 = -VM14 / TR14

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const highs = [...]; // array of high values
const lows = [...]; // array of low values
const closings = [...]; // array of closing values

const vortexDefault = indicators.vortex(highs, lows, closings);
// The default period is 14
console.log(vortexDefault);
// Use the return value to interpret trends:
if (vortexDefault.plus[i] > vortexDefault.minus[i]) {
  // ... bullish signal detected
} else {
  // ... bearish signal detected
}
```

// Example 2: Using custom parameters
```javascript
const vortexCustom = indicators.vortex(highs, lows, closings, { period: 9 });
// This uses a custom period of 9
console.log(vortexCustom);
// Similarly, use the return value to interpret trends:
if (vortexCustom.plus[i] > vortexCustom.minus[i]) {
  // ... bullish signal detected
} else {
  // ... bearish signal detected
}
```

In both examples, the output structure will provide you with two arrays: `plus` and `minus`, representing the positive and negative trend indicators, respectively. Use these values to determine potential bullish or bearish signals based on their comparative values.

---

### Acceleration Bands (AB)

The `accelerationBands` function plots upper and lower envelope bands around a simple moving average. It calculates the following:

- **Upper Band** = SMA(High * (1 + 4 * (High - Low) / (High + Low)))
- **Middle Band** = SMA(Closing)
- **Lower Band** = SMA(Low * (1 - 4 * (High - Low) / (High + Low)))

The default configuration for the `accelerationBands` function is:
- `period`: 20
- `multiplier`: 4

```javascript
// Example 1: Using default parameters
const highs = [...]; // an array of high prices
const lows = [...]; // an array of low prices
const closings = [...]; // an array of closing prices

const abDefault = indicators.ab(highs, lows, closings);
// Example output structure
const { upper, middle, lower } = abDefault;

// Process the output to make trading decisions. 
if (abDefault.upper[i] < prices[i]) {
  // ... long/buy signal
} else {
  // ... short/sell signal
}

// Example 2: Using custom parameters
const customConfig = { period: 9, multiplier: 3 }; // custom period and multiplier
const abCustom = indicators.ab(highs, lows, closings, customConfig);
// Process the output to make trading decisions.
if (abCustom.lower[i] > prices[i]) {
  // ... action for negative signal
} else {
  // ... action for positive signal
}
```

In the examples above, replace `prices[i]` with the current price you're evaluating against the calculated bands for your trading decisions.

---

### Average True Range (ATR)

The `averageTrueRange` function allows you to measure market volatility by analyzing stock price movements over a defined period. It computes the True Range (TR) and then calculates the Average True Range (ATR) based on the TR. 

**Default parameters:** The default configuration uses a period of 14.

```javascript
// Example 1: Using default parameters
const highs = [...]; // an array of high prices
const lows = [...]; // an array of low prices
const closings = [...]; // an array of closing prices

const atrDefault = indicators.atr(highs, lows, closings);
// atrDefault contains two arrays: trLine and atrLine
console.log(atrDefault.trLine); // Array of True Range values
console.log(atrDefault.atrLine); // Array of Average True Range values
// Utilize the ATR values to inform trading strategies.
// Example condition (adjust based on requirements):
if (atrDefault.atrLine[i] > threshold) {
  // ... action for high volatility
} else {
  // ... action for low volatility
}

// Example 2: Using custom parameters
const atrCustom = indicators.atr(highs, lows, closings, { period: 9 });
// atrCustom also contains trLine and atrLine based on the custom period.
console.log(atrCustom.trLine); // True Range values for the custom period
console.log(atrCustom.atrLine); // Average True Range values for the custom period
// Decision-making can be applied similarly:
if (atrCustom.atrLine[i] > threshold) {
  // ... action for higher than expected volatility
} else {
  // ... action for expected stability
}
``` 

With the above examples, you can easily compute the ATR for your trading strategies using both default and custom parameters.

---

### Bollinger Bands (BB)

The **Bollinger Bands** indicator calculates the upper, middle, and lower bands which help identify overbought or oversold conditions in the market. The bands are based on a moving average (the middle band) and standard deviations (the upper and lower bands). 

The default configuration uses a period of **20**.

#### Usage Examples:

```javascript
// Example 1: Using default parameters
const closings = [...]; // an array of closing prices
const bbDefault = indicators.bb(closings);
// The returned structure contains:
const upperBands = bbDefault.upper;  // Upper band values
const middleBands = bbDefault.middle; // Middle band (SMA) values
const lowerBands = bbDefault.lower;   // Lower band values

// You can use these values to make trading decisions, e.g.,
// if (closings[i] > upperBands[i]) {
//   // ... market may be overbought (short signal)
// } else if (closings[i] < lowerBands[i]) {
//   // ... market may be oversold (long signal)
// }

// Example 2: Using custom parameters
const customConfig = { period: 14 }; // Setting a custom period of 14
const bbCustom = indicators.bb(closings, customConfig);
// Output structure remains the same:
// const upperBands = bbCustom.upper;
// const middleBands = bbCustom.middle;
// const lowerBands = bbCustom.lower;

// Similarly, use the return values for decisions,
// if (closings[i] > upperBands[i]) {
//   // ... action for overbought condition
// } else if (closings[i] < lowerBands[i]) {
//   // ... action for oversold condition
// }
```

This documentation provides you with clear examples on how to use the `bb` function to compute Bollinger Bands, whether with default settings or custom parameters.

---

### Bollinger Band Width (BBW)

The Bollinger Band Width (BBW) measures the percentage difference between the upper and lower Bollinger Bands. It narrows during periods of low market volatility and widens during periods of high volatility.

#### Function Signature
```javascript
// Importing the function
import { bbw } from 'indicatorts';
```

**Return Structure:** The function returns an object containing:
- `width`: An array of the calculated band width values.
- `widthEma`: An array of the calculated Exponential Moving Average (EMA) of the band width.

#### Example 1: Using Default Parameters
```javascript
const closings = [...]; // an array of closing prices
const bbResult = indicators.bb(closings); // Default period: 20
const bbwDefault = indicators.bbw(bbResult);
// Use the returned width values from the BBW.
console.log(bbwDefault.width); // This logs the width values based on default settings
```

#### Example 2: Using Custom Parameters
```javascript
const closings = [...]; // an array of closing prices
const bbResult = indicators.bb(closings, { period: 14 }); // Custom period: 14
const bbwCustom = indicators.bbw(bbResult, { period: 90 });
// Use the returned width values with custom configuration.
console.log(bbwCustom.width); // This logs the width values based on the custom period
```

Make sure to explore different input data for `closings` and adjust the parameters to see how they impact the Bollinger Bands Width!

---

### Chandelier Exit (CE)

The Chandelier Exit indicator sets a trailing stop-loss based on the Average True Range (ATR). It helps traders identify exit points in trends by calculating long and short exit levels.

**Default Parameters:** The default configuration for the Chandelier Exit uses a `period` of `22`.

```javascript
// Example 1: Using default parameters
const highs = [...]; // an array of high prices
const lows = [...]; // an array of low prices
const closings = [...]; // an array of closing prices

const ceDefault = indicators.ce(highs, lows, closings);
// The default period is used here, which is 22.
// The return value contains long and short exit levels.
const { long, short } = ceDefault;

// Use the return value to make decisions
if (currentPrice < long[i]) {
  // ... consider long exit
} else if (currentPrice > short[i]) {
  // ... consider short exit
}

// Example 2: Using custom parameters
const ceCustom = indicators.ce(highs, lows, closings, { period: 14 });
// Here we are using a custom period of 14.
const { long: customLong, short: customShort } = ceCustom;

// Use the return value to make decisions with custom settings
if (currentPrice < customLong[i]) {
  // ... consider long exit with custom parameters
} else if (currentPrice > customShort[i]) {
  // ... consider short exit with custom parameters
}
```

In both examples, the `long` and `short` arrays return the calculated exit points based on the provided high, low, and closing prices, which can be used to inform trading decisions. Adjust the `period` parameter as needed to fit your trading strategy.

---

### Donchian Channel (DC)

The **Donchian Channel** (DC) calculates three lines: the upper band, lower band, and middle band, which represent the highest and lowest asset prices over a specified period. This indicator helps traders identify potential breakouts and trend reversals.

#### Function Return Structure

The function returns an object containing three arrays:
- **upper:** An array of upper band values.
- **middle:** An array of middle band values.
- **lower:** An array of lower band values.

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const closings = [...]; // an array of closing prices
const { upper, middle, lower } = indicators.dc(closings);
// Default parameters: period is set to 4.
// Use the return value for decision-making.
if (closings[i] > upper[i]) {
  // ... potential breakout above upper band
} else if (closings[i] < lower[i]) {
  // ... potential breakdown below lower band
}
```

// Example 2: Using custom parameters
```javascript
const closings = [...]; // an array of closing prices
const customConfig = { period: 8 };
const { upper, middle, lower } = indicators.dc(closings, customConfig);
// Using a custom period of 8.
// Utilize the return value for trading signals.
if (closings[i] > upper[i]) {
  // ... action for breakout above upper band
} else if (closings[i] < lower[i]) {
  // ... action for breakdown below lower band
}
```

In these examples, you can see how to invoke the Donchian Channel function with both default and custom parameters while utilizing the returned values for trading decisions.

---

### Keltner Channel (KC)

The Keltner Channel (KC) provides volatility-based bands that are placed on either side of an asset's price and can aid in determining the direction of a trend.

**Default Parameters:** The default configuration uses a period of 20 days.

```javascript
// Example 1: Using default parameters
const highs = [...];   // an array of high values
const lows = [...];    // an array of low values
const closings = [...]; // an array of closing values

const kcDefault = indicators.kc(highs, lows, closings);
// The returned object contains:
// - kcDefault.middle: Array of middle line values
// - kcDefault.upper: Array of upper band values
// - kcDefault.lower: Array of lower band values

// Use the return value to make decisions related to market trends
if (kcDefault.middle[i] > kcDefault.upper[i]) {
  // ... potential sell signal
} else if (kcDefault.middle[i] < kcDefault.lower[i]) {
  // ... potential buy signal
}

// Example 2: Using custom parameters
const kcCustom = indicators.kc(highs, lows, closings, { period: 14 });
// The returned object will still contain:
// - kcCustom.middle: Array of middle line values
// - kcCustom.upper: Array of upper band values
// - kcCustom.lower: Array of lower band values

// Use the return value for decision making
if (kcCustom.middle[i] > kcCustom.upper[i]) {
  // ... potential sell signal
} else if (kcCustom.middle[i] < kcCustom.lower[i]) {
  // ... potential buy signal
}
```
In this documentation, you can effectively use the Keltner Channel indicator with either the default configuration or customize the parameters as needed. Make sure to adapt your trading signal logic based on the unique insights provided by the Keltner Channel outputs.

---

### Moving Standard Deviation (MSTD)

The `movingStandardDeviation` function calculates the moving standard deviation for a given period, which indicates the volatility of a dataset across time.

#### Function Return Structure
The function returns an array of numbers, where each number represents the moving standard deviation calculated at each point based on the input values.

```javascript
const values = [...]; // an array of numbers representing the dataset
```

#### Usage Examples

// Example 1: Using default parameters
```javascript
const mstdDefault = indicators.mstd(values);
// The default parameter is: { period: 4 }

// Process the results. Typically, you would analyze how the standard deviation values shift over time.
for (let i = 0; i < mstdDefault.length; i++) {
  console.log(`Standard Deviation at index ${i}:`, mstdDefault[i]);
}
```

// Example 2: Using custom parameters
```javascript
const customConfig = { period: 2 };
const mstdCustom = indicators.mstd(values, customConfig);
// We are using a custom period of 2

// Similar to above, analyze the computed standard deviations.
for (let i = 0; i < mstdCustom.length; i++) {
  console.log(`Custom Standard Deviation at index ${i}:`, mstdCustom[i]);
}
```

These examples illustrate how to invoke the `movingStandardDeviation` function with both default and custom parameters, making it easier to adjust the calculation based on user needs.

---

### Projection Oscillator (PO)

The Projection Oscillator (PO) calculates the oscillator using the linear regression slope, along with highs and lows. The PO adjusts based on the defined period and uses a smoothed version to generate the SPO.

```javascript
// Example 1: Using default parameters
const highs = [...]; // an array of high prices
const lows = [...];  // an array of low prices
const closings = [...]; // an array of closing prices

const poDefault = indicators.po(highs, lows, closings);
// The default parameters for PO are period: 14 and smooth: 3.
// Use the return value to make a decision about market conditions.
if (poDefault.poResult[i] > 100) {
  // ... potential buy signal
} else {
  // ... potential sell signal
}

// Example 2: Using custom parameters
const poCustom = indicators.po(highs, lows, closings, { period: 9, smooth: 2 });
// Custom parameters allow for finer tuning of the calculation.
if (poCustom.poResult[i] > 100) {
  // ... action for a strong upward price movement
} else {
  // ... action for a probability of a bearish trend
}
```

In the examples, the returned structure contains `poResult` for the main oscillator values and `spoResult` for the smoothed values. Adjust the logic based on your trading strategy and threshold criteria.

---

### True Range (TR)

The `trueRange` function calculates the True Range (TR) for a given period, which is a measurement of volatility in financial markets.

**Formula:**
```
TR = Max((High - Low), Abs(High - Closing[-1]), Abs(Low - Closing[-1]))
```

#### Usage Examples:

// Example 1: Using default parameters
```javascript
// Sample input arrays
const highs = [...]; // an array of high prices
const lows = [...]; // an array of low prices
const closings = [...]; // an array of closing prices

const trDefault = indicators.trueRange(highs, lows, closings);
// The return value will be an array containing TR values for each period.
console.log(trDefault); // Display the calculated True Range values

// Decision making based on the True Range value
if (trDefault[i] > some_threshold) {
  // ... indicate high volatility
} else {
  // ... indicate low volatility
}
```

// Example 2: TRUE RANGE does not support custom parameters as it calculates based on input arrays only.
```javascript
const trCustom = indicators.trueRange(highs, lows, closings);
// Use the return value for decision making
console.log(trCustom); // Display the calculated True Range values
if (trCustom[i] > some_threshold) {
  // ... indicate high volatility
} else {
  // ... indicate low volatility
}
```

In the above examples, you can see how to invoke the `trueRange` function with necessary input parameters to analyze price volatility in the market. The TR values can be used to make informed trading decisions by assessing market conditions.

---

### Ulcer Index (UI)

The **Ulcer Index (UI)** measures downside risk. The index increases in value as the price moves farther away from a recent high and decreases as the price rises to new highs.

#### Function Signature
```javascript
ui(closings, config = {});
```
- `closings`: An array of closing prices.
- `config`: An optional configuration object that allows customization of the calculation. The available configuration parameter is:
  - `period` (default is 14)

#### Example 1: Using Default Parameters
To use the Ulcer Index with the default parameters, simply call the function without passing the configuration object.

```javascript
const closings = [...]; // an array of closing prices
const uiDefault = ui(closings); // no config passed, default period of 14 will be used
console.log(uiDefault); // Output: an array representing the Ulcer Index values
```
In this example, the index will be calculated using the default period of 14.

#### Example 2: Using Custom Parameters
You can customize the computation of the Ulcer Index by providing a specific period. For instance, if you want to calculate it with a period of 8:

```javascript
const closings = [...]; // an array of closing prices
const uiCustom = ui(closings, { period: 8 }); // custom period of 8
console.log(uiCustom); // Output: an array representing the Ulcer Index values for period 8
```
In this example, we are calculating the Ulcer Index using a period of 8, which alters the sensitivity of the index's response to price movements.

Using the results from both methods, you can evaluate market risks based on past performance and make informed trading decisions.

---

### Accumulation/Distribution (A/D)

The Accumulation/Distribution (A/D) indicator is a cumulative metric that employs both volume and price movements to evaluate whether a stock is being accumulated or distributed. The A/D indicator aims to identify divergences between stock price and volume flow.

#### Formula:
- MFM = ((Closing - Low) - (High - Closing)) / (High - Low)
- MFV = MFM * Period Volume
- AD = Previous AD + MFV

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const highs = [...]; // an array of high prices
const lows = [...]; // an array of low prices
const closings = [...]; // an array of closing prices
const volumes = [...]; // an array of volumes

const adDefault = indicators.ad(highs, lows, closings, volumes);
// The default configuration has no additional parameters here.

// Decision-making based on the result:
if (adDefault[i] > 0) {
  // ... long/buy signal
} else {
  // ... short/sell signal
}
```

// Example 2: Using custom parameters
```javascript
const adCustom = indicators.ad(highs, lows, closings, volumes, { /* custom parameters */ });
// This indicator does not require custom parameters for its computation, but you may pass an empty object.

if (adCustom[i] > 0) {
  // ... action for accumulation
} else {
  // ... action for distribution
}
```

#### Return Structure:
The A/D function returns an array of numeric values representing the cumulative A/D calculation for each period based on the input closing prices and volumes. For example:
```javascript
console.log(adDefault); // Output: [...]; // e.g., [50, 650, -50, -1250, -2750]
```

Make use of the output to gauge market sentiment and make informed trading decisions.

---

### Chaikin Money Flow (CMF)

The **Chaikin Money Flow (CMF)** measures the amount of money flow volume over a given period, combining price action and volume to indicate the buying or selling pressure.

#### Function Structure
The `cmf` function requires the following parameters:
- `highs`: An array of high prices.
- `lows`: An array of low prices.
- `closings`: An array of closing prices.
- `volumes`: An array of volumes.
- `config`: (Optional) A configuration object where you can specify the period (default is 20).

#### Example 1: Using Default Parameters
```javascript
const highs = [...]; // an array of high prices
const lows = [...]; // an array of low prices
const closings = [...]; // an array of closing prices
const volumes = [...]; // an array of volumes

// Use the Chaikin Money Flow with default parameters
const cmfDefault = indicators.cmf(highs, lows, closings, volumes);
// Default period: 20

// Use the return value to make a trading decision
if (cmfDefault[i] > 0) {
  // Bullish signal - consider buying
} else {
  // Bearish signal - consider selling
}
```

#### Example 2: Using Custom Parameters
```javascript
const highs = [...]; // an array of high prices
const lows = [...]; // an array of low prices
const closings = [...]; // an array of closing prices
const volumes = [...]; // an array of volumes

// Use the Chaikin Money Flow with a custom period
const customConfig = { period: 14 };
const cmfCustom = indicators.cmf(highs, lows, closings, volumes, customConfig);

// Use the return value to make a trading decision
if (cmfCustom[i] > 0) {
  // Bullish signal - consider buying
} else {
  // Bearish signal - consider selling
}
```

This concise setup provides a clear understanding of how to implement the CMF in your trading strategies using this indicator.

---

### Ease of Movement (EMV)

The **Ease of Movement (EMV)** is a volume-based oscillator that measures the ease of price movement. It provides insights into price trends based on both price and volume data, indicating how easily prices are moving up or down.

#### Usage Examples:

```javascript
const highs = [...]; // Array of high prices
const lows = [...];  // Array of low prices
const volumes = [...]; // Array of volume data

// Example 1: Using default parameters
const emvDefault = indicators.emv(highs, lows, volumes);
// By default, the period is set to 14
if (emvDefault[i] > 0) {
  // ... potential upward movement signal
} else {
  // ... potential downward movement signal
}

// Example 2: Using custom parameters
const emvCustom = indicators.emv(highs, lows, volumes, { period: 20 });
// Here, a custom period of 20 is specified
if (emvCustom[i] > 0) {
  // ... action for positive EMV
} else {
  // ... action for negative EMV
}
```

### Return Structure:
The **emv** function returns an array of values representing the Ease of Movement for each time period, calculated based on the specified high, low, and volume data. For instance:

- **For default parameters:** 
  ```javascript
  console.log(emvDefault); // Output: [... calculated values ...]
  ```

- **For custom parameters (period: 20):**
  ```javascript
  console.log(emvCustom); // Output: [... calculated values based on 20 period ...]
  ```

This documentation provides a quick guide on how to utilize the EMV indicator effectively, allowing you to make informed trading decisions based on price and volume trends.

---

### Force Index (FI)

The Force Index (FI) uses closing prices and volume to assess the strength behind price movements and to identify potential turning points.

**Return Structure:**
The `fi` function returns an array of numbers representing the calculated Force Index values over the specified period. 

```javascript
// Example 1: Using default parameters
const closings = [...]; // an array of closing prices
const volumes = [...]; // an array of volume values
const fiDefault = indicators.fi(closings, volumes); // Default period is 13
// The fiiDefault array contains Force Index values based on the closing prices and volumes 

if (fiDefault[i] > 0) {
  // ... consider a bullish action if the Force Index indicates strength
} else {
  // ... consider a bearish action if the Force Index indicates weakness
}

// Example 2: Using custom parameters
const fiCustom = indicators.fi(closings, volumes, { period: 1 }); // Custom period set to 1
// The fiCustom array will provide more sensitive Force Index values due to the shorter period

if (fiCustom[i] > 0) {
  // ... continue with bullish strategy as indicated
} else {
  // ... consider a bearish strategy if the Force Index values are negative
}
```

This example demonstrates how to utilize the Force Index indicator with both default and custom parameters, along with the possible actions based on the computed values.

---

### Money Flow Index (MFI)

The Money Flow Index (MFI) is a momentum indicator that uses both price and volume to identify overbought or oversold conditions in the market. It's similar to the Relative Strength Index (RSI) but incorporates volume into the calculation.

#### Usage Examples:

```javascript
// Example 1: Using default parameters
const highs = [...]; // an array of high prices
const lows = [...]; // an array of low prices
const closings = [...]; // an array of closing prices
const volumes = [...]; // an array of trading volumes

const mfiDefault = indicators.mfi(highs, lows, closings, volumes);
// The default configuration uses a period of 14.
// Resulting MFI values can be used to identify overbought (above 80) or oversold (below 20) conditions.
if (mfiDefault[i] > 80) {
  // ... overbought condition
} else if (mfiDefault[i] < 20) {
  // ... oversold condition
}

// Example 2: Using custom parameters
const customMFIConfig = { period: 2 };
const mfiCustom = indicators.mfi(highs, lows, closings, volumes, customMFIConfig);
// Here, we've set the period to 2 for faster signals.
if (mfiCustom[i] > 80) {
  // ... overbought condition for custom settings
} else if (mfiCustom[i] < 20) {
  // ... oversold condition for custom settings
}
```

### Return Structure
The `mfi` function returns an array of Money Flow Index values corresponding to each closing price. For example, given input arrays, a sample output might look like this:
```javascript
const exampleOutput = [100, 100, 70.95, 81.38, 66.46]; // Demonstrating the MFI values for respective periods.
```
These values can be analyzed to guide trading decisions based on market conditions.

---

### Negative Volume Index (NVI)

The **Negative Volume Index (NVI)** is a cumulative indicator that uses the change in volume to assess when "smart money" is active. Based on volume and closing prices, it can provide insights into potential price movements.

The formula is as follows:
- If the current volume is greater than the previous volume:
  ```
  NVI = Previous NVI
  ```
- Otherwise:
  ```
`
  NVI = Previous NVI + (((Closing - Previous Closing) / Previous Closing) * Previous NVI)
  ```

#### Usage Examples

// Example 1: Using default parameters
```javascript
const closings = [...]; // an array of closing prices
const volumes = [...]; // an array of volumes
const nviDefault = indicators.nvi(closings, volumes);
// Default parameters: start = 1000, period = 255

// Decision making based on NVI values
if (nviDefault[i] > nviDefault[i-1]) {
  // ... indicate smart money is active (potential buy)
} else {
  // ... indicate smart money is inactive (potential sell or hold)
}
```

// Example 2: Using custom parameters
```javascript
const nviCustom = indicators.nvi(closings, volumes, { start: 500, period: 10 });
// Custom parameters: start = 500, period = 10

// Decision making based on custom NVI values
if (nviCustom[i] > nviCustom[i-1]) {
  // ... indicate smart money is active (potential buy)
} else {
  // ... indicate smart money is inactive (potential sell or hold)
}
```

By following this documentation, you can leverage the NVI indicator for enhanced trading decisions based on volume trends.

---

### On-Balance Volume (OBV)

The On-Balance Volume (OBV) is a technical trading momentum indicator that uses volume flow to predict changes in stock price.

#### Function Signature:
```javascript
obv(closings, volumes)
```
- `closings`: An array of closing prices.
- `volumes`: An array of corresponding volume values.

#### Return Structure:
The function returns an array of OBV values, where each value represents the cumulative volume at that point in time based on price movements.

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const closings = [...]; // an array of closing prices
const volumes = [...];   // an array of volume values
const obvDefault = indicators.obv(closings, volumes);

// Use the return value to make a decision based on OBV trends
if (obvDefault[i] > obvDefault[i - 1]) {
  // ... bullish signal, consider buying
} else {
  // ... bearish signal, consider selling
}
```

// Example 2: Using custom parameters
(Note: The OBV function does not support custom parameters. This example is just for demonstration purposes.)
```javascript
const obvCustom = indicators.obv(closings, volumes, { customParam: true });
// The usage would be similar to above; however, `obv` currently does not accept any options.
```

In the implementation provided, ***custom parameters are not required*** for the OBV function. The default behavior suffices for the calculations, making it convenient for users who seek quick insights without complex configurations. Use the OBV results to guide trading decisions based on volume pressure associated with price changes.

---

### Volume Price Trend (VPT)

The **Volume Price Trend (VPT)** provides a correlation between volume and price, allowing traders to assess how volume influences price movement. The formula for calculating VPT is as follows:

```
VPT = Previous VPT + (Volume * (Current Closing - Previous Closing) / Previous Closing)
```

#### Usage Examples:

// Example 1: Using default parameters
```javascript
const closings = [...]; // An array of closing prices
const volumes = [...]; // An array of corresponding volumes
const vptDefault = indicators.vpt(closings, volumes);
// Example of interpreting VPT values
if (vptDefault[i] > 0) {
  // VPT increased; potential buy signal
} else {
  // VPT decreased; potential sell signal
}
```

// Example 2: Using custom parameters (NOTE: VPT does not support custom parameters)
```javascript
// VPT function does not take custom parameters, use it as shown above
const vptCustom = indicators.vpt(closings, volumes);
// Use the same logic as above for interpretation
if (vptCustom[i] > 0) {
  // VPT increased; potential buy signal
} else {
  // VPT decreased; potential sell signal
}
```

**Note:** The VPT function does not have configurable parameters, but it can be used effectively by providing arrays of closing prices and corresponding volumes. The return value is an array of VPT values, which can guide trading decisions based on the trends observed.

---

### Volume Weighted Average Price (VWAP)

The Volume Weighted Average Price (VWAP) provides the average price at which an asset has traded, weighted by volume.

**Formula:**
```
VWAP = Sum(Closing * Volume) / Sum(Volume)
```

#### Usage Examples:

```javascript
// Example 1: Using default parameters
const closings = [...]; // an array of closing prices
const volumes = [...];   // an array of corresponding volumes
const vwapDefault = indicators.vwap(closings, volumes);
// The default parameters are: { period: 14 }

// Use the return value to make a decision
if (vwapDefault[i] > closings[i]) {
  // ... signal to sell, as price is above VWAP
} else {
  // ... signal to buy, as price is below VWAP
}

// Example 2: Using custom parameters
const vwapCustom = indicators.vwap(closings, volumes, { period: 2 });
// period is set to 2 for a shorter-term average

// Same as above, use the return value to make a decision
if (vwapCustom[i] > closings[i]) {
  // ... signal to sell, as price is above VWAP
} else {
  // ... signal to buy, as price is below VWAP
}
```

The `vwap` function returns an array of VWAP values corresponding to the input closing prices, which can be used for making trading decisions based on the price's relation to VWAP.
