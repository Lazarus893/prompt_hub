package sdkhub

import (
	"context"
	"encoding/xml"
	"errors"
	"fmt"
	"io/fs"
	"math"
	"os"
	"path"
	"sort"
	"strings"
)

var ErrNoSDKFound = errors.New("no SDK found")

const (
	MDDocSeparator = "\n---\n"
)

// Build flags for enabling specific module prefixes
const (
	BuildFlagIncludeArraysInternal = "--include-arrays-internal"
	BuildFlagIncludeTestUtils      = "--include-test-utils"
)

const (
	testUtilsPrefix      = "@test/"
	arraysInternalPrefix = "@arrays/internal/"
)

// disabledByDefaultPrefixes defines module prefixes that are disabled by default.
// These modules will only be loaded if a specific build flag enables them.
var disabledByDefaultPrefixes = []string{
	testUtilsPrefix,
	arraysInternalPrefix,
}

// buildFlagToPrefixes maps build flags to the set of module prefixes they enable.
// When a build flag is provided, modules matching any of its prefixes will be included.
var buildFlagToPrefixes = map[string][]string{
	BuildFlagIncludeArraysInternal: {
		arraysInternalPrefix,
	},
	BuildFlagIncludeTestUtils: {
		testUtilsPrefix,
	},
}

type SDKUpdater interface {
	UpdateSDK(ctx context.Context, name string, doc string, code string, isPublic bool) error
}

type sdkSet map[*SDK]struct{}

func (s sdkSet) add(sdk *SDK) {
	s[sdk] = struct{}{}
}

// SDKHub is an instance that holds all the SDKs.
type SDKHub struct {
	// modules["@org/[namespace]*/module_name:v0.1.0"] = *SDK
	modules        map[string]*SDK
	xmlDoc         string
	mdDoc          string
	maxModuleBytes int               // Maximum size of any single module in markdown format
	invertedIndex  map[string]sdkSet // word -> SDKs that contain this word
}

func (h *SDKHub) buildInvertedIndex() error {
	h.invertedIndex = make(map[string]sdkSet)
	for fullName, sdk := range h.modules {
		spec, err := ParseModuleSpec(fullName)
		if err != nil {
			return fmt.Errorf("failed to parse module spec: %w", err)
		}
		words := append([]string{spec.Org}, append(spec.Namespaces, spec.ModuleName)...)
		for _, key := range words {
			key = strings.ToLower(strings.TrimSpace(key))
			if key == "" {
				continue
			}
			set, ok := h.invertedIndex[key]
			if !ok {
				set = make(sdkSet)
				h.invertedIndex[key] = set
			}
			set.add(sdk)
		}
	}
	return nil
}

// Update updates the SDKs with the given SDKUpdater.
func (h *SDKHub) Update(cli SDKUpdater) error {
	for _, sdk := range h.modules {
		err := cli.UpdateSDK(context.Background(), sdk.name, sdk.doc, sdk.code, true)
		if err != nil {
			return fmt.Errorf("failed to update SDK %s: %w", sdk.name, err)
		}
	}
	return nil
}

// GetXMLDoc returns the XML documentation for all SDKs.
func (h *SDKHub) GetXMLDoc() string {
	return h.xmlDoc
}

// GetMDDoc returns the Markdown documentation for all SDKs.
func (h *SDKHub) GetMDDoc() string {
	return h.mdDoc
}

// GetMaxModuleBytes returns the maximum size of any single module in markdown format.
func (h *SDKHub) GetMaxModuleBytes() int {
	return h.maxModuleBytes
}

// GetModule returns the SDK for the given FullNameWithVersion.
func (h *SDKHub) GetModule(fullNameWithVersion string) (*SDK, error) {
	sdk, ok := h.modules[fullNameWithVersion]
	if !ok {
		return nil, fmt.Errorf("module %s not found", fullNameWithVersion)
	}
	return sdk, nil
}

// GetModuleFuzzy returns the top N SDKs for the given fullNameWithVersion using fuzzy search.
// The fuzzy search is based on the inverted index.
func (h *SDKHub) GetModuleFuzzy(fullNameWithVersion string, topN int) ([]*SDK, error) {
	if len(h.modules) == 0 {
		return nil, fmt.Errorf("no modules found in hub")
	}
	if topN <= 0 {
		topN = 1
	}
	if topN > len(h.modules) {
		topN = len(h.modules)
	}

	queryWithoutVersion := strings.Split(fullNameWithVersion, ":")[0]
	queryWithoutVersion = strings.TrimPrefix(queryWithoutVersion, "@")
	raw := strings.Split(queryWithoutVersion, "/")

	// normalize and deduplicate terms
	seen := make(map[string]struct{}, len(raw))
	terms := make([]string, 0, len(raw))
	for _, t := range raw {
		t = strings.ToLower(strings.TrimSpace(t))
		if t == "" {
			continue
		}
		if _, ok := seen[t]; !ok {
			seen[t] = struct{}{}
			terms = append(terms, t)
		}
	}

	N := float64(len(h.modules))
	sdkScores := make(map[*SDK]float64, len(h.modules))

	for _, term := range terms {
		set, ok := h.invertedIndex[term]
		if !ok || len(set) == 0 {
			continue
		}
		df := float64(len(set))
		idf := 1.0 + math.Log((N+1.0)/(df+1.0))
		for sdk := range set {
			sdkScores[sdk] += idf
		}
	}

	// fallback: no matches -> return modules sorted by Name
	if len(sdkScores) == 0 {
		sdks := h.Modules()
		if len(sdks) > topN {
			sdks = sdks[:topN]
		}
		return sdks, nil
	}

	// sort sdks by score desc, then by name asc for deterministic order
	sdks := make([]*SDK, 0, len(sdkScores))
	for sdk := range sdkScores {
		sdks = append(sdks, sdk)
	}
	sort.Slice(sdks, func(i, j int) bool {
		si, sj := sdkScores[sdks[i]], sdkScores[sdks[j]]
		if si == sj {
			return sdks[i].Name() < sdks[j].Name()
		}
		return si > sj
	})
	if len(sdks) > topN {
		sdks = sdks[:topN]
	}
	return sdks, nil
}

// GetModuleWithDefaultVersion returns the SDK for the given name with the default version.
func (h *SDKHub) GetModuleWithDefaultVersion(name string) (*SDK, error) {
	// This will parse the name and add the default version if not provided.
	spec, err := ParseModuleSpec(name)
	if err != nil {
		return nil, fmt.Errorf("failed to parse module spec: %w", err)
	}
	return h.GetModule(spec.FullNameWithVersion())
}

// Modules returns all SDKs stored in the hub sorted by name.
func (h *SDKHub) Modules() []*SDK {
	modules := make([]*SDK, 0, len(h.modules))
	for _, sdk := range h.modules {
		modules = append(modules, sdk)
	}
	sort.Slice(modules, func(i, j int) bool {
		return modules[i].Name() < modules[j].Name()
	})
	return modules
}

// GenerateMarkdownDocs generates formatted markdown documentation for the given SDK IDs
func (h *SDKHub) GenerateMarkdownDocs(sdkIds []string) (string, error) {
	var sb strings.Builder
	sb.WriteString("## SDK Docs\n\n")

	includedSDKs := make([]string, 0, len(sdkIds))

	for _, sdkId := range sdkIds {
		// Skip empty SDK IDs
		if strings.TrimSpace(sdkId) == "" {
			continue
		}

		sdk, err := h.GetModuleWithDefaultVersion(strings.TrimSpace(sdkId))
		if err != nil {
			// Fallback to fuzzy search if exact match fails
			fuzzyMatches, fuzzyErr := h.GetModuleFuzzy(strings.TrimSpace(sdkId), 1)
			if fuzzyErr != nil || len(fuzzyMatches) == 0 {
				return "", fmt.Errorf("failed to get module %s: %w", sdkId, err)
			}
			sdk = fuzzyMatches[0]
		}

		// Skip SDKs with empty documentation
		if sdk.Doc() == "" {
			continue
		}

		sb.WriteString(formatSDKDoc(sdk.Name(), sdk.Doc()))
		sb.WriteString("\n")
		includedSDKs = append(includedSDKs, sdk.Name())
	}

	result := finalizeWithSDKSummary(sb.String(), includedSDKs)
	return result, nil
}

// GetModulesByDiv groups SDK modules into divisions based on byte size limit.
func (h *SDKHub) GetModulesByDiv(divMaxBytes int) (int, []string, error) {
	if divMaxBytes <= 0 {
		return 0, nil, fmt.Errorf("divMaxBytes must be positive, got %d", divMaxBytes)
	}

	if len(h.modules) == 0 {
		return 0, nil, fmt.Errorf("no modules found in hub")
	}

	if divMaxBytes < h.maxModuleBytes {
		return 0, nil, fmt.Errorf(
			"divMaxBytes (%d) must be at least %d to accommodate largest module",
			divMaxBytes,
			h.maxModuleBytes,
		)
	}

	sortedModules := h.Modules()

	var divisions []string
	var currentDiv strings.Builder
	currentDivSDKs := make([]string, 0, 10)
	currentSize := 0
	moduleCount := 0

	for _, sdk := range sortedModules {
		// Skip SDKs with empty documentation
		if sdk.Doc() == "" {
			continue
		}

		var moduleBuilder strings.Builder

		if moduleCount > 0 {
			moduleBuilder.WriteString(MDDocSeparator)
		}

		moduleBuilder.WriteString(formatSDKDoc(sdk.Name(), sdk.Doc()))

		moduleContent := moduleBuilder.String()
		moduleSize := len(moduleContent)

		// Check if adding this module would exceed the limit
		if currentSize > 0 && currentSize+moduleSize > divMaxBytes {
			finalizedDiv := finalizeWithSDKSummary(currentDiv.String(), currentDivSDKs)
			divisions = append(divisions, finalizedDiv)

			currentDiv.Reset()
			currentDivSDKs = make([]string, 0, 10) // Reset with pre-allocation
			currentSize = 0
			moduleCount = 0

			moduleBuilder.Reset()
			moduleBuilder.WriteString(formatSDKDoc(sdk.Name(), sdk.Doc()))
			moduleContent = moduleBuilder.String()
			moduleSize = len(moduleContent)
		}

		currentDiv.WriteString(moduleContent)
		currentDivSDKs = append(currentDivSDKs, sdk.Name())
		currentSize += moduleSize
		moduleCount++
	}

	if currentDiv.Len() > 0 {
		finalizedDiv := finalizeWithSDKSummary(currentDiv.String(), currentDivSDKs)
		divisions = append(divisions, finalizedDiv)
	}

	return len(divisions), divisions, nil
}

// buildXMLDoc serializes modules with non-empty documentation into XML format using proper XML marshaling
func (h *SDKHub) buildXMLDoc() error {
	xmlDoc := XMLDoc{
		Docs: make([]XMLDocEntry, 0, len(h.modules)),
	}

	// Convert modules map to XML entries, excluding SDKs with empty docs
	for path, sdk := range h.modules {
		if sdk.Doc() == "" {
			continue // Skip SDKs with empty documentation
		}
		entry := XMLDocEntry{
			ID:      path,
			Content: sdk.Doc(),
		}
		xmlDoc.Docs = append(xmlDoc.Docs, entry)
	}

	// Marshal to XML with proper formatting
	xmlBytes, err := xml.MarshalIndent(xmlDoc, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to marshal XML: %w", err)
	}

	// Add XML declaration
	h.xmlDoc = xml.Header + string(xmlBytes)
	return nil
}

// buildMDDoc builds the Markdown documentation for SDKs with non-empty documentation
func (h *SDKHub) buildMDDoc() error {
	var sb strings.Builder
	sb.WriteString("# SDK Documentation\n\n")

	i := 0
	for _, sdk := range h.modules {
		if sdk.Doc() == "" {
			continue // Skip SDKs with empty documentation
		}

		if i > 0 {
			sb.WriteString(MDDocSeparator)
		}

		sb.WriteString(formatSDKDoc(sdk.Name(), sdk.Doc()))

		i++
	}

	h.mdDoc = sb.String()
	return nil
}

// calculateMaxModuleBytes calculates the maximum size of any module in markdown format
func (h *SDKHub) calculateMaxModuleBytes() {
	h.maxModuleBytes = 0

	for _, sdk := range h.modules {
		// Calculate the size of this module in md format
		var moduleBuilder strings.Builder
		moduleBuilder.WriteString(formatSDKDoc(sdk.Name(), sdk.Doc()))

		moduleSize := len(moduleBuilder.String())
		if moduleSize > h.maxModuleBytes {
			h.maxModuleBytes = moduleSize
		}
	}

	h.maxModuleBytes += len(MDDocSeparator)
}

// pathToVersionedModuleName converts the path to a versioned module name.
// e.g. "@alva/data/stock/company/income/v1.0.0" -> "@alva/data/stock/company/income:v1.0.0"
func pathToVersionedModuleName(name string) (string, error) {
	// replace the last / with :, because the module spec is like @alva/data/stock/company/income:v1.0.0
	split := strings.Split(name, "/")
	if len(split) < 2 {
		return "", fmt.Errorf(
			"invalid name: %s, expected @org/[namespace]*/module_name/version",
			name,
		)
	}
	name = strings.Join(split[:len(split)-1], "/") + ":" + split[len(split)-1]
	return name, nil
}

// isDisabledByDefault checks if a module is disabled by default based on its name.
func isDisabledByDefault(moduleName string) bool {
	for _, prefix := range disabledByDefaultPrefixes {
		if strings.HasPrefix(moduleName, prefix) {
			return true
		}
	}
	return false
}

// shouldIncludeModule determines if a module should be included based on build flags.
// Returns true if the module should be loaded, false otherwise.
func shouldIncludeModule(moduleName string, buildFlags []string) bool {
	if !isDisabledByDefault(moduleName) {
		return true
	}

	// Parse build flags to get enabled prefixes
	enabledPrefixes := make([]string, 0)
	for _, flag := range buildFlags {
		if prefixes, ok := buildFlagToPrefixes[flag]; ok {
			enabledPrefixes = append(enabledPrefixes, prefixes...)
		}
	}

	// Check if module matches any enabled prefix
	for _, prefix := range enabledPrefixes {
		if strings.HasPrefix(moduleName, prefix) {
			return true
		}
	}
	return false
}

// NewSDKHub initializes the SDK Hub.
// For arrays: use NewSDKHub(ctx, true, "", "--include-arrays-only") to only load the arrays namespace.
func NewSDKHub(
	ctx context.Context,
	loadTests bool,
	localHubPath string,
	buildFlags ...string,
) (*SDKHub, error) {
	// Initialize the global Hub
	hub := &SDKHub{
		modules: make(map[string]*SDK),
	}
	// Determine source filesystem (embedded by default, or local override)
	var sourceFS fs.FS = sdkFS
	if strings.TrimSpace(localHubPath) != "" {
		sourceFS = os.DirFS(localHubPath)
		// Optional sanity check: ensure the expected root exists
		if _, err := fs.Stat(sourceFS, "assets"); err != nil {
			return nil, fmt.Errorf("localHubPath does not contain assets/: %w", err)
		}
	}

	dirs, err := walk(sourceFS)
	if err != nil {
		return nil, fmt.Errorf("failed to walk sdk directory: %w", err)
	}
	for _, dir := range dirs {
		// dir is like "assets/@org/.../version" in the embedded FS; trim the assets/ prefix for module parsing
		modulePath := strings.TrimPrefix(dir, "assets/")
		moduleName, err := pathToVersionedModuleName(modulePath)
		if err != nil {
			return nil, fmt.Errorf("failed to convert name to versioned name: %w", err)
		}

		// Check if this module should be included based on build flags
		if !shouldIncludeModule(moduleName, buildFlags) {
			continue
		}

		spec, err := ParseModuleSpec(moduleName)
		if err != nil {
			return nil, fmt.Errorf("failed to parse module spec: %w", err)
		}
		var docContent string
		docBytes, docErr := fs.ReadFile(sourceFS, path.Join(dir, "doc"))
		docNodifiedBytes, docNodifiedErr := fs.ReadFile(sourceFS, path.Join(dir, "doc_nodified"))

		// Enforce mutual existence: if one exists, the other must exist
		if (docErr == nil && errors.Is(docNodifiedErr, fs.ErrNotExist)) ||
			(docNodifiedErr == nil && errors.Is(docErr, fs.ErrNotExist)) {
			return nil, fmt.Errorf(
				"doc and doc_nodified must both exist or both be absent for SDK %s",
				dir,
			)
		}

		if docErr != nil && !errors.Is(docErr, fs.ErrNotExist) {
			return nil, fmt.Errorf("failed to read doc file for SDK %s: %w", dir, docErr)
		}
		if docNodifiedErr != nil && !errors.Is(docNodifiedErr, fs.ErrNotExist) {
			return nil, fmt.Errorf(
				"failed to read doc_nodified file for SDK %s: %w",
				dir,
				docNodifiedErr,
			)
		}

		if docErr == nil && docNodifiedErr == nil {
			// Both exist: concatenate
			docContent = strings.TrimSpace(
				string(docBytes),
			) + "\n\n" + strings.TrimSpace(
				string(docNodifiedBytes),
			)
		} else {
			// Neither exists
			docContent = ""
		}
		code, err := fs.ReadFile(sourceFS, path.Join(dir, "code.js"))
		if err != nil {
			if !errors.Is(err, fs.ErrNotExist) {
				return nil, fmt.Errorf("failed to read code file for SDK %s: %w", dir, err)
			}
		}
		codeContent := strings.TrimSpace(string(code))

		testContent := ""
		if loadTests {
			test, err := fs.ReadFile(sourceFS, path.Join(dir, "test.js"))
			if err != nil {
				if !errors.Is(err, fs.ErrNotExist) {
					return nil, fmt.Errorf("failed to read test file for SDK %s: %w", dir, err)
				}
			} else {
				testContent = strings.TrimSpace(string(test))
			}
		}

		sdk := &SDK{
			name: spec.FullNameWithVersion(), // canonical name
			doc:  docContent,
			code: codeContent,
			test: testContent,
		}
		// Add SDK to the Hub's modules map
		hub.modules[spec.FullNameWithVersion()] = sdk
	}

	// Calculate the maximum module size
	hub.calculateMaxModuleBytes()

	// Build the XML documentation
	if err := hub.buildXMLDoc(); err != nil {
		return nil, fmt.Errorf("failed to build XML documentation: %w", err)
	}

	// Build the Markdown documentation
	if err := hub.buildMDDoc(); err != nil {
		return nil, fmt.Errorf("failed to build Markdown documentation: %w", err)
	}

	// Build inverted index
	if err := hub.buildInvertedIndex(); err != nil {
		return nil, fmt.Errorf("failed to build inverted index: %w", err)
	}

	return hub, nil
}

// walk walks the SDK directory and returns the names of the SDKs
// paths, e.g. "@arrays/data/stock/company/income/v1.0.0"
func walk(fsys fs.FS) ([]string, error) {
	var sdkNames []string

	err := fs.WalkDir(fsys, ".", func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if !d.IsDir() {
			return nil
		}
		if p == "." {
			return nil
		}
		if _, err := fs.Stat(fsys, path.Join(p, "code.js")); err == nil {
			// Include directories that have code.js, regardless of whether doc exists
			sdkNames = append(sdkNames, p)
		}
		return nil
	})

	return sdkNames, err
}

// extractModuleName extracts the module name from a full SDK path.
func extractModuleName(fullName string) string {
	// Remove version part first (everything after :)
	nameWithoutVersion := strings.Split(fullName, ":")[0]

	// Split by / and get the last part
	parts := strings.Split(nameWithoutVersion, "/")
	if len(parts) == 0 {
		return fullName
	}

	return parts[len(parts)-1]
}

func formatSDKDoc(sdkName, sdkDoc string) string {
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("<sdk \"id\" = %s>\n", sdkName))
	sb.WriteString("```javascript\n")
	sb.WriteString(sdkDoc)
	sb.WriteString("\n```\n")
	sb.WriteString("</sdk>\n")
	return sb.String()
}

func finalizeWithSDKSummary(content string, sdkNames []string) string {
	if content == "" || len(sdkNames) == 0 {
		return content
	}

	var sb strings.Builder
	sb.WriteString(content)

	moduleNames := make([]string, len(sdkNames))
	for i, fullName := range sdkNames {
		moduleNames[i] = extractModuleName(fullName) + "->" + fullName
	}

	sb.WriteString(
		fmt.Sprintf("\n\nYou Must only choose from the sdks: %s", strings.Join(moduleNames, ", ")),
	)
	return sb.String()
}
