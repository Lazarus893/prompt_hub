package main

import (
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/alva-ai/sdkhub"
)

func main() {
	// Set environment to disable sync
	_ = os.Setenv("SDKHUB_SYNC", "false")

	// Initialize the SDK Hub
	hub, err := sdkhub.NewSDKHub(context.Background(), false, "")
	if err != nil {
		panic(err)
	}

	// Get the XML documentation
	xmlDoc := hub.GetXMLDoc()

	// Print a preview of the XML structure
	lines := strings.Split(xmlDoc, "\n")
	fmt.Println("=== XML Documentation Preview ===")
	for i, line := range lines {
		if i > 200 { // Show first 200 lines
			fmt.Println("... (truncated)")
			break
		}
		fmt.Println(line)
	}

	fmt.Printf("\n=== Summary ===\n")
	fmt.Printf("Total XML length: %d characters\n", len(xmlDoc))
	fmt.Printf("Number of modules: %d\n", len(strings.Split(xmlDoc, "<doc id="))-1)
	fmt.Println(xmlDoc)
}
