package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/rs/zerolog"
	"github.com/stumble/axe"
	cc "github.com/stumble/axe/code/container"
	clitool "github.com/stumble/axe/tools/cli"
)

const (
	codeFile = "code.js"
	docFile  = "doc"
	testFile = "test.js"
	sdk      = "crypto_quant_sdk.js"
)

const (
	onlyPrefix = "@arrays"
)

type Module struct {
	Dir  string
	Name string
}

func main() {
	var (
		model        string
		skipInterval time.Duration
	)

	flag.StringVar(&model, "model", "gpt-5", "LLM model to use")
	flag.DurationVar(
		&skipInterval,
		"skip-interval",
		0,
		"skip modules updated within this interval (set 0 to disable)",
	)
	flag.Parse()

	log.Printf(
		"Starting run (model=%s, skip-interval=%s, only-prefix=%q)",
		model,
		skipInterval,
		onlyPrefix,
	)

	modules, err := discoverModules("assets")
	if err != nil {
		log.Fatalf("discover modules: %v", err)
	}
	log.Printf("Discovered %d module directories containing code.js", len(modules))

	var filtered []Module
	for _, m := range modules {
		if strings.HasPrefix(m.Name, onlyPrefix) {
			filtered = append(filtered, m)
		}
	}
	if len(filtered) == 0 {
		log.Printf("no modules matched prefix %q", onlyPrefix)
		return
	}
	log.Printf("Filtered to %d modules by prefix %q", len(filtered), onlyPrefix)
	modules = filtered

	// Process modules with bounded concurrency (max 30 concurrent edits)
	sem := make(chan struct{}, 30)
	var wg sync.WaitGroup
	for _, module := range modules {
		sem <- struct{}{}
		wg.Add(1)
		m := module
		go func() {
			defer func() {
				wg.Done()
				<-sem
			}()
			log.Printf("Evaluating module %s (dir=%s)", m.Name, m.Dir)
			if err := rewriteIndicators(m, io.Discard); err != nil {
				log.Printf("failed to edit code for %s: %v", m.Name, err)
				return
			}
			log.Printf("Completed update for %s", m.Name)
		}()
	}
	wg.Wait()
}

func discoverModules(root string) ([]Module, error) {
	var modules []Module

	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}

		rel, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}

		if !d.IsDir() {
			return nil
		}

		codePath := filepath.Join(path, "code.js")
		if _, err := os.Stat(codePath); errors.Is(err, os.ErrNotExist) {
			// code.js is the root file of the module
			return nil
		} else if err != nil {
			return err
		}
		modules = append(modules, Module{
			Dir:  path,
			Name: deriveName(rel),
		})
		return nil
	})
	if err != nil {
		return nil, err
	}
	return modules, nil
}

// convert the relative path to the module name, e.g. "@alva/data/crypto/meme:v1.0.0"
func deriveName(rel string) string {
	parts := strings.Split(rel, string(filepath.Separator))
	if len(parts) < 2 {
		return rel
	}
	return fmt.Sprintf("%s:%s", strings.Join(parts[:len(parts)-1], "/"), parts[len(parts)-1])
}

const prompt = `1.阅读当前的doc，对当前的doc的每个函数都做1次总结。然后我们可以得到每个函数的对应baseFuncDesc字符串。这个字符串应该尽量精简。之后我们声明该字符串到code.js中。
例如对于/**
 * Get official announcements from cryptocurrency exchanges
 * @function getExchangeAnnouncements
const baseDescription = "Get official announcements";
2.之后按照每个函数的doc中的param，单独为每个函数构建1个buildDynamicDescription function。例如对于getExchangeAnnouncements，我们可以这样构建：
function buildGetExchangeAnnouncementsCallDescription(actualParams = {}) {

    // 1. 使用数组动态构建
    const parts = [baseDescription]; // 以“核心描述”开头

    // 2. 【关键】动态添加来自 "actualParams" 的信息

    // 2a. 添加 Exchange (来自 params.exchange)
    if (actualParams.exchange) {
` +
	// 这里是第一个需要拼接的反引号
	"        parts.push(`from ${actualParams.exchange}`);" +
	`
    } else {
        // 如果 doc 暗示这是一个必需参数但未提供，
        // 或者我们可以保持通用，说 "from exchanges"
        // (这里我们选择：如果不提供，就不提)
    }

    // 2b. 添加其他过滤条件
    const filters = [];
    if (actualParams.category) {
` +
	// 第二个反引号
	"        filters.push(`Category: ${actualParams.category}`);" +
	`
    }
    if (actualParams.limit && actualParams.limit !== 50) { // 假设 50 是默认值，可以不显示
` +
	// 第三个反引号
	"        filters.push(`Limit: ${actualParams.limit}`);" +
	`
    }
    if (actualParams.start_time && actualParams.end_time) {
` +
	// 第四个反引号
	"        filters.push(`Time: ${actualParams.start_time} to ${actualParams.end_time}`);" +
	`
    } else if (actualParams.start_time) {
` +
	// 第五个反引号
	"        filters.push(`Time from: ${actualParams.start_time}`);" +
	`
    }
    // ... 可以添加其他 params 的处理 ...

    // 3. 如果有过滤条件，将它们组合并添加到 parts
    if (filters.length > 0) {
` +
	// 第六个反引号
	"        parts.push(`(${filters.join(', ')})`);" +
	`
    }

    // 用空格将所有部分连接起来
    return parts.join(' ').trim();
}

构建完毕后将该func加入到code.js中。
如果你看到code.js中已经有了相关的build为前缀的func或Desc字符串，请你用新生成的func或Desc字符串做覆盖。
最后，不要将这些函数和字符串做export。这些是内部函数和字符串，不应该被外部使用和访问到！`

func rewriteIndicators(module Module, sink io.Writer) error {
	zerolog.SetGlobalLevel(zerolog.InfoLevel)
	baseDir := module.Dir // relative to current working directory
	pwd, err := os.Getwd()
	if err != nil {
		return fmt.Errorf("failed to get current working directory: %w", err)
	}
	localJsonPath := filepath.Join(pwd, "local.json")
	localSdKhubPath := pwd
	runner, err := axe.NewRunner(
		baseDir,
		[]string{prompt},
		cc.MustNewCodeContainerFromFS(
			baseDir,
			[]string{codeFile, docFile},
		), // same, relative to current wd
		axe.WithTools([]clitool.Definition{
			clitool.MustNewDefinition(
				"run_test_js",
				fmt.Sprintf(
					"jagent --mock %s --local-sdkhub %s test.js",
					localJsonPath,
					localSdKhubPath,
				),
				"run test.js using 'jagent ./test.js'. The working directory must be the directory of the module, where the test.js is located.",
				nil,
			),
		}),
		axe.WithModel(axe.ModelGPT5),
		axe.WithSink(sink),
	)
	if err != nil {
		return fmt.Errorf("failed to run: %w", err)
	}
	err = runner.Run(context.Background(), false)
	if err != nil {
		return fmt.Errorf("failed to run: %w", err)
	}
	return nil
}
