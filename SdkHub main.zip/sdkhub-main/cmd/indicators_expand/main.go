package main

import (
	"bufio"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"strings"
)

func main() {
	var (
		indicatorsPath string
		assetsRoot     string
		namespacePath  string
		version        string
	)

	flag.StringVar(
		&indicatorsPath,
		"source",
		"ai-code/indicators-generated.md",
		"path to indicators markdown file",
	)
	flag.StringVar(&assetsRoot, "assets", "assets", "assets root directory")
	flag.StringVar(
		&namespacePath,
		"ns",
		"@alva/technical-indicators",
		"namespace path under assets for indicators",
	)
	flag.StringVar(&version, "version", "v1.0.0", "version directory to use")
	flag.Parse()

	if err := run(indicatorsPath, assetsRoot, namespacePath, version, os.Stdout); err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		os.Exit(1)
	}
}

func run(sourcePath, assetsRoot, namespacePath, version string, out io.Writer) error {
	content, err := os.ReadFile(sourcePath)
	if err != nil {
		return fmt.Errorf("read %s: %w", sourcePath, err)
	}

	// Split on lines that are exactly --- (possibly surrounded by whitespace)
	parts := splitOnTripleDash(string(content))
	if len(parts) == 0 {
		return errors.New("no sections found after splitting on '---'")
	}

	created := 0
	for _, part := range parts {
		section := strings.TrimSpace(part)
		if section == "" {
			continue
		}
		title := extractSectionTitle(section)
		if title == "" {
			_, _ = fmt.Fprintf(out, "skipping section with no title: %s\n", section)
			continue
		}
		_, _ = fmt.Fprintf(out, "processing section with title: %s\n", title)
		name := slugifyTitle(title)
		dir := filepath.Join(assetsRoot, namespacePath, name, version)
		if err := os.MkdirAll(dir, 0o755); err != nil {
			return fmt.Errorf("mkdir %s: %w", dir, err)
		}
		docPath := filepath.Join(dir, "doc")
		if err := os.WriteFile(docPath, []byte(strings.TrimSpace(section)+"\n"), 0o600); err != nil {
			return fmt.Errorf("write doc %s: %w", docPath, err)
		}
		created++
		_, err = fmt.Fprintf(out, "wrote %s\n", docPath)
		if err != nil {
			return fmt.Errorf("write output: %w", err)
		}
		// touch 3 empty files: code.js, test.js, doc_nodified
		if err := os.WriteFile(filepath.Join(dir, "code.js"), []byte(""), 0o600); err != nil {
			return fmt.Errorf("write code.js %s: %w", dir, err)
		}
		_, _ = fmt.Fprintf(out, "wrote %s\n", filepath.Join(dir, "code.js"))
		if err := os.WriteFile(filepath.Join(dir, "test.js"), []byte(""), 0o600); err != nil {
			return fmt.Errorf("write test.js %s: %w", dir, err)
		}
		_, _ = fmt.Fprintf(out, "wrote %s\n", filepath.Join(dir, "test.js"))
		if err := os.WriteFile(filepath.Join(dir, "doc_nodified"), []byte(""), 0o600); err != nil {
			return fmt.Errorf("write doc_nodified %s: %w", dir, err)
		}
		_, _ = fmt.Fprintf(out, "wrote %s\n", filepath.Join(dir, "doc_nodified"))
	}

	if created == 0 {
		return errors.New("no sections written; no titles detected")
	}
	return nil
}

// splitOnTripleDash splits content by lines that contain only --- (optionally with surrounding whitespace).
func splitOnTripleDash(s string) []string {
	scanner := bufio.NewScanner(strings.NewReader(s))
	var parts []string
	var current []string
	for scanner.Scan() {
		line := scanner.Text()
		if strings.TrimSpace(line) == "---" {
			parts = append(parts, strings.Join(current, "\n"))
			current = current[:0]
			continue
		}
		current = append(current, line)
	}
	if len(current) > 0 {
		parts = append(parts, strings.Join(current, "\n"))
	}
	return parts
}

var headingRe = regexp.MustCompile(`(?m)^\s{0,3}#{1,6}\s+(.+?)\s*$`)

// extractSectionTitle finds the first markdown heading and returns its text.
func extractSectionTitle(md string) string {
	m := headingRe.FindStringSubmatch(md)
	if len(m) >= 2 {
		return strings.TrimSpace(stripInlineCode(m[1]))
	}
	return ""
}

// slugifyTitle converts a title into a kebab-case package name suitable for directories.
func slugifyTitle(title string) string {
	t := strings.ToLower(title)
	// Replace common punctuation with spaces
	t = strings.ReplaceAll(t, "&", " and ")
	// Remove backticks and quotes
	t = strings.NewReplacer("`", "", "\"", "", "'", "").Replace(t)
	// Replace non-alphanumeric sequences with single hyphen
	re := regexp.MustCompile(`[^a-z0-9]+`)
	t = re.ReplaceAllString(t, "-")
	t = strings.Trim(t, "-")
	if t == "" {
		t = "unnamed"
	}
	return t
}

func stripInlineCode(s string) string {
	// remove inline code fences like `text`
	var b strings.Builder
	inCode := false
	for _, r := range s {
		if r == '`' {
			inCode = !inCode
			continue
		}
		if !inCode {
			b.WriteRune(r)
		}
	}
	return b.String()
}
