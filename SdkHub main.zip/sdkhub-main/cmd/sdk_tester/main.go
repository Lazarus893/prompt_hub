package main

import (
	"bufio"
	"bytes"
	"context"
	"encoding/xml"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"

	"github.com/alva-ai/sdkhub"
)

// TestFailure captures a failed test case for XML reporting.
type TestFailure struct {
	Name   string
	Detail string
}

// JUnit-like XML structures
type Testsuite struct {
	XMLName  xml.Name   `xml:"testsuite"`
	Name     string     `xml:"name,attr"`
	Tests    int        `xml:"tests,attr"`
	Failures int        `xml:"failures,attr"`
	Testcase []Testcase `xml:"testcase"`
}

type Testcase struct {
	Name    string   `xml:"name,attr"`
	Failure *Failure `xml:"failure,omitempty"`
}

type Failure struct {
	// Use innerxml to embed raw CDATA content
	Message string `xml:",innerxml"`
}

func main() {
	statePath := flag.String("state", "sdk_tester.passed.txt", "path to the persistence file")
	mockPath := flag.String("mock", "", "path to local.json for jagent --mock")
	logPath := flag.String("log", "sdk_tester.failed.xml", "path to write XML failure log")
	stopOnFail := flag.Bool("stop-on-fail", false, "stop on first failure")
	localSDKHubPath := flag.String(
		"local-sdkhub",
		"./",
		"path to the local sdkhub, default to current working directory",
	)
	filterPrefix := flag.String(
		"filter-prefix",
		"",
		"only run tests for modules whose names start with this prefix",
	)
	flag.Parse()

	// Allow users to specify one or more module names to test as positional
	// arguments. Also support comma-separated lists for convenience.
	requestedArgs := flag.Args()
	requestedModules := make(map[string]struct{})
	for _, arg := range requestedArgs {
		for _, part := range strings.Split(arg, ",") {
			name := strings.TrimSpace(part)
			if name == "" {
				continue
			}
			requestedModules[name] = struct{}{}
		}
	}

	if *mockPath == "" {
		fmt.Fprintf(os.Stderr, "mock path is required\n")
		os.Exit(1)
	}

	ctx := context.Background()

	hub, err := sdkhub.NewSDKHub(ctx, true, "")
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to initialize sdk hub: %v\n", err)
		os.Exit(1)
	}

	passed, err := loadState(*statePath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to load state: %v\n", err)
		os.Exit(1)
	}

	modules := hub.Modules()
	if len(modules) == 0 {
		fmt.Println("no sdks available to test")
		return
	}

	var failures []TestFailure
	executedTests := 0

	for _, sdk := range modules {
		name := sdk.Name()
		if sdk.Test() == "" {
			continue
		}

		if *filterPrefix != "" && !strings.HasPrefix(name, *filterPrefix) {
			fmt.Printf("Skip %s (does not match prefix %q)\n", name, *filterPrefix)
			continue
		}

		// If a filter list is provided, only run tests for the selected modules.
		if len(requestedModules) > 0 {
			if _, ok := requestedModules[name]; !ok {
				continue
			}
		}
		// skip only when no filter list is provided and the module has already been passed
		if len(requestedModules) == 0 && passed[name] {
			fmt.Printf("Skip %s (found in state)\n", name)
			continue
		}

		executedTests++
		fmt.Printf("Running test for %s\n", name)
		output, err := runTest(ctx, sdk, *mockPath, *localSDKHubPath)
		if err != nil {
			fmt.Fprintf(os.Stderr, "test failed for %s: %v\n", name, err)
			detail := buildFailureDetail(err, output)
			failures = append(failures, TestFailure{Name: name, Detail: detail})
			if *stopOnFail {
				os.Exit(1)
			}
			continue
		}
		fmt.Printf("\ntest passed for %s\n", name)

		passed[name] = true
		if err := writeState(*statePath, passed); err != nil {
			fmt.Fprintf(os.Stderr, "failed to persist state after %s: %v\n", name, err)
			os.Exit(1)
		}
	}

	// If there are failures, write XML log and exit with non-zero code
	if len(failures) > 0 {
		if err := writeXMLFailures(*logPath, "sdk_tester", executedTests, len(failures), failures); err != nil {
			fmt.Fprintf(os.Stderr, "failed to write XML failure log: %v\n", err)
		} else {
			fmt.Fprintf(os.Stderr, "wrote XML failure log to %s (%d failures)\n", *logPath, len(failures))
		}
		os.Exit(1)
	}

	fmt.Println("all sdk tests completed")
}

func loadState(path string) (map[string]bool, error) {
	passed := make(map[string]bool)

	file, err := os.Open(path)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return passed, nil
		}
		return nil, err
	}
	defer func() {
		_ = file.Close()
	}()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		name := strings.TrimSpace(scanner.Text())
		if name == "" {
			continue
		}
		passed[name] = true
	}
	if err := scanner.Err(); err != nil {
		return nil, err
	}

	return passed, nil
}

func writeState(path string, passed map[string]bool) error {
	dir := filepath.Dir(path)
	if dir != "." {
		if err := os.MkdirAll(dir, 0o755); err != nil {
			return err
		}
	}

	names := make([]string, 0, len(passed))
	for name := range passed {
		names = append(names, name)
	}
	sort.Strings(names)

	content := strings.Join(names, "\n")
	if err := os.WriteFile(path, []byte(content), 0o600); err != nil {
		return err
	}

	return nil
}

func runTest(
	ctx context.Context,
	sdk *sdkhub.SDK,
	mockPath string,
	localSDKHubPath string,
) (string, error) {
	script := sdk.Test()
	if strings.TrimSpace(script) == "" {
		return "", nil
	}

	tempDir, err := os.MkdirTemp("", "sdk-test-")
	if err != nil {
		return "", err
	}
	defer func() {
		_ = os.RemoveAll(tempDir)
	}()

	testPath := filepath.Join(tempDir, "test.js")
	if err := os.WriteFile(testPath, []byte(script+"\n"), 0o600); err != nil {
		return "", err
	}

	args := []string{}
	args = append(args, "--mock", mockPath)
	args = append(args, "--local-sdkhub", localSDKHubPath)
	args = append(args, "--jid", "123")
	args = append(args, "--user", "tester")
	args = append(
		args,
		"--max-heap",
		"128",
	) // @alva/data/crypto/defi:v1.0.0 test needs more than 16 MB memory, the response is huge and suspiciously big.
	args = append(args, testPath)
	cmd := exec.CommandContext(ctx, "jagent", args...)
	var stdoutBuf, stderrBuf bytes.Buffer
	cmd.Stdout = io.MultiWriter(os.Stdout, &stdoutBuf)
	cmd.Stderr = io.MultiWriter(os.Stderr, &stderrBuf)
	if err := cmd.Run(); err != nil {
		combined := strings.TrimSpace(stdoutBuf.String() + "\n" + stderrBuf.String())
		return combined, err
	}

	combined := strings.TrimSpace(stdoutBuf.String() + "\n" + stderrBuf.String())
	return combined, nil
}

// buildFailureDetail builds a human-readable failure detail string
// that includes the error message and captured process output.
func buildFailureDetail(err error, output string) string {
	var b strings.Builder
	b.WriteString("Error: ")
	b.WriteString(err.Error())
	if strings.TrimSpace(output) != "" {
		b.WriteString("\n\nOutput:\n")
		b.WriteString(output)
	}
	return b.String()
}

// writeXMLFailures writes a minimal JUnit-style XML with CDATA-wrapped failure details.
func writeXMLFailures(
	path string,
	suiteName string,
	total int,
	failuresCount int,
	failures []TestFailure,
) error {
	dir := filepath.Dir(path)
	if dir != "." {
		if err := os.MkdirAll(dir, 0o755); err != nil {
			return err
		}
	}

	ts := Testsuite{
		Name:     suiteName,
		Tests:    total,
		Failures: failuresCount,
	}
	for _, f := range failures {
		content := "<![CDATA[" + wrapCDATA(f.Detail) + "]]>"
		ts.Testcase = append(ts.Testcase, Testcase{
			Name: f.Name,
			Failure: &Failure{
				Message: content,
			},
		})
	}

	data, err := xml.MarshalIndent(ts, "", "  ")
	if err != nil {
		return err
	}
	data = append([]byte(xml.Header), data...)

	return os.WriteFile(path, data, 0o600)
}

// escapeAttr removed; encoding/xml handles attribute escaping during marshaling

// wrapCDATA ensures CDATA does not prematurely close by splitting any occurrences of
// the "]]>" sequence.
func wrapCDATA(s string) string {
	if s == "" {
		return ""
	}
	return strings.ReplaceAll(s, "]]>", "]]]]><![CDATA[>")
}
