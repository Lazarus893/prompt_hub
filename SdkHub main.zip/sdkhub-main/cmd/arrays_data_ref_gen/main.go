package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/rs/zerolog"
	"github.com/stumble/axe"
	cc "github.com/stumble/axe/code/container"
	clitool "github.com/stumble/axe/tools/cli"
)

const (
	codeFile        = "code.js"
	testFile        = "test.js"
	docFile         = "doc"
	docNodifiedFile = "doc_nodified"
	toolFile        = "tool.json"
)

const (
	onlyPrefix = "@arrays"
)

type Module struct {
	Dir  string
	Name string
}

func main() {
	var (
		model        string
		skipInterval time.Duration
	)

	flag.StringVar(&model, "model", "gpt-5", "LLM model to use")
	flag.DurationVar(
		&skipInterval,
		"skip-interval",
		0,
		"skip modules updated within this interval (set 0 to disable)",
	)
	flag.Parse()

	log.Printf(
		"Starting run (model=%s, skip-interval=%s, only-prefix=%q)",
		model,
		skipInterval,
		onlyPrefix,
	)

	modules, err := discoverModules("assets")
	if err != nil {
		log.Fatalf("discover modules: %v", err)
	}
	log.Printf("Discovered %d module directories containing code.js", len(modules))

	var filtered []Module
	for _, m := range modules {
		if strings.HasPrefix(m.Name, onlyPrefix) {
			filtered = append(filtered, m)
		}
	}
	if len(filtered) == 0 {
		log.Printf("no modules matched prefix %q", onlyPrefix)
		return
	}
	log.Printf("Filtered to %d modules by prefix %q", len(filtered), onlyPrefix)
	modules = filtered

	// Process modules with bounded concurrency (max 30 concurrent edits)
	sem := make(chan struct{}, 30)
	var wg sync.WaitGroup
	for _, module := range modules {
		sem <- struct{}{}
		wg.Add(1)
		m := module
		go func() {
			defer func() {
				wg.Done()
				<-sem
			}()
			log.Printf("Evaluating module %s (dir=%s)", m.Name, m.Dir)
			if err := rewriteIndicators(m, io.Discard); err != nil {
				log.Printf("failed to edit code for %s: %v", m.Name, err)
				return
			}
			log.Printf("Completed update for %s", m.Name)
		}()
	}
	wg.Wait()
}

func discoverModules(root string) ([]Module, error) {
	var modules []Module

	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}

		rel, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}

		if !d.IsDir() {
			return nil
		}

		codePath := filepath.Join(path, "code.js")
		if _, err := os.Stat(codePath); errors.Is(err, os.ErrNotExist) {
			// code.js is the root file of the module
			return nil
		} else if err != nil {
			return err
		}
		modules = append(modules, Module{
			Dir:  path,
			Name: deriveName(rel),
		})
		return nil
	})
	if err != nil {
		return nil, err
	}
	return modules, nil
}

// convert the relative path to the module name, e.g. "@alva/data/crypto/meme:v1.0.0"
func deriveName(rel string) string {
	parts := strings.Split(rel, string(filepath.Separator))
	if len(parts) < 2 {
		return rel
	}
	return fmt.Sprintf("%s:%s", strings.Join(parts[:len(parts)-1], "/"), parts[len(parts)-1])
}

const prompt = `
First, you need to learn the following content:
{
    "ModuleName": "@alva/data/crypto/defi ",
    "ModuleDisplayName": "Crypto Project KPI \u0026 Operating Metrics",
    "SdkName": "getDefiProtocolUserActivity",
    "SdkDisplayName": "Crypto Project User Activity",
    "SourceName": "DefiLlama",
    "Source": "https://api-docs.defillama.com/#tag/active-users/get/api/userData/%7Btype%7D/%7BprotocolId%7D"
}

const getDefiProtocolUserActivityRef = {
         id: "@alva/data/crypto/defi/getDefiProtocolUserActivity",
         module_name: "@alva/data/crypto/defi",
          module_display_name: "Crypto Project KPI \u0026 Operating Metrics",
             sdk_name: "getDefiProtocolUserActivity",
             sdk_display_name: "Crypto Project User Activity",
             source_name: "DefiLlama",
             source: "https://api-docs.defillama.com/#tag/active-users/get/api/userData/%7Btype%7D/%7BprotocolId%7D"
};

function makeDefiProtocolUserActivityNode(params) {
	const activityType = params && params.type ? params.type : 'users';
	return {
		inputs: {
			activity_raw: () => getDefiProtocolUserActivity(params),
		},
		outputs: {
			user_activity: {
				name: 'protocol_user_activity',
				description: 'Protocol user activity time series data.',
				fields: [
					{ name: 'date', type: 'number', description: 'day start time ms (UTC)' },
					{ name: 'protocol_id', type: 'number', description: 'protocol ID' },
					{ name: 'activity_type', type: 'string', description: "one of: 'users' | 'txs' | 'gas' | 'newusers'" },
					{ name: 'value', type: 'number', description: 'activity value (users count, tx count, gas cost, or new users)' },
				],
				ref: getDefiProtocolUserActivityRef,
			},
		},
		run: (inputs) => {
		...
		},
	};
}

After you have learned the content above, you should first find all function names in code.js that start with the "get" prefix.
Then, you must use these function names you found to search for corresponding objects in tool.json located in the current directory.
Following the pattern you learned, add them to code.js, and add the ref field to the corresponding make node functions.
Note, the Ref's id must be ModuleName + function name to ensure global uniqueness.
`

func rewriteIndicators(module Module, sink io.Writer) error {
	zerolog.SetGlobalLevel(zerolog.InfoLevel)
	baseDir := module.Dir // relative to current working directory
	pwd, err := os.Getwd()
	if err != nil {
		return fmt.Errorf("failed to get current working directory: %w", err)
	}
	localJsonPath := filepath.Join(pwd, "local.json")
	localSdKhubPath := pwd
	runner, err := axe.NewRunner(
		baseDir,
		[]string{prompt},
		cc.MustNewCodeContainerFromFS(
			baseDir,
			[]string{codeFile, toolFile, testFile},
		), // same, relative to current wd
		axe.WithTools([]clitool.Definition{
			clitool.MustNewDefinition(
				"run_test_js",
				fmt.Sprintf(
					"jagent --mock %s --local-sdkhub %s test.js",
					localJsonPath,
					localSdKhubPath,
				),
				"run test.js using 'jagent ./test.js'. The working directory must be the directory of the module, where the test.js is located.",
				nil,
			),
		}),
		axe.WithModel(axe.ModelGPT5),
		axe.WithSink(sink),
	)
	if err != nil {
		return fmt.Errorf("failed to run: %w", err)
	}
	err = runner.Run(context.Background(), false)
	if err != nil {
		return fmt.Errorf("failed to run: %w", err)
	}
	return nil
}
