package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/rs/zerolog"
	"github.com/stumble/axe"
	cc "github.com/stumble/axe/code/container"
	clitool "github.com/stumble/axe/tools/cli"
)

const (
	codeFile = "code.js"
)

const (
	onlyPrefix = "@alva/data"
)

type Module struct {
	Dir  string
	Name string
}

func main() {
	var (
		model        string
		skipInterval time.Duration
	)

	flag.StringVar(&model, "model", "gpt-5", "LLM model to use")
	flag.DurationVar(
		&skipInterval,
		"skip-interval",
		0,
		"skip modules updated within this interval (set 0 to disable)",
	)
	flag.Parse()

	log.Printf(
		"Starting run (model=%s, skip-interval=%s, only-prefix=%q)",
		model,
		skipInterval,
		onlyPrefix,
	)

	modules, err := discoverModules("assets")
	if err != nil {
		log.Fatalf("discover modules: %v", err)
	}
	log.Printf("Discovered %d module directories containing code.js", len(modules))

	var filtered []Module
	for _, m := range modules {
		if strings.HasPrefix(m.Name, onlyPrefix) {
			filtered = append(filtered, m)
		}
	}
	if len(filtered) == 0 {
		log.Printf("no modules matched prefix %q", onlyPrefix)
		return
	}
	log.Printf("Filtered to %d modules by prefix %q", len(filtered), onlyPrefix)
	modules = filtered

	// Process modules with bounded concurrency (max 30 concurrent edits)
	sem := make(chan struct{}, 30)
	var wg sync.WaitGroup
	for _, module := range modules {
		sem <- struct{}{}
		wg.Add(1)
		m := module
		go func() {
			defer func() {
				wg.Done()
				<-sem
			}()
			log.Printf("Evaluating module %s (dir=%s)", m.Name, m.Dir)
			if err := rewriteIndicators(m, io.Discard); err != nil {
				log.Printf("failed to edit code for %s: %v", m.Name, err)
				return
			}
			log.Printf("Completed update for %s", m.Name)
		}()
	}
	wg.Wait()
}

func discoverModules(root string) ([]Module, error) {
	var modules []Module

	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}

		rel, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}

		if !d.IsDir() {
			return nil
		}

		codePath := filepath.Join(path, "code.js")
		if _, err := os.Stat(codePath); errors.Is(err, os.ErrNotExist) {
			// code.js is the root file of the module
			return nil
		} else if err != nil {
			return err
		}
		modules = append(modules, Module{
			Dir:  path,
			Name: deriveName(rel),
		})
		return nil
	})
	if err != nil {
		return nil, err
	}
	return modules, nil
}

// convert the relative path to the module name, e.g. "@alva/data/crypto/meme:v1.0.0"
func deriveName(rel string) string {
	parts := strings.Split(rel, string(filepath.Separator))
	if len(parts) < 2 {
		return rel
	}
	return fmt.Sprintf("%s:%s", strings.Join(parts[:len(parts)-1], "/"), parts[len(parts)-1])
}

const prompt = `First, you will study the following content:
const getDefiProtocolVolumeRef = {
    id: '@alva/data/crypto/defi/getDefiProtocolVolume',
    module_name: '@alva/data/crypto/defi',
    module_display_name: 'Crypto Project KPI \u0026 Operating Metrics',
    sdk_name: 'getDefiProtocolVolume',
    sdk_display_name: 'DEX Protocol Volume',
    source_name: 'DefiLlama',
    source: 'https://api-docs.defillama.com/#tag/volumes/get/api/summary/dexs/%7Bprotocol%7D'
};
function getDefiProtocolVolume(params) {
    useCredit('getDefiProtocolVolume', 350);
    return defiLlamaSDK.getDLDexVolumeSummary(params);
}
function makeDefiProtocolVolumeNode(params) {
    return {
        inputs: {
            volume_raw: () => getDefiProtocolVolume(params),
        },
        outputs: {
            volume_summary: {
                name: 'dex_volume_summary',
                description: 'DEX volume summary snapshot at run time.',
                fields: [
                    { name: 'date', type: 'number', description: 'snapshot time ms (UTC)' },
                    { name: 'protocol_name', type: 'string', description: 'DEX protocol name' },
                    {
                        name: 'chains',
                        type: 'array',
                        description: 'blockchains where the DEX operates',
                        fields: [{ name: 'chain', type: 'string', description: 'blockchain name' }],
                    },
                    { name: 'total_volume_24h', type: 'number', description: 'total volume in the past 24 hours (USD)' },
                    { name: 'total_volume_all_time', type: 'number', description: 'cumulative total volume (USD)' },
                ],
                ref: getDefiProtocolVolumeRef,
            },
            historical_volume: {
                name: 'historical_volume',
                description: 'Daily volume time series for the DEX.',
                fields: [
                    { name: 'date', type: 'number', description: 'day start time ms (UTC)' },
                    { name: 'volume', type: 'number', description: 'daily volume in USD' },
                ],
                ref: getDefiProtocolVolumeRef,
            },
        },
        run: (inputs) => {
            const raw = inputs.volume_raw;
            const seriesIn = raw.totalDataChart;

            const mapPoint = (pt) => {
                return { date: toMs(pt[0]), volume: Number(pt[1]) };
            };

            const mapped = seriesIn.map(mapPoint);
            const historical = ensureUniqueDates(mapped);

            // Build summary snapshot
            const summary = {
                date: Date.now(),
                protocol_name: raw.name || raw.displayName,
                chains: raw.chains.map((c) => ({ chain: String(c) })),
                total_volume_24h: raw.total24h,
                total_volume_all_time: raw.totalAllTime,
            };

            return {
                volume_summary: [summary],
                historical_volume: historical,
            };
        },
    };
}
You will notice that a function prefixed with get corresponds to one Ref object. This Ref object is then added to the ref field within the corresponding make...Node function.

I am going to give you a code.js file. Now, you need to go into the code.js file and check if the functions prefixed with get have a corresponding Ref object.
If not, you must first draft a corresponding Ref object according to the format you have just learned, and then add that ref into the corresponding make...Node function."
`

func rewriteIndicators(module Module, sink io.Writer) error {
	zerolog.SetGlobalLevel(zerolog.InfoLevel)
	baseDir := module.Dir // relative to current working directory
	pwd, err := os.Getwd()
	if err != nil {
		return fmt.Errorf("failed to get current working directory: %w", err)
	}
	localJsonPath := filepath.Join(pwd, "local.json")
	localSdKhubPath := pwd
	runner, err := axe.NewRunner(
		baseDir,
		[]string{prompt},
		cc.MustNewCodeContainerFromFS(
			baseDir,
			[]string{codeFile},
		), // same, relative to current wd
		axe.WithTools([]clitool.Definition{
			clitool.MustNewDefinition(
				"run_test_js",
				fmt.Sprintf(
					"jagent --mock %s --local-sdkhub %s test.js",
					localJsonPath,
					localSdKhubPath,
				),
				"run test.js using 'jagent ./test.js'. The working directory must be the directory of the module, where the test.js is located.",
				nil,
			),
		}),
		axe.WithModel(axe.ModelGPT5),
		axe.WithSink(sink),
	)
	if err != nil {
		return fmt.Errorf("failed to run: %w", err)
	}
	err = runner.Run(context.Background(), false)
	if err != nil {
		return fmt.Errorf("failed to run: %w", err)
	}
	return nil
}
