package main

import (
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"sort"

	"github.com/alva-ai/sdkhub"
)

func main() {
	assetsRoot := flag.String("assets", "assets", "path to the assets directory")
	failOnMissing := flag.Bool(
		"fail-on-missing",
		false,
		"exit with status 1 when missing nodified functions are found",
	)
	flag.Parse()

	missing, err := sdkhub.CheckNodifiedCoverage(*assetsRoot)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		os.Exit(1)
	}

	if len(missing) == 0 {
		fmt.Printf("All exported SDK functions under %s have nodified counterparts.\n", *assetsRoot)
		return
	}

	grouped := make(map[string][]sdkhub.NodifiedMissing)
	for _, entry := range missing {
		grouped[entry.Module] = append(grouped[entry.Module], entry)
	}

	modules := make([]string, 0, len(grouped))
	for module := range grouped {
		modules = append(modules, module)
	}
	sort.Strings(modules)

	fmt.Printf("Found %d modules with missing nodified exports:\n", len(modules))
	for _, module := range modules {
		modulePath := filepath.ToSlash(filepath.Join(*assetsRoot, module))
		fmt.Printf("- %s\n", modulePath)
		entries := grouped[module]
		sort.Slice(entries, func(i, j int) bool {
			if entries[i].Original == entries[j].Original {
				return entries[i].Expected < entries[j].Expected
			}
			return entries[i].Original < entries[j].Original
		})
		for _, entry := range entries {
			fmt.Printf("    -> missing %s => expected %s\n", entry.Original, entry.Expected)
		}
	}

	if *failOnMissing {
		os.Exit(1)
	}
}
