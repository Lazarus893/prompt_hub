package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/rs/zerolog"
	"github.com/stumble/axe"
	cc "github.com/stumble/axe/code/container"
	clitool "github.com/stumble/axe/tools/cli"
)

const (
	codeFile        = "code.js"
	testFile        = "test.js"
	docFile         = "doc"
	docNodifiedFile = "doc_nodified"
)

var skipPrefixes = []string{
	"@alva/algorithm",
	"@alva/llm",
	"@alva/external",
	"@alva/jstat",
	"@alva/technical-indicators",
}

type Module struct {
	Dir  string
	Name string
}

func main() {
	var (
		model        string
		skipInterval time.Duration
		modulePrefix string
	)

	flag.StringVar(&model, "model", "gpt-5", "LLM model to use")
	flag.DurationVar(
		&skipInterval,
		"skip-interval",
		0,
		"skip modules updated within this interval (set 0 to disable)",
	)
	flag.StringVar(
		&modulePrefix,
		"module-prefix",
		"",
		"if set, only modules whose names start with this prefix will be processed",
	)
	flag.Parse()

	log.Printf(
		"Starting run (model=%s, skip-interval=%s, module-prefix=%q)",
		model,
		skipInterval,
		modulePrefix,
	)

	guideline, err := os.ReadFile("ai-code/code_review_nodified_sdk.md")
	if err != nil {
		log.Fatalf("read guideline: %v", err)
	}

	modules, err := discoverModules("assets")
	if err != nil {
		log.Fatalf("discover modules: %v", err)
	}
	log.Printf("Discovered %d module directories containing code.js", len(modules))

	if modulePrefix != "" {
		var filtered []Module
		for _, m := range modules {
			if strings.HasPrefix(m.Name, modulePrefix) {
				filtered = append(filtered, m)
			}
		}
		if len(filtered) == 0 {
			log.Printf("no modules matched prefix %q", modulePrefix)
			return
		}
		log.Printf("Filtered to %d modules by prefix %q", len(filtered), modulePrefix)
		modules = filtered
	}

	if len(modules) == 0 {
		log.Println("no modules with code.js found under assets")
		return
	}

	// Process modules with bounded concurrency (max 10 concurrent edits)
	sem := make(chan struct{}, 10)
	var wg sync.WaitGroup
	for _, module := range modules {
		sem <- struct{}{}
		wg.Add(1)
		m := module
		go func() {
			defer func() {
				wg.Done()
				<-sem
			}()
			log.Printf("Evaluating module %s (dir=%s)", m.Name, m.Dir)
			if err := editCode(m, string(guideline), skipInterval, io.Discard); err != nil {
				log.Printf("failed to edit code for %s: %v", m.Name, err)
				return
			}
			log.Printf("Completed update for %s", m.Name)
		}()
	}
	wg.Wait()
}

func discoverModules(root string) ([]Module, error) {
	var modules []Module

	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}

		rel, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}

		if rel != "." {
			for _, prefix := range skipPrefixes {
				if rel == prefix || strings.HasPrefix(rel, prefix+string(filepath.Separator)) {
					if d.IsDir() {
						log.Printf("Skipping directory %s (matched prefix %s)", path, prefix)
						return filepath.SkipDir
					}
					return nil
				}
			}
		}

		if !d.IsDir() {
			return nil
		}

		codePath := filepath.Join(path, "code.js")
		if _, err := os.Stat(codePath); errors.Is(err, os.ErrNotExist) {
			// code.js is the root file of the module
			return nil
		} else if err != nil {
			return err
		}
		modules = append(modules, Module{
			Dir:  path,
			Name: deriveName(rel),
		})
		return nil
	})
	if err != nil {
		return nil, err
	}
	return modules, nil
}

// convert the relative path to the module name, e.g. "@alva/data/crypto/meme:v1.0.0"
func deriveName(rel string) string {
	parts := strings.Split(rel, string(filepath.Separator))
	if len(parts) < 2 {
		return rel
	}
	return fmt.Sprintf("%s:%s", strings.Join(parts[:len(parts)-1], "/"), parts[len(parts)-1])
}

func editCode(module Module, instruction string, skipInterval time.Duration, sink io.Writer) error {
	zerolog.SetGlobalLevel(zerolog.InfoLevel)
	baseDir := module.Dir // relative to current working directory
	pwd, err := os.Getwd()
	if err != nil {
		return fmt.Errorf("failed to get current working directory: %w", err)
	}
	localJsonPath := filepath.Join(pwd, "local.json")
	localSdKhubPath := pwd
	runner, err := axe.NewRunner(
		baseDir,
		[]string{instruction},
		cc.MustNewCodeContainerFromFS(
			baseDir,
			[]string{codeFile, testFile, docFile, docNodifiedFile},
		), // same, relative to current wd
		axe.WithTools([]clitool.Definition{
			clitool.MustNewDefinition(
				"run_test_js",
				fmt.Sprintf(
					"jagent --mock %s --local-sdkhub %s test.js",
					localJsonPath,
					localSdKhubPath,
				),
				"run test.js using 'jagent ./test.js'. The working directory must be the directory of the module, where the test.js is located.",
				nil,
			),
		}),
		axe.WithModel(axe.ModelGPT5),
		axe.WithMinInterval(skipInterval),
		axe.WithSink(sink),
	)
	if err != nil {
		return fmt.Errorf("failed to run: %w", err)
	}
	err = runner.Run(context.Background(), false)
	if err != nil {
		return fmt.Errorf("failed to run: %w", err)
	}
	return nil
}
