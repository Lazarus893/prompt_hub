package sdkhub

// SDK is an instance that holds a SDK information.
type SDK struct {
	name string
	doc  string
	code string
	test string
}

// Name returns the name of the SDK.
func (s *SDK) Name() string {
	return s.name
}

// Doc returns the documentation of the SDK.
func (s *SDK) Doc() string {
	return s.doc
}

// Code returns the code of the SDK.
func (s *SDK) Code() string {
	return s.code
}

// Test returns the test script associated with the SDK, if any.
func (s *SDK) Test() string {
	return s.test
}
